import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";

export default defineConfig([
  ...nextVitals,
  ...nextTypescript,
  {
    rules: {
      "@next/next/no-html-link-for-pages": "off",
      "@typescript-eslint/consistent-type-imports": "error",
      "@typescript-eslint/no-explicit-any": "error",
      "@typescript-eslint/no-non-null-assertion": "error",
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
    },
  },
  {
    files: ["packages/modules/*/src/domain/**/*.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: [
                "@gestor/database",
                "@prisma/client",
                "next",
                "next/*",
                "**/application/**",
                "**/infrastructure/**",
              ],
              message: "Domain code must remain independent from application and infrastructure.",
            },
            {
              group: ["@gestor/*/src/**"],
              message: "Import another module only through its package exports.",
            },
          ],
        },
      ],
    },
  },
  {
    files: ["packages/modules/*/src/application/**/*.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: [
                "@gestor/database",
                "@prisma/client",
                "next",
                "next/*",
                "**/infrastructure/**",
              ],
              message:
                "Application code depends on ports, never on infrastructure implementations.",
            },
            {
              group: ["@gestor/*/src/**"],
              message: "Import another module only through its package exports.",
            },
          ],
        },
      ],
    },
  },
  {
    files: ["packages/modules/*/src/infrastructure/**/*.ts", "packages/modules/*/src/index.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["@gestor/*/src/**"],
              message: "Import another module only through its package exports.",
            },
          ],
        },
      ],
    },
  },
  {
    files: [
      "apps/web/src/features/**/components/**/*.{ts,tsx}",
      "apps/web/src/features/**/use-*.{ts,tsx}",
    ],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["node:*", "@gestor/database", "@prisma/client", "@/lib/server/**"],
              message:
                "Client-facing features must use HTTP contracts and cannot import server infrastructure.",
            },
          ],
        },
      ],
    },
  },
  globalIgnores([
    "**/.next/**",
    "**/coverage/**",
    "**/dist/**",
    "**/node_modules/**",
    "outputs/**",
    "work/**",
    "packages/database/src/generated/**",
  ]),
]);
