# Gestor SaaS

Fundação do sistema de gerenciamento multiempresa.

## Requisitos

- Node.js 24+
- pnpm 11+
- PostgreSQL 15+

## Início rápido

```powershell
Copy-Item .env.example .env
pnpm install
pnpm db:validate
pnpm db:migrate:deploy
pnpm dev
```

Autenticação local usa Better Auth com adaptador Prisma. O header `x-user-id`
existe somente como atalho explícito de desenvolvimento quando
`ALLOW_INSECURE_DEV_AUTH=true` e falha obrigatoriamente em produção.

## Primeiro administrador interno

Depois que o usuário proprietário concluir o cadastro, o primeiro acesso ao
painel interno é concedido fora da API:

```powershell
psql $env:DATABASE_URL -v "owner_email=dono@empresa.com" -f packages/database/prisma/roles/bootstrap_platform_owner.sql
```

Esse bootstrap exige uma conexão administrativa. Administradores de empresas
clientes não conseguem conceder a si próprios acesso interno.

## Documentação

- [`outputs/requisitos_sistema.md`](outputs/requisitos_sistema.md)
- [`outputs/arquitetura/README.md`](outputs/arquitetura/README.md)
- [`outputs/modelo-dados/README.md`](outputs/modelo-dados/README.md)
