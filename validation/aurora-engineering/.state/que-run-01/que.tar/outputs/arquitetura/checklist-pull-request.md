# Checklist de pull request

Use somente os itens aplicáveis. Um item crítico não pode ser marcado sem teste
ou evidência correspondente.

## Contrato e escopo

- [ ] A mudança atende a um requisito ou decisão registrada.
- [ ] Não inclui funcionalidade futura fora do escopo.
- [ ] Contrato HTTP/evento foi atualizado quando necessário.
- [ ] Compatibilidade com clientes/consumers anteriores foi preservada.

## Arquitetura

- [ ] Regra de negócio está em domain/application, não na rota ou consumer.
- [ ] Dependências respeitam os boundaries do módulo.
- [ ] Nenhum módulo importou infraestrutura interna de outro.
- [ ] Não foi criada abstração genérica sem necessidade concreta.
- [ ] Adapter novo de infraestrutura possui teste `.spec.ts` pareado.
- [ ] Arquivo novo respeita o limite de 400 linhas (`.ts`) ou 350 linhas (`.tsx`).
- [ ] Arquivo legado acima do limite não cresceu; a alteração reduz ou mantém sua dívida.

## Tenant e segurança

- [ ] Organização vem de identidade/membership validada.
- [ ] Operação usa transação com contexto RLS.
- [ ] Escopo de filial foi aplicado.
- [ ] Permissão foi verificada no servidor.
- [ ] Autorização usa permissão, não comparação com nome do papel.
- [ ] Ownership (`own`/`all`) foi aplicado quando necessário.
- [ ] Entrada externa foi validada.
- [ ] Rate limit foi considerado.
- [ ] Logs, erros e auditoria não vazam PII ou segredos.

## Plano e limites

- [ ] Recurso consulta `FeatureCode`/entitlement, não nome Básico/Pro/Premium.
- [ ] Entitlement foi validado no caso de uso.
- [ ] Módulo opcional valida `OrganizationModule`; segmento não é usado como
      autorização.
- [ ] Alteração comercial usa `PlatformActorContext`; permissão do tenant não
      concede acesso ao painel interno.
- [ ] Mudança de módulo valida `expected_version`, dependências, obrigações,
      histórico, auditoria e Outbox na mesma transação.
- [ ] Plano/add-on, módulo da organização e permissão permanecem verificações
      independentes.
- [ ] Worker/consumer/webhook do módulo reavalia o acesso antes do efeito.
- [ ] Dependências do módulo foram validadas sem habilitação silenciosa.
- [ ] Limite foi revalidado dentro da transação.
- [ ] Concorrência não permite ultrapassar a cota.
- [ ] Downgrade mantém dados em leitura/exportação quando exigido.
- [ ] Worker reavalia plano sem interromper obrigação financeira/fiscal existente.
- [ ] Frontend não é a autoridade para bloquear recurso do plano.

## Importação inteligente

- [ ] Arquivo passou por quarentena, MIME/tamanho e malware antes do OCR.
- [ ] Provedor de OCR está atrás de port e não recebe acesso ao banco/ferramentas.
- [ ] Texto do documento é tratado como dado não confiável.
- [ ] Saída do provedor usa schema fechado e Zod.
- [ ] Prévia preserva valor extraído, corrigido e confiança.
- [ ] Nenhuma linha é confirmada sem ação humana.
- [ ] Modo histórico não gera estoque, conta, caixa, banco ou fiscal.
- [ ] Modo operacional reutiliza os casos de uso normais.
- [ ] Lote e linha possuem idempotência e detecção de duplicidade.

## WhatsApp e Instagram

- [ ] Integração usa API oficial; não há scraping ou sessão web simulada.
- [ ] OAuth/callback valida `state`; tokens ficam no secret manager.
- [ ] Webhook valida assinatura sobre bytes brutos e deduplica ID externo.
- [ ] Consentimento, descadastro, frequência, template/janela e módulo são
      reavaliados no envio.
- [ ] Instagram não oferece disparo de DM fria.
- [ ] Rate limit usa backoff e DLQ; estado tardio não regride entrega/leitura.
- [ ] Logs não contêm token nem conteúdo integral desnecessário.

## Banco e transação

- [ ] Prisma global não foi usado dentro de operação de tenant.
- [ ] Integração externa não ocorre dentro da transação.
- [ ] Queries possuem `select` e limites adequados.
- [ ] Concorrência foi considerada.
- [ ] Estratégia está na matriz de concorrência do padrão de código.
- [ ] Transição sem `version` usa update condicional pelo estado atual.
- [ ] Idempotência foi considerada.
- [ ] Ledger, auditoria e outbox são gravados quando aplicável.
- [ ] Migration foi criada sem alterar migrations já aplicadas.
- [ ] RLS e relações entre organizações foram testadas.

## Assíncrono

- [ ] Evento tem nome de fato passado e schema versionado.
- [ ] Producer usa outbox.
- [ ] Consumer registra `ProcessedEvent` na transação do efeito.
- [ ] Offset só é confirmado depois do commit.
- [ ] Retry e DLQ não duplicam efeito.
- [ ] Workflow Temporal permanece determinístico.

## Qualidade

- [ ] Typecheck, lint e format passaram.
- [ ] `pnpm architecture:check` passou.
- [ ] Cobertura global do backend não caiu abaixo da linha de base versionada.
- [ ] Cobertura do frontend foi avaliada separadamente; ela não é inferida da cobertura backend.
- [ ] Testes de sucesso e falha foram adicionados.
- [ ] Falta de permissão e outro tenant foram testados.
- [ ] Idempotência e concorrência foram testadas quando aplicáveis.
- [ ] Estados de loading, vazio, erro e sucesso existem na interface.
- [ ] Primitive reutilizável usa `packages/ui`/shadcn; regra específica permanece
      na feature.
- [ ] Componente shadcn alterado foi revisado por diff, teclado, foco e contraste.
- [ ] Métricas e alertas foram adicionados para processo crítico.

## Interface operacional

- [ ] O fluxo identifica proprietário/configurador, gestor/consulta e operador/atendimento.
- [ ] A próxima ação é visível em celular e tablet sem depender de hover ou precisão de mouse.
- [ ] Quantidades, valores, estados e erros usam linguagem do trabalho, sem precisão técnica dispensável.
- [ ] Cenário feliz, erro de validação e conflito concorrente foram exercitados quando aplicáveis.
