# Conectores necessários para homologação

Conectar somente contas, projetos e chaves de **teste/homologação**. Nenhum
conector precisa receber credenciais de produção.

| Conector         | Acesso mínimo necessário                                   | Uso nesta etapa                                                                   |
| ---------------- | ---------------------------------------------------------- | --------------------------------------------------------------------------------- |
| **Vercel**       | projeto `que-homologation`, variáveis e deploys            | cadastrar segredos server-side, publicar a branch e consultar logs/deploys        |
| **Supabase**     | projeto `uoimwzuhisaujzmknxjc`, SQL, Storage, Vault e Cron | migrations, bucket privado, Vault, `pg_cron`, `pg_net` e ensaio de restauração    |
| **Resend**       | domínio/remetente de homologação e API keys de teste       | validar envio transacional e auditoria de e-mail                                  |
| **Stripe**       | conta de teste, Checkout, webhooks e chaves de teste       | criar chave `sk_test_`, endpoint webhook e executar Checkout/estorno de teste     |
| **Mercado Pago** | aplicação e credenciais de teste, Point sandbox e Webhooks | criar token de teste, terminal Point de teste, webhook e simular cobrança/estorno |
| **GitHub**       | environment `homologation`, Actions e secrets/variables    | preencher o gate remoto e executar o workflow manual                              |
| **Google Cloud** | cliente OAuth Web exclusivo de homologação                 | redirects, consentimento e smoke do login social                                  |

## Segredos e valores que serão criados ou cadastrados

- Vercel: `PAYMENT_PROVIDER_CREDENTIALS_JSON`, somente para o runtime e sem
  prefixo `NEXT_PUBLIC_`.
- Mercado Pago: `accessToken` e `webhookSecret` de teste, associados ao UUID da
  organização técnica no JSON acima.
- Stripe: `sk_test_*`, `whsec_*` e `pixEnabled: false`. Esse campo só muda para
  `true` se a conta de teste receber habilitação explícita para Pix.
- GitHub: cópia do JSON apenas como secret do environment `homologation`, caso o
  gate remoto passe a executar o ensaio de pagamentos.

## Sequência após conectar

1. Criar as credenciais de teste nos dois provedores e registrá-las no cofre da Vercel.
2. Criar uma organização, filial, venda concluída e recebível em aberto técnicos.
3. Configurar os endpoints versionados de webhook descritos em
   [`operacao-homologacao.md`](operacao-homologacao.md).
4. Executar cartão e QR Pix no Point sandbox; executar Checkout e estorno no Stripe.
5. Conferir no sistema a confirmação assinada, o lançamento financeiro, a reversão
   idempotente e os eventos de auditoria.
6. Rodar o workflow GitHub `Homologation gate` e anexar a evidência ao status de liberação.
