# Arquitetura

Ordem de leitura:

1. [`padroes-de-codigo.md`](padroes-de-codigo.md): padrão normativo de implementação;
2. [`checklist-pull-request.md`](checklist-pull-request.md): verificação diária;
3. [`decisoes/ADR-001-monolito-modular.md`](decisoes/ADR-001-monolito-modular.md): decisão estrutural inicial;
4. [`decisoes/ADR-002-autenticacao-supabase.md`](decisoes/ADR-002-autenticacao-supabase.md):
   decisão de autenticação substituída antes da implementação;
5. [`decisoes/ADR-003-autenticacao-local-better-auth.md`](decisoes/ADR-003-autenticacao-local-better-auth.md):
   autenticação local, sessões de banco, Prisma e MFA;
6. [`../modelo-dados/README.md`](../modelo-dados/README.md): banco, migrations e RLS;
7. [`operacao-homologacao.md`](operacao-homologacao.md): health, readiness, métricas e ensaio de backup/restauração;
8. [`conectores-homologacao.md`](conectores-homologacao.md): acessos mínimos e sequência para concluir a homologação remota;
9. [`status-liberacao.md`](status-liberacao.md): gates e percentuais independentes de homologação e Plano Básico;
10. [`rollback-homologacao.md`](rollback-homologacao.md): publicação, rollback forward-only e resposta a falhas;
11. [`integracao-nfse-nacional.md`](integracao-nfse-nacional.md): emissão e cancelamento diretos no Portal Nacional da NFS-e;
12. [`integracao-fiscal-http.md`](integracao-fiscal-http.md): contrato neutro alternativo para um emissor fiscal remoto homologado;
13. [`../requisitos_sistema.md`](../requisitos_sistema.md): requisitos funcionais e não funcionais.
14. [`iteracoes/README.md`](iteracoes/README.md): registro obrigatório de cada iteração.
15. [`dependencias-externas-homologacao.md`](dependencias-externas-homologacao.md): pendências de provedores e infraestrutura para a homologação remota.
16. [`modulo-operacao-alimentacao.md`](modulo-operacao-alimentacao.md): fronteiras, estados e entregas do módulo opcional de restaurantes e delivery.

Referência informativa de produto:

- [`../pesquisa-mercado/trustmrr-solucoes-comparaveis.md`](../pesquisa-mercado/trustmrr-solucoes-comparaveis.md):
  soluções comparáveis, evidências de tração e diretrizes de posicionamento.

Em caso de conflito, requisitos definem a intenção do produto, ADRs registram
decisões estruturais e os padrões de código definem a forma de implementação.
