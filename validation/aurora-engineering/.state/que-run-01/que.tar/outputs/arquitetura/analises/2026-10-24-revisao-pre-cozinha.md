# Revisão pré-cozinha — comandas, concorrência e fronteiras

**Data:** 24 de outubro de 2026
**Escopo:** sessão de mesa, pedido de comanda e aceite, antes de estações e tickets de cozinha.

## Resultado

A separação entre mesa, pedido, catálogo, estoque, financeiro e produção está correta. A cozinha deve ser acrescentada como projeção operacional do pedido aceito, sem transformar ticket em venda, pagamento ou baixa de estoque.

Há três correções mandatórias para concluir antes de liberar o uso operacional de tickets. Elas não exigem uma mudança de produto visível, mas protegem dados e evitam que um pedido seja preparado ou cobrado de forma incorreta.

## Portões obrigatórios

### 1. Um rascunho ativo por sessão de mesa

Hoje a criação do pedido valida que a sessão está aberta, mas o banco não garante que ela tenha somente um pedido em `DRAFT` ou `ACCEPTED`. Dois atendentes podem iniciar pedidos simultaneamente para a mesma mesa e obter comandas distintas.

A migração do bloco de pedidos deve criar uma restrição parcial única para os estados ativos por `table_session_id` (ao menos `DRAFT` e `ACCEPTED`). O comando de criação deve ser idempotente: se o mesmo operador repetir a ação por falha de rede, retorna o pedido existente; se houver disputa, não cria uma segunda comanda.

### 2. Resolver preço pela regra central de catálogo

A inclusão de item atualmente consulta uma tabela de preço ativa da filial diretamente. A regra consolidada de catálogo também considera início e fim de vigência e ordena por vigência mais recente. A cozinha não deve perpetuar uma segunda interpretação de preço.

Antes da primeira cobrança, o adaptador de comanda deve usar o mesmo resolvedor de preço por filial do catálogo, no mesmo instante transacional em que fotografa o item. A fotografia de nome, unidade e preço continua sendo a fonte histórica do pedido.

### 3. Cancelamento seguro da sessão

Uma sessão de mesa aberta pode hoje ser cancelada sem verificar se possui pedido aceito. Isso pode liberar a mesa enquanto uma produção já está em andamento, deixando ticket e atendimento sem uma origem operacional válida.

O cancelamento deve falhar quando existir pedido `ACCEPTED`, ticket em fila, em preparo ou pronto, ou qualquer pagamento associado no futuro. O fluxo correto será cancelar ou estornar o pedido conforme suas regras, e somente então encerrar/liberar a mesa. O bloqueio precisa existir na persistência, não apenas na interface.

## Regras para tickets de cozinha

- A transição `DRAFT → ACCEPTED` e a criação dos tickets devem ocorrer na mesma transação. Se o aceite falhar, nenhum ticket pode existir; se o cliente repetir a requisição, nenhum ticket duplicado pode ser criado.
- O banco deve guardar a origem de cada ticket em item de pedido e estação, com restrição única de idempotência adequada ao modelo de divisão de preparo.
- Ticket e item devem carregar fotografias suficientes para a produção: descrição, quantidade, observação, ordem, horário do aceite e estimativa. A cozinha não deve depender de leitura posterior do catálogo.
- A fila deve ser isolada por organização e filial; uma estação só pode receber itens configurados para sua filial. Toda transição de estado deve validar o escopo do operador.
- Os estados mínimos são `QUEUED`, `PREPARING`, `READY`, `CANCELLED`; cada transição deve ser controlada por versão ou atualização condicional para impedir duas telas de concluir o mesmo ticket.
- Reenvio após mudança de item não pode ser implícito. Enquanto o pedido estiver aceito, alterações exigem um comando explícito de correção e geram novo evento/ticket, preservando o histórico do que a cozinha já recebeu.

## Efeitos fora de escopo do ticket

Gerar, iniciar ou concluir um ticket não cria venda, recebível, cobrança, documento fiscal, movimento de caixa ou baixa de estoque. Esses efeitos permanecem em seus módulos e serão disparados somente pelos eventos explicitamente definidos nas configurações da empresa.

## Cenários de validação exigidos

1. Dois atendentes tentam iniciar uma comanda na mesma mesa ao mesmo tempo: somente uma comanda ativa permanece.
2. Dois atendentes alteram o mesmo rascunho: um comando vence e o outro recebe conflito de versão sem perder item.
3. Tabela de preço vencida não é escolhida; a mais recente vigente é fotografada.
4. Aceite repetido por reenvio de rede cria somente um conjunto de tickets.
5. Usuário de outra filial não visualiza nem altera a fila, tickets ou pedidos da filial restrita.
6. Tentativa de cancelar mesa com produção ativa falha com uma mensagem orientando o encerramento/cancelamento do pedido.
7. Falha ao criar ticket reverte o aceite; não existe pedido aceito sem a projeção de produção exigida pela configuração.

## Decisão de sequência

As estações e tickets podem ser desenvolvidos em paralelo, mas a migração e o comando de aceite devem incorporar os três portões acima antes da publicação do bloco de cozinha. A baixa de estoque só entra depois de validar os tickets visualmente e de forma concorrente.
