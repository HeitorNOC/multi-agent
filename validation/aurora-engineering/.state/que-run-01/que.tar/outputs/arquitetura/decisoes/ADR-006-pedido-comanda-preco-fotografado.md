# ADR-006 — Pedido de comanda com preço fotografado

**Status:** Aceita  
**Data:** 24 de outubro de 2026

## Decisão

O pedido de alimentação nasce como `DRAFT`, vinculado a uma sessão de mesa aberta e à mesma filial. Cada item registra produto, descrição, unidade, preço unitário, quantidade e total fotografados.

O preço é resolvido usando a tabela de preço ativa da filial no instante da inclusão do item; sem tabela aplicável, usa-se o preço padrão ativo do produto. Uma alteração posterior no catálogo não modifica pedidos existentes.

Cada alteração exigirá a versão atual do pedido. O comando atualizará somente se essa versão ainda for válida e então incrementará a versão, impedindo que duas telas sobrescrevam itens sem aviso.

## Consequências

- Estoque, cobrança, fiscal e cozinha permanecem sem efeito enquanto o pedido é rascunho.
- Somente um comando futuro de aceite poderá enviar itens à produção e disparar efeitos configuráveis.
- O pedido interno não será exposto ao portal do cliente; uma projeção pública específica será criada para canais externos.
