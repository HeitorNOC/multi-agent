# ADR-003 — Autenticação local com Better Auth e Prisma

- Status: aceito — implementação base validada
- Data: 2026-07-28
- Substitui: ADR-002
- Requisito principal: RF-01 — Conta, autenticação e acesso

## Contexto

O sistema precisa oferecer e-mail e senha, confirmação de e-mail, recuperação de
senha, convites, revogação de sessões e MFA para administradores e usuários com
acesso financeiro ou bancário.

O ADR-002 escolheu Supabase Auth para reduzir a responsabilidade operacional de
segurança. Essa solução, porém, adicionaria um domínio de falha: a aplicação e o
PostgreSQL poderiam estar saudáveis enquanto uma indisponibilidade do serviço de
autenticação impediria novos logins e renovação de sessões.

Isso viola a restrição de disponibilidade definida para o produto. A
autenticação deve acompanhar a disponibilidade do núcleo da aplicação, sem
depender de um serviço remoto adicional para login ou validação de sessão.

Disponibilidade absoluta não pode ser garantida por nenhuma arquitetura. A
decisão abaixo elimina especificamente a dependência do Supabase Auth: se o
processo web ou o banco principal estiver indisponível, o restante do sistema já
estará indisponível; autenticação não introduzirá um terceiro ponto necessário.

## Decisão

Usar **Better Auth** dentro do processo Next.js, com:

- integração oficial com Next.js;
- Prisma Adapter;
- sessões persistidas no mesmo PostgreSQL da aplicação;
- autenticação por e-mail e senha;
- autenticação social opcional com Google;
- verificação de e-mail e recuperação de senha;
- plugin oficial de dois fatores;
- Resend para envio dos e-mails;
- autorização multiempresa mantida nos módulos da aplicação.

Better Auth responde por credenciais e sessões. Membership, papel, permissão,
organização, filial, ownership, entitlement e estado do recurso continuam sendo
responsabilidade do sistema.

### Disponibilidade

- Login por e-mail e senha, validação e renovação de sessão não chamarão provedor
  de autenticação externo. Somente o fluxo explicitamente iniciado com Google
  dependerá do Google durante a autenticação.
- Usuários, contas, sessões, verificações e fatores serão persistidos no mesmo
  cluster PostgreSQL usado pelo backend.
- Múltiplas réplicas do processo web poderão atender autenticação porque não
  manterão sessão em memória local.
- Alta disponibilidade real dependerá do balanceador, das réplicas web e da
  topologia de alta disponibilidade do PostgreSQL.
- Indisponibilidade do Resend não impedirá login de usuário já verificado; ela
  afetará somente operações que necessitem de novo e-mail, como confirmação,
  convite e recuperação.
- Falhas de dependências opcionais, como Kafka e Temporal, não bloquearão login.
- Credenciais Google ausentes ou indisponibilidade do provedor não bloquearão o
  login por e-mail e senha.
- A autenticação falhará de modo fechado quando não puder validar a sessão.

Não será criado um “login de emergência” que ignore senha, MFA ou banco. Um
fallback desse tipo aumentaria o risco de invasão e inconsistência.

### Modelo de dados

`User.id` será o identificador usado simultaneamente pelo Better Auth e pelo
domínio da aplicação. As tabelas de autenticação serão mantidas no schema
Prisma definitivo:

- `User`: identidade e perfil mínimo;
- `AuthAccount`: credencial ou conta vinculada;
- `AuthSession`: sessão revogável;
- `AuthVerification`: tokens de verificação e recuperação;
- `AuthTwoFactor`: segredo TOTP, backup codes e estado de verificação;
- `AuthRateLimit`: contadores atômicos e compartilhados entre instâncias.

Regras:

- senha não será armazenada em `User`;
- credencial será armazenada pelo Better Auth em `AuthAccount`;
- `password_hash` atual será removido de `users`;
- relações de negócio continuarão apontando para `User.id`;
- migration será escrita e revisada no fluxo Prisma do projeto;
- o CLI do Better Auth poderá gerar schema de referência, mas não aplicará
  migrations diretamente em produção;
- tabelas de autenticação não receberão `organization_id`, pois identidade e
  sessão existem antes da seleção da organização;
- autorização de tenant começará somente depois de resolver sessão e usuário.

### Senhas

- O hash padrão será `scrypt`, fornecido pelo Better Auth.
- Comprimento mínimo, máximo, política de força e proteção contra senhas
  comprometidas serão configurados explicitamente.
- Recuperação de senha revogará as demais sessões do usuário.
- Alteração autenticada exigirá a senha atual e poderá revogar outras sessões.
- Senha, hash, token de recuperação e credenciais nunca serão registrados em
  logs, auditoria ou eventos.
- Respostas de cadastro e recuperação não revelarão a existência do e-mail.

Trocar o algoritmo de hash exige migration progressiva: o sistema verifica o
formato antigo e regrava com o algoritmo atual após login válido. Não haverá
rehash em massa com acesso à senha em texto.

### Sessões

- Sessões serão opacas, persistidas no PostgreSQL e referenciadas por cookie
  seguro.
- A aplicação validará a sessão no servidor em toda página, Route Handler ou
  ação protegida.
- Verificar somente a existência do cookie será permitido para redirecionamento
  otimista, nunca para autorização.
- Cookie usará `HttpOnly`, `Secure` em produção, `SameSite=Lax`, escopo de path
  mínimo aplicável e nome próprio do produto.
- Logout revogará a sessão corrente.
- O usuário poderá listar e revogar sessões individuais, demais sessões ou todas
  as sessões.
- Mudança ou recuperação de senha poderá invalidar todas as outras sessões.
- Cache de sessão em cookie ficará desabilitado inicialmente para que bloqueio e
  revogação tenham efeito na próxima validação no servidor.
- Expiração absoluta e por inatividade serão definidas por configuração e
  testadas.
- IP e user-agent serão armazenados com minimização e retenção definida.

### MFA

Usar o plugin oficial de dois fatores com TOTP:

- enrollment exige sessão válida e confirmação da senha para contas com
  credencial;
- o fator só é ativado após a primeira verificação correta;
- backup codes serão apresentados uma única vez e armazenados de forma segura;
- tentativas consecutivas inválidas causarão bloqueio temporário;
- administradores e usuários com permissões financeiras ou bancárias serão
  obrigados a concluir o segundo fator;
- a obrigação será verificada pelo backend depois de resolver membership e
  permissões;
- dispositivo confiável não será habilitado na primeira versão;
- desativar ou substituir MFA exigirá reautenticação e será auditado.

O frontend orienta enrollment e challenge, mas não decide se o segundo fator é
obrigatório.

### E-mails

Resend enviará:

- confirmação de e-mail;
- recuperação de senha;
- convite de usuário;
- aviso de alteração de senha;
- aviso de mudança de e-mail;
- alerta de ação sensível quando aplicável.

Os callbacks recebem URLs construídas no servidor a partir de uma origem
permitida. O navegador não poderá fornecer redirect arbitrário.

O envio não será aguardado de modo que diferenças de tempo revelem se uma conta
existe. Falha e retentativa serão observáveis sem registrar token ou endereço
completo desnecessariamente.

### Login com Google

- O Google será configurado como provedor OAuth opcional do Better Auth; não
  haverá segundo mecanismo de sessão.
- O login social criará a mesma sessão persistida e o mesmo `User.id` usados pelo
  restante da aplicação.
- Vinculação implícita por e-mail será aceita somente quando o Google declarar o
  e-mail verificado. O Google não será incluído em uma lista que force confiança.
- Contas com e-mails diferentes não serão vinculadas automaticamente.
- Access token, refresh token e ID token OAuth serão criptografados antes da
  persistência pelo Better Auth.
- O sistema não solicitará escopos de Gmail, Drive ou perfil além do mínimo
  necessário para autenticação.
- `returnTo` será limitado a caminho local; destinos externos, caminhos com barra
  invertida e URLs iniciadas por `//` serão descartados.
- A tela apresentará erro neutro e permitirá continuar com e-mail e senha quando
  o usuário cancelar ou o provedor falhar.

### Convites e provisionamento

- Convite será criado somente por usuário autorizado.
- Token de convite será de uso único, terá expiração e não conterá permissão
  confiável no próprio payload.
- A permissão e a organização do convite serão consultadas no banco durante a
  aceitação.
- Aceitação repetida será idempotente.
- Autocadastro provisionará usuário, organização, filial matriz, membership
  administrativa, trial e onboarding por caso de uso idempotente.
- Usuário autenticado sem provisionamento completo ficará no fluxo de reparo e
  não acessará dados de negócio.

### Termos e privacidade

O banco da aplicação terá documentos legais versionados e aceitações append-only
por usuário, contendo versão, data, IP, user-agent e origem.

O `Consent` existente permanece exclusivo para consentimento de marketing de
clientes e não será reutilizado.

### Auditoria e rate limit

- Login bem-sucedido, logout, recuperação concluída, convite aceito, enrollment,
  challenge, remoção de MFA, bloqueio e revogação serão auditáveis.
- Falha de login será registrada em estrutura de segurança própria, inclusive
  quando não houver usuário interno identificável.
- Rate limit será aplicado por IP e identificador normalizado, sem usar o e-mail
  puro como chave observável.
- Mensagens públicas serão neutras para impedir enumeração.
- Logs redigirão senha, hash, cookie, token, backup code e segredo TOTP.

## Por que Better Auth, e não Auth.js com Credentials

Auth.js é adequado para OAuth, magic links e integração com provedores. Seu
Credentials Provider entrega controle para autenticar contra um sistema de
credenciais existente; a própria documentação recomenda soluções testadas em
vez de reconstruir gerenciamento de senha e proteção contra abuso.

Better Auth foi escolhido porque fornece no mesmo runtime:

- e-mail e senha;
- verificação e recuperação;
- sessões de banco revogáveis;
- Prisma Adapter;
- plugin TOTP com backup codes e bloqueio;
- integração atual com Next.js 16.

O Prisma Adapter não é um mecanismo de autenticação sozinho. Ele apenas conecta
o mecanismo selecionado ao banco.

## Alternativas consideradas

### Supabase Auth hospedado

Substituído porque sua indisponibilidade poderia impedir login e refresh enquanto
web e banco da aplicação permanecessem disponíveis.

### Supabase Auth self-hosted

Eliminaria o fornecedor hospedado, mas adicionaria outro serviço, deploy,
monitoramento e banco/schema operacional. Não oferece vantagem suficiente sobre
executar Better Auth dentro do monólito.

### Auth.js com Prisma Adapter

É uma alternativa válida para OAuth e sessões, mas o fluxo de credenciais deixa
mais componentes de senha, recuperação e MFA sob implementação própria ou
dependências adicionais.

### Autenticação totalmente própria

Descartada. Mesmo sendo executada no monólito, exigiria criar protocolos,
persistência, cookies, rotação, recuperação e MFA que já são fornecidos por uma
biblioteca especializada.

### Serviço externo com fallback local

Descartado. Sincronizar hashes, fatores, sessões e revogações entre dois
mecanismos cria inconsistência e uma superfície crítica de ataque. Fallback não
pode significar bypass.

## Consequências

Vantagens:

- autenticação acompanha a disponibilidade do web e PostgreSQL;
- nenhum serviço remoto adicional é necessário para login e sessão;
- sessões podem ser revogadas imediatamente no banco;
- MFA, recuperação e verificação permanecem cobertos;
- dados e migrations continuam sob o fluxo Prisma existente;
- menor lock-in de infraestrutura.

Custos e riscos:

- a equipe passa a operar tabelas, índices e retenção da autenticação;
- carga de validação de sessão atinge o PostgreSQL;
- segurança depende da atualização contínua da biblioteca;
- configuração incorreta de cookie, e-mail ou rate limit permanece risco da
  aplicação;
- incidentes no banco afetam simultaneamente autenticação e operação, o que é
  deliberado para não criar consistência parcial.

## Critérios de aceite da implementação

- login e validação de sessão funcionam sem acesso ao Supabase Auth;
- indisponibilidade de Resend não derruba login de usuário verificado;
- cadastro, confirmação, recuperação e convite não permitem enumeração;
- sessão revogada deixa de ser aceita na próxima validação;
- mudança de senha pode revogar as demais sessões;
- MFA TOTP e backup code são testados;
- bloqueio por tentativas inválidas é testado;
- sessão sem usuário ativo não acessa Prisma de negócio;
- membership e escopo de filial continuam obrigatórios;
- segredos não aparecem em logs;
- banco vazio recebe as migrations de autenticação pelo fluxo Prisma;
- múltiplas instâncias web compartilham sessões sem estado em memória.

## Plano de reversão

O módulo de identidade continuará expondo `IdentityProvider`. Para trocar o
mecanismo:

1. adicionar um novo adaptador;
2. criar vínculo verificado entre identidade nova e `User.id`;
3. migrar credenciais quando tecnicamente seguro ou exigir redefinição de senha;
4. manter sessões antigas até expiração controlada;
5. remover tabelas e adaptador antigos somente após a transição.

Memberships, papéis, permissões e relações de negócio permanecem vinculados ao
mesmo `User.id`.

## Resultado do spike técnico

Implementado em 2026-07-28:

- Better Auth 1.6.25 com Prisma Adapter e IDs UUID;
- login e cadastro com Google pelo mesmo runtime Better Auth, com vinculação
  restrita a e-mail verificado e tokens OAuth criptografados;
- modelos Prisma compatíveis com o schema efetivo da biblioteca;
- senha migrada de `users.password_hash` para `auth_accounts.password`;
- sessões opacas no PostgreSQL, sem cache de sessão em cookie;
- revogação das demais sessões após recuperação de senha;
- MFA TOTP com backup codes e bloqueio de tentativas consecutivas;
- rate limit compartilhado no PostgreSQL;
- papel de grupo `app_auth`, sem login e sem `BYPASSRLS`;
- RLS separando autenticação global das transações multiempresa;
- políticas de `users` direcionadas por papel para impedir que o serviço de
  autenticação avalie ou consulte memberships;
- rota Next.js `/api/auth/[...all]`;
- `IdentityProvider` de produção que rejeita sessão ausente e usuário inativo;
- Resend carregado somente nas operações de e-mail;
- cliente web Better Auth isolado em `@gestor/auth/client`, sem importar código
  de servidor no bundle do navegador;
- telas responsivas de login, cadastro, confirmação de e-mail, recuperação e
  redefinição de senha;
- formulários com React Hook Form, contratos Zod e os mesmos limites de senha
  usados pelo servidor;
- mensagens neutras na recuperação de senha e tradução somente de erros seguros,
  sem expor detalhes internos;
- e-mail pendente mantido somente no armazenamento de sessão do navegador, sem
  dado pessoal na URL de confirmação;
- estados de envio, sucesso, erro, reenvio de confirmação e link expirado;
- build de produção, TypeScript, lint e testes unitários aprovados.

O contrato gerado pelo Better Auth foi comparado com o schema Prisma e confirmou
os seis modelos e todos os campos esperados.

As cinco migrations foram aplicadas do zero em PostgreSQL local. O teste de
integração comprovou:

- cadastro e confirmação de e-mail;
- login de usuário verificado durante indisponibilidade simulada do emissor de
  e-mail;
- criação e leitura da sessão persistida;
- remoção da sessão no logout;
- rejeição imediata do cookie da sessão revogada;
- sincronização atômica de `email_verified_at`;
- acesso de `app_auth` somente a `users` e `auth_*`;
- rejeição de `app_auth` nas tabelas empresariais;
- rejeição de `app_runtime` nas tabelas de autenticação.

A interface foi percorrida em navegador local nos layouts desktop e móvel. Foram
confirmados:

- navegação entre os cinco fluxos;
- associação acessível entre labels, campos, erros e botões;
- validação de campos obrigatórios e de confirmação de senha;
- ausência de rolagem horizontal em viewport de 390 px;
- ausência de erros ou avisos no console durante a navegação.

## Referências

- [Better Auth — integração com Next.js](https://better-auth.com/docs/integrations/next)
- [Better Auth — Prisma Adapter](https://better-auth.com/docs/adapters/prisma)
- [Better Auth — e-mail e senha](https://better-auth.com/docs/authentication/email-password)
- [Better Auth — gerenciamento de sessões](https://better-auth.com/docs/concepts/session-management)
- [Better Auth — plugin de dois fatores](https://better-auth.com/docs/plugins/2fa)
- [Better Auth — segurança](https://better-auth.com/docs/reference/security)
- [Auth.js — Credentials Provider](https://authjs.dev/getting-started/providers/credentials)
