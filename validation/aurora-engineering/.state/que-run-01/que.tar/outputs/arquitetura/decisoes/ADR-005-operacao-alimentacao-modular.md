# ADR-005 — Operação de alimentação como módulo especializado

**Status:** Aceita  
**Data:** 24 de outubro de 2026

## Contexto

O catálogo público já permite vitrine, carrinho, pedido, retirada, entrega própria
e entrega combinada. Esse fluxo atende lojas e negócios de serviço, mas não
representa corretamente uma operação de alimentação: mesa, comanda, produção,
prioridade de cozinha e despacho são conceitos próprios, com ritmos, permissões e
efeitos de estoque diferentes.

Reaproveitar `CustomerPortalOrder` como comanda, ou transformar cada pedido de
restaurante diretamente em uma venda, misturaria atendimento, produção, logística,
pagamento e fiscal. Também reduziria a segurança: clientes não podem enxergar a
fila da cozinha, outras mesas, custos, margem, estoque ou ações internas.

## Decisão

1. Criar o módulo de produto opcional `food_service`, com dependências de
   `catalog`, `sales` e `financial`; `inventory` será exigido somente quando a
   empresa optar por baixa de insumos.
2. Manter `CustomerPortalOrder` como pedido comercial público. O módulo de
   alimentação terá seu próprio agregado `FoodServiceOrder`, capaz de referenciar
   um pedido público quando o canal for cardápio digital, sem compartilhar estado
   nem permitir acesso reverso ao contexto interno.
3. Separar os ciclos de vida:
   - pedido comercial e pagamento;
   - produção de cozinha;
   - atendimento em salão/mesa;
   - entrega ou retirada;
   - conversão financeira e fiscal.
4. A configuração é por empresa, com sobrescritas por filial e canal. Nenhuma
   modalidade de atendimento é presumida pelo segmento informado no onboarding.
5. O portal do cliente é uma projeção pública própria: mostra somente seu pedido,
   valores e eventos autorizados. Equipe usa UI interna e permissões próprias.

## Estados iniciais

`FoodServiceOrder`: `DRAFT`, `SUBMITTED`, `ACCEPTED`, `IN_PREPARATION`,
`READY`, `FULFILLED`, `CANCELLED`.

`KitchenTicket`: `QUEUED`, `IN_PREPARATION`, `READY`, `SERVED`, `CANCELLED`.

`TableSession`: `OPEN`, `PAYMENT_PENDING`, `CLOSED`, `CANCELLED`.

`FoodServiceDelivery`: `PENDING`, `DISPATCHED`, `DELIVERED`, `ISSUE_REPORTED`,
`CANCELLED`.

Uma transição guarda versão otimista e publica auditoria/outbox na mesma
transação. Repetir uma solicitação idempotente não duplica ticket, consumo,
cobrança ou aviso.

## Consequências

- A plataforma passa a cobrir alimentação sem prometer uma solução de delivery
  genérica para todos os segmentos.
- O catálogo pode continuar evoluindo de maneira estável para varejo e serviços.
- O primeiro slice precisa entregar configuração operacional e salão antes de
  integrar baixa por ficha técnica, marketplace ou roteirização.
- Retirar o módulo preserva consultas e históricos, mas bloqueia novos pedidos e
  operações de cozinha.

## Alternativas rejeitadas

### Adicionar campos de cozinha ao pedido público

Rejeitada porque um pedido de catálogo não possui mesa, estação de produção,
comanda ou regras de preparo. Campos opcionais não preservariam as fronteiras de
segurança nem os estados.

### Ativar automaticamente por segmento

Rejeitada porque uma empresa de alimentação pode operar somente balcão, sem mesas
ou delivery. Segmento sugere o checklist; módulo e canais são escolhas explícitas.

