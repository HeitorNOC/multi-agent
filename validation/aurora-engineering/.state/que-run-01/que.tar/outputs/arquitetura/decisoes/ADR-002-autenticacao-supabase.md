# ADR-002 — Autenticação com Supabase Auth

- Status: substituído pelo ADR-003
- Data: 2026-07-28
- Requisito principal: RF-01 — Conta, autenticação e acesso

> Esta decisão não foi implementada. A dependência do Supabase Auth criaria um
> domínio de falha externo capaz de impedir login e renovação de sessão enquanto
> a aplicação e seu banco continuassem disponíveis. O
> [ADR-003](ADR-003-autenticacao-local-better-auth.md) substitui esta decisão.

## Contexto

O sistema precisa oferecer cadastro por e-mail e senha, recuperação de senha,
convites, revogação de sessões e MFA obrigatório para administradores e usuários
com acesso financeiro ou bancário.

Autenticação é uma fronteira crítica de segurança. Implementar armazenamento de
senha, rotação de refresh token, recuperação de conta, confirmação de e-mail e
TOTP dentro do monólito aumentaria o risco e o custo operacional sem representar
um diferencial do produto.

O documento de requisitos já seleciona Supabase para autenticação, PostgreSQL
gerenciado, RLS e arquivos privados. Ainda faltava definir como a identidade
externa se relaciona com o usuário interno, como a sessão chega ao Next.js e
onde termina a responsabilidade do provedor.

## Decisão

Usar **Supabase Auth** como provedor de identidade e `@supabase/ssr` para integrar
sessões baseadas em cookies ao Next.js App Router.

Supabase responde somente **quem é o usuário e qual o nível de garantia da
sessão**. O banco da aplicação continua responsável por organização ativa,
membership, papel, permissões, escopo de filial, ownership, entitlement e estado
do recurso.

### Identidade interna

- `User.id` continua sendo um UUID interno, independente do provedor.
- `User` terá `identity_provider` e `identity_subject`.
- Para Supabase, `identity_subject` recebe o claim imutável `sub` do JWT.
- O par `(identity_provider, identity_subject)` será único.
- E-mail nunca será usado como chave de vínculo, pois pode mudar.
- `password_hash` será removido de `users`; credenciais pertencem exclusivamente
  ao Supabase Auth.
- A interface `IdentityProvider` continuará devolvendo o `userId` interno. O
  adaptador Supabase fará a tradução entre `sub` e `User.id`.

Essa alteração de modelo será feita por migration própria no incremento de
implementação da autenticação; este ADR não modifica o banco.

### Sessão no Next.js

- O login por senha usará fluxo PKCE e cookies administrados por
  `@supabase/ssr`.
- Haverá um cliente Supabase por requisição; clientes server-side autenticados
  nunca serão singletons.
- O Proxy do Next.js atualizará tokens expirados e propagará todos os cookies e
  cabeçalhos de cache devolvidos pelo SDK.
- Páginas e respostas autenticadas serão dinâmicas e não poderão usar ISR ou
  cache público.
- Route Handlers validarão a identidade com `auth.getClaims()`.
- Operações de segurança de conta ou risco elevado poderão exigir
  `auth.getUser()` para consultar o estado atual no servidor de autenticação.
- `getSession()` não será usado como prova de identidade nem como fonte para
  autorização.
- Logout comum usará escopo `local`; “encerrar todas as sessões” usará escopo
  `global`, sempre de forma explícita.

### Chaves e segredos

- URL do projeto e chave publicável podem ser usadas pelo cliente web.
- Chave administrativa/service role existe somente no servidor e será usada
  apenas em adaptadores administrativos, como convite e bloqueio de conta.
- Nenhuma chave administrativa, refresh token ou segredo TOTP poderá aparecer
  em bundle do navegador, log, auditoria ou resposta de erro.
- O backend Prisma continuará conectando com papel PostgreSQL sem `BYPASSRLS`;
  usar Supabase Auth não substitui a transação de tenant já implementada.

### Cadastro e convite

- Autocadastro cria primeiro a identidade no Supabase e somente depois
  provisiona `User`, organização, filial matriz, membership administrativa,
  assinatura trial e onboarding em uma operação idempotente da aplicação.
- Uma identidade sem provisionamento concluído não acessa dados de negócio; ela
  retorna ao fluxo seguro de conclusão ou reparo.
- Convites são criados no servidor por usuário autorizado.
- Aceitar convite vincula ou cria o usuário interno e ativa a membership
  correspondente; repetir o callback não cria usuário nem membership duplicados.
- Confirmação de e-mail é obrigatória antes de acessar uma organização.

### Recuperação de senha

- O Supabase enviará o e-mail de recuperação.
- O callback permitido será fixo e validado; não será aceito `redirectTo`
  arbitrário informado pelo navegador.
- A troca de senha ocorrerá somente depois de o código PKCE ser convertido em
  sessão de recuperação válida.
- A resposta ao pedido de recuperação será neutra, sem revelar se o e-mail
  existe.

### MFA

- O segundo fator inicial será TOTP.
- A sessão convencional é `aal1`; uma verificação TOTP válida eleva a sessão para
  `aal2`.
- Administradores e usuários com permissões financeiras ou bancárias precisarão
  de `aal2` antes de acessar essas capacidades.
- A obrigação será verificada no servidor depois de resolver membership e
  permissões. Esconder a tela ou redirecionar no frontend não será controle de
  segurança.
- Usuário obrigado a usar MFA, mas ainda sem fator, será direcionado ao
  enrollment; usuário com fator não verificado será direcionado ao challenge.
- Remoção de fator exigirá sessão `aal2` recente e será auditada.
- Como o provedor não oferece recovery codes, a política operacional permitirá
  fator TOTP reserva ou recuperação administrativa com verificação de identidade
  e auditoria.

### Termos e privacidade

Aceitação de termos não será armazenada em metadata editável do provedor. O
banco da aplicação terá versões de documentos legais e aceitações append-only
por usuário, contendo versão, data, IP, user-agent e origem.

O `Consent` existente continua exclusivo para consentimento de marketing de
clientes e não será reutilizado para termos do usuário do SaaS.

### Auditoria e erros

- Sucesso de login, logout, recuperação concluída, convite aceito, enrollment,
  challenge, remoção de MFA, bloqueio e revogação de sessão serão eventos de
  segurança auditáveis.
- Falhas de login anteriores à identificação interna serão obtidas dos logs ou
  hooks seguros do provedor e não serão inseridas em `audit_logs` com um usuário
  inventado.
- Mensagens públicas não revelarão existência de conta, membership, organização
  ou motivo interno de bloqueio.
- Tokens, códigos, senha, segredo TOTP e payload integral do provedor serão
  redigidos dos logs.

## Alternativas consideradas

### Autenticação própria no monólito

Descartada por exigir implementação e operação de hashes, recuperação, proteção
contra credential stuffing, refresh tokens, revogação e MFA. O custo e o risco
não geram valor de negócio proporcional.

### Auth.js ou Better Auth com armazenamento próprio

Oferecem maior portabilidade e controle, mas mantêm na equipe uma parcela maior
da operação de credenciais, sessões e MFA. Podem ser reavaliados se houver
exigência comprovada de self-hosting ou múltiplos provedores.

### Clerk ou Auth0

São alternativas maduras, mas adicionariam outro fornecedor enquanto Supabase
já foi escolhido para banco, RLS e arquivos. Não há requisito atual que
justifique o custo e a integração adicionais.

### Usar diretamente `auth.users.id` como `users.id`

Descartada para não acoplar a identidade de domínio ao identificador de um
fornecedor. O vínculo explícito permite migração futura e múltiplos provedores
sem reescrever todas as relações de usuário.

## Consequências

Vantagens:

- senha, confirmação de e-mail, PKCE, rotação de token e TOTP ficam sob um
  provedor especializado;
- integração oficial com SSR e cookies do Next.js;
- identidade externa permanece separada de autorização multiempresa;
- vínculo por subject imutável evita dependência de e-mail;
- troca futura de provedor não altera FKs de usuário.

Custos e riscos:

- indisponibilidade do Supabase Auth impede novos logins e refresh de sessões;
- existe lock-in nas APIs de sessão, convite e MFA;
- a aplicação precisa tratar provisionamento parcial e callbacks repetidos;
- revogação de refresh token não invalida imediatamente um access token já
  emitido; sua validade deve ser curta e ações críticas podem consultar o estado
  atual;
- SSR autenticado exige cuidado rigoroso com cookies e cache.

## Critérios de aceite da implementação

- cadastro, confirmação de e-mail, login, logout local e logout global testados;
- recuperação de senha não permite enumeração de conta nem redirect aberto;
- convite repetido é idempotente;
- sessão sem identidade válida não consulta Prisma;
- `sub` é traduzido para usuário interno ativo;
- troca de e-mail não cria outro usuário interno;
- usuário sem membership ativa não acessa organização;
- regra de `aal2` é aplicada no servidor às permissões sensíveis;
- token, senha e segredo TOTP não aparecem em logs;
- rota autenticada envia política de cache privado adequada;
- adaptador de desenvolvimento por `x-user-id` permanece impossível em produção;
- testes cobrem callback repetido, usuário bloqueado, sessão revogada e tentativa
  de acesso entre organizações.

## Plano de reversão

O domínio depende da interface `IdentityProvider`, não do SDK Supabase. Para
trocar o provedor:

1. adicionar novo adaptador e novo valor de `identity_provider`;
2. vincular de forma verificada um novo subject aos usuários internos;
3. manter os vínculos antigos durante a migração;
4. trocar emissão e validação de sessão;
5. remover o adaptador Supabase somente após expirar as sessões antigas.

Memberships, papéis, permissões, auditoria e relações de negócio continuam
apontando para `User.id` e não precisam ser reescritos.

## Referências

- [Supabase — escolha do pacote server-side](https://supabase.com/docs/guides/auth/choosing-a-server-package)
- [Supabase — cliente SSR para Next.js](https://supabase.com/docs/guides/auth/server-side/creating-a-client?framework=nextjs&queryGroups=framework)
- [Supabase — guia avançado de SSR](https://supabase.com/docs/guides/auth/server-side/advanced-guide)
- [Supabase — sessões](https://supabase.com/docs/guides/auth/sessions)
- [Supabase — MFA](https://supabase.com/docs/guides/auth/auth-mfa)
- [Supabase — logout e escopos](https://supabase.com/docs/guides/auth/signout)
