# Decisão — divisão parcial de item entre subcomandas

## Regra

A divisão parcial será permitida somente para um item de conta `DRAFT`, entre duas contas `DRAFT` da mesma sessão de mesa e filial. A quantidade transferida deve ser positiva, ter no máximo quatro casas decimais e ser estritamente menor que a quantidade de origem.

## Integridade

O item de origem conserva a quantidade restante; o destino recebe uma nova fotografia do item, incluindo preço unitário, observações e complementos. Ambos os totais são recalculados dentro da mesma transação, protegidos pelas versões esperadas das duas contas e pelas mesmas travas ordenadas da transferência integral.

## Barreiras

Não haverá divisão após aceite, geração de ticket, baixa de estoque, checkout ou pagamento. A operação integral existente continua sendo usada quando a quantidade informada for igual à quantidade inteira da origem. Itens fracionáveis permanecem sujeitos à unidade comercial já configurada no produto.
