# ADR-004 — Módulos de produto por organização

**Status:** Aceita  
**Data:** 30 de julho de 2026

## Contexto

O produto atende empresas de segmentos diferentes e empresas iguais com
necessidades diferentes. Uma barbearia pode contratar agenda; outra, não. O
segmento não é autorização e o nome comercial do plano não deve produzir
condicionais espalhadas no código.

“Módulo” também tem dois significados:

- módulo de código: boundary do monólito, sempre implantado;
- módulo de produto: capacidade comercial habilitável por organização.

Confundir os dois levaria a builds, migrations ou tabelas diferentes por
cliente, inviáveis em um SaaS multiempresa simples.

## Decisão

1. O deploy contém todos os módulos de código da versão.
2. `ModuleDefinition` mantém o catálogo global de módulos de produto.
3. `ModuleDependency` mantém dependências acíclicas.
4. `OrganizationModule` registra a seleção explícita por organização.
5. `PlanEntitlement` e add-ons definem elegibilidade/limites; não substituem a
   seleção da organização.
6. O segmento apenas sugere configuração no onboarding.
7. A autorização de uma capacidade opcional exige:

```text
membership ativa
AND plano/add-on elegível
AND OrganizationModule = HABILITADO
AND permissão
AND escopo de filial
AND estado do recurso compatível
```

8. `SOMENTE_LEITURA` permite consulta/exportação e bloqueia novos efeitos.
9. Retirar módulo nunca executa `DROP`, migration, uninstall ou exclusão dos
   dados do cliente.
10. Frontend consome uma projeção de capacidades; casos de uso, workers e
    webhooks fazem a validação autoritativa no servidor.

## Estados e origem

Estados persistidos:

- `HABILITADO`;
- `SOMENTE_LEITURA`;
- `DESABILITADO`.

Origem comercial:

- `PLAN`;
- `ADD_ON`;
- `TRIAL`;
- `ADMIN_GRANT`.

Motivo de suspensão/retirada é campo separado. Exceção administrativa exige
motivo, autor e expiração quando temporária.

## Dependências

- dependências são validadas ao publicar o catálogo;
- ciclos são proibidos;
- habilitar apresenta dependências antes da confirmação;
- retirar um requisito com dependente ativo é bloqueado ou exige uma alteração
  conjunta explícita;
- dependências não são ativadas silenciosamente.

## Cache

A projeção de acesso pode ser cacheada por
`organization_id + subscription_version + module_version`. Alteração de plano,
add-on ou módulo incrementa versão, invalida cache e publica Outbox. A transação
de criação de recurso revalida limites que possam sofrer concorrência.

## Consequências

### Positivas

- empresas do mesmo segmento podem ter composições distintas;
- não há forks de aplicação;
- plano, módulo e permissão permanecem compreensíveis;
- retirada preserva dados;
- novos módulos entram no catálogo sem reescrever autorização.

### Custos

- todo entrypoint de módulo opcional precisa de guard;
- jobs e webhooks precisam tratar `SOMENTE_LEITURA`;
- o painel interno precisa simular impacto de retirada;
- testes devem cobrir combinações de plano, módulo e permissão.

## Alternativas rejeitadas

### Ativar por segmento

Rejeitada porque duas empresas do mesmo segmento podem contratar capacidades
diferentes.

### Usar somente plano/feature flag

Rejeitada porque não representa a seleção individual nem add-ons/exceções com
vigência e auditoria.

### Instalar/desinstalar código por cliente

Rejeitada porque exigiria deploy/schema diferente e poderia apagar dados.

### Apenas esconder menu

Rejeitada porque não protege rotas, jobs, consumers ou webhooks.

## Validação

Cada módulo opcional deve ter testes para:

1. plano permite + módulo habilitado + permissão concede;
2. plano permite + módulo desabilitado;
3. módulo habilitado + plano/add-on expirado;
4. módulo somente leitura;
5. usuário sem permissão;
6. worker após retirada;
7. webhook depois da revogação;
8. dependência ausente ou retirada;
9. duas alterações concorrentes;
10. reativação sem perda de dados.
