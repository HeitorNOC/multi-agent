# ADR-001 — Monólito modular

- Status: aceito
- Data: 2026-07-27

## Contexto

O produto possui muitos domínios, mas precisa começar simples, barato e fácil de
operar. Ao mesmo tempo, estoque, financeiro, agenda, integrações e relatórios
assíncronos exigem boundaries claros e processos com escalabilidade diferente.

Iniciar com microserviços criaria custo de deploy, observabilidade, contratos,
rede e consistência distribuída antes de existir volume que justifique esse
custo. Colocar tudo diretamente dentro do Next.js criaria acoplamento entre
interface, regras e infraestrutura.

## Decisão

Usar um monorepo com monólito modular:

- módulos de negócio independentes por código;
- PostgreSQL compartilhado como fonte de verdade;
- Next.js como processo web;
- worker Kafka como processo assíncrono;
- worker Temporal separado quando houver workflows duráveis;
- módulos compartilhados pelos processos por API pública;
- outbox como fronteira para eventos;
- proibição de acesso ao interior de outro módulo.

## Consequências

Vantagens:

- implantação inicial simples;
- transações locais para estoque e financeiro;
- menos infraestrutura;
- testes de integração diretos;
- possibilidade de escalar web e workers separadamente.

Custos:

- boundaries dependem de lint, revisão e disciplina;
- schema PostgreSQL é compartilhado;
- deploy de mudança interna pode envolver mais de um processo;
- extração futura exige contrato e ownership bem definidos.

## Critério para extrair um serviço

Um módulo só será extraído quando existir evidência de pelo menos um fator:

- escala ou disponibilidade muito diferente;
- ciclo de deploy independente necessário;
- isolamento regulatório ou de segurança;
- equipe proprietária independente;
- carga que prejudica o restante do sistema;
- integração externa que exige isolamento operacional.

Quantidade de arquivos ou preferência técnica não é justificativa.

## Plano de reversão

Como as regras não dependem de Next.js e a comunicação assíncrona já usa
contratos, um módulo pode ser extraído atrás de seu port público. Até que isso
seja necessário, ele continua no mesmo banco e processo lógico.
