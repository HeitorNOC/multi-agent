# Decisão — transferência de item entre contas separadas

## Objetivo

Permitir corrigir a conta de um cliente antes de enviar o pedido à produção, sem reescrever o histórico de cozinha, estoque ou pagamento.

## Regra inicial

A primeira entrega transfere o item completo somente entre duas contas `DRAFT` da mesma sessão de mesa e da mesma filial. A operação transfere junto os complementos e observações já fotografados, recalcula os dois totais e audita origem, destino e atendente.

## Barreiras

- não há transferência para outra mesa, balcão, filial ou organização;
- origem e destino exigem versões esperadas e trava transacional ordenada;
- item aceito, em cozinha, pronto, servido, em checkout ou pago nunca pode ser movido;
- o fluxo não divide quantidade. A divisão parcial será uma operação posterior, explícita, que recria os snapshots necessários e só poderá ocorrer antes do aceite;
- a tela oferece apenas outras contas em rascunho da mesma mesa.

## Efeito operacional

A equipe consegue corrigir rapidamente uma conta errada no tablet. Cozinha, estoque, financeiro e cliente continuam recebendo apenas o pedido definitivamente aceito, sem exposição de contas internas.
