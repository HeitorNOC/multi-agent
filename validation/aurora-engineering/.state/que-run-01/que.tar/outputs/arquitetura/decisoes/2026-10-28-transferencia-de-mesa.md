# Decisão — transferência segura de mesa no salão

## Contexto

Trocar uma mesa na operação diária não pode recriar pedidos, perder o vínculo dos tickets de cozinha, alterar valores ou misturar contas de grupos distintos. Com subcomandas, uma sessão pode conter várias contas independentes, mas elas ainda compartilham a mesma ocupação física da mesa.

## Decisão

A transferência move a **sessão aberta inteira** para outra mesa ativa da mesma filial. Todas as contas, itens, tickets, consumo de estoque e estados de pagamento permanecem ligados à sessão original; apenas a mesa física referenciada por ela muda.

O recurso não transfere itens isolados, não mescla mesas e não muda o número das contas. Essas operações exigem uma reconciliação própria de cozinha, preços e rateio e não serão simuladas por atualizações diretas de banco.

## Barreiras

- a origem precisa estar aberta e dentro do escopo de filial do colaborador;
- o destino precisa estar ativo, ser diferente da origem, pertencer à mesma filial e suportar a quantidade informada de pessoas;
- o destino não pode ter outra sessão aberta;
- travas transacionais por mesa são adquiridas em ordem estável antes de validar disponibilidade, impedindo duas movimentações concorrentes de ocupar o mesmo lugar;
- se outra tela alterou a sessão enquanto a operação aguardava a trava, a transferência falha e exige atualização;
- a ação gera auditoria com mesa anterior, mesa de destino e ator responsável.

## Efeito nos demais módulos

Não há migração nem nova entidade. A chave de sessão continua a mesma, portanto estoque, cozinha, financeiro, caixa, catálogo público e autorização não recebem alteração semântica. A tela exibe somente destinos livres da filial, mas o servidor repete todas as validações para preservar o isolamento contra chamadas diretas.
