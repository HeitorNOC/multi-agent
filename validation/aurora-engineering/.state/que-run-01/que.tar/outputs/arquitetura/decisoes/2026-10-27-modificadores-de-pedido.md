# Decisão de arquitetura — complementos e modificadores de pedidos

## Objetivo

Permitir que um restaurante modele escolhas como ponto da carne, tamanho, retirada de ingredientes, acompanhamentos e adicionais sem transformar cada combinação em um produto distinto. O recurso será restrito ao módulo de alimentação e não modifica vendas, catálogo ou serviços de empresas que não o habilitam.

## Modelo escolhido

1. **Grupo vinculado ao produto preparado.** Um grupo possui nome, ordem de exibição, mínimo e máximo de escolhas. Ex.: `Ponto da carne` exige 1 escolha; `Adicionais` aceita 0 a 3.
2. **Opção pertencente ao grupo.** Uma opção possui nome de atendimento/cozinha, acréscimo ou desconto de preço e ordem. Ela não é, por si, um movimento de estoque.
3. **Seleção imutável no item do pedido.** Ao acrescentar o item, as escolhas recebem instantâneo de grupo, nome, preço e quantidade. Mudanças futuras no cardápio não alteram pedidos em andamento, comanda, cozinha nem recibo.
4. **Validação no servidor.** Mínimo/máximo, opção ativa, pertencimento ao grupo e versão do pedido são validados antes de alterar preço ou criar ticket de cozinha. A interface só guia a escolha; não é a autoridade.
5. **Preço.** O total do item é `quantidade × (preço base + soma dos complementos por unidade)`. O pedido conserva preço de cada escolha para auditoria e para pagamentos parciais futuros.
6. **Cozinha.** O ticket recebe uma descrição legível das escolhas. Ex.: `Hambúrguer · sem cebola · adicional bacon`; nomes internos e IDs não chegam ao cozinheiro.
7. **Estoque.** Complemento comercial não baixa estoque automaticamente. Isso evita consumo fictício de insumos. Quando uma escolha alterar receita, ela será ligada a uma regra de ajuste de ficha técnica em um bloco próprio, com validação de saldo e reversão igual à receita atual.
8. **Portal do cliente.** A mesma regra de seleção será reaproveitada no catálogo público apenas para grupos publicados pela empresa. A separação de acesso continua: o cliente só envia escolhas para seu carrinho; nunca vê configuração, custo, estoque, estações ou usuários internos.

## Por que não usar texto livre

Observações livres continuam disponíveis para exceções, mas não formam preço, não permitem limites, não aparecem de maneira consistente na cozinha e não podem alimentar análise de produto. Grupos estruturados resolvem essas regras; a observação fica como complemento humano.

## Referências

- A Oracle Simphony diferencia escolhas obrigatórias, permitidas e forçadas com mínimo e máximo; ponto da carne é um exemplo de escolha obrigatória. [Condimentos](https://docs.oracle.com/en/industries/food-beverage/simphony/19.7/simcg/c_condiments.htm)
- O Toast apresenta grupos obrigatórios ou opcionais para orientar atendentes nas escolhas repetitivas. [Toast Menu Builder](https://pos.toasttab.com/restaurant-pos/mexican-latino)

## Efeitos colaterais tratados

- Produto removido ou opção desativada não pode ser adicionada a pedidos novos, mas permanece em pedidos existentes por meio de instantâneos.
- Uma atualização concorrente do pedido retorna conflito e não cria item/ticket duplicado.
- Cancelamento e resolução de ingredientes continuam usando o item de pedido já persistido; complementos não desviam esse fluxo.
- O recurso ficará atrás do módulo de alimentação e de permissões internas de gerenciamento/atendimento.
