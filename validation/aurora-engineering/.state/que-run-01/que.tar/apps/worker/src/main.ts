import { randomUUID } from "node:crypto";

import { getFileStorageEnv, getKafkaEnv, getWorkerEnv } from "@gestor/config";
import { createPrismaClient } from "@gestor/database";
import { createLogger, metrics } from "@gestor/observability";
import { ExpireReports, NotifyGeneratedReport, PublishReportOutbox } from "@gestor/reporting";
import { ResendGeneratedReportEmailSender } from "@gestor/reporting/email";
import {
  KafkaReportEventPublisher,
  KafkaReportRequestedConsumer,
  type ReportRequestedConsumerConfiguration,
} from "@gestor/reporting/kafka";
import {
  PrismaGeneratedReportNotificationRepository,
  PrismaReportExpirationRepository,
  PrismaReportOutboxRepository,
} from "@gestor/reporting/prisma";
import { ReportGeneratedMessageHandler } from "@gestor/reporting/messaging";
import {
  createReportRequestedMessageHandler,
  ReportExpirationRelay,
  ReportOutboxRelay,
} from "@gestor/reporting/runtime";
import { SupabaseReportArtifactStorage } from "@gestor/reporting/storage";

import { WorkerHealthServer } from "./health-server";

const worker = getWorkerEnv();
const logger = createLogger({
  environment: worker.NODE_ENV,
  level: worker.LOG_LEVEL,
  service: "gestor-report-worker",
});
const kafka = getKafkaEnv();
const prisma = createPrismaClient(worker.WORKER_DATABASE_URL);
const storageConfiguration = () => {
  const environment = getFileStorageEnv();
  return {
    bucket: environment.SUPABASE_STORAGE_BUCKET,
    secretKey: environment.SUPABASE_STORAGE_SECRET_KEY,
    url: environment.SUPABASE_STORAGE_URL,
  };
};
const handler = createReportRequestedMessageHandler({
  generatorVersion: "reporting@0.1.0",
  prisma,
  storage: storageConfiguration,
});
const kafkaConfiguration: ReportRequestedConsumerConfiguration = {
  brokers: kafka.KAFKA_BROKERS,
  clientId: kafka.KAFKA_CLIENT_ID,
  deadLetterTopic: kafka.KAFKA_REPORT_REQUESTED_DLQ_TOPIC,
  groupId: kafka.KAFKA_GROUP_ID,
  generatedDeadLetterTopic: kafka.KAFKA_REPORT_GENERATED_DLQ_TOPIC,
  generatedTopic: kafka.KAFKA_REPORT_GENERATED_TOPIC,
  partitionsConsumedConcurrently: kafka.KAFKA_PARTITIONS_CONCURRENTLY,
  securityProtocol: kafka.KAFKA_SECURITY_PROTOCOL,
  topic: kafka.KAFKA_REPORT_REQUESTED_TOPIC,
  ...(kafka.KAFKA_SASL_MECHANISM && kafka.KAFKA_SASL_PASSWORD && kafka.KAFKA_SASL_USERNAME
    ? {
        sasl: {
          mechanism: kafka.KAFKA_SASL_MECHANISM,
          password: kafka.KAFKA_SASL_PASSWORD,
          username: kafka.KAFKA_SASL_USERNAME,
        },
      }
    : {}),
};
const eventPublisher = new KafkaReportEventPublisher(kafkaConfiguration);
const consumer = new KafkaReportRequestedConsumer(kafkaConfiguration, handler, eventPublisher);
const generatedHandler = new ReportGeneratedMessageHandler(
  new NotifyGeneratedReport(
    new PrismaGeneratedReportNotificationRepository(prisma),
    new ResendGeneratedReportEmailSender(),
    worker.REPORTS_APP_URL,
  ),
);
const generatedConsumer = new KafkaReportRequestedConsumer(
  {
    ...kafkaConfiguration,
    clientId: `${kafkaConfiguration.clientId}-email`,
    deadLetterTopic: kafkaConfiguration.generatedDeadLetterTopic,
    groupId: `${kafkaConfiguration.groupId}-email`,
    topic: kafkaConfiguration.generatedTopic,
  },
  generatedHandler,
  eventPublisher,
);
const publishOutbox = new PublishReportOutbox(
  new PrismaReportOutboxRepository(prisma),
  eventPublisher,
  { now: () => new Date() },
  { create: randomUUID },
  {
    batchSize: kafka.KAFKA_OUTBOX_BATCH_SIZE,
    maxAttempts: kafka.KAFKA_OUTBOX_MAX_ATTEMPTS,
  },
);
let expirationReady = false;
let outboxReady = false;
const health = new WorkerHealthServer(
  () => expirationReady && outboxReady,
  () => metrics.renderPrometheus(),
  worker.METRICS_BEARER_TOKEN,
);
const relay = new ReportOutboxRelay(
  publishOutbox,
  kafka.KAFKA_OUTBOX_POLL_INTERVAL_MS,
  (result) => {
    metrics.increment("worker_outbox_batches_total", {
      outcome: result instanceof Error ? "error" : "success",
    });
    if (result instanceof Error) {
      outboxReady = false;
      logger.error({ error: result }, "Outbox relay batch failed");
    } else {
      outboxReady = true;
      metrics.increment("worker_outbox_events_total", { outcome: "published" }, result.published);
      metrics.increment("worker_outbox_events_total", { outcome: "failed" }, result.failed);
    }
    if (!(result instanceof Error) && (result.failed > 0 || result.published > 0))
      logger.info(result, "Outbox relay batch completed");
  },
);
const expiration = new ExpireReports(
  new PrismaReportExpirationRepository(prisma),
  new SupabaseReportArtifactStorage(storageConfiguration),
  { now: () => new Date() },
  { create: randomUUID },
  worker.REPORT_EXPIRATION_BATCH_SIZE,
);
const expirationRelay = new ReportExpirationRelay(
  expiration,
  worker.REPORT_EXPIRATION_POLL_INTERVAL_MS,
  (result) => {
    metrics.increment("worker_report_expiration_batches_total", {
      outcome: result instanceof Error ? "error" : "success",
    });
    if (result instanceof Error) {
      expirationReady = false;
      logger.error({ error: result }, "Report expiration batch failed");
      return;
    }
    expirationReady = true;
    metrics.increment("worker_report_expiration_total", { outcome: "expired" }, result.expired);
    metrics.increment("worker_report_expiration_total", { outcome: "failed" }, result.failed);
    if (result.expired > 0 || result.failed > 0)
      logger.info(result, "Report expiration batch completed");
  },
);

let stopping = false;
async function stop(signal: string): Promise<void> {
  if (stopping) return;
  stopping = true;
  expirationReady = false;
  outboxReady = false;
  logger.info({ signal }, "Stopping report worker");
  await health.stop();
  await relay.stop();
  await expirationRelay.stop();
  await consumer.stop();
  await generatedConsumer.stop();
  await eventPublisher.stop();
  await prisma.$disconnect();
}

process.once("SIGINT", () => void stop("SIGINT"));
process.once("SIGTERM", () => void stop("SIGTERM"));

try {
  await health.start(worker.WORKER_HEALTH_HOST, worker.WORKER_HEALTH_PORT);
  await eventPublisher.start();
  await consumer.start();
  await generatedConsumer.start();
  relay.start();
  expirationRelay.start();
  logger.info({ topic: kafka.KAFKA_REPORT_REQUESTED_TOPIC }, "Report worker started");
} catch (error) {
  logger.fatal({ error }, "Report worker failed to start");
  await stop("STARTUP_FAILURE");
  process.exitCode = 1;
}
