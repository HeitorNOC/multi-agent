import { afterEach, describe, expect, it } from "vitest";

import { WorkerHealthServer } from "./health-server";

const token = "worker-metrics-token-at-least-32-characters";
let server: WorkerHealthServer | null = null;

afterEach(async () => {
  await server?.stop();
  server = null;
});

describe("WorkerHealthServer", () => {
  it("separates liveness from dependency readiness", async () => {
    let ready = false;
    server = new WorkerHealthServer(
      () => ready,
      () => "worker_batches_total 1\n",
      token,
    );
    await server.start("127.0.0.1", 0);
    const port = requirePort(server);
    expect((await fetch(`http://127.0.0.1:${port}/health/live`)).status).toBe(200);
    expect((await fetch(`http://127.0.0.1:${port}/health/ready`)).status).toBe(503);
    ready = true;
    expect((await fetch(`http://127.0.0.1:${port}/health/ready`)).status).toBe(200);
  });

  it("protects metrics with a constant-time bearer comparison", async () => {
    server = new WorkerHealthServer(
      () => true,
      () => "worker_batches_total 1\n",
      token,
    );
    await server.start("127.0.0.1", 0);
    const url = `http://127.0.0.1:${requirePort(server)}/metrics`;
    expect((await fetch(url)).status).toBe(401);
    const response = await fetch(url, { headers: { authorization: `Bearer ${token}` } });
    expect(response.status).toBe(200);
    expect(await response.text()).toContain("worker_batches_total 1");
  });
});

function requirePort(health: WorkerHealthServer): number {
  const address = health.address();
  if (!address) throw new Error("Health server is not listening.");
  return address.port;
}
