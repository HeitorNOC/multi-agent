import { createServer, type Server, type ServerResponse } from "node:http";
import { timingSafeEqual } from "node:crypto";

export class WorkerHealthServer {
  private server: Server | null = null;

  constructor(
    private readonly readiness: () => boolean,
    private readonly renderMetrics: () => string,
    private readonly metricsToken: string,
  ) {}

  async start(host: string, port: number): Promise<void> {
    if (this.server) return;
    const server = createServer((request, response) => {
      const path = new URL(request.url ?? "/", "http://worker.local").pathname;
      if (request.method !== "GET") return json(response, 405, { status: "METHOD_NOT_ALLOWED" });
      if (path === "/health/live") return json(response, 200, { status: "UP" });
      if (path === "/health/ready") {
        const ready = this.readiness();
        return json(response, ready ? 200 : 503, { status: ready ? "READY" : "NOT_READY" });
      }
      if (path === "/metrics") {
        if (!authorized(request.headers.authorization, this.metricsToken)) {
          response.setHeader("www-authenticate", "Bearer");
          return json(response, 401, { status: "UNAUTHORIZED" });
        }
        response.writeHead(200, { "content-type": "text/plain; version=0.0.4; charset=utf-8" });
        return response.end(this.renderMetrics());
      }
      return json(response, 404, { status: "NOT_FOUND" });
    });
    this.server = server;
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(port, host, () => {
        server.off("error", reject);
        resolve();
      });
    });
  }

  async stop(): Promise<void> {
    const server = this.server;
    if (!server) return;
    this.server = null;
    await new Promise<void>((resolve, reject) =>
      server.close((error) => (error ? reject(error) : resolve())),
    );
  }

  address(): { port: number } | null {
    const address = this.server?.address();
    return address && typeof address === "object" ? { port: address.port } : null;
  }
}

function authorized(header: string | undefined, expectedToken: string): boolean {
  const token = header?.startsWith("Bearer ") ? header.slice(7) : "";
  const actual = Buffer.from(token);
  const expected = Buffer.from(expectedToken);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function json(response: ServerResponse, status: number, body: object): void {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}
