import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  consumers: [] as Array<{ start: ReturnType<typeof vi.fn>; stop: ReturnType<typeof vi.fn> }>,
  disconnect: vi.fn(),
  expirationRelay: undefined as
    | {
        callback: (result: Error | { expired: number; failed: number }) => void;
        start: ReturnType<typeof vi.fn>;
        stop: ReturnType<typeof vi.fn>;
      }
    | undefined,
  health: undefined as
    { start: ReturnType<typeof vi.fn>; stop: ReturnType<typeof vi.fn> } | undefined,
  healthStartError: undefined as Error | undefined,
  kafka: {} as Record<string, unknown>,
  logger: {
    error: vi.fn(),
    fatal: vi.fn(),
    info: vi.fn(),
  },
  metrics: { increment: vi.fn(), renderPrometheus: vi.fn(() => "metrics") },
  publisher: undefined as
    { start: ReturnType<typeof vi.fn>; stop: ReturnType<typeof vi.fn> } | undefined,
  relay: undefined as
    | {
        callback: (result: Error | { failed: number; published: number }) => void;
        start: ReturnType<typeof vi.fn>;
        stop: ReturnType<typeof vi.fn>;
      }
    | undefined,
  signals: new Map<string, (...arguments_: unknown[]) => unknown>(),
}));

vi.mock("@gestor/config", () => ({
  getFileStorageEnv: vi.fn(() => ({
    SUPABASE_STORAGE_BUCKET: "reports",
    SUPABASE_STORAGE_SECRET_KEY: "secret",
    SUPABASE_STORAGE_URL: "https://storage.example.com",
  })),
  getKafkaEnv: vi.fn(() => state.kafka),
  getWorkerEnv: vi.fn(() => ({
    LOG_LEVEL: "info",
    METRICS_BEARER_TOKEN: "metrics-token",
    NODE_ENV: "test",
    REPORTS_APP_URL: "https://app.example.com",
    REPORT_EXPIRATION_BATCH_SIZE: 50,
    REPORT_EXPIRATION_POLL_INTERVAL_MS: 60_000,
    WORKER_DATABASE_URL: "postgresql://worker",
    WORKER_HEALTH_HOST: "127.0.0.1",
    WORKER_HEALTH_PORT: 8081,
  })),
}));

vi.mock("@gestor/database", () => ({
  createPrismaClient: vi.fn(() => ({ $disconnect: state.disconnect })),
}));

vi.mock("@gestor/observability", () => ({
  createLogger: vi.fn(() => state.logger),
  metrics: state.metrics,
}));

vi.mock("@gestor/reporting", () => ({
  ExpireReports: class {},
  NotifyGeneratedReport: class {},
  PublishReportOutbox: class {},
}));

vi.mock("@gestor/reporting/email", () => ({
  ResendGeneratedReportEmailSender: class {},
}));

vi.mock("@gestor/reporting/kafka", () => ({
  KafkaReportEventPublisher: class {
    start = vi.fn();
    stop = vi.fn();
    constructor() {
      state.publisher = this;
    }
  },
  KafkaReportRequestedConsumer: class {
    start = vi.fn();
    stop = vi.fn();
    constructor() {
      state.consumers.push(this);
    }
  },
}));

vi.mock("@gestor/reporting/prisma", () => ({
  PrismaGeneratedReportNotificationRepository: class {},
  PrismaReportExpirationRepository: class {},
  PrismaReportOutboxRepository: class {},
}));

vi.mock("@gestor/reporting/messaging", () => ({
  ReportGeneratedMessageHandler: class {},
}));

vi.mock("@gestor/reporting/runtime", () => ({
  createReportRequestedMessageHandler: vi.fn(() => ({ handle: vi.fn() })),
  ReportOutboxRelay: class {
    start = vi.fn();
    stop = vi.fn();
    constructor(
      _publish: unknown,
      _interval: number,
      readonly callback: (result: Error | { failed: number; published: number }) => void,
    ) {
      state.relay = this;
    }
  },
  ReportExpirationRelay: class {
    start = vi.fn();
    stop = vi.fn();
    constructor(
      _expiration: unknown,
      _interval: number,
      readonly callback: (result: Error | { expired: number; failed: number }) => void,
    ) {
      state.expirationRelay = this;
    }
  },
}));

vi.mock("@gestor/reporting/storage", () => ({
  SupabaseReportArtifactStorage: class {},
}));

vi.mock("./health-server", () => ({
  WorkerHealthServer: class {
    start = vi.fn(async () => {
      if (state.healthStartError) throw state.healthStartError;
    });
    stop = vi.fn();
    constructor() {
      state.health = this;
    }
  },
}));

function kafka(overrides: Record<string, unknown> = {}) {
  return {
    KAFKA_BROKERS: ["broker:9092"],
    KAFKA_CLIENT_ID: "reports",
    KAFKA_GROUP_ID: "reports-worker",
    KAFKA_OUTBOX_BATCH_SIZE: 20,
    KAFKA_OUTBOX_MAX_ATTEMPTS: 10,
    KAFKA_OUTBOX_POLL_INTERVAL_MS: 1000,
    KAFKA_PARTITIONS_CONCURRENTLY: 1,
    KAFKA_REPORT_GENERATED_DLQ_TOPIC: "generated-dlq",
    KAFKA_REPORT_GENERATED_TOPIC: "generated",
    KAFKA_REPORT_REQUESTED_DLQ_TOPIC: "requested-dlq",
    KAFKA_REPORT_REQUESTED_TOPIC: "requested",
    KAFKA_SECURITY_PROTOCOL: "plaintext",
    ...overrides,
  };
}

async function load(overrides: Record<string, unknown> = {}) {
  state.kafka = kafka(overrides);
  await import("./main");
}

beforeEach(() => {
  vi.resetModules();
  state.consumers.length = 0;
  state.disconnect.mockReset();
  state.expirationRelay = undefined;
  state.health = undefined;
  state.healthStartError = undefined;
  state.logger.error.mockReset();
  state.logger.fatal.mockReset();
  state.logger.info.mockReset();
  state.metrics.increment.mockReset();
  state.publisher = undefined;
  state.relay = undefined;
  state.signals.clear();
  vi.spyOn(process, "once").mockImplementation(((event: string, listener: () => void) => {
    state.signals.set(event, listener);
    return process;
  }) as never);
});

describe("report worker composition", () => {
  it("starts, reports relay outcomes and stops once", async () => {
    await load();
    expect(state.health?.start).toHaveBeenCalledWith("127.0.0.1", 8081);
    expect(state.publisher?.start).toHaveBeenCalledOnce();
    expect(state.consumers).toHaveLength(2);
    expect(state.relay?.start).toHaveBeenCalledOnce();
    expect(state.expirationRelay?.start).toHaveBeenCalledOnce();

    state.relay?.callback(new Error("broker unavailable"));
    state.relay?.callback({ failed: 0, published: 0 });
    state.relay?.callback({ failed: 1, published: 2 });
    expect(state.logger.error).toHaveBeenCalledOnce();
    expect(state.logger.info).toHaveBeenCalledWith(
      { failed: 1, published: 2 },
      "Outbox relay batch completed",
    );
    state.expirationRelay?.callback(new Error("storage unavailable"));
    state.expirationRelay?.callback({ expired: 0, failed: 0 });
    state.expirationRelay?.callback({ expired: 2, failed: 1 });
    expect(state.logger.info).toHaveBeenCalledWith(
      { expired: 2, failed: 1 },
      "Report expiration batch completed",
    );

    state.signals.get("SIGTERM")?.();
    await vi.waitFor(() => expect(state.disconnect).toHaveBeenCalledOnce());
    state.signals.get("SIGINT")?.();
    expect(state.disconnect).toHaveBeenCalledOnce();
  });

  it.each([
    { KAFKA_SASL_MECHANISM: "plain" },
    { KAFKA_SASL_MECHANISM: "plain", KAFKA_SASL_PASSWORD: "password" },
    {
      KAFKA_SASL_MECHANISM: "plain",
      KAFKA_SASL_PASSWORD: "password",
      KAFKA_SASL_USERNAME: "worker",
    },
  ])("evaluates optional SASL configuration safely", async (configuration) => {
    await load(configuration);
    expect(state.publisher?.start).toHaveBeenCalledOnce();
  });

  it("cleans up and marks startup failures", async () => {
    state.healthStartError = new Error("port unavailable");
    await load();
    await vi.waitFor(() => expect(state.disconnect).toHaveBeenCalledOnce());
    expect(state.logger.fatal).toHaveBeenCalledOnce();
    expect(process.exitCode).toBe(1);
    process.exitCode = undefined;
  });
});
