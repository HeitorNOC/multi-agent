"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  cashRegisterListSchema,
  cashRegisterViewSchema,
  financialAccountListSchema,
  openCashRegisterBodySchema,
  type BranchView,
  type CashRegisterView,
  type FinancialAccountView,
  type OpenCashRegisterBody,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { CashRegisterCard } from "./cash-register-card";
import { formatBrl, moneyEquals } from "./cash-register-money";
import { ErrorBox, Field } from "./cash-register-ui";

export function CashRegisterConfigurations({ organizationId }: { organizationId: string }) {
  const [registers, setRegisters] = useState<readonly CashRegisterView[] | null>(null);
  const [branches, setBranches] = useState<readonly BranchView[] | null>(null);
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[] | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reloadVersion, setReloadVersion] = useState(0);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<OpenCashRegisterBody>({
    defaultValues: {
      branchId: "",
      financialAccountId: "",
      openingAmount: "",
      openingDifferenceReason: null,
    },
    resolver: zodResolver(openCashRegisterBodySchema),
  });
  const branchId = useWatch({ control, name: "branchId" });
  const financialAccountId = useWatch({ control, name: "financialAccountId" });
  const openingAmount = useWatch({ control, name: "openingAmount" });
  const activeBranches = useMemo(
    () => branches?.filter((branch) => branch.status === "ACTIVE") ?? [],
    [branches],
  );
  const cashAccounts = useMemo(
    () =>
      accounts?.filter(
        (account) =>
          account.status === "ACTIVE" && account.type === "CASH" && account.branchId === branchId,
      ) ?? [],
    [accounts, branchId],
  );
  const selectedAccount = accounts?.find((account) => account.id === financialAccountId);
  const openingDiffers =
    selectedAccount && openingAmount
      ? !moneyEquals(selectedAccount.currentBalance, openingAmount)
      : false;
  const branchNames = useMemo(
    () => new Map(branches?.map((branch) => [branch.id, branch.name]) ?? []),
    [branches],
  );
  const accountNames = useMemo(
    () => new Map(accounts?.map((account) => [account.id, account.name]) ?? []),
    [accounts],
  );

  useEffect(() => {
    const controller = new AbortController();
    let didTimeout = false;
    const timeoutId = setTimeout(() => {
      didTimeout = true;
      controller.abort();
    }, 10_000);

    async function load() {
      try {
        const [registerResponse, branchResponse, accountResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/cash-registers`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/branches`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
            signal: controller.signal,
          }),
        ]);

        for (const response of [registerResponse, branchResponse, accountResponse]) {
          if (!response.ok) {
            const problem = (await response.json()) as ProblemDetails;
            throw new Error(problem.detail);
          }
        }

        const registerPayload = (await registerResponse.json()) as { data: unknown };
        const branchPayload = (await branchResponse.json()) as { data: unknown };
        const accountPayload = (await accountResponse.json()) as { data: unknown };
        setRegisters(cashRegisterListSchema.parse(registerPayload.data));
        setBranches(branchListSchema.parse(branchPayload.data));
        setAccounts(financialAccountListSchema.parse(accountPayload.data));
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted || didTimeout) {
          setLoadError(
            didTimeout
              ? "A consulta demorou mais que o esperado. Verifique a conexão e tente novamente."
              : error instanceof Error
                ? error.message
                : "Não foi possível carregar os caixas.",
          );
        }
      } finally {
        clearTimeout(timeoutId);
      }
    }

    void load();
    return () => {
      clearTimeout(timeoutId);
      controller.abort();
    };
  }, [organizationId, reloadVersion]);

  useEffect(() => {
    setValue("financialAccountId", "");
  }, [branchId, setValue]);

  useEffect(() => {
    if (selectedAccount) {
      setValue("openingAmount", selectedAccount.currentBalance);
    }
  }, [selectedAccount, setValue]);

  useEffect(() => {
    if (!openingDiffers) {
      setValue("openingDifferenceReason", null);
    }
  }, [openingDiffers, setValue]);

  const submit = handleSubmit(async (values) => {
    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/cash-registers`, {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": idempotencyKey,
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const opened = cashRegisterViewSchema.parse(payload.data);
      setRegisters((current) => [opened, ...(current ?? [])]);
      setFeedback("Caixa aberto e pronto para receber movimentações.");
      setIdempotencyKey(crypto.randomUUID());
      reset({
        branchId: values.branchId,
        financialAccountId: "",
        openingAmount: "",
        openingDifferenceReason: null,
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  function updateRegister(updated: CashRegisterView, message: string) {
    setRegisters(
      (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [],
    );
    setFeedback(message);
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section
        aria-labelledby="cash-opening-title"
        className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7"
      >
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Abertura</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="cash-opening-title">
          Conferir dinheiro inicial
        </h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          O valor esperado vem do saldo da conta. Informe o dinheiro realmente contado.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <Field error={errors.branchId?.message} htmlFor="cash-branch" label="Filial">
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="cash-branch"
              {...register("branchId")}
            >
              <option value="">Selecione</option>
              {activeBranches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </Field>
          <Field
            error={errors.financialAccountId?.message}
            htmlFor="cash-account"
            label="Conta-caixa"
          >
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              disabled={!branchId}
              id="cash-account"
              {...register("financialAccountId")}
            >
              <option value="">Selecione</option>
              {cashAccounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name} · {formatBrl(account.currentBalance)}
                </option>
              ))}
            </select>
          </Field>
          <Field
            error={errors.openingAmount?.message}
            htmlFor="cash-opening-amount"
            label="Valor contado"
          >
            <Input
              className="h-11"
              id="cash-opening-amount"
              inputMode="decimal"
              placeholder="0,00"
              {...register("openingAmount")}
            />
          </Field>
          {selectedAccount ? (
            <p className="rounded-xl bg-slate-50 px-4 py-3 text-xs text-slate-600">
              Esperado na conta: {formatBrl(selectedAccount.currentBalance)}
            </p>
          ) : null}
          {openingDiffers ? (
            <Field
              error={errors.openingDifferenceReason?.message}
              htmlFor="cash-opening-reason"
              label="Motivo da diferença"
            >
              <Input
                className="h-11"
                id="cash-opening-reason"
                placeholder="Ex.: Falta conferida na abertura"
                {...register("openingDifferenceReason")}
              />
            </Field>
          ) : null}
          {errors.root?.message ? <ErrorBox>{errors.root.message}</ErrorBox> : null}
          <Button className="h-11" disabled={isSubmitting || !branches || !accounts} type="submit">
            {isSubmitting ? "Abrindo..." : "Abrir caixa"}
          </Button>
        </form>
      </section>

      <section aria-labelledby="cash-register-list-title" className="grid content-start gap-4">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
            Seus caixas
          </p>
          <h2 className="mt-2 text-xl font-semibold text-slate-950" id="cash-register-list-title">
            Sessões recentes
          </h2>
        </div>
        {feedback ? (
          <div
            className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700"
            role="status"
          >
            {feedback}
          </div>
        ) : null}
        {!registers || !branches || !accounts ? (
          <div className="grid gap-3 rounded-2xl border bg-white p-5">
            <p className="text-sm text-slate-600">
              {loadError ?? "Carregando caixas, filiais e contas financeiras..."}
            </p>
            {loadError ? (
              <div>
                <Button
                  onClick={() => {
                    setLoadError(null);
                    setReloadVersion((value) => value + 1);
                  }}
                  size="sm"
                  variant="outline"
                >
                  Tentar novamente
                </Button>
              </div>
            ) : null}
          </div>
        ) : registers.length === 0 ? (
          <div className="rounded-2xl border border-dashed bg-white p-6 text-sm text-slate-600">
            Você ainda não abriu um caixa.
          </div>
        ) : (
          <ul className="grid gap-4">
            {registers.map((cashRegister) => (
              <CashRegisterCard
                accountName={accountNames.get(cashRegister.financialAccountId) ?? "Conta-caixa"}
                branchName={branchNames.get(cashRegister.branchId) ?? "Filial"}
                cashRegister={cashRegister}
                key={cashRegister.id}
                onUpdated={updateRegister}
                organizationId={organizationId}
              />
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
