"use client";

import {
  catalogCommercialPolicyViewSchema,
  customerPortalOrderManagementListSchema,
  financialAccountListSchema,
  financialCategoryListSchema,
  paymentMethodConfigurationListSchema,
  type CustomerPortalOrderManagementView,
  type FinancialAccountView,
  type FinancialCategoryView,
  type PaymentMethodConfigurationView,
} from "@gestor/contracts";
import { useEffect, useMemo, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

import { formatCatalogItemCount, formatCatalogQuantity } from "./catalog-presentation";

function money(value: string) {
  return new Intl.NumberFormat("pt-BR", { currency: "BRL", style: "currency" }).format(
    Number(value),
  );
}

function fulfillmentLabel(method: CustomerPortalOrderManagementView["fulfillmentMethod"]) {
  if (method === "PICKUP") return "Retirada";
  if (method === "ARRANGED") return "Entrega a combinar";
  return "Entrega pela empresa";
}

function formatDeliveryAddress(address: CustomerPortalOrderManagementView["deliveryAddress"]) {
  if (!address) return null;
  const street = `${address.street}, ${address.number}`;
  const complement = address.complement ? `, ${address.complement}` : "";
  return `${street}${complement} · ${address.district} · ${address.city}/${address.state} · ${address.postalCode}`;
}

export function CatalogOrderManager({ organizationId }: { organizationId: string }) {
  const [orders, setOrders] = useState<readonly CustomerPortalOrderManagementView[] | null>(null);
  const [status, setStatus] = useState<"ALL" | CustomerPortalOrderManagementView["status"]>("ALL");
  const [issuesOnly, setIssuesOnly] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fulfillingId, setFulfillingId] = useState<string | null>(null);
  const [deliveryCodes, setDeliveryCodes] = useState<Record<string, string>>({});
  const [issueResolution, setIssueResolution] = useState<Record<string, string>>({});
  const [revenueCategories, setRevenueCategories] = useState<readonly FinancialCategoryView[]>([]);
  const [financialAccounts, setFinancialAccounts] = useState<readonly FinancialAccountView[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<readonly PaymentMethodConfigurationView[]>(
    [],
  );
  const [requireReceiptConfirmation, setRequireReceiptConfirmation] = useState(false);
  const [receiveNow, setReceiveNow] = useState(false);
  const [financialAccountId, setFinancialAccountId] = useState("");
  const [paymentMethodConfigurationId, setPaymentMethodConfigurationId] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [revenueCategoryId, setRevenueCategoryId] = useState("");
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    void Promise.all([
      fetch(`/api/v1/organizations/${organizationId}/catalog-orders`, {
        signal: controller.signal,
      }),
      fetch(`/api/v1/organizations/${organizationId}/financial-categories`, {
        signal: controller.signal,
      }),
      fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
        signal: controller.signal,
      }),
      fetch(`/api/v1/organizations/${organizationId}/payment-methods`, {
        signal: controller.signal,
      }),
      fetch(`/api/v1/organizations/${organizationId}/catalog-commercial-policy`, {
        signal: controller.signal,
      }),
    ])
      .then(
        async ([
          ordersResponse,
          categoriesResponse,
          accountsResponse,
          methodsResponse,
          policyResponse,
        ]) => {
          const [ordersPayload, categoriesPayload, accountsPayload, methodsPayload, policyPayload] =
            (await Promise.all([
              ordersResponse.json(),
              categoriesResponse.json(),
              accountsResponse.json(),
              methodsResponse.json(),
              policyResponse.json(),
            ])) as [
              { data?: unknown; detail?: string },
              { data?: unknown; detail?: string },
              { data?: unknown; detail?: string },
              { data?: unknown; detail?: string },
              { data?: unknown; detail?: string },
            ];
          if (!ordersResponse.ok)
            throw new Error(ordersPayload.detail ?? "Não foi possível carregar os pedidos.");
          if (!categoriesResponse.ok)
            throw new Error(categoriesPayload.detail ?? "Não foi possível carregar as categorias.");
          if (!accountsResponse.ok || !methodsResponse.ok)
            throw new Error("Não foi possível carregar as opções de recebimento.");
          if (!policyResponse.ok)
            throw new Error(
              policyPayload.detail ?? "Não foi possível carregar as regras comerciais.",
            );
          return {
            accounts: financialAccountListSchema
              .parse(accountsPayload.data)
              .filter(({ status }) => status === "ACTIVE"),
            categories: financialCategoryListSchema
              .parse(categoriesPayload.data)
              .filter(({ status, type }) => status === "ACTIVE" && type === "REVENUE"),
            orders: customerPortalOrderManagementListSchema.parse(ordersPayload.data),
            methods: paymentMethodConfigurationListSchema
              .parse(methodsPayload.data)
              .filter(({ status, allowsReceipts }) => status === "ACTIVE" && allowsReceipts),
            requireReceiptConfirmation:
              policyPayload.data === null || policyPayload.data === undefined
                ? false
                : catalogCommercialPolicyViewSchema.parse(policyPayload.data)
                    .requireReceiptConfirmation === true,
          };
        },
      )
      .then(({ accounts, categories, methods, orders, requireReceiptConfirmation }) => {
        setOrders(orders);
        setFinancialAccounts(accounts);
        setPaymentMethods(methods);
        setRevenueCategories(categories);
        setRequireReceiptConfirmation(requireReceiptConfirmation);
        setRevenueCategoryId(categories[0]?.id ?? "");
      })
      .catch((cause) => {
        if (!controller.signal.aborted)
          setError(
            cause instanceof Error ? cause.message : "Não foi possível carregar os pedidos.",
          );
      });
    return () => controller.abort();
  }, [organizationId]);

  const visible = useMemo(
    () => {
      const byStatus = status === "ALL" ? (orders ?? []) : (orders ?? []).filter((order) => order.status === status);
      return issuesOnly ? byStatus.filter((order) => order.deliveryStatus === "ISSUE_REPORTED") : byStatus;
    },
    [issuesOnly, orders, status],
  );

  async function updateStatus(
    order: CustomerPortalOrderManagementView,
    nextStatus: "CONFIRMED" | "CANCELLED",
  ) {
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}`,
        {
          body: JSON.stringify({ expectedUpdatedAt: order.updatedAt, status: nextStatus }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );
      const payload = (await response.json()) as {
        data?: CustomerPortalOrderManagementView;
        detail?: string;
      };
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível atualizar o pedido.");
      const updated = customerPortalOrderManagementListSchema.element.parse(payload.data);
      setOrders(
        (current) => current?.map((entry) => (entry.id === updated.id ? updated : entry)) ?? [],
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível atualizar o pedido.");
    } finally {
      setUpdatingId(null);
    }
  }

  async function fulfill(order: CustomerPortalOrderManagementView) {
    if (!revenueCategoryId) {
      setError("Cadastre ou ative uma categoria de receita antes de concluir o pedido.");
      return;
    }
    if (!dueDate) {
      setError("Informe a data de vencimento da venda.");
      return;
    }
    if (receiveNow && (!financialAccountId || !paymentMethodConfigurationId)) {
      setError("Selecione a forma de pagamento e a conta para receber agora.");
      return;
    }
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}/fulfill`,
        {
          body: JSON.stringify({
            dueDate,
            revenueCategoryId,
            ...(receiveNow
              ? {
                  payments: [
                    { amount: order.total, financialAccountId, paymentMethodConfigurationId },
                  ],
                }
              : {}),
          }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const payload = (await response.json()) as { detail?: string };
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível concluir a venda.");
      setOrders(
        (current) =>
          current?.map((entry) =>
            entry.id === order.id ? { ...entry, status: "FULFILLED" as const } : entry,
          ) ?? [],
      );
      setFulfillingId(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível concluir a venda.");
    } finally {
      setUpdatingId(null);
    }
  }

  async function confirmDelivery(order: CustomerPortalOrderManagementView) {
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}/delivery`,
        {
          body: JSON.stringify({
            deliveryCode: deliveryCodes[order.id] ?? "",
            expectedUpdatedAt: order.updatedAt,
          }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      const payload = (await response.json()) as {
        data?: CustomerPortalOrderManagementView;
        detail?: string;
      };
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível confirmar a entrega.");
      const updated = customerPortalOrderManagementListSchema.element.parse(payload.data);
      setOrders(
        (current) => current?.map((entry) => (entry.id === updated.id ? updated : entry)) ?? [],
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível confirmar a entrega.");
    } finally {
      setUpdatingId(null);
    }
  }

  async function dispatchDelivery(order: CustomerPortalOrderManagementView) {
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}/dispatch`,
        {
          body: JSON.stringify({ expectedUpdatedAt: order.updatedAt }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      const payload = (await response.json()) as {
        data?: CustomerPortalOrderManagementView;
        detail?: string;
      };
      if (!response.ok)
        throw new Error(payload.detail ?? "Não foi possível enviar o pedido para entrega.");
      const updated = customerPortalOrderManagementListSchema.element.parse(payload.data);
      setOrders(
        (current) => current?.map((entry) => (entry.id === updated.id ? updated : entry)) ?? [],
      );
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Não foi possível enviar o pedido para entrega.",
      );
    } finally {
      setUpdatingId(null);
    }
  }

  async function resolveDeliveryIssue(order: CustomerPortalOrderManagementView) {
    const resolution = issueResolution[order.id]?.trim() ?? "";
    if (resolution.length < 5) {
      setError("Descreva a decisão tomada com pelo menos 5 caracteres.");
      return;
    }
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}/delivery-issue`,
        {
          body: JSON.stringify({ expectedUpdatedAt: order.updatedAt, resolution }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      const payload = (await response.json()) as {
        data?: CustomerPortalOrderManagementView;
        detail?: string;
      };
      if (!response.ok)
        throw new Error(payload.detail ?? "Não foi possível resolver a divergência.");
      const updated = customerPortalOrderManagementListSchema.element.parse(payload.data);
      setOrders(
        (current) => current?.map((entry) => (entry.id === updated.id ? updated : entry)) ?? [],
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível resolver a divergência.");
    } finally {
      setUpdatingId(null);
    }
  }

  async function assumeDeliveryIssue(order: CustomerPortalOrderManagementView) {
    setUpdatingId(order.id);
    setError(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/catalog-orders/${order.id}/delivery-issue`,
        { method: "PATCH" },
      );
      const payload = (await response.json()) as {
        data?: CustomerPortalOrderManagementView;
        detail?: string;
      };
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível assumir a análise.");
      const updated = customerPortalOrderManagementListSchema.element.parse(payload.data);
      setOrders((current) => current?.map((entry) => (entry.id === order.id ? updated : entry)) ?? []);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível assumir a análise.");
    } finally {
      setUpdatingId(null);
    }
  }

  return (
    <section className="rounded-2xl border bg-white p-5" aria-labelledby="catalog-orders-title">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-bold tracking-[0.14em] text-brand-600 uppercase">Operação</p>
          <h2 className="mt-2 text-xl font-semibold text-slate-950" id="catalog-orders-title">
            Pedidos do catálogo
          </h2>
          <p className="mt-1 text-sm leading-6 text-slate-600">
            Pedidos enviados pelos clientes aguardam a confirmação operacional.
          </p>
        </div>
        <label className="text-sm text-slate-700">
          <span className="sr-only">Filtrar pedidos por status</span>
          <select
            className="rounded-lg border bg-white px-3 py-2"
            onChange={(event) => setStatus(event.target.value as typeof status)}
            value={status}
          >
            <option value="ALL">Todos</option>
            <option value="PENDING">Pendentes</option>
            <option value="CONFIRMED">Confirmados</option>
            <option value="FULFILLED">Concluídos</option>
            <option value="CANCELLED">Cancelados</option>
          </select>
        </label>
        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input checked={issuesOnly} onChange={(event) => setIssuesOnly(event.target.checked)} type="checkbox" />
          Mostrar somente divergências em aberto
        </label>
      </div>
      {error ? (
        <p className="mt-4 text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
      {!orders && !error ? (
        <div className="mt-4">
          <LoadingRows rows={2} />
        </div>
      ) : null}
      {orders ? (
        <div className="mt-4 grid gap-3">
          {visible.map((order) => (
            <article className="rounded-xl border p-4" key={order.id}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-slate-950">{order.customerName}</h3>
                  <p className="mt-1 text-sm text-slate-600">
                    {fulfillmentLabel(order.fulfillmentMethod)} ·{" "}
                    {formatCatalogItemCount(order.items.length)}
                  </p>
                </div>
                <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-900">
                  {order.status === "PENDING"
                    ? "Pendente"
                    : order.status === "CONFIRMED"
                      ? "Confirmado"
                      : order.status === "FULFILLED"
                        ? "Concluído"
                        : "Cancelado"}
                </span>
              </div>
              <ul className="mt-3 text-sm text-slate-700">
                {order.items.map((item) => (
                  <li key={item.productId}>
                    {formatCatalogQuantity(item.quantity)} {item.unit} · {item.productName}
                  </li>
                ))}
              </ul>
              {order.fulfillmentMethod === "DELIVERY" ? (
                <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm leading-6 text-slate-700">
                  <strong className="text-slate-950">Endereço de entrega:</strong>{" "}
                  {formatDeliveryAddress(order.deliveryAddress) ??
                    "Não informado em pedidos antigos."}
                </p>
              ) : null}
              <p className="mt-3 font-semibold text-slate-950">{money(order.total)}</p>
              {order.status === "PENDING" ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    className="rounded-lg bg-brand-700 px-3 py-2 text-sm font-semibold text-white disabled:opacity-60"
                    disabled={updatingId === order.id}
                    onClick={() => void updateStatus(order, "CONFIRMED")}
                    type="button"
                  >
                    {updatingId === order.id ? "Atualizando..." : "Aceitar pedido"}
                  </button>
                  <button
                    className="rounded-lg border px-3 py-2 text-sm font-medium text-slate-700 disabled:opacity-60"
                    disabled={updatingId === order.id}
                    onClick={() => void updateStatus(order, "CANCELLED")}
                    type="button"
                  >
                    Cancelar
                  </button>
                </div>
              ) : null}
              {order.status === "CONFIRMED" ? (
                <div className="mt-3 grid gap-3">
                  {order.fulfillmentMethod !== "PICKUP" && order.deliveryStatus === "PENDING" ? (
                    <button
                      className="w-fit rounded-lg bg-brand-700 px-3 py-2 text-sm font-semibold text-white disabled:opacity-60"
                      disabled={updatingId === order.id}
                      onClick={() => void dispatchDelivery(order)}
                      type="button"
                    >
                      {updatingId === order.id ? "Atualizando..." : "Enviar para entrega"}
                    </button>
                  ) : null}
                  {order.fulfillmentMethod !== "PICKUP" &&
                  order.deliveryStatus === "OUT_FOR_DELIVERY" ? (
                    <div className="grid max-w-md gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                      <p>
                        Peça ao cliente o código de 6 dígitos mostrado no portal antes de confirmar
                        a entrega.
                      </p>
                      <input
                        aria-label="Código de entrega"
                        className="rounded-lg border bg-white px-3 py-2 text-slate-950"
                        inputMode="numeric"
                        maxLength={6}
                        onChange={(event) =>
                          setDeliveryCodes((current) => ({
                            ...current,
                            [order.id]: event.target.value.replace(/\D/g, ""),
                          }))
                        }
                        placeholder="000000"
                        value={deliveryCodes[order.id] ?? ""}
                      />
                      <button
                        className="w-fit rounded-lg bg-brand-700 px-3 py-2 font-semibold text-white disabled:opacity-60"
                        disabled={
                          updatingId === order.id || (deliveryCodes[order.id] ?? "").length !== 6
                        }
                        onClick={() => void confirmDelivery(order)}
                        type="button"
                      >
                        Confirmar entrega
                      </button>
                    </div>
                  ) : null}
                  {order.deliveryStatus === "ISSUE_REPORTED" ? (
                    <div className="grid gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900">
                      <p>
                        O cliente reportou uma divergência.{" "}
                        {order.deliveryIssueReason
                          ? `Relato: ${order.deliveryIssueReason}`
                          : "Analise o caso antes de concluir ou cancelar este pedido."}
                      </p>
                      <p className="text-xs leading-5 text-red-800">
                        Fila interna: {order.deliveryIssueCaseStatus === "IN_REVIEW" ? "em análise" : "aberta"}
                        {order.deliveryIssueDueAt
                          ? ` · tratar até ${new Intl.DateTimeFormat("pt-BR", {
                              dateStyle: "short",
                              timeStyle: "short",
                            }).format(new Date(order.deliveryIssueDueAt))}`
                          : ""}
                      </p>
                      {order.deliveryIssueCaseStatus !== "IN_REVIEW" ? <button className="w-fit rounded-lg border border-red-300 bg-white px-3 py-2 font-semibold text-red-900 disabled:opacity-60" disabled={updatingId === order.id} onClick={() => void assumeDeliveryIssue(order)} type="button">Assumir análise</button> : <p className="text-xs font-medium text-red-900">Caso em análise pela equipe.</p>}
                      <label className="grid gap-1 font-medium text-slate-950">
                        Decisão da empresa
                        <textarea
                          className="min-h-20 rounded-lg border bg-white p-2 font-normal text-slate-950"
                          maxLength={1200}
                          onChange={(event) =>
                            setIssueResolution((current) => ({
                              ...current,
                              [order.id]: event.target.value,
                            }))
                          }
                          placeholder="Ex.: comprovante de entrega validado com o cliente."
                          value={issueResolution[order.id] ?? ""}
                        />
                      </label>
                      <button
                        className="w-fit rounded-lg bg-red-800 px-3 py-2 font-semibold text-white disabled:opacity-60"
                        disabled={updatingId === order.id}
                        onClick={() => void resolveDeliveryIssue(order)}
                        type="button"
                      >
                        Registrar decisão, encerrar caso e liberar pedido
                      </button>
                    </div>
                  ) : order.fulfillmentMethod !== "PICKUP" &&
                    order.deliveryConfirmedAt &&
                    !order.receiptConfirmedAt ? (
                    <p className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                      {requireReceiptConfirmation
                        ? "A empresa confirmou a entrega. Aguarde o cliente confirmar o recebimento antes de concluir a venda; ele também pode reportar uma divergência."
                        : "Entrega confirmada pela empresa. O cliente pode confirmar o recebimento ou reportar uma divergência."}
                    </p>
                  ) : null}
                  {order.fulfillmentMethod !== "PICKUP" && order.receiptConfirmedAt ? (
                    <p className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">
                      Cliente confirmou o recebimento. O pedido pode ser concluído como venda.
                    </p>
                  ) : null}
                  {order.fulfillmentMethod === "PICKUP" ||
                  (order.deliveryConfirmedAt &&
                    order.deliveryStatus !== "ISSUE_REPORTED" &&
                    (!requireReceiptConfirmation || Boolean(order.receiptConfirmedAt))) ? (
                    <>
                      {!order.branchId ? (
                        <p className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-900">
                          Este pedido antigo não possui filial de atendimento. Defina a filial antes
                          de concluir a venda.
                        </p>
                      ) : fulfillingId === order.id ? (
                        <div className="grid gap-3 rounded-xl border border-brand-100 bg-brand-50 p-3 sm:grid-cols-2">
                          <label className="grid gap-1 text-sm font-medium text-slate-800">
                            Categoria de receita
                            <select
                              className="rounded-lg border bg-white px-3 py-2 text-sm"
                              onChange={(event) => setRevenueCategoryId(event.target.value)}
                              value={revenueCategoryId}
                            >
                              <option value="">Selecione</option>
                              {revenueCategories.map((category) => (
                                <option key={category.id} value={category.id}>
                                  {category.name}
                                </option>
                              ))}
                            </select>
                          </label>
                          <label className="grid gap-1 text-sm font-medium text-slate-800">
                            Vencimento
                            <input
                              className="rounded-lg border bg-white px-3 py-2 text-sm"
                              min={new Date().toISOString().slice(0, 10)}
                              onChange={(event) => setDueDate(event.target.value)}
                              type="date"
                              value={dueDate}
                            />
                          </label>
                          <p className="text-sm leading-5 text-slate-600 sm:col-span-2">
                            Itens, valores, cliente e filial serão preservados.
                          </p>
                          <label className="flex items-center gap-2 text-sm font-medium text-slate-800 sm:col-span-2">
                            <input
                              checked={receiveNow}
                              onChange={(event) => setReceiveNow(event.target.checked)}
                              type="checkbox"
                            />
                            Receber o valor total agora ({money(order.total)})
                          </label>
                          {receiveNow ? (
                            <>
                              <label className="grid gap-1 text-sm font-medium text-slate-800">
                                Forma de pagamento
                                <select
                                  className="rounded-lg border bg-white px-3 py-2 text-sm"
                                  onChange={(event) =>
                                    setPaymentMethodConfigurationId(event.target.value)
                                  }
                                  value={paymentMethodConfigurationId}
                                >
                                  <option value="">Selecione</option>
                                  {paymentMethods.map((method) => (
                                    <option key={method.id} value={method.id}>
                                      {method.name}
                                    </option>
                                  ))}
                                </select>
                              </label>
                              <label className="grid gap-1 text-sm font-medium text-slate-800">
                                Conta de recebimento
                                <select
                                  className="rounded-lg border bg-white px-3 py-2 text-sm"
                                  onChange={(event) => setFinancialAccountId(event.target.value)}
                                  value={financialAccountId}
                                >
                                  <option value="">Selecione</option>
                                  {financialAccounts.map((account) => (
                                    <option key={account.id} value={account.id}>
                                      {account.name}
                                    </option>
                                  ))}
                                </select>
                              </label>
                            </>
                          ) : (
                            <p className="text-sm leading-5 text-slate-600 sm:col-span-2">
                              Sem recebimento imediato, a venda ficará a prazo para baixa posterior.
                            </p>
                          )}
                          <div className="flex flex-wrap gap-2 sm:col-span-2">
                            <button
                              className="rounded-lg bg-brand-700 px-3 py-2 text-sm font-semibold text-white disabled:opacity-60"
                              disabled={updatingId === order.id}
                              onClick={() => void fulfill(order)}
                              type="button"
                            >
                              {updatingId === order.id ? "Concluindo..." : "Concluir venda"}
                            </button>
                            <button
                              className="rounded-lg border px-3 py-2 text-sm font-medium text-slate-700"
                              onClick={() => setFulfillingId(null)}
                              type="button"
                            >
                              Voltar
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          className="w-fit rounded-lg bg-brand-700 px-3 py-2 text-sm font-semibold text-white disabled:opacity-60"
                          disabled={updatingId === order.id}
                          onClick={() => {
                            setDueDate(new Date().toISOString().slice(0, 10));
                            setFulfillingId(order.id);
                          }}
                          type="button"
                        >
                          Concluir como venda
                        </button>
                      )}
                    </>
                  ) : null}
                  {order.fulfillmentMethod === "PICKUP" || order.deliveryStatus === "PENDING" ? (
                    <button
                      className="rounded-lg border px-3 py-2 text-sm font-medium text-slate-700 disabled:opacity-60"
                      disabled={updatingId === order.id}
                      onClick={() => void updateStatus(order, "CANCELLED")}
                      type="button"
                    >
                      {updatingId === order.id ? "Atualizando..." : "Cancelar e liberar estoque"}
                    </button>
                  ) : null}
                </div>
              ) : null}
            </article>
          ))}
          {visible.length === 0 ? (
            <p className="text-sm text-slate-600">Nenhum pedido neste filtro.</p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
