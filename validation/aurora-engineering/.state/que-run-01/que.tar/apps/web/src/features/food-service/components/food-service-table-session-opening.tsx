import type { FoodServiceDiningTableView, FoodServiceTableSessionView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import type { FormEvent } from "react";

export function FoodServiceTableSessionOpening({
  branchId,
  onSubmit,
  sessions,
  tables,
}: {
  branchId: string;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  sessions: readonly FoodServiceTableSessionView[];
  tables: readonly FoodServiceDiningTableView[];
}) {
  const openSessions = sessions.filter(
    (session) => session.branchId === branchId && session.status === "OPEN",
  );
  const availableTables = tables.filter(
    (table) =>
      table.branchId === branchId &&
      table.status === "ACTIVE" &&
      !openSessions.some((session) => session.diningTableId === table.id),
  );

  return (
    <section className="grid gap-4 rounded-xl border bg-slate-50 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-semibold">Atendimento do salão</h3>
          <p className="mt-1 text-sm text-slate-600">
            Abra uma mesa, acompanhe a comanda e avance para pagamento no mesmo lugar.
          </p>
        </div>
        <div className="rounded-lg bg-white px-3 py-2 text-sm font-medium text-slate-700">
          {openSessions.length} mesa(s) em atendimento
        </div>
      </div>
      <div className="rounded-xl border bg-white p-4">
        <h4 className="font-semibold">Abrir novo atendimento</h4>
        <p className="mt-1 text-sm text-slate-600">
          Selecione uma mesa disponível. Mesas em uso não aparecem nesta lista.
        </p>
      </div>
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={onSubmit}>
        <select className="h-10 rounded-xl border px-3" name="diningTableId" required>
          <option value="">Selecione uma mesa disponível</option>
          {availableTables.map((table) => (
            <option key={table.id} value={table.id}>
              {table.code} · até {table.capacity} pessoas
            </option>
          ))}
        </select>
        <input
          className="h-10 rounded-xl border px-3"
          min="1"
          name="guestCount"
          placeholder="Quantidade de pessoas (opcional)"
          type="number"
        />
        <input
          className="h-10 rounded-xl border px-3 sm:col-span-2"
          maxLength={500}
          name="notes"
          placeholder="Observação inicial (opcional)"
        />
        <Button disabled={!branchId} type="submit">
          Abrir mesa
        </Button>
      </form>
    </section>
  );
}
