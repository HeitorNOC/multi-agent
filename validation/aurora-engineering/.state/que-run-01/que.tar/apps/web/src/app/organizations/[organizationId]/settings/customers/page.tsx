import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { CustomerConfigurations } from "@/features/customers/components/customer-configurations";
import { CustomFieldConfigurations } from "@/features/custom-fields/components/custom-field-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = { title: "Clientes | Gestor" };

type CustomersPageProps = { params: Promise<{ organizationId: string }> };

export default async function CustomersPage({ params }: CustomersPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">CRM</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">Clientes</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Mantenha os contatos essenciais sem duplicar cadastros. Etiquetas e campos personalizados
          permanecem vinculados ao mesmo cliente.
        </p>
      </header>
      <ModuleGate moduleCode="crm" organizationId={organizationId}>
        <CustomerConfigurations organizationId={organizationId} />
        <CustomFieldConfigurations entity="CUSTOMER" organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
