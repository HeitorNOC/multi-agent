import {
  createOrganizationInvitationBodySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

async function actor(
  request: Request,
  organizationId: string,
  api: { correlationId: string; requestId: string },
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({ ...api, organizationId, userId: identity.userId });
}

export async function GET(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    return Response.json(
      await services.listOrganizationInvitations.execute(
        organizationId,
        await actor(request, organizationId, api),
      ),
    );
  });
}

export async function POST(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    const body = createOrganizationInvitationBodySchema.parse(await readJsonBody(request));
    const invitation = await services.createOrganizationInvitation.execute(
      { ...body, idempotencyKey: requireIdempotencyKey(request), organizationId },
      await actor(request, organizationId, api),
    );
    return Response.json({ data: invitation }, { status: 201 });
  });
}
