import type { ReportJobView } from "@gestor/contracts";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { ReportJobStatus } from "./report-job-status";

const report = {
  completedAt: "2026-08-13T20:00:00.000Z",
  createdAt: "2026-08-13T19:59:00.000Z",
  expiresAt: "2026-08-20T20:00:00.000Z",
  failureCode: null,
  fileAvailable: true,
  filters: {},
  format: "CSV",
  id: "30000000-0000-4000-8000-000000000002",
  progress: 100,
  recipientUserId: "30000000-0000-4000-8000-000000000003",
  reportType: "SALES",
  requestedByUserId: "30000000-0000-4000-8000-000000000003",
  status: "COMPLETED",
} satisfies ReportJobView;

describe("ReportJobStatus", () => {
  it("offers download only for an available completed file", () => {
    const markup = renderToStaticMarkup(
      <ReportJobStatus downloading={false} onDownload={() => undefined} report={report} />,
    );
    expect(markup).toContain("Concluído");
    expect(markup).toContain("Baixar arquivo");
    expect(markup).toContain(report.id);
    expect(markup).toContain("Vendas");
  });

  it("shows the requested report type instead of a fixed label", () => {
    const markup = renderToStaticMarkup(
      <ReportJobStatus
        downloading={false}
        onDownload={() => undefined}
        report={{ ...report, reportType: "INVENTORY" }}
      />,
    );

    expect(markup).toContain("Estoque");
    expect(markup).not.toContain("Vendas");
  });

  it("explains an expired report without offering download", () => {
    const markup = renderToStaticMarkup(
      <ReportJobStatus
        downloading={false}
        onDownload={() => undefined}
        report={{ ...report, fileAvailable: false, status: "EXPIRED" }}
      />,
    );
    expect(markup).toContain("Solicite um novo relatório");
    expect(markup).not.toContain("Baixar arquivo");
  });
});
