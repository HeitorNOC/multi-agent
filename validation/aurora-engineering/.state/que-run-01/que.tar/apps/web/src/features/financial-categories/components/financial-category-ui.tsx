import type { FinancialCategoryView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

export function ReadinessItem({ ready, text }: { ready: boolean; text: string }) {
  return (
    <div className="flex items-center gap-2 text-slate-700">
      <span
        aria-hidden="true"
        className={
          ready
            ? "grid size-5 place-items-center rounded-full bg-emerald-100 font-bold text-emerald-700"
            : "grid size-5 place-items-center rounded-full bg-amber-100 font-bold text-amber-700"
        }
      >
        {ready ? "✓" : "•"}
      </span>
      {text}
    </div>
  );
}

export function CategoryCard({
  busy,
  category,
  onChangeStatus,
}: {
  busy: boolean;
  category: FinancialCategoryView;
  onChangeStatus: (category: FinancialCategoryView) => Promise<void>;
}) {
  return (
    <article className="rounded-2xl border bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-semibold text-slate-950">{category.name}</span>
          <span
            className={
              category.status === "ACTIVE"
                ? "rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-800"
                : "rounded-full bg-slate-200 px-2 py-0.5 text-xs font-semibold text-slate-700"
            }
          >
            {category.status === "ACTIVE" ? "Ativa" : "Inativa"}
          </span>
        </div>
        <Button
          disabled={busy}
          onClick={() => void onChangeStatus(category)}
          size="sm"
          variant="outline"
        >
          {busy ? "Salvando..." : category.status === "ACTIVE" ? "Desativar" : "Ativar"}
        </Button>
      </div>
    </article>
  );
}
