import type { ReportJobView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

const labels: Record<ReportJobView["status"], string> = {
  COMPLETED: "Concluído",
  EXPIRED: "Expirado",
  FAILED: "Falhou",
  PENDING: "Na fila",
  PROCESSING: "Processando",
};

const typeLabels: Record<ReportJobView["reportType"], string> = {
  CASH: "Caixa",
  CUSTOMERS: "Clientes",
  FINANCIAL_MOVEMENTS: "Movimentos financeiros",
  INVENTORY: "Estoque",
  PAYABLES: "Contas a pagar",
  PURCHASES: "Compras",
  RECEIVABLES: "Contas a receber",
  SALES: "Vendas",
  SIMPLIFIED_INCOME_STATEMENT: "DRE simplificada",
  SUPPLIERS: "Fornecedores",
};

export function ReportHistory({
  onSelect,
  reports,
}: {
  onSelect: (report: ReportJobView) => void;
  reports: readonly ReportJobView[];
}) {
  return (
    <section className="grid gap-4" aria-labelledby="report-history-title">
      <div>
        <h2 className="text-xl font-semibold" id="report-history-title">
          Histórico
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Os protocolos permanecem disponíveis após atualizar ou fechar a página.
        </p>
      </div>
      <div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">
        <table className="w-full min-w-[680px] text-left text-sm">
          <thead className="border-b bg-slate-50 text-slate-600">
            <tr>
              <th className="px-4 py-3">Solicitado em</th>
              <th className="px-4 py-3">Tipo</th>
              <th className="px-4 py-3">Formato</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Ação</th>
            </tr>
          </thead>
          <tbody>
            {reports.map((report) => (
              <tr className="border-b last:border-0" key={report.id}>
                <td className="px-4 py-3">{formatDate(report.createdAt)}</td>
                <td className="px-4 py-3">{typeLabels[report.reportType]}</td>
                <td className="px-4 py-3">{report.format}</td>
                <td className="px-4 py-3">{labels[report.status]}</td>
                <td className="px-4 py-3">
                  <Button
                    onClick={() => onSelect(report)}
                    size="sm"
                    type="button"
                    variant="outline"
                  >
                    Acompanhar
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {reports.length === 0 ? (
          <p className="p-5 text-sm text-slate-600">Nenhum relatório solicitado.</p>
        ) : null}
      </div>
    </section>
  );
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}
