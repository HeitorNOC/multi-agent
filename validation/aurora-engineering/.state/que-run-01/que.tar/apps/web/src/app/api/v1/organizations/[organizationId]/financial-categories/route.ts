import { createFinancialCategoryBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
  }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const categories = await services.listFinancialCategories.execute(params, actor);

    return Response.json({ data: categories });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createFinancialCategoryBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const category = await services.createFinancialCategory.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );

    return Response.json(
      { data: category },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/financial-categories/${category.id}`,
        },
        status: 201,
      },
    );
  });
}
