import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { FiscalProfileManagement } from "@/features/fiscal/components/fiscal-profile-management";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = { title: "Fiscal | Gestor" };
export default async function FiscalPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Configuração
        </p>
        <h1 className="mt-2 text-3xl font-semibold">Fiscal por filial</h1>
        <p className="mt-2 text-sm text-slate-600">
          Configure o emitente antes de solicitar documentos fiscais.
        </p>
      </header>
      <ModuleGate moduleCode="fiscal" organizationId={organizationId}>
        <FiscalProfileManagement organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
