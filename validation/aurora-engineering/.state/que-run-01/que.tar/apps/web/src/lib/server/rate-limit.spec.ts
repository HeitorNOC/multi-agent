import { createHash, createHmac } from "node:crypto";

import { afterEach, describe, expect, it, vi } from "vitest";

import { resetServerEnvForTests } from "@gestor/config";
import { defineRateLimitPolicy } from "@gestor/kernel";

import { createRateLimitSubject, MemoryRateLimiter, PrismaRateLimiter } from "./rate-limit";

afterEach(() => {
  vi.unstubAllEnvs();
  resetServerEnvForTests();
});

describe("MemoryRateLimiter", () => {
  it("blocks requests above the policy and resets after the window", async () => {
    const limiter = new MemoryRateLimiter();
    const policy = defineRateLimitPolicy({ limit: 2, namespace: "test.policy", windowMs: 1_000 });
    const atStart = new Date("2026-08-05T12:00:00.000Z");

    await expect(limiter.consume({ key: "client", now: atStart, policy })).resolves.toMatchObject({
      allowed: true,
      remaining: 1,
    });
    await expect(limiter.consume({ key: "client", now: atStart, policy })).resolves.toMatchObject({
      allowed: true,
      remaining: 0,
    });
    await expect(limiter.consume({ key: "client", now: atStart, policy })).resolves.toMatchObject({
      allowed: false,
      remaining: 0,
    });
    await expect(
      limiter.consume({ key: "client", now: new Date(atStart.getTime() + 1_000), policy }),
    ).resolves.toMatchObject({ allowed: true, remaining: 1 });
  });

  it("keeps independent buckets for namespaces and subjects", async () => {
    const limiter = new MemoryRateLimiter();
    const now = new Date("2026-08-05T12:00:00.000Z");
    const firstPolicy = defineRateLimitPolicy({ limit: 1, namespace: "first", windowMs: 1_000 });
    const secondPolicy = defineRateLimitPolicy({ limit: 1, namespace: "second", windowMs: 1_000 });

    await limiter.consume({ key: "client-a", now, policy: firstPolicy });

    await expect(
      limiter.consume({ key: "client-b", now, policy: firstPolicy }),
    ).resolves.toMatchObject({ allowed: true });
    await expect(
      limiter.consume({ key: "client-a", now, policy: secondPolicy }),
    ).resolves.toMatchObject({ allowed: true });
  });
});

describe("PrismaRateLimiter", () => {
  it("hashes the private key and maps the atomic database counter", async () => {
    const queryRaw = vi.fn().mockResolvedValue([{ count: 3, windowStartedAt: 1_000n }]);
    const limiter = new PrismaRateLimiter({ $queryRaw: queryRaw } as never);
    const policy = defineRateLimitPolicy({ limit: 2, namespace: "api.test", windowMs: 5_000 });

    await expect(
      limiter.consume({ key: "private-client", now: new Date(10_000), policy }),
    ).resolves.toEqual({
      allowed: false,
      limit: 2,
      remaining: 0,
      resetAt: new Date(6_000),
    });

    const query = queryRaw.mock.calls[0]?.[0];
    expect(query.values).toContain(
      createHash("sha256").update("api.test:private-client").digest("hex"),
    );
  });

  it("fails closed when the database does not return the updated counter", async () => {
    const limiter = new PrismaRateLimiter({ $queryRaw: vi.fn().mockResolvedValue([]) } as never);
    const policy = defineRateLimitPolicy({ limit: 1, namespace: "api.test", windowMs: 1_000 });

    await expect(limiter.consume({ key: "client", now: new Date(0), policy })).rejects.toThrow(
      "Rate limit counter did not return a value.",
    );
  });
});

describe("createRateLimitSubject", () => {
  const secret = "s".repeat(32);

  function configureEnvironment(
    trustProxyHeaders: boolean,
    hashSecret: string | null = secret,
  ): void {
    vi.stubEnv("DATABASE_URL", "postgresql://test:test@localhost:5432/test");
    vi.stubEnv("NODE_ENV", "test");
    vi.stubEnv("RATE_LIMIT_HASH_SECRET", hashSecret ?? secret);
    if (hashSecret === null) delete process.env.RATE_LIMIT_HASH_SECRET;
    vi.stubEnv("TRUST_PROXY_HEADERS", String(trustProxyHeaders));
    resetServerEnvForTests();
  }

  function expectedSubject(rawSubject: string, hashSecret = secret): string {
    return createHmac("sha256", hashSecret).update(rawSubject).digest("hex");
  }

  it.each([
    ["Cloudflare", { "cf-connecting-ip": " 203.0.113.1 " }, "203.0.113.1"],
    ["proxy direto", { "x-real-ip": " 203.0.113.2 " }, "203.0.113.2"],
    ["cadeia de proxies", { "x-forwarded-for": "203.0.113.3, 10.0.0.1" }, "203.0.113.3"],
  ])("prioritizes the trusted %s address", (_source, headers, address) => {
    configureEnvironment(true);

    expect(createRateLimitSubject(new Request("http://localhost", { headers }))).toBe(
      expectedSubject(`ip:${address}`),
    );
  });

  it("ignores forwarded headers when the proxy is not trusted", () => {
    configureEnvironment(false);
    const request = new Request("http://localhost", {
      headers: {
        "accept-language": "pt-BR",
        "user-agent": "test-agent",
        "x-forwarded-for": "203.0.113.4",
      },
    });

    expect(createRateLimitSubject(request)).toBe(expectedSubject("untrusted:test-agent:pt-BR"));
  });

  it("uses safe fallbacks when no client headers or hash secret exist", () => {
    configureEnvironment(true, null);

    expect(createRateLimitSubject(new Request("http://localhost"))).toBe(
      expectedSubject(
        "untrusted:unknown:unknown",
        "local-rate-limit-secret-must-not-be-used-in-production",
      ),
    );
  });
});
