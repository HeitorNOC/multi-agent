import { describe, expect, it } from "vitest";

import { safeReturnTo } from "./return-to";

describe("safeReturnTo", () => {
  it("allows only local absolute paths", () => {
    expect(safeReturnTo("/convites/aceitar")).toBe("/convites/aceitar");
    expect(safeReturnTo("https://evil.example")).toBeUndefined();
    expect(safeReturnTo("//evil.example")).toBeUndefined();
    expect(safeReturnTo("/\\evil.example")).toBeUndefined();
  });
});
