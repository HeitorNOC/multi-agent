import {
  bankAccountParamsSchema,
  bankStatementUploadMetadataSchema,
  type BankStatementFormat,
} from "@gestor/contracts";
import { AppError } from "@gestor/kernel";

import {
  authenticateApiRequest,
  handleApiRequest,
  readLimitedTextBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForFinancialMutation } from "@/lib/server/mfa-policy";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

const MAX_STATEMENT_BYTES = 1024 * 1024;
const acceptedContentTypes = new Set([
  "application/csv",
  "application/ofx",
  "application/octet-stream",
  "application/vnd.ms-excel",
  "application/x-ofx",
  "text/csv",
  "text/plain",
]);

type RouteParameters = {
  params: Promise<{
    bankAccountId: string;
    organizationId: string;
  }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const params = bankAccountParamsSchema.parse(await route.params);
      const metadata = readMetadata(request);
      const identity = await authenticateApiRequest(request);
      const actor = await services.resolveTenantActor.execute({
        correlationId: api.correlationId,
        organizationId: params.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });
      requireMfaForFinancialMutation(identity, actor, "bank_transaction.import");
      const source = await readLimitedTextBody(request, MAX_STATEMENT_BYTES);
      const statementImport = await services.importBankStatement.execute(
        {
          bankAccountId: params.bankAccountId,
          checksumSha256: source.checksumSha256,
          content: source.content,
          format: metadata.format,
          idempotencyKey: requireIdempotencyKey(request),
          organizationId: params.organizationId,
          originalFileName: metadata.fileName,
        },
        actor,
      );

      return Response.json(
        { data: statementImport },
        {
          headers: {
            location: `/api/v1/organizations/${params.organizationId}/bank-accounts/${params.bankAccountId}/statement-imports/${statementImport.id}`,
          },
          status: 201,
        },
      );
    },
    { rateLimit: apiRateLimitPolicies.fileImport },
  );
}

function readMetadata(request: Request) {
  const encodedFileName = request.headers.get("x-file-name")?.trim();

  if (!encodedFileName) {
    throw validationError("BANK_STATEMENT_FILE_NAME_REQUIRED", "Informe o nome do arquivo.");
  }

  let fileName: string;

  try {
    fileName = decodeURIComponent(encodedFileName);
  } catch {
    throw validationError(
      "BANK_STATEMENT_FILE_NAME_INVALID",
      "O nome codificado do arquivo é inválido.",
    );
  }

  const extension = fileName.split(".").at(-1)?.toLocaleLowerCase("pt-BR");
  const format: BankStatementFormat =
    extension === "csv"
      ? "CSV"
      : extension === "ofx"
        ? "OFX"
        : (() => {
            throw validationError(
              "BANK_STATEMENT_EXTENSION_UNSUPPORTED",
              "Envie um arquivo com extensão .csv ou .ofx.",
            );
          })();
  const contentType = request.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase();

  if (!contentType || !acceptedContentTypes.has(contentType)) {
    throw validationError(
      "BANK_STATEMENT_CONTENT_TYPE_UNSUPPORTED",
      "O tipo do arquivo não é aceito para importação bancária.",
    );
  }

  return bankStatementUploadMetadataSchema.parse({ contentType, fileName, format });
}

function validationError(code: string, message: string): AppError {
  return new AppError({ code, kind: "VALIDATION", message });
}
