import {
  foodServiceListQuerySchema,
  openFoodServiceTableSessionBodySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

export async function GET(request: Request, context: { params: Promise<{ organizationId: string }> }) {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await context.params);
    const query = foodServiceListQuerySchema.parse(Object.fromEntries(new URL(request.url).searchParams));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({ correlationId: api.correlationId, organizationId: params.organizationId, requestId: api.requestId, userId: identity.userId });
    return Response.json({ data: await services.listFoodServiceTableSessions.execute({ ...params, ...(query.branchId ? { branchId: query.branchId } : {}) }, actor) });
  });
}

export async function POST(request: Request, context: { params: Promise<{ organizationId: string }> }) {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await context.params);
    const body = openFoodServiceTableSessionBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({ correlationId: api.correlationId, organizationId: params.organizationId, requestId: api.requestId, userId: identity.userId });
    return Response.json({ data: await services.openFoodServiceTableSession.execute({ ...params, ...body }, actor) }, { status: 201 });
  });
}
