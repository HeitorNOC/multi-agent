import { availabilityRuleParamsSchema, updateAvailabilityRuleBodySchema } from "@gestor/contracts";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ availabilityRuleId: string; organizationId: string }> };

export async function DELETE(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = availabilityRuleParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    await services.removeAvailabilityRule.execute(params, actor);
    return new Response(null, { status: 204 });
  });
}
export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = availabilityRuleParamsSchema.parse(await route.params);
    const body = updateAvailabilityRuleBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.updateAvailabilityRule.execute({ ...body, ...params }, actor),
    });
  });
}
