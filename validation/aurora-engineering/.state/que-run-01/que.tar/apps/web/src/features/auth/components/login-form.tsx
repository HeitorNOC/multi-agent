"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { authClient } from "@gestor/auth/client";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";

import { getAuthenticationErrorMessage } from "../authentication-error";
import { safeReturnTo } from "../return-to";
import { loginSchema, type LoginInput, type LoginValues } from "../schemas";
import { isTwoFactorRedirect } from "../two-factor-login";
import { FormFeedback } from "./form-feedback";
import { GoogleSignInButton } from "./google-sign-in-button";
import { PasswordInput } from "./password-input";

type LoginFormProps = {
  emailVerified?: boolean;
  googleEnabled: boolean;
  returnTo?: string;
};

const inputClassName = "h-11 rounded-xl bg-white px-3";

export function LoginForm({ emailVerified = false, googleEnabled, returnTo }: LoginFormProps) {
  const router = useRouter();
  const destination = safeReturnTo(returnTo);
  const signUpHref = destination
    ? `/cadastro?returnTo=${encodeURIComponent(destination)}`
    : "/cadastro";
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
  } = useForm<LoginInput, undefined, LoginValues>({
    defaultValues: {
      email: "",
      password: "",
      rememberMe: true,
    },
    resolver: zodResolver(loginSchema),
  });

  const submit = handleSubmit(async (values) => {
    try {
      const result = await authClient.signIn.email({
        email: values.email,
        password: values.password,
        rememberMe: values.rememberMe,
      });

      if (result.error) {
        if (result.error.code === "EMAIL_NOT_VERIFIED") {
          window.sessionStorage.setItem("gestor.pendingVerificationEmail", values.email);
          router.push("/verificar-email");
          return;
        }

        setError("root", {
          message: getAuthenticationErrorMessage(
            result.error,
            "Não foi possível entrar. Confira os dados e tente novamente.",
          ),
          type: result.error.code ?? "server",
        });
        return;
      }

      if (isTwoFactorRedirect(result.data)) {
        const verification = new URL("/verificar-2fa", window.location.origin);
        if (destination) verification.searchParams.set("returnTo", destination);
        router.replace(`${verification.pathname}${verification.search}`);
        return;
      }

      // A successful credential response alone is not enough to let someone
      // into a protected area.  The browser must have received and sent the
      // session cookie back to the application first.  Keeping this check at
      // the boundary avoids a misleading redirect followed by a 401 screen.
      const session = await authClient.getSession();
      if (!session.data?.session || !session.data.user) {
        setError("root", {
          message:
            "Não foi possível confirmar sua sessão. Tente entrar novamente. Se o problema continuar, fale com o suporte.",
          type: "session",
        });
        return;
      }

      const acceptance = new URL("/aceite", window.location.origin);
      if (destination) acceptance.searchParams.set("returnTo", destination);
      router.replace(`${acceptance.pathname}${acceptance.search}`);
      router.refresh();
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <form className="grid gap-5" noValidate onSubmit={submit}>
      {emailVerified ? (
        <FormFeedback kind="success">E-mail confirmado. Agora você já pode entrar.</FormFeedback>
      ) : null}

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="login-email">
          E-mail
        </Label>
        <Input
          aria-describedby={errors.email ? "login-email-error" : undefined}
          aria-invalid={Boolean(errors.email)}
          autoComplete="email"
          className={inputClassName}
          id="login-email"
          inputMode="email"
          placeholder="voce@empresa.com.br"
          type="email"
          {...register("email")}
        />
        {errors.email ? (
          <p className="text-sm text-red-700" id="login-email-error" role="alert">
            {errors.email.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <div className="flex items-center justify-between gap-4">
          <Label className="text-slate-800" htmlFor="login-password">
            Senha
          </Label>
          <Link
            className="text-brand-600 hover:text-brand-700 text-xs font-semibold"
            href="/recuperar-senha"
          >
            Esqueci minha senha
          </Link>
        </div>
        <PasswordInput
          aria-describedby={errors.password ? "login-password-error" : undefined}
          aria-invalid={Boolean(errors.password)}
          autoComplete="current-password"
          className={inputClassName}
          id="login-password"
          {...register("password")}
        />
        {errors.password ? (
          <p className="text-sm text-red-700" id="login-password-error" role="alert">
            {errors.password.message}
          </p>
        ) : null}
      </div>

      <label className="flex w-fit cursor-pointer items-center gap-3 text-sm text-slate-600">
        <input
          className="text-brand-600 focus:ring-brand-100 size-4 rounded border-slate-300"
          type="checkbox"
          {...register("rememberMe")}
        />
        Manter conectado neste dispositivo
      </label>

      {errors.root?.message ? (
        <FormFeedback kind="error">{errors.root.message}</FormFeedback>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSubmitting} type="submit">
        {isSubmitting ? "Entrando..." : "Entrar"}
      </Button>

      {googleEnabled ? (
        <GoogleSignInButton
          errorPath="/login"
          {...(destination ? { returnTo: destination } : {})}
        />
      ) : null}

      <p className="text-center text-sm text-slate-600">
        Ainda não tem uma conta?{" "}
        <Link className="text-brand-600 hover:text-brand-700 font-semibold" href={signUpHref}>
          Criar conta
        </Link>
      </p>
    </form>
  );
}
