import type { ProblemDetails } from "@gestor/contracts";
import type { ZodType } from "zod";
import { z } from "zod";

export const saleFormSchema = z.object({
  branchId: z.string().min(1, "Selecione a filial."),
  customerId: z.string(),
  discountAmount: z.string().min(1, "Informe o desconto."),
  dueDate: z.string().min(1, "Informe o vencimento."),
  items: z
    .array(
      z.object({
        catalogEntry: z.string().min(1, "Selecione um produto ou serviço."),
        quantity: z.string().min(1, "Informe a quantidade."),
      }),
    )
    .min(1),
  payments: z.array(
    z.object({
      amount: z.string().min(1, "Informe o valor."),
      financialAccountId: z.string().min(1, "Selecione a conta financeira."),
      paymentMethodConfigurationId: z.string().min(1, "Selecione a forma de pagamento."),
    }),
  ),
  revenueCategoryId: z.string().min(1, "Selecione a categoria de receita."),
  salesOrderId: z.string().nullable(),
  salesOrderUpdatedAt: z.string().nullable(),
});

export type SaleForm = z.infer<typeof saleFormSchema>;
export type CatalogEntry =
  | { id: string; kind: "PRODUCT"; label: string; price: string }
  | { id: string; kind: "SERVICE"; label: string; price: string };

export async function fetchData<T>(
  path: string,
  schema: ZodType<T>,
  signal: AbortSignal,
): Promise<T> {
  const response = await fetch(path, { signal });
  let payload: { data?: unknown } & Partial<ProblemDetails> = {};
  try {
    payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  } catch {
    // A proxy or a missing route can return HTML. Preserve a useful operational message.
  }
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar os dados.");

  const parsed = schema.safeParse(payload.data);
  if (!parsed.success) {
    throw new Error("Recebemos uma resposta inesperada. Atualize a página e tente novamente.");
  }

  return parsed.data;
}
