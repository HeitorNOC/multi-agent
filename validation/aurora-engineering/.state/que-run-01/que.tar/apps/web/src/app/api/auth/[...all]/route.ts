import { handleAuthenticationRequest } from "@gestor/auth";

export const runtime = "nodejs";

async function handle(request: Request): Promise<Response> {
  return handleAuthenticationRequest(request);
}

export { handle as DELETE, handle as GET, handle as PATCH, handle as POST, handle as PUT };
