import {
  paymentMethodConfigurationParamsSchema,
  updatePaymentMethodConfigurationBodySchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
    paymentMethodConfigurationId: string;
  }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = paymentMethodConfigurationParamsSchema.parse(await route.params);
    const body = updatePaymentMethodConfigurationBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const configuration = await services.updatePaymentMethodConfiguration.execute(
      { ...params, ...body },
      actor,
    );

    return Response.json({ data: configuration });
  });
}
