import type { AppointmentView, CreateAppointmentBody } from "@gestor/contracts";

export function appointmentDefaults(_date: string, branchId: string): CreateAppointmentBody {
  return {
    branchId,
    customerId: "",
    durationMinutes: 60,
    notes: "",
    professionalUserId: "",
    serviceId: "",
    startsAt: "" as CreateAppointmentBody["startsAt"],
  };
}
export function appointmentValues(appointment: AppointmentView): CreateAppointmentBody {
  return {
    branchId: appointment.branchId,
    customerId: appointment.customerId,
    durationMinutes: Math.round(
      (new Date(appointment.endsAt).getTime() - new Date(appointment.startsAt).getTime()) / 60_000,
    ),
    notes: appointment.notes ?? "",
    professionalUserId: appointment.professionalUserId,
    serviceId: appointment.serviceId,
    startsAt: isoToLocalDateTime(appointment.startsAt),
  };
}
export function localDateTimeToIso(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toISOString();
}

export function isoToLocalDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}
