"use client";

import {
  catalogPriceHistoryListSchema,
  type CatalogPriceHistoryView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useState } from "react";

import { money } from "./catalog-helpers";

export function PriceHistoryButton({
  itemId,
  organizationId,
  segment,
}: {
  itemId: string;
  organizationId: string;
  segment: "products" | "services";
}) {
  const [history, setHistory] = useState<readonly CatalogPriceHistoryView[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  async function load() {
    if (history) return setHistory(null);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/${segment}/${itemId}/price-history`,
    );
    if (!response.ok) return setError(((await response.json()) as ProblemDetails).detail);
    const payload = (await response.json()) as { data: unknown };
    setError(null);
    setHistory(catalogPriceHistoryListSchema.parse(payload.data));
  }
  return (
    <div className="relative">
      <Button onClick={() => void load()} type="button" variant="outline">
        Preços
      </Button>
      {error ? (
        <p className="absolute right-0 top-11 z-10 w-72 rounded-xl border bg-white p-3 text-xs text-red-700 shadow-lg">
          {error}
        </p>
      ) : null}
      {history ? (
        <div className="absolute right-0 top-11 z-10 w-72 rounded-xl border bg-white p-3 text-left text-xs shadow-lg">
          <p className="mb-2 font-semibold">Histórico de preços</p>
          {history.map((entry) => (
            <p className="py-1" key={entry.id}>
              R$ {money(entry.price)} · {entry.reason === "INITIAL" ? "Inicial" : "Alteração"} ·{" "}
              {new Date(entry.recordedAt).toLocaleString("pt-BR")}
            </p>
          ))}
        </div>
      ) : null}
    </div>
  );
}
