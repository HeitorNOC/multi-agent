import {
  organizationParamsSchema,
  setFoodServiceKitchenDefaultStationBodySchema,
} from "@gestor/contracts";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type RouteParameters = { params: Promise<{ organizationId: string; stationId: string }> };
export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const routeParams = await route.params;
    const params = organizationParamsSchema.parse(routeParams);
    const body = setFoodServiceKitchenDefaultStationBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.setFoodServiceKitchenDefaultStation.execute(
        { ...body, ...params, kitchenStationId: routeParams.stationId },
        actor,
      ),
    });
  });
}
