import type {
  FinancialAccountView,
  FinancialCategoryView,
  FoodServiceOrderView,
  FoodServiceTableSessionView,
  PaymentMethodConfigurationView,
  ProductView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useState, type FormEvent } from "react";

import {
  FoodServiceOrderCheckout,
  type FoodServiceCheckoutForm,
  type FoodServiceCheckoutPayment,
} from "./food-service-order-checkout";
import { FoodServiceOrderItemAdder } from "./food-service-order-item-adder";

function formatCurrency(value: string) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    Number(value),
  );
}
function formatQuantity(value: string) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(Number(value));
}
function quantityInputValue(value: string) {
  return String(Number(value));
}
function formatItemQuantity(quantity: string, unit: string) {
  const amount = Number(quantity);
  if (unit === "UN") return `${formatQuantity(quantity)} ${amount === 1 ? "unidade" : "unidades"}`;
  return `${formatQuantity(quantity)} ${unit.toLowerCase()}`;
}
function orderStatusLabel(status: FoodServiceOrderView["status"]) {
  const labels = {
    ACCEPTED: "Pedido aceito",
    CANCELLED: "Pedido cancelado",
    CHECKOUT_PENDING: "Aguardando pagamento",
    DRAFT: "Rascunho editável",
    SETTLED: "Pedido pago",
  } as const;
  return labels[status];
}

export function FoodServiceTableSessionCards({
  branchId,
  checkoutDefaults,
  checkoutForms,
  compatibleAccounts,
  onAcceptOrder,
  onAddCheckoutPayment,
  onAddOrderItem,
  onBeginCheckout,
  onCancelOrder,
  onCancelSession,
  onCreateOrder,
  onMoveOrderItem,
  onRemoveOrderItem,
  onMoveSession,
  onRemovePayment,
  onSettle,
  onUpdateCheckout,
  onUpdatePayment,
  organizationId,
  orders,
  paymentMethods,
  products,
  revenueCategories,
  sessions,
  settlingOrderId,
  tables,
}: {
  branchId: string;
  checkoutDefaults: () => FoodServiceCheckoutForm;
  checkoutForms: Readonly<Record<string, FoodServiceCheckoutForm>>;
  compatibleAccounts: (paymentMethodConfigurationId: string) => readonly FinancialAccountView[];
  onAcceptOrder: (orderId: string) => void;
  onAddCheckoutPayment: (orderId: string, orderTotal: string) => void;
  onAddOrderItem: (event: FormEvent<HTMLFormElement>, orderId: string) => void;
  onBeginCheckout: (orderId: string) => void;
  onCancelOrder: (orderId: string, reason: string) => void;
  onCancelSession: (sessionId: string) => void;
  onCreateOrder: (session: FoodServiceTableSessionView, tabLabel?: string) => void;
  onMoveOrderItem: (
    itemId: string,
    sourceOrder: FoodServiceOrderView,
    targetOrderId: string,
    quantity: string,
  ) => void;
  onRemoveOrderItem: (itemId: string, order: FoodServiceOrderView) => void;
  onMoveSession: (session: FoodServiceTableSessionView, diningTableId: string) => void;
  onRemovePayment: (orderId: string, index: number) => void;
  onSettle: (orderId: string) => void;
  onUpdateCheckout: (orderId: string, changes: Partial<FoodServiceCheckoutForm>) => void;
  onUpdatePayment: (
    orderId: string,
    index: number,
    changes: Partial<FoodServiceCheckoutPayment>,
  ) => void;
  organizationId: string;
  orders: Readonly<Record<string, readonly FoodServiceOrderView[]>>;
  paymentMethods: readonly PaymentMethodConfigurationView[];
  products: readonly ProductView[];
  revenueCategories: readonly FinancialCategoryView[];
  sessions: readonly FoodServiceTableSessionView[];
  settlingOrderId: string | null;
  tables: readonly { branchId: string; code: string; id: string; status: string }[];
}) {
  const [cancellationReasons, setCancellationReasons] = useState<Record<string, string>>({});
  const [newTabLabels, setNewTabLabels] = useState<Record<string, string>>({});
  const [itemMoveTargets, setItemMoveTargets] = useState<Record<string, string>>({});
  const [itemMoveQuantities, setItemMoveQuantities] = useState<Record<string, string>>({});
  const [moveTargets, setMoveTargets] = useState<Record<string, string>>({});
  const openSessions = sessions.filter(
    (session) => session.branchId === branchId && session.status === "OPEN",
  );

  return (
    <section className="grid gap-4 rounded-xl border bg-slate-50 p-4">
      <div className="grid gap-2">
        {openSessions.length === 0 ? (
          <p className="text-sm text-slate-600">Nenhuma mesa aberta nesta filial.</p>
        ) : (
          openSessions.map((session) => {
            const sessionOrders = orders[session.id] ?? [];
            const occupiedTableIds = new Set(openSessions.map((item) => item.diningTableId));
            const availableMoveTargets = tables.filter(
              (table) =>
                table.branchId === branchId &&
                table.status === "ACTIVE" &&
                table.id !== session.diningTableId &&
                !occupiedTableIds.has(table.id),
            );
            return (
              <article
                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-white p-3"
                key={session.id}
              >
                <div>
                  <p className="font-semibold">Mesa {session.diningTableCode} aberta</p>
                  <p className="text-sm text-slate-600">
                    {session.guestCount
                      ? `${session.guestCount} pessoa(s)`
                      : "Quantidade de pessoas não informada"}
                  </p>
                </div>
                <Button onClick={() => onCancelSession(session.id)} type="button" variant="outline">
                  Cancelar abertura
                </Button>
                {availableMoveTargets.length > 0 ? (
                  <div className="flex w-full flex-wrap gap-2 rounded-lg border border-dashed bg-slate-50 p-3">
                    <select
                      aria-label="Mover atendimento para outra mesa"
                      className="h-10 min-w-52 flex-1 rounded-lg border bg-white px-3 text-sm"
                      onChange={(event) =>
                        setMoveTargets((value) => ({ ...value, [session.id]: event.target.value }))
                      }
                      value={moveTargets[session.id] ?? ""}
                    >
                      <option value="">Mover atendimento para…</option>
                      {availableMoveTargets.map((table) => (
                        <option key={table.id} value={table.id}>
                          Mesa {table.code}
                        </option>
                      ))}
                    </select>
                    <Button
                      disabled={!moveTargets[session.id]}
                      onClick={() => {
                        const target = moveTargets[session.id];
                        if (target) onMoveSession(session, target);
                      }}
                      type="button"
                      variant="outline"
                    >
                      Mover mesa
                    </Button>
                  </div>
                ) : null}
                {sessionOrders.length === 0 ? (
                  <Button onClick={() => onCreateOrder(session)} type="button">
                    Iniciar pedido
                  </Button>
                ) : null}
                {sessionOrders.length > 0 ? (
                  <div className="flex w-full flex-wrap gap-2 rounded-lg border border-dashed bg-slate-50 p-3">
                    <input
                      className="h-10 min-w-52 flex-1 rounded-lg border px-3 text-sm"
                      maxLength={80}
                      onChange={(event) =>
                        setNewTabLabels((value) => ({ ...value, [session.id]: event.target.value }))
                      }
                      aria-label="Responsável opcional da nova conta"
                      placeholder="Responsável pela conta (opcional)"
                      value={newTabLabels[session.id] ?? ""}
                    />
                    <Button
                      onClick={() => {
                        onCreateOrder(session, newTabLabels[session.id]);
                        setNewTabLabels((value) => ({ ...value, [session.id]: "" }));
                      }}
                      type="button"
                      variant="outline"
                    >
                      Nova conta
                    </Button>
                  </div>
                ) : null}
                {sessionOrders.map((order) => (
                  <section className="grid w-full gap-3 rounded-lg bg-slate-50 p-3" key={order.id}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-semibold">
                        Conta {order.tabNumber ?? ""}
                        {order.tabLabel ? ` · ${order.tabLabel}` : ""}
                      </p>
                      <p className="text-xs font-semibold text-slate-600">
                        {orderStatusLabel(order.status)}
                      </p>
                    </div>
                    {order.status === "DRAFT" ? (
                      <form
                        className="grid gap-2"
                        onSubmit={(event) => onAddOrderItem(event, order.id)}
                      >
                        <FoodServiceOrderItemAdder
                          organizationId={organizationId}
                          products={products}
                          resetKey={order.version}
                        />
                      </form>
                    ) : null}
                    {order.status === "DRAFT" || order.status === "ACCEPTED" ? (
                      <div className="flex flex-wrap gap-2">
                        <input
                          className="h-10 min-w-52 flex-1 rounded-lg border px-3 text-sm"
                          maxLength={240}
                          onChange={(event) =>
                            setCancellationReasons((value) => ({
                              ...value,
                              [order.id]: event.target.value,
                            }))
                          }
                          placeholder="Motivo do cancelamento"
                          value={cancellationReasons[order.id] ?? ""}
                        />
                        <Button
                          onClick={() =>
                            onCancelOrder(order.id, cancellationReasons[order.id] ?? "")
                          }
                          type="button"
                          variant="outline"
                        >
                          Cancelar pedido
                        </Button>
                      </div>
                    ) : null}
                    {order.status === "ACCEPTED" ? (
                      <Button onClick={() => onBeginCheckout(order.id)} type="button">
                        Ir para pagamento
                      </Button>
                    ) : null}
                    {order.status === "CHECKOUT_PENDING" ? (
                      <FoodServiceOrderCheckout
                        checkout={checkoutForms[order.id] ?? checkoutDefaults()}
                        compatibleAccounts={compatibleAccounts}
                        onAddPayment={(orderTotal) => onAddCheckoutPayment(order.id, orderTotal)}
                        onRemovePayment={(index) => onRemovePayment(order.id, index)}
                        onSettle={() => onSettle(order.id)}
                        onUpdateCheckout={(changes) => onUpdateCheckout(order.id, changes)}
                        onUpdatePayment={(index, changes) =>
                          onUpdatePayment(order.id, index, changes)
                        }
                        order={order}
                        paymentMethods={paymentMethods}
                        revenueCategories={revenueCategories}
                        settling={settlingOrderId === order.id}
                      />
                    ) : null}
                    <div className="grid gap-1 text-sm">
                      {order.items.map((item) => (
                        <div className="rounded-lg bg-white px-2 py-1.5" key={item.id}>
                          <p>
                            {formatItemQuantity(item.quantity, item.unit)} · {item.description}
                            <span className="float-right font-medium">
                              {formatCurrency(item.total)}
                            </span>
                          </p>
                          {item.modifierNames.length > 0 ? (
                            <p className="mt-0.5 text-xs text-slate-600">
                              {item.modifierNames.join(" · ")}
                            </p>
                          ) : null}
                          {item.notes ? (
                            <p className="mt-0.5 text-xs text-slate-600">
                              Observação: {item.notes}
                            </p>
                          ) : null}
                          {order.status === "DRAFT" ? (
                            <Button
                              className="mt-2"
                              onClick={() => onRemoveOrderItem(item.id, order)}
                              type="button"
                              variant="outline"
                            >
                              Remover item
                            </Button>
                          ) : null}
                          {order.status === "DRAFT" &&
                          sessionOrders.some(
                            (candidate) =>
                              candidate.id !== order.id && candidate.status === "DRAFT",
                          ) ? (
                            <div className="mt-2 flex flex-wrap items-end gap-2">
                              <label className="grid gap-1 text-xs font-medium text-slate-600">
                                Quantidade a mover
                                <input
                                  aria-label={`Quantidade de ${item.description} para mover`}
                                  className="h-8 w-28 rounded border px-2 text-xs"
                                  inputMode="decimal"
                                  max={quantityInputValue(item.quantity)}
                                  min="0.0001"
                                  onChange={(event) =>
                                    setItemMoveQuantities((value) => ({
                                      ...value,
                                      [item.id]: event.target.value,
                                    }))
                                  }
                                  step="0.0001"
                                  type="number"
                                  value={itemMoveQuantities[item.id] ?? quantityInputValue(item.quantity)}
                                />
                              </label>
                              <select
                                aria-label={`Mover ${item.description} para outra conta`}
                                className="h-8 min-w-44 rounded border px-2 text-xs"
                                onChange={(event) =>
                                  setItemMoveTargets((value) => ({
                                    ...value,
                                    [item.id]: event.target.value,
                                  }))
                                }
                                value={itemMoveTargets[item.id] ?? ""}
                              >
                                <option value="">Mover item para…</option>
                                {sessionOrders
                                  .filter(
                                    (candidate) =>
                                      candidate.id !== order.id && candidate.status === "DRAFT",
                                  )
                                  .map((candidate) => (
                                    <option key={candidate.id} value={candidate.id}>
                                      Conta {candidate.tabNumber}
                                      {candidate.tabLabel ? ` · ${candidate.tabLabel}` : ""}
                                    </option>
                                  ))}
                              </select>
                              <Button
                                disabled={!itemMoveTargets[item.id]}
                                onClick={() => {
                                  const target = itemMoveTargets[item.id];
                                  if (target)
                                    onMoveOrderItem(
                                      item.id,
                                      order,
                                      target,
                                      itemMoveQuantities[item.id] ?? item.quantity,
                                    );
                                }}
                                type="button"
                                variant="outline"
                              >
                                Mover
                              </Button>
                            </div>
                          ) : null}
                        </div>
                      ))}
                      <p className="mt-1 border-t pt-2 font-semibold">
                        Total <span className="float-right">{formatCurrency(order.total)}</span>
                      </p>
                    </div>
                    {order.status === "DRAFT" ? (
                      <Button onClick={() => onAcceptOrder(order.id)} type="button">
                        Aceitar pedido
                      </Button>
                    ) : null}
                  </section>
                ))}
              </article>
            );
          })
        )}
      </div>
    </section>
  );
}
