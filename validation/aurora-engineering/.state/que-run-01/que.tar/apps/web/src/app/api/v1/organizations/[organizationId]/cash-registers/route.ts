import {
  cashRegisterListSchema,
  openCashRegisterBodySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForFinancialMutation } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{ organizationId: string }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const registers = await services.listCashRegisters.execute(
      { organizationId: params.organizationId },
      actor,
    );
    return Response.json({ data: cashRegisterListSchema.parse(registers) });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = openCashRegisterBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForFinancialMutation(identity, actor, "cash_register.manage");
    const register = await services.openCashRegister.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json({ data: register }, { status: 201 });
  });
}
