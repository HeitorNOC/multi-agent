import type { OrganizationModuleView } from "@gestor/contracts";

export type ModuleAccessPresentation =
  | { mode: "ENABLED"; reason: null }
  | { mode: "READ_ONLY"; reason: string }
  | { mode: "DISABLED"; reason: string };

export function resolveModuleAccessPresentation(
  modules: readonly OrganizationModuleView[],
  moduleCode: string,
): ModuleAccessPresentation {
  const moduleDefinition = modules.find(({ code }) => code === moduleCode);

  if (!moduleDefinition || moduleDefinition.access.mode === "DISABLED") {
    return {
      mode: "DISABLED",
      reason: "Este módulo não está disponível para esta empresa.",
    };
  }

  if (moduleDefinition.access.mode === "READ_ONLY") {
    return {
      mode: "READ_ONLY",
      reason:
        "Este módulo está em modo somente leitura. Os dados existentes continuam disponíveis, mas alterações estão bloqueadas.",
    };
  }

  return { mode: "ENABLED", reason: null };
}
