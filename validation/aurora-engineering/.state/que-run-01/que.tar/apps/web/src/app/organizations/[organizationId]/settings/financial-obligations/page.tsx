import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { FinancialObligationConfigurations } from "@/features/financial-obligations/components/financial-obligation-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Contas a pagar e receber | Gestor",
};

type FinancialObligationsPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function FinancialObligationsPage({ params }: FinancialObligationsPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao checklist
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Implantação financeira
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Contas a pagar e receber
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Registre compromissos já existentes. Esta etapa alimenta o fluxo projetado sem alterar os
          saldos de caixa ou banco.
        </p>
      </header>

      <ModuleGate moduleCode="financial" organizationId={organizationId}>
        <FinancialObligationConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
