import { describe, expect, it } from "vitest";

import {
  createBasicReportBody,
  reportRequestFingerprint,
  requestReportFormDefaults,
  requestReportFormSchema,
} from "./request-report";

describe("request report form", () => {
  it("creates a supported sales request and removes empty filters", () => {
    expect(
      createBasicReportBody({
        ...requestReportFormDefaults,
        from: "2026-08-01",
        status: "COMPLETED",
      }),
    ).toEqual({
      filters: { from: "2026-08-01", status: "COMPLETED" },
      format: "CSV",
      reportType: "SALES",
    });
  });

  it("rejects an inverted period", () => {
    const result = requestReportFormSchema.safeParse({
      ...requestReportFormDefaults,
      from: "2026-08-10",
      to: "2026-08-01",
    });

    expect(result.success).toBe(false);
    expect(result.error?.issues[0]?.path).toEqual(["to"]);
  });

  it("produces the same fingerprint for an unchanged retry", () => {
    const body = createBasicReportBody(requestReportFormDefaults);
    expect(reportRequestFingerprint(body)).toBe(reportRequestFingerprint(body));
  });

  it("keeps the selected output format", () => {
    expect(createBasicReportBody({ ...requestReportFormDefaults, format: "PDF" }).format).toBe(
      "PDF",
    );
  });

  it("removes period filters from the inventory snapshot", () => {
    expect(
      createBasicReportBody({
        ...requestReportFormDefaults,
        from: "2026-08-01",
        reportType: "INVENTORY",
        to: "2026-08-10",
      }),
    ).toEqual({ filters: {}, format: "CSV", reportType: "INVENTORY" });
  });
});
