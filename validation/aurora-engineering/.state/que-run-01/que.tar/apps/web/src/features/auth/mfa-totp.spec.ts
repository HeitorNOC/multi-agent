import { describe, expect, it } from "vitest";

import { parseTotpEnrollmentUri } from "./mfa-totp";

describe("parseTotpEnrollmentUri", () => {
  it("extracts the Base32 key required by manual authenticator setup", () => {
    expect(
      parseTotpEnrollmentUri(
        "otpauth://totp/Gestor:owner%40example.com?secret=jbsw%20y3dp%20ehpk%203pxp&issuer=Gestor",
      ),
    ).toEqual({
      manualKey: "JBSWY3DPEHPK3PXP",
      totpUri:
        "otpauth://totp/Gestor:owner%40example.com?secret=jbsw%20y3dp%20ehpk%203pxp&issuer=Gestor",
    });
  });

  it("rejects URIs without a TOTP secret", () => {
    expect(() => parseTotpEnrollmentUri("otpauth://totp/Gestor:owner?issuer=Gestor")).toThrow(
      "TOTP enrollment URI is invalid.",
    );
  });
});
