"use client";

import {
  inventoryCountSessionListSchema,
  type InventoryCountSessionView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useEffect, useState } from "react";

type CountDraft = { countedQuantity: string; reason: string };

function qty(value: string, unit: string) {
  const number = Number(value);
  return `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(number)} ${
    unit === "UN" ? (Math.abs(number) === 1 ? "unidade" : "unidades") : unit.toLowerCase()
  }`;
}

function differsFromExpected(value: string, expected: string) {
  if (!value.trim()) return false;
  return Number(value.replace(",", ".")) !== Number(expected);
}

export function DailyInventoryCount({
  organizationId,
  branchId,
  onCompleted,
}: {
  organizationId: string;
  branchId: string;
  onCompleted: () => Promise<void>;
}) {
  const [sessions, setSessions] = useState<readonly InventoryCountSessionView[]>([]);
  const [drafts, setDrafts] = useState<Record<string, CountDraft>>({});
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const base = `/api/v1/organizations/${organizationId}/branches/${branchId}/inventory-count-sessions`;
  const active = sessions.find((session) => session.status === "OPEN");

  async function load() {
    if (!branchId) return;
    const response = await fetch(base);
    const payload = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) throw new Error(payload.detail || "Não foi possível carregar a conferência.");
    setSessions(inventoryCountSessionListSchema.parse(payload.data));
  }

  useEffect(() => {
    void load().catch((error: unknown) =>
      setMessage(error instanceof Error ? error.message : "Não foi possível carregar a conferência."),
    );
  }, [branchId]);

  useEffect(() => {
    setDrafts({});
  }, [active?.id]);

  function draftFor(item: InventoryCountSessionView["items"][number]): CountDraft {
    return drafts[item.id] ?? { countedQuantity: item.countedQuantity ?? "", reason: item.reason ?? "" };
  }

  function updateDraft(itemId: string, patch: Partial<CountDraft>) {
    setDrafts((current) => ({
      ...current,
      [itemId]: { countedQuantity: current[itemId]?.countedQuantity ?? "", reason: current[itemId]?.reason ?? "", ...patch },
    }));
  }

  async function open() {
    setBusy(true);
    try {
      const response = await fetch(base, {
        body: "{}",
        headers: { "content-type": "application/json" },
        method: "POST",
      });
      const payload = (await response.json()) as { data?: unknown } & ProblemDetails;
      if (!response.ok) throw new Error(payload.detail);
      await load();
      setMessage("Conferência iniciada. As vendas continuam funcionando enquanto ela é preenchida.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível iniciar.");
    } finally {
      setBusy(false);
    }
  }

  async function record(item: InventoryCountSessionView["items"][number]) {
    if (!active) return;
    const draft = draftFor(item);
    if (!draft.countedQuantity.trim()) return;
    if (differsFromExpected(draft.countedQuantity, item.expectedQuantity) && !draft.reason.trim()) {
      setMessage(`Informe o motivo da diferença em ${item.productName}.`);
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${base}/${active.id}/items/${item.id}`, {
        body: JSON.stringify({ countedQuantity: draft.countedQuantity, reason: draft.reason || undefined }),
        headers: { "content-type": "application/json" },
        method: "PATCH",
      });
      const payload = (await response.json()) as { data?: unknown } & ProblemDetails;
      if (!response.ok) throw new Error(payload.detail);
      setDrafts((current) => {
        const next = { ...current };
        delete next[item.id];
        return next;
      });
      await load();
      setMessage("");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível registrar.");
    } finally {
      setBusy(false);
    }
  }

  async function close() {
    if (!active) return;
    setBusy(true);
    try {
      const response = await fetch(`${base}/${active.id}/close`, { method: "POST" });
      const payload = (await response.json()) as { data?: unknown } & ProblemDetails;
      if (!response.ok) throw new Error(payload.detail);
      await load();
      await onCompleted();
      setMessage("Conferência concluída e diferenças registradas no histórico.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Não foi possível concluir.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="rounded-2xl border bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-semibold">Conferência de fechamento</h2>
          <p className="mt-1 text-sm text-slate-600">
            Opcional por padrão. Registre o estoque físico sem interromper vendas; diferenças precisam ser justificadas.
          </p>
        </div>
        {!active ? <Button disabled={busy || !branchId} onClick={() => void open()} type="button">Iniciar conferência</Button> : null}
      </div>
      {message ? <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm" role="status">{message}</p> : null}
      {active ? (
        <div className="mt-4 grid gap-3">
          <p className="text-sm font-medium">
            {active.items.filter((item) => item.countedQuantity !== null).length} de {active.items.length} itens contados
          </p>
          {active.items.map((item) => {
            const draft = draftFor(item);
            const hasDifference = differsFromExpected(draft.countedQuantity, item.expectedQuantity);
            return (
              <div className="grid gap-2 rounded-xl border p-3 sm:grid-cols-[1fr_10rem]" key={item.id}>
                <div>
                  <p className="font-medium">{item.productName}</p>
                  <p className="text-xs text-slate-600">Saldo registrado: {qty(item.expectedQuantity, item.unit)}</p>
                  {hasDifference ? (
                    <input
                      className="mt-2 w-full rounded-md border px-2 py-1 text-sm"
                      disabled={busy}
                      onBlur={() => void record(item)}
                      onChange={(event) => updateDraft(item.id, { reason: event.target.value })}
                      placeholder="Motivo da diferença (obrigatório)"
                      value={draft.reason}
                    />
                  ) : null}
                </div>
                <input
                  aria-label={`Quantidade contada de ${item.productName}`}
                  className="h-10 rounded-md border px-2"
                  disabled={busy}
                  min="0"
                  onBlur={() => void record(item)}
                  onChange={(event) => updateDraft(item.id, { countedQuantity: event.target.value })}
                  placeholder="Quantidade"
                  step="0.0001"
                  type="number"
                  value={draft.countedQuantity}
                />
              </div>
            );
          })}
          <Button disabled={busy || active.items.some((item) => item.countedQuantity === null)} onClick={() => void close()} type="button">
            Concluir conferência
          </Button>
        </div>
      ) : null}
    </section>
  );
}
