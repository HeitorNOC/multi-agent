import { organizationParamsSchema, saveFoodServiceRecipeBodySchema } from "@gestor/contracts";
import { z } from "zod";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

const querySchema = organizationParamsSchema.extend({ branchId: z.uuid(), productId: z.uuid() });
type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = querySchema.parse({
      ...(await route.params),
      branchId: new URL(request.url).searchParams.get("branchId"),
      productId: new URL(request.url).searchParams.get("productId"),
    });
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({ data: await services.listFoodServiceRecipe.execute(params, actor) });
  });
}

export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = saveFoodServiceRecipeBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.saveFoodServiceRecipe.execute({ ...body, ...params }, actor),
    });
  });
}
