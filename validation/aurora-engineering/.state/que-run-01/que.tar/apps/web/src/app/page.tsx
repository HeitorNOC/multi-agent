import Link from "next/link";

const foundations = [
  {
    description: "Membership, permissões e escopo explícito de filiais.",
    title: "Acesso por contexto",
  },
  {
    description: "Entitlements e limites avaliados dentro da transação.",
    title: "Planos sem hardcode",
  },
  {
    description: "RLS, auditoria e outbox em toda mutação relevante.",
    title: "Segurança por padrão",
  },
  {
    description: "Contratos Zod compartilhados entre formulário e API.",
    title: "Validação ponta a ponta",
  },
] as const;

export default function HomePage() {
  return (
    <main className="mx-auto w-full max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
      <section className="grid gap-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-brand-600 text-xs font-bold tracking-[0.18em] uppercase">
            Fundação em desenvolvimento
          </p>
          <div className="flex items-center gap-2">
            <Link
              className="hover:text-brand-700 px-3 py-2 text-sm font-semibold text-slate-600"
              href="/login"
            >
              Entrar
            </Link>
            <Link
              className="bg-brand-600 hover:bg-brand-700 rounded-xl px-4 py-2 text-sm font-semibold text-white transition"
              href="/cadastro"
            >
              Criar conta
            </Link>
          </div>
        </div>
        <h1 className="max-w-4xl text-5xl leading-[0.96] font-semibold tracking-[-0.055em] text-balance sm:text-7xl lg:text-8xl">
          Gestão clara para o negócio real.
        </h1>
        <p className="max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">
          A primeira vertical conecta organização, filiais, permissões, plano, auditoria e
          processamento assíncrono com uma interface simples e consistente.
        </p>
      </section>

      <section
        className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        aria-label="Fundações implementadas"
      >
        {foundations.map((foundation, index) => (
          <article
            className="rounded-2xl border bg-white p-5 shadow-[0_1px_2px_rgb(15_23_42/0.04)]"
            key={foundation.title}
          >
            <span className="text-brand-600 text-xs font-semibold">
              {String(index + 1).padStart(2, "0")}
            </span>
            <h2 className="mt-8 font-semibold text-slate-900">{foundation.title}</h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">{foundation.description}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
