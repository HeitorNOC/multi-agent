"use client";

import { acceptedOrganizationInvitationViewSchema, type ProblemDetails } from "@gestor/contracts";
import { buttonVariants } from "@gestor/ui/components/button";
import { cn } from "@gestor/ui/lib/utils";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

const STORAGE_KEY = "gestor.pendingOrganizationInvitation";

export function AcceptInvitationPanel() {
  const router = useRouter();
  const started = useRef(false);
  const [authenticationRequired, setAuthenticationRequired] = useState(false);
  const [feedback, setFeedback] = useState("Validando convite...");

  const accept = useCallback(
    async (organizationId: string, token: string) => {
      try {
        const response = await fetch("/api/v1/invitations/accept", {
          body: JSON.stringify({ organizationId, token }),
          headers: { "content-type": "application/json" },
          method: "POST",
        });
        const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
        if (response.status === 401) {
          setAuthenticationRequired(true);
          setFeedback("Entre ou crie sua conta com o mesmo e-mail que recebeu o convite.");
          return;
        }
        if (!response.ok) {
          setFeedback(payload.detail ?? "Não foi possível aceitar o convite.");
          return;
        }
        const accepted = acceptedOrganizationInvitationViewSchema.parse(payload.data);
        window.sessionStorage.removeItem(STORAGE_KEY);
        window.history.replaceState(null, "", "/convites/aceitar");
        setFeedback("Convite aceito. Abrindo a empresa...");
        router.replace(`/organizations/${accepted.organizationId}`);
        router.refresh();
      } catch {
        setFeedback("Não foi possível conectar ao servidor. Tente novamente.");
      }
    },
    [router],
  );

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    void Promise.resolve().then(async () => {
      const fragment = window.location.hash.slice(1);
      const stored = window.sessionStorage.getItem(STORAGE_KEY);
      const serialized = fragment || stored;
      if (!serialized) {
        setFeedback("O link do convite está incompleto.");
        return;
      }
      window.sessionStorage.setItem(STORAGE_KEY, serialized);
      const values = new URLSearchParams(serialized);
      const organizationId = values.get("organizationId");
      const token = values.get("token");
      if (!organizationId || !token) {
        setFeedback("O link do convite está incompleto.");
        return;
      }
      await accept(organizationId, token);
    });
  }, [accept]);

  return (
    <div className="grid gap-5">
      <p className="text-sm text-slate-700" role="status">
        {feedback}
      </p>
      {authenticationRequired ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <Link className={buttonVariants()} href="/login?returnTo=%2Fconvites%2Faceitar">
            Entrar
          </Link>
          <Link
            className={cn(buttonVariants({ variant: "outline" }))}
            href="/cadastro?returnTo=%2Fconvites%2Faceitar"
          >
            Criar conta
          </Link>
        </div>
      ) : null}
    </div>
  );
}
