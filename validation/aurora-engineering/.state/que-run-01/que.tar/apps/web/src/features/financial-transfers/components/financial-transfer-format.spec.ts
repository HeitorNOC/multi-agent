import { describe, expect, it } from "vitest";

import { formatBrl, formatDateTime } from "./financial-transfer-format";

describe("financial transfer formatting", () => {
  it("preserves canonical precision and negative signs", () => {
    expect(formatBrl("1234.5000")).toBe("R$ 1.234,50");
    expect(formatBrl("-10.2500")).toBe("- R$ 10,25");
    expect(formatBrl("7")).toBe("R$ 7,00");
  });

  it("formats date and time for pt-BR", () => {
    expect(formatDateTime("2026-08-11T15:30:00.000Z")).toMatch(/^11\/08\/2026/);
  });
});
