"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createSupplierBodySchema,
  supplierListSchema,
  supplierViewSchema,
  type CreateSupplierBody,
  type ProblemDetails,
  type SupplierView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useForm } from "react-hook-form";

import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

const defaults: CreateSupplierBody = {
  document: "",
  email: "",
  name: "",
  notes: "",
  phone: "",
};

export function SupplierConfigurations({ organizationId }: { organizationId: string }) {
  const [suppliers, setSuppliers] = useState<readonly SupplierView[] | null>(null);
  const [editing, setEditing] = useState<SupplierView | null>(null);
  const [query, setQuery] = useState("");
  const [feedback, setFeedback] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateSupplierBody>({
    defaultValues: defaults,
    resolver: zodResolver(createSupplierBodySchema),
  });

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/suppliers`, {
          signal: controller.signal,
        });
        if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
        const payload = (await response.json()) as { data: unknown };
        setSuppliers(supplierListSchema.parse(payload.data));
      } catch (error) {
        if (!controller.signal.aborted) {
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar os fornecedores.",
          );
        }
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId]);

  const visibleSuppliers = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return suppliers ?? [];
    return (suppliers ?? []).filter((supplier) =>
      [supplier.name, supplier.document, supplier.email, supplier.phone].some((value) =>
        value?.toLowerCase().includes(normalized),
      ),
    );
  }, [query, suppliers]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);
    try {
      const response = await fetch(
        editing
          ? `/api/v1/organizations/${organizationId}/suppliers/${editing.id}`
          : `/api/v1/organizations/${organizationId}/suppliers`,
        {
          body: JSON.stringify(
            editing ? { ...values, expectedUpdatedAt: editing.updatedAt } : values,
          ),
          headers: editing
            ? { "content-type": "application/json" }
            : { "content-type": "application/json", "idempotency-key": idempotencyKey },
          method: editing ? "PATCH" : "POST",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const supplier = supplierViewSchema.parse(payload.data);
      setSuppliers((current) =>
        editing
          ? (current ?? []).map((item) => (item.id === supplier.id ? supplier : item))
          : [...(current ?? []), supplier],
      );
      if (!editing) setIdempotencyKey(crypto.randomUUID());
      setFeedback(editing ? "Fornecedor atualizado." : "Fornecedor cadastrado.");
      setEditing(null);
      reset(defaults);
    } catch {
      setError("root", { message: "Não foi possível conectar ao servidor.", type: "network" });
    }
  });

  function beginEditing(supplier: SupplierView) {
    setEditing(supplier);
    reset({
      document: supplier.document ?? "",
      email: supplier.email ?? "",
      name: supplier.name,
      notes: supplier.notes ?? "",
      phone: supplier.phone ?? "",
    });
  }

  async function toggleStatus(supplier: SupplierView) {
    setUpdatingId(supplier.id);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/suppliers/${supplier.id}`,
        {
          body: JSON.stringify({
            expectedUpdatedAt: supplier.updatedAt,
            status: supplier.status === "ACTIVE" ? "INACTIVE" : "ACTIVE",
          }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      const updated = supplierViewSchema.parse(payload.data);
      setSuppliers((current) =>
        (current ?? []).map((item) => (item.id === updated.id ? updated : item)),
      );
      setFeedback(updated.status === "ACTIVE" ? "Fornecedor reativado." : "Fornecedor inativado.");
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível atualizar o fornecedor.",
      );
    } finally {
      setUpdatingId(null);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
      <section className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)]">
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          {editing ? "Editar fornecedor" : "Novo fornecedor"}
        </p>
        <h2 className="mt-2 text-xl font-semibold">Dados essenciais</h2>
        <form className="mt-6 grid gap-4" noValidate onSubmit={submit}>
          <Field error={errors.name?.message} id="supplier-name" label="Nome ou razão social">
            <Input id="supplier-name" {...register("name")} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field error={errors.phone?.message} id="supplier-phone" label="Telefone">
              <Input id="supplier-phone" {...register("phone")} />
            </Field>
            <Field error={errors.email?.message} id="supplier-email" label="E-mail">
              <Input id="supplier-email" type="email" {...register("email")} />
            </Field>
          </div>
          <Field error={errors.document?.message} id="supplier-document" label="CPF ou CNPJ">
            <Input id="supplier-document" {...register("document")} />
          </Field>
          <Field error={errors.notes?.message} id="supplier-notes" label="Observações">
            <textarea
              className="min-h-24 rounded-xl border px-3 py-2 text-sm"
              id="supplier-notes"
              {...register("notes")}
            />
          </Field>
          {errors.root?.message ? (
            <p className="text-sm text-red-700" role="alert">
              {errors.root.message}
            </p>
          ) : null}
          <div className="flex gap-2">
            <Button disabled={isSubmitting} type="submit">
              {isSubmitting
                ? "Salvando..."
                : editing
                  ? "Salvar alterações"
                  : "Cadastrar fornecedor"}
            </Button>
            {editing ? (
              <Button
                onClick={() => {
                  setEditing(null);
                  reset(defaults);
                }}
                type="button"
                variant="outline"
              >
                Cancelar
              </Button>
            ) : null}
          </div>
        </form>
      </section>
      <section className="grid content-start gap-4">
        <h2 className="text-xl font-semibold">Fornecedores cadastrados</h2>
        <Label className="sr-only" htmlFor="supplier-search">
          Buscar fornecedor
        </Label>
        <Input
          id="supplier-search"
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar por nome, contato ou documento"
          value={query}
        />
        {feedback ? (
          <p className="rounded-xl border px-4 py-3 text-sm" role="status">
            {feedback}
          </p>
        ) : null}
        {!suppliers ? <p className="text-sm text-slate-500">Carregando fornecedores...</p> : null}
        {suppliers && visibleSuppliers.length === 0 ? (
          <p className="rounded-2xl border border-dashed p-6 text-sm text-slate-600">
            Nenhum fornecedor encontrado.
          </p>
        ) : null}
        {visibleSuppliers.map((supplier) => (
          <article className="rounded-2xl border bg-white p-5" key={supplier.id}>
            <div className="flex justify-between gap-4">
              <div>
                <h3 className="font-semibold">{supplier.name}</h3>
                <p className="mt-1 text-sm text-slate-600">{supplier.phone ?? supplier.email}</p>
              </div>
              <span
                className={
                  supplier.status === "ACTIVE"
                    ? "text-xs font-semibold text-emerald-700"
                    : "text-xs font-semibold text-slate-500"
                }
              >
                {supplier.status === "ACTIVE" ? "Ativo" : "Inativo"}
              </span>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <CatalogFilesButton
                allowImage={false}
                itemId={supplier.id}
                organizationId={organizationId}
                segment="suppliers"
              />
              <Button
                onClick={() => beginEditing(supplier)}
                size="sm"
                type="button"
                variant="outline"
              >
                Editar
              </Button>
              <Button
                disabled={updatingId === supplier.id}
                onClick={() => void toggleStatus(supplier)}
                size="sm"
                type="button"
                variant="outline"
              >
                {updatingId === supplier.id
                  ? "Salvando..."
                  : supplier.status === "ACTIVE"
                    ? "Inativar"
                    : "Reativar"}
              </Button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

function Field({
  children,
  error,
  id,
  label,
}: {
  children: ReactNode;
  error: string | undefined;
  id: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? (
        <p className="text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
