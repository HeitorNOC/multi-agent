import { describe, expect, it } from "vitest";

import {
  financialCategoryTypeDescriptions,
  financialCategoryTypeOptions,
  financialOutflowCategoryTypes,
} from "./financial-category-options";

describe("financial category options", () => {
  it("keeps labels, descriptions and outflow classification aligned", () => {
    expect(financialCategoryTypeOptions.map(([type]) => type)).toEqual([
      "REVENUE",
      "COST",
      "EXPENSE",
      "TAX",
      "OTHER",
    ]);
    expect(financialCategoryTypeDescriptions.REVENUE).toContain("Entrada");
    expect(financialOutflowCategoryTypes).toEqual(new Set(["COST", "EXPENSE", "TAX"]));
  });
});
