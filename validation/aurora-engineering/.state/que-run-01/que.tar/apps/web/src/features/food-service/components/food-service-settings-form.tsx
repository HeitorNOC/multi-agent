import type { FoodServiceSettingsView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";

type SettingsValues = Pick<
  FoodServiceSettingsView,
  | "acceptsArrangedDelivery"
  | "acceptsCounter"
  | "acceptsDelivery"
  | "acceptsDineIn"
  | "acceptsPickup"
  | "defaultPreparationMinutes"
  | "requiresManualAcceptance"
  | "requiresPrepayment"
  | "requiresInventoryCountBeforeCashClose"
  | "stockConsumptionMoment"
>;

export function FoodServiceSettingsForm({
  onSubmit,
  settings,
}: {
  onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
  settings: SettingsValues;
}) {
  return (
    <form className="grid gap-4 rounded-2xl border bg-white p-5" onSubmit={onSubmit}>
      <div>
        <h2 className="text-lg font-semibold">Canais e preparo</h2>
        <p className="mt-1 text-sm text-slate-600">
          Escolha somente as modalidades que a empresa realmente atende.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {(
          [
            ["acceptsDineIn", "Salão"],
            ["acceptsCounter", "Balcão"],
            ["acceptsPickup", "Retirada"],
            ["acceptsDelivery", "Entrega própria"],
            ["acceptsArrangedDelivery", "Entrega combinada"],
            ["requiresManualAcceptance", "Confirmar pedido antes do preparo"],
            ["requiresPrepayment", "Exigir pagamento antes do preparo"],
            ["requiresInventoryCountBeforeCashClose", "Exigir conferência de estoque antes de fechar o caixa"],
          ] as const
        ).map(([key, label]) => (
          <label className="flex items-center gap-3 rounded-xl border p-3 text-sm" key={key}>
            <input defaultChecked={settings[key]} name={key} type="checkbox" />
            {label}
          </label>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1.5">
          <Label htmlFor="prep">Tempo padrão de preparo (minutos)</Label>
          <input
            className="h-10 rounded-xl border px-3"
            defaultValue={settings.defaultPreparationMinutes}
            id="prep"
            min="1"
            name="defaultPreparationMinutes"
            type="number"
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="stock">Baixa de estoque</Label>
          <select
            className="h-10 rounded-xl border px-3"
            defaultValue={settings.stockConsumptionMoment}
            id="stock"
            name="stockConsumptionMoment"
          >
            <option value="NONE">Não baixar automaticamente</option>
            <option value="ON_ACCEPTANCE">Ao aceitar pedido</option>
            <option value="ON_PREPARATION">Ao iniciar preparo</option>
            <option value="ON_FULFILLMENT">Ao finalizar atendimento</option>
          </select>
        </div>
      </div>
      <Button type="submit">Salvar configurações</Button>
    </form>
  );
}
