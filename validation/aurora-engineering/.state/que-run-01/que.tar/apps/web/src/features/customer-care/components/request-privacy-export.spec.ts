import { describe, expect, it } from "vitest";

import {
  createPrivacyExportReportBody,
  privacyExportIdempotencyKey,
} from "./request-privacy-export";

const customerId = "20000000-0000-4000-8000-000000000001";
const requestId = "30000000-0000-4000-8000-000000000001";

describe("privacy export report request", () => {
  it("creates a private asynchronous customer export scoped to the data subject", () => {
    expect(createPrivacyExportReportBody(customerId)).toEqual({
      filters: { customerId },
      format: "XLSX",
      reportType: "CUSTOMERS",
    });
    expect(privacyExportIdempotencyKey(requestId)).toBe(`lgpd-export-${requestId}`);
  });

  it("rejects invalid tenant data identifiers before calling the API", () => {
    expect(() => createPrivacyExportReportBody("invalid")).toThrow();
    expect(() => privacyExportIdempotencyKey("invalid")).toThrow();
  });
});
