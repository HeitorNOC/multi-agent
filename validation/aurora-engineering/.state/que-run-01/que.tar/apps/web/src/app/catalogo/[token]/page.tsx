import type { Metadata } from "next";

import { PublicCatalogLink } from "@/features/catalog/components/public-catalog-link";

export const metadata: Metadata = { title: "Catálogo | Gestor" };

type PublicCatalogPageProps = { params: Promise<{ token: string }> };

export default async function PublicCatalogPage({ params }: PublicCatalogPageProps) {
  const { token } = await params;
  return <PublicCatalogLink token={token} />;
}
