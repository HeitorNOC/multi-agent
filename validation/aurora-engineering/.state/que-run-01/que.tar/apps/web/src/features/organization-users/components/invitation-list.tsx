"use client";

import type { OrganizationInvitationView, ProblemDetails } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useState } from "react";

const statusLabels: Record<OrganizationInvitationView["status"], string> = {
  ACCEPTED: "Aceito",
  EXPIRED: "Expirado",
  PENDING: "Aguardando aceite",
  REVOKED: "Revogado",
};

export function InvitationList({
  invitations,
  onCompleted,
  organizationId,
}: {
  invitations: readonly OrganizationInvitationView[];
  onCompleted: () => void;
  organizationId: string;
}) {
  const [feedback, setFeedback] = useState("");
  if (invitations.length === 0) return null;

  async function revoke(invitationId: string) {
    setFeedback("");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/invitations/${invitationId}/revoke`,
      { headers: { "idempotency-key": crypto.randomUUID() }, method: "POST" },
    );
    const payload = (await response.json()) as Partial<ProblemDetails>;
    if (!response.ok) {
      setFeedback(payload.detail ?? "Não foi possível revogar o convite.");
      return;
    }
    setFeedback("Convite revogado.");
    onCompleted();
  }

  return (
    <section className="grid gap-3">
      <h2 className="text-xl font-semibold">Convites</h2>
      <div className="grid gap-3 md:grid-cols-2">
        {invitations.map((invitation) => (
          <article className="rounded-2xl border bg-white p-5 shadow-sm" key={invitation.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold">{invitation.email}</h3>
                <p className="text-sm text-slate-600">{invitation.roleName}</p>
              </div>
              <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium">
                {statusLabels[invitation.status]}
              </span>
            </div>
            {invitation.status === "PENDING" && invitation.deliveryStatus === "FAILED" ? (
              <p className="mt-3 text-sm text-amber-700">
                O convite foi salvo, mas o e-mail não foi entregue. Convide novamente para gerar um
                novo link.
              </p>
            ) : null}
            {invitation.status === "PENDING" ? (
              <Button
                className="mt-4"
                onClick={() => void revoke(invitation.id)}
                type="button"
                variant="outline"
              >
                Revogar convite
              </Button>
            ) : null}
          </article>
        ))}
      </div>
      {feedback ? (
        <p className="text-sm" role="status">
          {feedback}
        </p>
      ) : null}
    </section>
  );
}
