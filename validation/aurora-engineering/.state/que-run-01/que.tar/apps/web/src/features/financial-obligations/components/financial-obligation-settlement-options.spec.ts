import { describe, expect, it } from "vitest";

import {
  availableSettlementAccounts,
  availableSettlementMethods,
} from "./financial-obligation-settlement-options";

const method = (overrides: Record<string, unknown>) =>
  ({
    allowsPayments: true,
    allowsReceipts: true,
    id: crypto.randomUUID(),
    method: "PIX",
    status: "ACTIVE",
    ...overrides,
  }) as never;

const account = (id: string, type: string, branchId: string | null, status = "ACTIVE") =>
  ({ branchId, id, status, type }) as never;

describe("financial obligation settlement options", () => {
  it("filters methods by direction and active status", () => {
    const methods = [
      method({ id: "pix", method: "PIX" }),
      method({ allowsPayments: false, id: "receipt", method: "CASH" }),
      method({ id: "card", method: "CARD" }),
      method({ id: "inactive", status: "INACTIVE" }),
    ];

    expect(availableSettlementMethods(methods, "RECEIVABLE").map(({ id }) => id)).toEqual([
      "pix",
      "receipt",
      "card",
    ]);
    expect(availableSettlementMethods(methods, "PAYABLE").map(({ id }) => id)).toEqual(["pix"]);
  });

  it("matches account type and branch to the selected method", () => {
    const accounts = [
      account("cash-a", "CASH", "branch-a"),
      account("cash-b", "CASH", "branch-b"),
      account("bank-global", "BANK", null),
      account("acquirer", "ACQUIRER", null),
      account("inactive", "BANK", null, "INACTIVE"),
    ];

    expect(availableSettlementAccounts(accounts, "branch-a", "CASH").map(({ id }) => id)).toEqual([
      "cash-a",
    ]);
    expect(availableSettlementAccounts(accounts, "branch-a", "PIX").map(({ id }) => id)).toEqual([
      "bank-global",
    ]);
    expect(availableSettlementAccounts(accounts, "branch-a", "CARD").map(({ id }) => id)).toEqual([
      "acquirer",
    ]);
    expect(availableSettlementAccounts(accounts, "branch-a", undefined)).toEqual([]);
  });
});
