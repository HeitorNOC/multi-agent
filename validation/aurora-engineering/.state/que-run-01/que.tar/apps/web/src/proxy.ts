import { NextResponse, type NextRequest } from "next/server";

const SESSION_COOKIE_NAMES = new Set(["gestor.session_token", "__Secure-gestor.session_token"]);

export function proxy(request: NextRequest) {
  if (!hasAuthenticationCredential(request)) {
    if (request.nextUrl.pathname.startsWith("/api/")) {
      return Response.json(
        {
          code: "AUTHENTICATION_REQUIRED",
          correlationId: crypto.randomUUID(),
          detail: "Autenticação necessária.",
          instance: request.nextUrl.pathname,
          status: 401,
          title: "Autenticação necessária",
          type: "https://api.gestor.local/problems/authentication-required",
        },
        { status: 401 },
      );
    }

    const login = new URL("/login", request.url);
    login.searchParams.set("returnTo", `${request.nextUrl.pathname}${request.nextUrl.search}`);
    return NextResponse.redirect(login);
  }

  const response = NextResponse.next();
  response.headers.set("permissions-policy", "camera=(), microphone=(), geolocation=()");
  response.headers.set("referrer-policy", "strict-origin-when-cross-origin");
  response.headers.set("x-content-type-options", "nosniff");
  response.headers.set("x-frame-options", "DENY");
  return response;
}

function hasAuthenticationCredential(request: NextRequest): boolean {
  if (
    process.env.NODE_ENV !== "production" &&
    process.env.ALLOW_INSECURE_DEV_AUTH === "true" &&
    request.headers.has("x-user-id")
  ) {
    return true;
  }

  return request.cookies
    .getAll()
    .some(
      ({ name }) =>
        SESSION_COOKIE_NAMES.has(name) ||
        name.startsWith("gestor.session_token.") ||
        name.startsWith("__Secure-gestor.session_token."),
    );
}

export const config = {
  matcher: [
    "/organizations/:path*",
    "/platform/:path*",
    "/api/v1/organizations/:path*",
    "/api/v1/platform/:path*",
    "/api/v1/invitations/:path*",
  ],
};
