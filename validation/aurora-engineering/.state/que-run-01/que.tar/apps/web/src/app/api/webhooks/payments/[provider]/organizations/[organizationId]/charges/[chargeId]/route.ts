import { paymentWebhookParamsSchema } from "@gestor/contracts";
import { AuthenticationError } from "@gestor/kernel";

import { handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ chargeId: string; organizationId: string; provider: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const params = paymentWebhookParamsSchema.parse(await route.params);
      const signature = request.headers.get("x-payment-signature");
      if (!signature)
        throw new AuthenticationError(
          "PAYMENT_WEBHOOK_SIGNATURE_REQUIRED",
          "A assinatura do evento de pagamento é obrigatória.",
        );
      return Response.json({
        data: await services.processTerminalPaymentWebhook.execute({
          ...params,
          rawBody: await request.text(),
          signature,
        }),
      });
    },
    { authentication: "PUBLIC" },
  );
}
