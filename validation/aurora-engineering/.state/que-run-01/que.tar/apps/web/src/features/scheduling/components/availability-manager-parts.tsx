"use client";

import type {
  AppointmentResourceView,
  AvailabilityRuleView,
  SchedulingProfessionalView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

import { LoadingRows } from "@/components/loading-skeleton";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import type { FormEvent } from "react";

const weekdays = [
  "Domingo",
  "Segunda-feira",
  "Terça-feira",
  "Quarta-feira",
  "Quinta-feira",
  "Sexta-feira",
  "Sábado",
];
type TargetType = "professional" | "resource";
type Target = AppointmentResourceView | SchedulingProfessionalView;

type AvailabilityFormsProps = {
  branchId: string;
  dayOfWeek: string;
  editingRule: AvailabilityRuleView | null;
  endsAt: string;
  onCancelEdit(): void;
  onCreateResource(event: FormEvent<HTMLFormElement>): Promise<void>;
  onCreateRule(event: FormEvent<HTMLFormElement>): Promise<void>;
  onDayOfWeekChange(value: string): void;
  onEndsAtChange(value: string): void;
  onResourceNameChange(value: string): void;
  onStartsAtChange(value: string): void;
  onTargetIdChange(value: string): void;
  onTargetTypeChange(value: TargetType): void;
  resourceName: string;
  resources: readonly AppointmentResourceView[];
  saving: boolean;
  startsAt: string;
  targetId: string;
  targetOptions: readonly Target[];
  targetType: TargetType;
};

export function AvailabilityForms(props: AvailabilityFormsProps) {
  const {
    branchId,
    dayOfWeek,
    editingRule,
    endsAt,
    resourceName,
    resources,
    saving,
    startsAt,
    targetId,
    targetOptions,
    targetType,
  } = props;
  return (
    <div className="grid gap-5 border-t pt-5 lg:grid-cols-2">
      <form
        className="grid content-start gap-3"
        onSubmit={(event) => void props.onCreateResource(event)}
      >
        <div>
          <h3 className="font-semibold text-slate-950">Novo recurso físico</h3>
          <p className="mt-1 text-sm text-slate-600">Ex.: Sala 1, cadeira ou equipamento.</p>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="resource-name">Nome do recurso</Label>
          <Input
            id="resource-name"
            maxLength={120}
            onChange={(event) => props.onResourceNameChange(event.target.value)}
            value={resourceName}
          />
        </div>
        <Button disabled={saving || !branchId} type="submit">
          {saving ? "Salvando..." : "Adicionar recurso"}
        </Button>
        {resources.length ? (
          <ul aria-label="Recursos cadastrados" className="divide-y rounded-xl border text-sm">
            {resources.map((resource) => (
              <li className="flex items-center justify-between gap-3 px-3 py-2" key={resource.id}>
                <span>{resource.name}</span>
                <span className="text-xs font-medium text-slate-500">
                  {resource.status === "ACTIVE" ? "Ativo" : "Inativo"}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-500">Nenhum recurso cadastrado nesta filial.</p>
        )}
      </form>
      <form
        className="grid content-start gap-3"
        onSubmit={(event) => void props.onCreateRule(event)}
      >
        <div>
          <h3 className="font-semibold text-slate-950">Novo horário disponível</h3>
          <p className="mt-1 text-sm text-slate-600">
            Os agendamentos fora deste período serão bloqueados.
          </p>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="availability-target-type">Aplicar a</Label>
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="availability-target-type"
            onChange={(event) => props.onTargetTypeChange(event.target.value as TargetType)}
            value={targetType}
          >
            <option value="professional">Profissional</option>
            <option value="resource">Recurso físico</option>
          </select>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="availability-target">
            {targetType === "professional" ? "Profissional" : "Recurso"}
          </Label>
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="availability-target"
            onChange={(event) => props.onTargetIdChange(event.target.value)}
            required
            value={targetId}
          >
            <option value="">Selecione uma opção</option>
            {targetOptions.map((target) => (
              <option key={target.id} value={target.id}>
                {target.name}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="grid gap-1.5">
            <Label htmlFor="availability-day">Dia</Label>
            <select
              className="h-10 rounded-xl border bg-white px-3 text-sm"
              id="availability-day"
              onChange={(event) => props.onDayOfWeekChange(event.target.value)}
              value={dayOfWeek}
            >
              {weekdays.map((day, index) => (
                <option key={day} value={index}>
                  {day}
                </option>
              ))}
            </select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="availability-start">Início</Label>
            <Input
              id="availability-start"
              onChange={(event) => props.onStartsAtChange(event.target.value)}
              required
              type="time"
              value={startsAt}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="availability-end">Fim</Label>
            <Input
              id="availability-end"
              onChange={(event) => props.onEndsAtChange(event.target.value)}
              required
              type="time"
              value={endsAt}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button disabled={saving || !branchId || !targetId} type="submit">
            {saving ? "Salvando..." : editingRule ? "Salvar alterações" : "Salvar disponibilidade"}
          </Button>
          {editingRule ? (
            <Button disabled={saving} onClick={props.onCancelEdit} type="button" variant="outline">
              Cancelar edição
            </Button>
          ) : null}
        </div>
      </form>
    </div>
  );
}

type AvailabilityRuleListProps = {
  onEdit(rule: AvailabilityRuleView): void;
  onRemove(rule: AvailabilityRuleView): Promise<void>;
  rules: readonly AvailabilityRuleView[] | null;
  saving: boolean;
};
export function AvailabilityRuleList({
  onEdit,
  onRemove,
  rules,
  saving,
}: AvailabilityRuleListProps) {
  return (
    <div className="border-t pt-5">
      <h3 className="font-semibold text-slate-950">Horários configurados</h3>
      {rules === null ? (
        <div className="mt-3">
          <LoadingRows rows={2} />
        </div>
      ) : rules.length === 0 ? (
        <p className="mt-3 text-sm text-slate-500">
          Nenhum horário disponível configurado nesta filial.
        </p>
      ) : (
        <ul className="mt-3 grid gap-2">
          {rules.map((rule) => (
            <li
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3 text-sm"
              key={rule.id}
            >
              <span>
                {weekdays[rule.dayOfWeek]} · {minutesToTime(rule.startsAtMinute)}–
                {minutesToTime(rule.endsAtMinute)} ·{" "}
                {rule.professionalUserId ? "Profissional" : "Recurso"}
              </span>
              <div className="flex gap-2">
                <Button
                  disabled={saving}
                  onClick={() => onEdit(rule)}
                  type="button"
                  variant="outline"
                >
                  Editar
                </Button>
                <Button
                  disabled={saving}
                  onClick={() => void onRemove(rule)}
                  type="button"
                  variant="outline"
                >
                  Remover
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function minutesToTime(value: number): string {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}
