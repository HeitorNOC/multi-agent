"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  reportJobViewSchema,
  type BranchView,
  type BasicReportType,
  type ProblemDetails,
  type ReportJobView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import {
  createBasicReportBody,
  reportRequestFingerprint,
  requestReportFormDefaults,
  requestReportFormSchema,
  type RequestReportFormValues,
} from "./request-report";

type RequestReportFormProps = {
  availableReportTypes: readonly BasicReportType[];
  onRequested: (report: ReportJobView) => void;
  organizationId: string;
};

type PendingRequest = { fingerprint: string; idempotencyKey: string };

export function RequestReportForm({
  availableReportTypes,
  onRequested,
  organizationId,
}: RequestReportFormProps) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [feedback, setFeedback] = useState("");
  const [pendingRequest, setPendingRequest] = useState<PendingRequest | null>(null);
  const form = useForm<RequestReportFormValues>({
    defaultValues: requestReportFormDefaults,
    resolver: zodResolver(requestReportFormSchema),
  });
  const reportType = useWatch({ control: form.control, name: "reportType" });

  useEffect(() => {
    const first = REPORT_OPTIONS.find(({ value }) => availableReportTypes.includes(value));
    if (first && !availableReportTypes.includes(reportType)) {
      form.setValue("reportType", first.value);
      form.setValue("status", "");
    }
  }, [availableReportTypes, form, reportType]);

  useEffect(() => {
    const controller = new AbortController();
    void loadBranches(organizationId, controller.signal)
      .then(setBranches)
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(errorMessage(error, "Não foi possível carregar as filiais."));
      });
    return () => controller.abort();
  }, [organizationId]);

  async function submit(values: RequestReportFormValues) {
    setFeedback("");
    const body = createBasicReportBody(values);
    const fingerprint = reportRequestFingerprint(body);
    const request =
      pendingRequest?.fingerprint === fingerprint
        ? pendingRequest
        : { fingerprint, idempotencyKey: crypto.randomUUID() };
    setPendingRequest(request);

    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/reports`, {
        body: JSON.stringify(body),
        headers: {
          "content-type": "application/json",
          "idempotency-key": request.idempotencyKey,
        },
        method: "POST",
      });
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        if (response.status < 500) setPendingRequest(null);
        throw new Error(payload.detail ?? "Não foi possível solicitar o relatório.");
      }
      const report = reportJobViewSchema.parse(payload.data);
      setPendingRequest(null);
      setFeedback("Relatório solicitado. A geração continuará em segundo plano.");
      onRequested(report);
    } catch (error) {
      setFeedback(errorMessage(error, "Não foi possível solicitar o relatório."));
    }
  }

  return (
    <section
      className="rounded-2xl border bg-white p-5 shadow-sm"
      aria-labelledby="request-report-title"
    >
      <h2 className="text-xl font-semibold" id="request-report-title">
        Solicitar relatório
      </h2>
      <p className="mt-1 text-sm text-slate-600">
        O arquivo será preparado em segundo plano e ficará disponível nesta tela.
      </p>
      <form
        className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        onSubmit={form.handleSubmit(submit)}
      >
        <Field label="Relatório" htmlFor="report-type">
          <select
            className="h-8 w-full rounded-lg border bg-transparent px-2.5 text-sm"
            id="report-type"
            {...form.register("reportType", {
              onChange: () => form.setValue("status", ""),
            })}
          >
            {REPORT_OPTIONS.filter(({ value }) => availableReportTypes.includes(value)).map(
              ({ label, value }) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ),
            )}
          </select>
        </Field>
        <Field label="Filial" htmlFor="report-branch">
          <select
            className="h-8 w-full rounded-lg border bg-transparent px-2.5 text-sm"
            id="report-branch"
            {...form.register("branchId")}
          >
            <option value="">Todas as filiais permitidas</option>
            {branches
              .filter(({ status }) => status === "ACTIVE")
              .map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
          </select>
        </Field>
        {reportType !== "INVENTORY" ? (
          <>
            <Field label="Data inicial" htmlFor="report-from">
              <Input id="report-from" type="date" {...form.register("from")} />
            </Field>
            <Field error={form.formState.errors.to?.message} label="Data final" htmlFor="report-to">
              <Input
                aria-invalid={Boolean(form.formState.errors.to)}
                id="report-to"
                type="date"
                {...form.register("to")}
              />
            </Field>
          </>
        ) : null}
        {reportType !== "SIMPLIFIED_INCOME_STATEMENT" ? (
          <Field label="Status" htmlFor="report-status">
            <select
              className="h-8 w-full rounded-lg border bg-transparent px-2.5 text-sm"
              id="report-status"
              {...form.register("status")}
            >
              <option value="">{reportType === "INVENTORY" ? "Ativos" : "Todos"}</option>
              {statusOptions(reportType).map(({ label, value }) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        <Field label="Formato" htmlFor="report-format">
          <select
            className="h-8 w-full rounded-lg border bg-transparent px-2.5 text-sm"
            id="report-format"
            {...form.register("format")}
          >
            <option value="CSV">CSV</option>
            <option value="XLSX">Excel (XLSX)</option>
            <option value="PDF">PDF</option>
          </select>
        </Field>
        <div className="sm:col-span-2 lg:col-span-4">
          <Button
            disabled={form.formState.isSubmitting || availableReportTypes.length === 0}
            type="submit"
          >
            {form.formState.isSubmitting ? "Solicitando..." : "Gerar relatório"}
          </Button>
        </div>
      </form>
      {availableReportTypes.length === 0 ? (
        <p className="mt-4 text-sm text-slate-600">
          Nenhum relatório está disponível para o seu acesso.
        </p>
      ) : null}
      {feedback ? (
        <p className="mt-4 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
    </section>
  );
}

const REPORT_OPTIONS: readonly {
  label: string;
  value: RequestReportFormValues["reportType"];
}[] = [
  { label: "Vendas", value: "SALES" },
  { label: "Compras", value: "PURCHASES" },
  { label: "Estoque atual", value: "INVENTORY" },
  { label: "Contas a pagar", value: "PAYABLES" },
  { label: "Contas a receber", value: "RECEIVABLES" },
  { label: "Caixa", value: "CASH" },
  { label: "Movimentações financeiras", value: "FINANCIAL_MOVEMENTS" },
  { label: "Clientes", value: "CUSTOMERS" },
  { label: "Fornecedores", value: "SUPPLIERS" },
  { label: "DRE simplificada", value: "SIMPLIFIED_INCOME_STATEMENT" },
];

function statusOptions(reportType: RequestReportFormValues["reportType"]) {
  if (reportType === "PURCHASES") {
    return [
      { label: "Rascunho", value: "DRAFT" },
      { label: "Pedido realizado", value: "ORDERED" },
      { label: "Parcialmente recebida", value: "PARTIALLY_RECEIVED" },
      { label: "Recebida", value: "RECEIVED" },
      { label: "Cancelada", value: "CANCELLED" },
    ];
  }
  if (reportType === "INVENTORY") {
    return [{ label: "Inativo", value: "INACTIVE" }];
  }
  if (reportType === "PAYABLES" || reportType === "RECEIVABLES") {
    return [
      { label: "Pendente", value: "PENDING" },
      { label: "Parcial", value: "PARTIAL" },
      { label: "Liquidado", value: "SETTLED" },
      { label: "Cancelado", value: "CANCELLED" },
      { label: "Revertido", value: "REVERSED" },
    ];
  }
  if (reportType === "CASH") {
    return [
      { label: "Aberto", value: "OPEN" },
      { label: "Em conferência", value: "RECONCILING" },
      { label: "Fechado", value: "CLOSED" },
    ];
  }
  if (reportType === "FINANCIAL_MOVEMENTS") {
    return [
      { label: "Entrada", value: "CREDIT" },
      { label: "Saída", value: "DEBIT" },
    ];
  }
  if (reportType === "CUSTOMERS" || reportType === "SUPPLIERS") {
    return [
      { label: "Ativo", value: "ACTIVE" },
      { label: "Inativo", value: "INACTIVE" },
    ];
  }
  return [
    { label: "Concluída", value: "COMPLETED" },
    { label: "Cancelada", value: "CANCELLED" },
    { label: "Parcialmente devolvida", value: "PARTIALLY_RETURNED" },
    { label: "Totalmente devolvida", value: "FULLY_RETURNED" },
  ];
}

function Field({
  children,
  error,
  htmlFor,
  label,
}: {
  children: React.ReactNode;
  error?: string | undefined;
  htmlFor: string;
  label: string;
}) {
  return (
    <div className="grid content-start gap-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {error ? (
        <p className="text-xs text-red-700" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

async function loadBranches(
  organizationId: string,
  signal: AbortSignal,
): Promise<readonly BranchView[]> {
  const response = await fetch(`/api/v1/organizations/${organizationId}/branches`, { signal });
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar as filiais.");
  return branchListSchema.parse(payload.data);
}

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}
