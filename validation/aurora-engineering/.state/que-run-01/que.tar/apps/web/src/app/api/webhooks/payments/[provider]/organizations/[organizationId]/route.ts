import { terminalProviderSchema } from "@gestor/contracts";
import { AuthenticationError } from "@gestor/kernel";
import { z } from "zod";

import { handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

const paramsSchema = z.object({ organizationId: z.uuid(), provider: terminalProviderSchema });

type RouteParameters = {
  params: Promise<{ organizationId: string; provider: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const params = paramsSchema.parse(await route.params);
      if (params.provider === "SANDBOX")
        throw new AuthenticationError(
          "PAYMENT_WEBHOOK_CHARGE_REQUIRED",
          "Use a rota de cobrança para eventos do ambiente de testes.",
        );
      const signature = request.headers.get(
        params.provider === "STRIPE" ? "stripe-signature" : "x-signature",
      );
      if (!signature)
        throw new AuthenticationError(
          "PAYMENT_WEBHOOK_SIGNATURE_REQUIRED",
          "A assinatura do evento de pagamento é obrigatória.",
        );
      const url = new URL(request.url);
      const dataId = url.searchParams.get("data.id");
      const requestId = request.headers.get("x-request-id");
      return Response.json({
        data: await services.processTerminalPaymentWebhook.execute({
          ...params,
          ...(dataId ? { dataId } : {}),
          rawBody: await request.text(),
          ...(requestId ? { requestId } : {}),
          signature,
        }),
      });
    },
    { authentication: "PUBLIC" },
  );
}
