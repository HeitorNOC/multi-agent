import type { Metadata } from "next";
import { isGoogleAuthConfigured } from "@gestor/config";
import { connection } from "next/server";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { LoginForm } from "@/features/auth/components/login-form";
import { FormFeedback } from "@/features/auth/components/form-feedback";
import { safeReturnTo } from "@/features/auth/return-to";

export const metadata: Metadata = {
  title: "Entrar | Gestor",
};

type LoginPageProps = {
  searchParams: Promise<{
    emailVerified?: string;
    oauthError?: string;
    returnTo?: string;
  }>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  await connection();
  const params = await searchParams;

  return (
    <AuthShell
      description="Acesse sua empresa com seu e-mail e senha."
      eyebrow="Bem-vindo de volta"
      title="Entre na sua conta"
    >
      <div className="grid gap-5">
        {params.oauthError === "1" ? (
          <FormFeedback kind="error">
            Não foi possível entrar com o Google. Tente novamente ou use e-mail e senha.
          </FormFeedback>
        ) : null}
        <LoginForm
          emailVerified={params.emailVerified === "1"}
          googleEnabled={isGoogleAuthConfigured()}
          {...(safeReturnTo(params.returnTo) ? { returnTo: params.returnTo } : {})}
        />
      </div>
    </AuthShell>
  );
}
