import { inventoryBranchParamsSchema, recordInventoryCountSessionItemBodySchema } from "@gestor/contracts";
import { z } from "zod";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type P={params:Promise<{branchId:string;organizationId:string;sessionId:string;itemId:string}>};
export async function PATCH(request:Request, route:P){return handleApiRequest(request,async api=>{const params=inventoryBranchParamsSchema.extend({sessionId:z.uuid(),itemId:z.uuid()}).parse(await route.params);const body=recordInventoryCountSessionItemBodySchema.parse(await readJsonBody(request));const identity=await authenticateApiRequest(request);const actor=await services.resolveTenantActor.execute({correlationId:api.correlationId,organizationId:params.organizationId,requestId:api.requestId,userId:identity.userId});return Response.json({data:await services.recordInventoryCountSessionItem.execute({...params,...body},actor)});});}
