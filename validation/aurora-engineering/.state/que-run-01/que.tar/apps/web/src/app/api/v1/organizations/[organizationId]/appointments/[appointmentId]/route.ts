import { appointmentParamsSchema, updateAppointmentBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ appointmentId: string; organizationId: string }> };

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = appointmentParamsSchema.parse(await route.params);
    const body = updateAppointmentBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const appointment = await services.updateAppointment.execute({ ...body, ...params }, actor);
    return Response.json({ data: appointment });
  });
}
