import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@gestor/config", () => ({
  getAuthEmailEnv: () => ({
    AUTH_EMAIL_FROM: "Gestor <noreply@example.com>",
    AUTH_EMAIL_REPLY_TO: "support@example.com",
    RESEND_API_KEY: "secret",
  }),
}));

import { ResendSaleReceiptEmailSender } from "./sale-receipt-email";

describe("ResendSaleReceiptEmailSender", () => {
  beforeEach(() => vi.unstubAllGlobals());

  it("forwards the receipt variants and idempotency key to Resend", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(null, { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    await new ResendSaleReceiptEmailSender().send({
      idempotencyKey: "sale-receipt/request-1",
      receipt: {
        fileName: "receipt.html",
        html: "<p>Comprovante</p>",
        subject: "Comprovante #1",
        text: "Comprovante #1",
      },
      recipientEmail: "cliente@example.com",
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.resend.com/emails",
      expect.objectContaining({
        headers: expect.objectContaining({ "idempotency-key": "sale-receipt/request-1" }),
        method: "POST",
      }),
    );
  });

  it("fails closed when Resend rejects the delivery", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 503 })));
    await expect(
      new ResendSaleReceiptEmailSender().send({
        idempotencyKey: "sale-receipt/request-1",
        receipt: { fileName: "receipt.html", html: "", subject: "", text: "" },
        recipientEmail: "cliente@example.com",
      }),
    ).rejects.toThrow("SALE_RECEIPT_EMAIL_DELIVERY_FAILED:503");
  });
});
