"use client";

import {
  catalogCommercialPolicyViewSchema,
  type CatalogCommercialPolicyBody,
  type CatalogCommercialPolicyView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

type FormValues = {
  allowsArrangedDelivery: boolean;
  allowsDelivery: boolean;
  allowsPickup: boolean;
  deliveryIssueWindowHours: string;
  deliveryIssueResolutionHours: string;
  cartExpiresAfterMinutes: string;
  catalogOpen: boolean;
  fulfillmentNotice: string;
  minimumOrderAmount: string;
  requireReceiptConfirmation: boolean;
};

const endpointFor = (organizationId: string) =>
  `/api/v1/organizations/${organizationId}/catalog-commercial-policy`;

const defaultValues: FormValues = {
  allowsArrangedDelivery: false,
  allowsDelivery: false,
  allowsPickup: true,
  deliveryIssueWindowHours: "168",
  deliveryIssueResolutionHours: "48",
  cartExpiresAfterMinutes: "1440",
  catalogOpen: true,
  fulfillmentNotice: "",
  minimumOrderAmount: "",
  requireReceiptConfirmation: false,
};

function toFormValues(policy: CatalogCommercialPolicyView): FormValues {
  return {
    allowsArrangedDelivery: policy.allowsArrangedDelivery ?? false,
    allowsDelivery: policy.allowsDelivery,
    allowsPickup: policy.allowsPickup,
    deliveryIssueWindowHours: String(policy.deliveryIssueWindowHours ?? 168),
    deliveryIssueResolutionHours: String(policy.deliveryIssueResolutionHours ?? 48),
    cartExpiresAfterMinutes: String(policy.cartExpiresAfterMinutes),
    catalogOpen: policy.catalogOpen,
    fulfillmentNotice: policy.fulfillmentNotice ?? "",
    minimumOrderAmount: policy.minimumOrderAmount === null ? "" : String(policy.minimumOrderAmount),
    requireReceiptConfirmation: policy.requireReceiptConfirmation ?? false,
  };
}

function readProblem(payload: unknown, fallback: string) {
  if (
    payload &&
    typeof payload === "object" &&
    "detail" in payload &&
    typeof (payload as ProblemDetails).detail === "string"
  )
    return (payload as ProblemDetails).detail;
  return fallback;
}

export function CatalogCommercialPolicySettings({ organizationId }: { organizationId: string }) {
  const [values, setValues] = useState<FormValues | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      setError(null);
      try {
        const response = await fetch(endpointFor(organizationId), { signal: controller.signal });
        const payload = (await response.json().catch(() => null)) as { data?: unknown } | null;
        if (!response.ok)
          throw new Error(readProblem(payload, "Não foi possível carregar as regras comerciais."));
        setValues(
          payload?.data === null || payload?.data === undefined
            ? defaultValues
            : toFormValues(catalogCommercialPolicyViewSchema.parse(payload.data)),
        );
      } catch (cause) {
        if (!controller.signal.aborted)
          setError(
            cause instanceof Error
              ? cause.message
              : "Não foi possível carregar as regras comerciais.",
          );
      }
    })();
    return () => controller.abort();
  }, [organizationId]);

  function update<Value extends keyof FormValues>(field: Value, value: FormValues[Value]) {
    setValues((current) => (current ? { ...current, [field]: value } : current));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!values) return;
    setError(null);
    setNotice(null);

    const cartExpiresAfterMinutes = Number(values.cartExpiresAfterMinutes);
    const minimumOrderAmount = values.minimumOrderAmount.trim()
      ? Number(values.minimumOrderAmount)
      : null;
    const deliveryIssueWindowHours = Number(values.deliveryIssueWindowHours);
    const deliveryIssueResolutionHours = Number(values.deliveryIssueResolutionHours);
    if (!Number.isInteger(cartExpiresAfterMinutes) || cartExpiresAfterMinutes < 15) {
      setError("O prazo do carrinho deve ser de pelo menos 15 minutos.");
      return;
    }
    if (
      !Number.isInteger(deliveryIssueWindowHours) ||
      deliveryIssueWindowHours < 1 ||
      deliveryIssueWindowHours > 720
    ) {
      setError("O prazo para relatar problemas deve ficar entre 1 hora e 30 dias.");
      return;
    }
    if (
      !Number.isInteger(deliveryIssueResolutionHours) ||
      deliveryIssueResolutionHours < 1 ||
      deliveryIssueResolutionHours > 720
    ) {
      setError("O prazo de tratamento deve ficar entre 1 hora e 30 dias.");
      return;
    }
    if (
      minimumOrderAmount !== null &&
      (!Number.isFinite(minimumOrderAmount) || minimumOrderAmount < 0)
    ) {
      setError("Informe um pedido mínimo válido ou deixe o campo vazio.");
      return;
    }

    const body: CatalogCommercialPolicyBody = {
      allowsArrangedDelivery: values.allowsArrangedDelivery,
      allowsDelivery: values.allowsDelivery,
      allowsPickup: values.allowsPickup,
      deliveryIssueWindowHours,
      deliveryIssueResolutionHours,
      cartExpiresAfterMinutes,
      catalogOpen: values.catalogOpen,
      fulfillmentNotice: values.fulfillmentNotice.trim(),
      minimumOrderAmount,
      requireReceiptConfirmation: values.requireReceiptConfirmation,
    };
    setSaving(true);
    try {
      const response = await fetch(endpointFor(organizationId), {
        body: JSON.stringify(body),
        headers: {
          "content-type": "application/json",
          "idempotency-key": crypto.randomUUID(),
        },
        method: "PUT",
      });
      const payload = (await response.json().catch(() => null)) as { data?: unknown } | null;
      if (!response.ok)
        throw new Error(readProblem(payload, "Não foi possível salvar as regras comerciais."));
      setValues(toFormValues(catalogCommercialPolicyViewSchema.parse(payload?.data)));
      setNotice("Regras comerciais salvas.");
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Não foi possível salvar as regras comerciais.",
      );
    } finally {
      setSaving(false);
    }
  }

  if (!values)
    return error ? (
      <section
        className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-800"
        role="alert"
      >
        {error}
      </section>
    ) : (
      <LoadingRows rows={2} />
    );

  return (
    <section
      className="grid gap-5 rounded-2xl border bg-white p-5"
      aria-labelledby="catalog-commercial-policy-title"
    >
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Vendas pelo catálogo
        </p>
        <h2
          className="mt-2 text-xl font-semibold text-slate-950"
          id="catalog-commercial-policy-title"
        >
          Regras comerciais
        </h2>
        <p className="mt-1 max-w-2xl text-sm text-slate-600">
          Defina o que o cliente pode escolher antes de confirmar um pedido. Estas regras não expõem
          dados financeiros ou operacionais internos.
        </p>
      </div>
      {error ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
          role="alert"
        >
          {error}
        </p>
      ) : null}
      {notice ? (
        <p
          className="border-brand-100 bg-brand-50 text-brand-700 rounded-xl border p-3 text-sm"
          role="status"
        >
          {notice}
        </p>
      ) : null}
      <form className="grid gap-5" onSubmit={save}>
        <fieldset className="grid gap-3">
          <legend className="font-medium text-slate-950">Catálogo e modalidades</legend>
          <label className="flex items-start gap-3 rounded-xl border p-3 text-sm">
            <input
              checked={values.catalogOpen}
              className="mt-0.5"
              onChange={(event) => update("catalogOpen", event.target.checked)}
              type="checkbox"
            />
            <span>
              <strong className="block text-slate-950">Catálogo aberto</strong>
              <span className="text-slate-600">
                Quando fechado, novos pedidos não podem ser iniciados pelo link público.
              </span>
            </span>
          </label>
          <div className="grid gap-3 sm:grid-cols-3">
            <label className="flex items-start gap-3 rounded-xl border p-3 text-sm">
              <input
                checked={values.allowsPickup}
                className="mt-0.5"
                onChange={(event) => update("allowsPickup", event.target.checked)}
                type="checkbox"
              />
              <span>
                <strong className="block text-slate-950">Retirada</strong>
                <span className="text-slate-600">
                  O cliente poderá retirar o pedido na empresa.
                </span>
              </span>
            </label>
            <label className="flex items-start gap-3 rounded-xl border p-3 text-sm">
              <input
                checked={values.allowsArrangedDelivery}
                className="mt-0.5"
                onChange={(event) => update("allowsArrangedDelivery", event.target.checked)}
                type="checkbox"
              />
              <span>
                <strong className="block text-slate-950">Entrega a combinar</strong>
                <span className="text-slate-600">
                  Uber, motoboy do cliente ou combinação direta.
                </span>
              </span>
            </label>
            <label className="flex items-start gap-3 rounded-xl border p-3 text-sm">
              <input
                checked={values.allowsDelivery}
                className="mt-0.5"
                onChange={(event) => update("allowsDelivery", event.target.checked)}
                type="checkbox"
              />
              <span>
                <strong className="block text-slate-950">Entrega pela empresa</strong>
                <span className="text-slate-600">
                  A empresa entrega no endereço informado pelo cliente.
                </span>
              </span>
            </label>
          </div>
        </fieldset>
        <fieldset className="grid gap-3">
          <legend className="font-medium text-slate-950">Confirmação de entrega</legend>
          <label className="flex items-start gap-3 rounded-xl border p-3 text-sm">
            <input
              checked={values.requireReceiptConfirmation}
              className="mt-0.5"
              onChange={(event) => update("requireReceiptConfirmation", event.target.checked)}
              type="checkbox"
            />
            <span>
              <strong className="block text-slate-950">Exigir confirmação do cliente</strong>
              <span className="text-slate-600">
                Depois da comprovação pela empresa, o pedido só poderá ser concluído como venda
                quando o cliente confirmar o recebimento.
              </span>
            </span>
          </label>
          <p className="text-xs text-slate-600">
            Esta regra vale para entrega própria e entrega a combinar. O código de entrega continua
            obrigatório para comprovar a entrega.
          </p>
        </fieldset>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-1.5">
            <Label htmlFor="catalog-minimum-order">Pedido mínimo (R$)</Label>
            <input
              className="h-10 rounded-xl border px-3 text-sm"
              id="catalog-minimum-order"
              inputMode="decimal"
              min="0"
              onChange={(event) => update("minimumOrderAmount", event.target.value)}
              placeholder="Sem mínimo"
              step="0.01"
              type="number"
              value={values.minimumOrderAmount}
            />
            <p className="text-xs text-slate-600">Deixe vazio para não exigir valor mínimo.</p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="catalog-cart-expiration">Reserva do carrinho (minutos)</Label>
            <input
              className="h-10 rounded-xl border px-3 text-sm"
              id="catalog-cart-expiration"
              max="10080"
              min="15"
              onChange={(event) => update("cartExpiresAfterMinutes", event.target.value)}
              step="1"
              type="number"
              value={values.cartExpiresAfterMinutes}
            />
            <p className="text-xs text-slate-600">
              Entre 15 minutos e 7 dias. O estoque definitivo é validado no pedido.
            </p>
          </div>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="catalog-delivery-issue-window">Prazo para relatar problema (horas)</Label>
          <input
            className="h-10 rounded-xl border px-3 text-sm"
            id="catalog-delivery-issue-window"
            max="720"
            min="1"
            onChange={(event) => update("deliveryIssueWindowHours", event.target.value)}
            step="1"
            type="number"
            value={values.deliveryIssueWindowHours}
          />
          <p className="text-xs text-slate-600">
            Após a entrega confirmada, o cliente poderá informar uma divergência durante este prazo.
          </p>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="catalog-delivery-issue-resolution">Prazo para tratar divergência (horas)</Label>
          <input
            className="h-10 rounded-xl border px-3 text-sm"
            id="catalog-delivery-issue-resolution"
            max="720"
            min="1"
            onChange={(event) => update("deliveryIssueResolutionHours", event.target.value)}
            step="1"
            type="number"
            value={values.deliveryIssueResolutionHours}
          />
          <p className="text-xs text-slate-600">
            Define o prazo interno da fila. Cada caso guarda o prazo válido na data em que foi aberto.
          </p>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="catalog-fulfillment-notice">Aviso para o cliente</Label>
          <textarea
            className="min-h-24 rounded-xl border px-3 py-2 text-sm"
            id="catalog-fulfillment-notice"
            maxLength={500}
            onChange={(event) => update("fulfillmentNotice", event.target.value)}
            placeholder="Ex.: Retiradas de segunda a sexta, das 9h às 18h."
            value={values.fulfillmentNotice}
          />
          <p className="text-xs text-slate-600">
            Mostrado no catálogo para orientar retirada e entrega.
          </p>
        </div>
        <div>
          <Button disabled={saving} type="submit">
            {saving ? "Salvando..." : "Salvar regras comerciais"}
          </Button>
        </div>
      </form>
    </section>
  );
}
