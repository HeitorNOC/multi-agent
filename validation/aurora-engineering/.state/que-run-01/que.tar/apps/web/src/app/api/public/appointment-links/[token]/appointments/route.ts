import {
  cancelPublicAppointmentBodySchema,
  createPublicAppointmentBodySchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ token: string }> };

async function portalActor(request: Request, api: { correlationId: string; requestId: string }, route: RouteParameters) {
  const { token } = await route.params;
  const identity = await authenticateApiRequest(request);
  const link = await services.resolvePublicAppointmentPortalLink.execute(token);
  const actor = await services.resolveCustomerPortalActor.execute({
    correlationId: api.correlationId,
    organizationId: link.organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
  return { actor, link };
}

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { actor } = await portalActor(request, api, route);
      return Response.json({ data: await services.listPublicAppointments.execute(actor) });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { actor, link } = await portalActor(request, api, route);
      const body = createPublicAppointmentBodySchema.parse(await readJsonBody(request));
      const appointment = await services.createPublicAppointment.execute(
        { ...body, idempotencyKey: requireIdempotencyKey(request), permittedBranchId: link.branchId },
        actor,
      );
      return Response.json({ data: appointment }, { status: 201 });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { actor } = await portalActor(request, api, route);
      const body = cancelPublicAppointmentBodySchema.parse(await readJsonBody(request));
      return Response.json({ data: await services.cancelPublicAppointment.execute(body, actor) });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}
