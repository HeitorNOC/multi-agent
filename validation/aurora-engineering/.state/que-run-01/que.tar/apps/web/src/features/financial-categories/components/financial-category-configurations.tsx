"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createFinancialCategoryBodySchema,
  type CreateFinancialCategoryBody,
  type FinancialCategoryView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { CategoryCard, ReadinessItem } from "./financial-category-ui";

import {
  financialCategoryTypeDescriptions,
  financialCategoryTypeOptions,
  financialOutflowCategoryTypes,
} from "./financial-category-options";
import {
  createFinancialCategory,
  loadFinancialCategories,
  toggleFinancialCategoryStatus,
} from "./financial-category-api";

type FinancialCategoryConfigurationsProps = {
  organizationId: string;
};

export function FinancialCategoryConfigurations({
  organizationId,
}: FinancialCategoryConfigurationsProps) {
  const [categories, setCategories] = useState<readonly FinancialCategoryView[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyCategory, setBusyCategory] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateFinancialCategoryBody>({
    defaultValues: {
      name: "",
      parentId: null,
      type: "REVENUE",
    },
    resolver: zodResolver(createFinancialCategoryBodySchema),
  });
  const selectedType = useWatch({ control, name: "type" });
  const selectedParentId = useWatch({ control, name: "parentId" });
  const availableParents = useMemo(
    () =>
      categories?.filter(
        (category) =>
          !category.parentId && category.status === "ACTIVE" && category.type === selectedType,
      ) ?? [],
    [categories, selectedType],
  );
  const categoryGroups = useMemo(
    () =>
      financialCategoryTypeOptions
        .map(([type, label]) => ({
          categories: categories?.filter((category) => category.type === type) ?? [],
          label,
          type,
        }))
        .filter((group) => group.categories.length > 0),
    [categories],
  );
  const hasActiveRevenue = Boolean(
    categories?.some((category) => category.status === "ACTIVE" && category.type === "REVENUE"),
  );
  const hasActiveOutflow = Boolean(
    categories?.some(
      (category) =>
        category.status === "ACTIVE" && financialOutflowCategoryTypes.has(category.type),
    ),
  );

  useEffect(() => {
    if (
      selectedParentId &&
      !availableParents.some((category) => category.id === selectedParentId)
    ) {
      setValue("parentId", null, { shouldValidate: true });
    }
  }, [availableParents, selectedParentId, setValue]);

  useEffect(() => {
    const controller = new AbortController();

    async function loadCategories() {
      try {
        setCategories(await loadFinancialCategories(organizationId, controller.signal));
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar as categorias financeiras.",
          );
        }
      }
    }

    void loadCategories();

    return () => controller.abort();
  }, [organizationId, reloadVersion]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const result = await createFinancialCategory(organizationId, values, idempotencyKey);
      if (result.problem) {
        setError("root", { message: result.problem.detail, type: result.problem.code });
        return;
      }
      const created = result.data;
      setCategories((current) => (current ? [...current, created] : [created]));
      setIdempotencyKey(crypto.randomUUID());
      setFeedback("Categoria criada. O checklist foi recalculado automaticamente.");
      reset({ name: "", parentId: null, type: values.type });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function changeStatus(category: FinancialCategoryView) {
    setBusyCategory(category.id);
    setFeedback(null);

    try {
      const { status: nextStatus, updated } = await toggleFinancialCategoryStatus(
        organizationId,
        category,
      );
      setCategories(
        (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [updated],
      );
      setFeedback(nextStatus === "ACTIVE" ? "Categoria ativada." : "Categoria desativada.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível alterar a categoria.");
    } finally {
      setBusyCategory(null);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section
        aria-labelledby="new-financial-category-title"
        className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7"
      >
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Nova categoria
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="new-financial-category-title">
          Organizar o financeiro
        </h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          A categoria classifica operações e relatórios. Criá-la não movimenta caixa nem gera
          contas.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="financial-category-name">Nome</Label>
            <Input
              aria-describedby={errors.name ? "financial-category-name-error" : undefined}
              aria-invalid={Boolean(errors.name)}
              id="financial-category-name"
              placeholder="Ex.: Venda de serviços"
              {...register("name")}
            />
            {errors.name ? (
              <p className="text-sm text-red-700" id="financial-category-name-error" role="alert">
                {errors.name.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="financial-category-type">Tipo</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="financial-category-type"
              {...register("type")}
            >
              {financialCategoryTypeOptions.map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
            <p className="text-xs leading-5 text-slate-500">
              {financialCategoryTypeDescriptions[selectedType]}
            </p>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="financial-category-parent">Categoria superior</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="financial-category-parent"
              {...register("parentId", {
                setValueAs: (value) => (value ? String(value) : null),
              })}
            >
              <option value="">Nenhuma — categoria principal</option>
              {availableParents.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
            <p className="text-xs leading-5 text-slate-500">
              Use uma subcategoria somente quando precisar detalhar um grupo. A árvore possui no
              máximo dois níveis.
            </p>
          </div>

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button disabled={isSubmitting} type="submit">
            {isSubmitting ? "Salvando..." : "Adicionar categoria"}
          </Button>
        </form>
      </section>

      <section aria-labelledby="financial-category-list-title" className="grid content-start gap-4">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
            Plano de categorias
          </p>
          <h2
            className="mt-2 text-xl font-semibold text-slate-950"
            id="financial-category-list-title"
          >
            Categorias financeiras
          </h2>
        </div>

        <div className="grid gap-2 rounded-2xl border bg-slate-50 p-4 text-xs sm:grid-cols-2">
          <ReadinessItem ready={hasActiveRevenue} text="Categoria de receita ativa" />
          <ReadinessItem ready={hasActiveOutflow} text="Categoria de saída ativa" />
        </div>

        {feedback ? (
          <div
            className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700"
            role="status"
          >
            {feedback}
          </div>
        ) : null}

        {!categories ? (
          <div className="grid gap-3 rounded-2xl border bg-white p-5">
            <p className="text-sm text-slate-600">
              {loadError ?? "Carregando categorias financeiras..."}
            </p>
            {loadError ? (
              <div>
                <Button
                  onClick={() => {
                    setLoadError(null);
                    setReloadVersion((version) => version + 1);
                  }}
                  size="sm"
                  variant="outline"
                >
                  Tentar novamente
                </Button>
              </div>
            ) : null}
          </div>
        ) : categories.length === 0 ? (
          <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
            Comece com uma categoria de receita e outra de custo, despesa ou imposto.
          </div>
        ) : (
          <div className="grid gap-5">
            {categoryGroups.map((group) => {
              const roots = group.categories.filter((category) => !category.parentId);

              return (
                <section className="grid gap-2" key={group.type}>
                  <h3 className="text-xs font-bold tracking-[0.12em] text-slate-500 uppercase">
                    {group.label}
                  </h3>
                  {roots.map((root) => (
                    <div className="grid gap-2" key={root.id}>
                      <CategoryCard
                        busy={busyCategory === root.id}
                        category={root}
                        onChangeStatus={changeStatus}
                      />
                      {group.categories
                        .filter((category) => category.parentId === root.id)
                        .map((child) => (
                          <div
                            className="ml-4 border-l-2 border-slate-200 pl-3 sm:ml-6"
                            key={child.id}
                          >
                            <CategoryCard
                              busy={busyCategory === child.id}
                              category={child}
                              onChangeStatus={changeStatus}
                            />
                          </div>
                        ))}
                    </div>
                  ))}
                </section>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
