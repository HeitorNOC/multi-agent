"use client";

import { useState } from "react";
import type { SalesOrderView } from "@gestor/contracts";

import { DirectSaleForm } from "./direct-sale-form";
import { CommercialDocuments } from "./commercial-documents";
import { SalesList } from "./sales-list";

export function SalesManagement({ organizationId }: { organizationId: string }) {
  const [revision, setRevision] = useState(0);
  const [salesOrder, setSalesOrder] = useState<SalesOrderView | null>(null);
  return (
    <div className="grid gap-10">
      <DirectSaleForm
        onCompleted={() => {
          setRevision((current) => current + 1);
          setSalesOrder(null);
        }}
        organizationId={organizationId}
        salesOrder={salesOrder}
      />
      <CommercialDocuments onCompleteOrder={setSalesOrder} organizationId={organizationId} />
      <SalesList
        onChanged={() => setRevision((current) => current + 1)}
        organizationId={organizationId}
        revision={revision}
      />
    </div>
  );
}
