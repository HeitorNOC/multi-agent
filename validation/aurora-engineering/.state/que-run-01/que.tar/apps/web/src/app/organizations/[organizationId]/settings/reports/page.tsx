import { organizationParamsSchema, reportSelectionQuerySchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { ModuleGate } from "@/features/modules/components/module-gate";
import { ReportManagement } from "@/features/reports/components/report-management";

export const metadata: Metadata = { title: "Relatórios | Gestor" };

export default async function ReportsPage({
  params,
  searchParams,
}: {
  params: Promise<{ organizationId: string }>;
  searchParams: Promise<{ reportId?: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  const { reportId } = reportSelectionQuerySchema.parse(await searchParams);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">Análise</p>
        <h1 className="mt-2 text-3xl font-semibold">Relatórios</h1>
        <p className="mt-2 text-sm text-slate-600">
          Solicite arquivos sem bloquear a operação e acompanhe a geração pelo protocolo.
        </p>
      </header>
      <ModuleGate moduleCode="reporting" organizationId={organizationId}>
        <ReportManagement initialReportId={reportId} organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
