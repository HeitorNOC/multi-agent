import { priceListParamsSchema, updatePriceListBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ organizationId: string; priceListId: string }>;
};
export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = priceListParamsSchema.parse(await route.params);
    const body = updatePriceListBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.updatePriceList.execute(
        {
          ...body,
          organizationId: params.organizationId,
          priceListId: params.priceListId,
        },
        actor,
      ),
    });
  });
}
