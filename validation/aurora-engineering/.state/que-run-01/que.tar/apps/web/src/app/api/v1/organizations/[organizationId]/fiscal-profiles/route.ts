import { organizationParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({ data: await services.listFiscalProfiles.execute(params, actor) });
  });
}
