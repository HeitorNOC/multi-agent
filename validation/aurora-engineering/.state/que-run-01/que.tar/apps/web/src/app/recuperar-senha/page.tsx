import type { Metadata } from "next";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { RecoverPasswordForm } from "@/features/auth/components/recover-password-form";

export const metadata: Metadata = {
  title: "Recuperar senha | Gestor",
};

export default function RecoverPasswordPage() {
  return (
    <AuthShell
      description="Informe o e-mail da conta para receber um link seguro de redefinição."
      eyebrow="Recuperação de acesso"
      title="Esqueceu sua senha?"
    >
      <RecoverPasswordForm />
    </AuthShell>
  );
}
