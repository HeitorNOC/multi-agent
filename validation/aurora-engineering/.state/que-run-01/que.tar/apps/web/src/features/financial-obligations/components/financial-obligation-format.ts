export function formatBrl(value: string): string {
  const [integer = "0", rawFraction = ""] = value.split(".");
  const fraction = rawFraction.padEnd(2, "0").replace(/0+$/, "").padEnd(2, "0");
  return `R$ ${BigInt(integer).toLocaleString("pt-BR")},${fraction}`;
}

export function formatDate(value: string): string {
  return new Intl.DateTimeFormat("pt-BR").format(new Date(`${value}T12:00:00.000Z`));
}
