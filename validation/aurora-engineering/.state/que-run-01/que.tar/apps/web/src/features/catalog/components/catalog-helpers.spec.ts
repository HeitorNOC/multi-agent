import { afterEach, describe, expect, it, vi } from "vitest";

import { active, mergeSupplierChoices, patch, post, setProblem, toggle } from "./catalog-helpers";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("catalog helpers", () => {
  it("deduplicates suppliers while preserving the newest complete choice", () => {
    expect(
      mergeSupplierChoices(
        [{ id: "supplier-1", name: "Fornecedor 1" }],
        [
          { id: "supplier-1", name: "Fornecedor atualizado" },
          { id: "supplier-2", name: "Fornecedor 2" },
        ],
      ),
    ).toEqual([
      { id: "supplier-1", name: "Fornecedor atualizado" },
      { id: "supplier-2", name: "Fornecedor 2" },
    ]);
    expect(active({ status: "ACTIVE" })).toBe(true);
    expect(active({ status: "INACTIVE" })).toBe(false);
  });

  it("uses idempotency only for creation requests", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(null, { status: 204 }));
    vi.stubGlobal("fetch", fetchMock);

    await post("/products", { name: "Produto" });
    await patch("/products/product-1", { name: "Produto alterado" });

    expect(fetchMock.mock.calls[0]?.[1]).toEqual(
      expect.objectContaining({
        headers: expect.objectContaining({
          "content-type": "application/json",
          "idempotency-key": expect.any(String),
        }),
        method: "POST",
      }),
    );
    expect(fetchMock.mock.calls[1]?.[1]).toEqual({
      body: JSON.stringify({ name: "Produto alterado" }),
      headers: { "content-type": "application/json" },
      method: "PATCH",
    });
  });

  it("maps API problems to the root form error", async () => {
    const setError = vi.fn();
    await setProblem(
      Response.json({ code: "INVALID_PRODUCT", detail: "Produto inválido." }, { status: 422 }),
      setError,
    );
    expect(setError).toHaveBeenCalledWith("root", {
      message: "Produto inválido.",
      type: "INVALID_PRODUCT",
    });
  });

  it("toggles status using optimistic-concurrency metadata", async () => {
    const updated = {
      id: "product-1",
      status: "INACTIVE" as const,
      updatedAt: "2026-08-11T13:00:00.000Z",
    };
    const fetchMock = vi.fn().mockResolvedValue(Response.json({ data: updated }));
    const update = vi.fn();
    const feedback = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    await toggle(
      "products",
      { id: "product-1", status: "ACTIVE", updatedAt: "2026-08-11T12:00:00.000Z" },
      "organization-1",
      { parse: (value) => value as typeof updated },
      update,
      feedback,
    );

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/organization-1/products/product-1",
      expect.objectContaining({
        body: JSON.stringify({
          expectedUpdatedAt: "2026-08-11T12:00:00.000Z",
          status: "INACTIVE",
        }),
        method: "PATCH",
      }),
    );
    expect(update).toHaveBeenCalledWith(updated);
    expect(feedback).toHaveBeenCalledWith("Cadastro inativado.");
  });
});
