import { applicationReadinessProbes, checkReadiness } from "@/lib/server/readiness";

export async function GET(): Promise<Response> {
  const result = await checkReadiness(applicationReadinessProbes);

  return Response.json(result, {
    headers: { "cache-control": "no-store" },
    status: result.status === "ok" ? 200 : 503,
  });
}
