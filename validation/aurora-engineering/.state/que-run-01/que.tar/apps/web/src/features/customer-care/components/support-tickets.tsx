"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createSupportTicketBodySchema,
  supportTicketListSchema,
  type ProblemDetails,
  type SupportTicketView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import type { z } from "zod";

import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

type FormValues = z.infer<typeof createSupportTicketBodySchema>;
const labels = {
  CLOSED: "Encerrado",
  IN_REVIEW: "Em análise",
  OPEN: "Aberto",
  RESOLVED: "Resolvido",
  WAITING_CUSTOMER: "Aguardando cliente",
} as const;
export function SupportTickets({ organizationId }: { organizationId: string }) {
  const [tickets, setTickets] = useState<readonly SupportTicketView[]>([]);
  const [feedback, setFeedback] = useState("");
  const [revision, setRevision] = useState(0);
  const form = useForm<FormValues>({
    defaultValues: { category: "Dúvida", description: "", priority: "NORMAL", subject: "" },
    resolver: zodResolver(createSupportTicketBodySchema),
  });
  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/v1/organizations/${organizationId}/support-tickets`, {
      signal: controller.signal,
    })
      .then(read)
      .then((payload) => setTickets(supportTicketListSchema.parse(payload)))
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Falha ao carregar chamados.");
      });
    return () => controller.abort();
  }, [organizationId, revision]);
  async function create(values: FormValues) {
    await read(
      await fetch(`/api/v1/organizations/${organizationId}/support-tickets`, {
        body: JSON.stringify(values),
        headers: jsonHeaders(),
        method: "POST",
      }),
    );
    form.reset({ ...values, description: "", subject: "" });
    setFeedback("Chamado aberto com sucesso.");
    setRevision((current) => current + 1);
  }
  return (
    <section className="grid gap-5" aria-labelledby="support-title">
      <div>
        <h2 className="text-2xl font-semibold" id="support-title">
          Suporte
        </h2>
        <p className="text-sm text-slate-600">Abra chamados e acompanhe todo o histórico.</p>
      </div>
      <form
        className="grid gap-3 rounded-2xl border bg-white p-5 md:grid-cols-2"
        onSubmit={form.handleSubmit(create)}
      >
        <Input placeholder="Assunto" {...form.register("subject")} />
        <Input placeholder="Categoria" {...form.register("category")} />
        <select className="rounded-md border px-3 py-2 text-sm" {...form.register("priority")}>
          <option value="LOW">Baixa</option>
          <option value="NORMAL">Normal</option>
          <option value="HIGH">Alta</option>
          <option value="URGENT">Urgente</option>
        </select>
        <textarea
          className="min-h-24 rounded-md border p-3 text-sm md:col-span-2"
          placeholder="Descreva o problema"
          {...form.register("description")}
        />
        <Button disabled={form.formState.isSubmitting} type="submit">
          Abrir chamado
        </Button>
      </form>
      {feedback ? (
        <p className="text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <div className="grid gap-3">
        {tickets.map((ticket) => (
          <Ticket
            key={ticket.id}
            onChanged={() => setRevision((current) => current + 1)}
            organizationId={organizationId}
            ticket={ticket}
          />
        ))}
      </div>
    </section>
  );
}
function Ticket({
  onChanged,
  organizationId,
  ticket,
}: {
  onChanged: () => void;
  organizationId: string;
  ticket: SupportTicketView;
}) {
  const [body, setBody] = useState("");
  async function reply() {
    await read(
      await fetch(`/api/v1/organizations/${organizationId}/support-tickets/${ticket.id}/messages`, {
        body: JSON.stringify({ body }),
        headers: jsonHeaders(),
        method: "POST",
      }),
    );
    setBody("");
    onChanged();
  }
  async function close() {
    await read(
      await fetch(`/api/v1/organizations/${organizationId}/support-tickets/${ticket.id}`, {
        body: JSON.stringify({ expectedUpdatedAt: ticket.updatedAt, status: "CLOSED" }),
        headers: jsonHeaders(),
        method: "PATCH",
      }),
    );
    onChanged();
  }
  return (
    <article className="rounded-2xl border bg-white p-5">
      <div className="flex justify-between gap-3">
        <div>
          <h3 className="font-semibold">
            #{ticket.number} · {ticket.subject}
          </h3>
          <p className="text-sm text-slate-600">
            {labels[ticket.status]} · {ticket.category}
          </p>
        </div>
        <div className="flex gap-2">
          <CatalogFilesButton
            allowImage={false}
            itemId={ticket.id}
            organizationId={organizationId}
            segment="support-tickets"
          />
          {ticket.status !== "CLOSED" ? (
            <Button onClick={() => void close()} size="sm" variant="outline">
              Encerrar
            </Button>
          ) : null}
        </div>
      </div>
      <div className="mt-4 grid gap-2">
        {ticket.messages.map((message) => (
          <p
            className={`rounded-lg p-3 text-sm ${message.ownMessage ? "bg-brand-50" : "bg-slate-100"}`}
            key={message.id}
          >
            {message.body}
          </p>
        ))}
      </div>
      {ticket.status !== "CLOSED" ? (
        <div className="mt-3 flex gap-2">
          <Input
            onChange={(event) => setBody(event.target.value)}
            placeholder="Adicionar mensagem"
            value={body}
          />
          <Button disabled={body.trim().length < 2} onClick={() => void reply()}>
            Enviar
          </Button>
        </div>
      ) : null}
    </article>
  );
}
function jsonHeaders() {
  return { "content-type": "application/json", "idempotency-key": crypto.randomUUID() };
}
async function read(response: Response): Promise<unknown> {
  const payload = (await response.json()) as Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "A operação falhou.");
  return payload;
}
