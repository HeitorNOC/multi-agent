"use client";

import type { FinancialAccountView, PaymentMethodConfigurationView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useWatch, type UseFieldArrayReturn, type UseFormReturn } from "react-hook-form";

import { compatiblePaymentAccounts } from "@/lib/payment-account-compatibility";
import type { SaleForm } from "./direct-sale-data";
import { SelectField } from "./direct-sale-support";

export function DirectSalePayments({
  branchId,
  financialAccounts,
  form,
  paymentFields,
  paymentMethods,
}: {
  branchId: string;
  financialAccounts: readonly FinancialAccountView[];
  form: UseFormReturn<SaleForm>;
  paymentFields: UseFieldArrayReturn<SaleForm, "payments", "id">;
  paymentMethods: readonly PaymentMethodConfigurationView[];
}) {
  const payments = useWatch({ control: form.control, name: "payments" });
  return (
    <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Recebimento no ato (opcional)</h2>
          <p className="text-sm text-slate-600">
            Deixe vazio para vender a prazo. Se usar, a soma deve ser igual ao total da venda.
          </p>
        </div>
        <Button
          disabled={paymentFields.fields.length >= 10}
          onClick={() =>
            paymentFields.append({
              amount: "",
              financialAccountId: "",
              paymentMethodConfigurationId: "",
            })
          }
          type="button"
          variant="outline"
        >
          Adicionar pagamento
        </Button>
      </div>
      {paymentFields.fields.map((field, index) => {
        const selectedMethodId = payments?.[index]?.paymentMethodConfigurationId ?? "";
        const accounts = compatiblePaymentAccounts({
          branchId,
          financialAccounts,
          paymentMethodConfigurationId: selectedMethodId,
          paymentMethods,
        });
        const methodRegistration = form.register(`payments.${index}.paymentMethodConfigurationId`);
        return (
          <div
            className="grid gap-3 border-t pt-4 sm:grid-cols-[1fr_1fr_10rem_auto]"
            key={field.id}
          >
            <SelectField
              error={form.formState.errors.payments?.[index]?.paymentMethodConfigurationId?.message}
              label="Forma de pagamento"
            >
              <select
                className="rounded-md border px-3 py-2 text-sm"
                {...methodRegistration}
                onChange={(event) => {
                  methodRegistration.onChange(event);
                  const nextAccounts = compatiblePaymentAccounts({
                    branchId,
                    financialAccounts,
                    paymentMethodConfigurationId: event.target.value,
                    paymentMethods,
                  });
                  form.setValue(`payments.${index}.financialAccountId`, nextAccounts[0]?.id ?? "", {
                    shouldValidate: true,
                  });
                }}
              >
                <option value="">Selecione</option>
                {paymentMethods.map((method) => (
                  <option key={method.id} value={method.id}>
                    {method.name}
                  </option>
                ))}
              </select>
            </SelectField>
            <SelectField
              error={form.formState.errors.payments?.[index]?.financialAccountId?.message}
              label="Conta financeira"
            >
              <select
                className="rounded-md border px-3 py-2 text-sm"
                {...form.register(`payments.${index}.financialAccountId`)}
              >
                <option value="">Selecione</option>
                {accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name}
                  </option>
                ))}
              </select>
            </SelectField>
            <SelectField
              error={form.formState.errors.payments?.[index]?.amount?.message}
              label="Valor"
            >
              <Input inputMode="decimal" {...form.register(`payments.${index}.amount`)} />
            </SelectField>
            <div className="flex items-end">
              <Button onClick={() => paymentFields.remove(index)} type="button" variant="outline">
                Remover
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
