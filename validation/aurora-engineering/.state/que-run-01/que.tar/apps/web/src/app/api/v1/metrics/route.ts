import { getServerEnv } from "@gestor/config";
import { metrics } from "@gestor/observability";

import { handleApiRequest } from "@/lib/server/api-request";
import { requireMetricsAccess } from "@/lib/server/metrics-access";

export async function GET(request: Request): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      requireMetricsAccess(request, getServerEnv().METRICS_BEARER_TOKEN);

      return new Response(metrics.renderPrometheus(), {
        headers: {
          "cache-control": "no-store",
          "content-type": "text/plain; version=0.0.4; charset=utf-8",
        },
      });
    },
    { authentication: "PUBLIC", rateLimit: false },
  );
}
