import { describe, expect, it } from "vitest";

import { getGoogleAuthNavigation } from "./google-auth-navigation";

describe("getGoogleAuthNavigation", () => {
  it("preserves a safe local destination in every Google callback", () => {
    expect(
      getGoogleAuthNavigation("http://localhost:3000", "/login", "/convites/aceitar?token=abc"),
    ).toEqual({
      callbackURL: "/convites/aceitar?token=abc",
      errorCallbackURL:
        "http://localhost:3000/login?oauthError=1&returnTo=%2Fconvites%2Faceitar%3Ftoken%3Dabc",
      newUserCallbackURL: "/convites/aceitar?token=abc",
    });
  });

  it("rejects external redirects and uses the default destinations", () => {
    expect(
      getGoogleAuthNavigation("https://app.example.com", "/cadastro", "https://evil.example"),
    ).toEqual({
      callbackURL: "/",
      errorCallbackURL: "https://app.example.com/cadastro?oauthError=1",
      newUserCallbackURL: "/onboarding",
    });
  });
});
