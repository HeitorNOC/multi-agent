"use client";

import { Input } from "@gestor/ui/components/input";
import type { ComponentProps } from "react";
import { useState } from "react";

type PasswordInputProps = Omit<ComponentProps<"input">, "type">;

export function PasswordInput({ className, ...props }: PasswordInputProps) {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="relative">
      <Input
        className={`${className ?? ""} w-full pr-20`}
        type={isVisible ? "text" : "password"}
        {...props}
      />
      <button
        aria-label={isVisible ? "Ocultar senha" : "Mostrar senha"}
        className="focus:ring-brand-100 absolute inset-y-1 right-1 rounded-lg px-3 text-xs font-semibold text-slate-500 transition hover:text-slate-800 focus:ring-4 focus:outline-none"
        onClick={() => setIsVisible((current) => !current)}
        type="button"
      >
        {isVisible ? "Ocultar" : "Mostrar"}
      </button>
    </div>
  );
}
