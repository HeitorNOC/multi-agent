import Link from "next/link";

export default function PrivacyPolicyPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-14 text-slate-800">
      <h1 className="text-3xl font-semibold">Política de Privacidade</h1>
      <p className="mt-3 text-sm text-slate-500">Versão 2026-10-18</p>
      <section className="mt-8 grid gap-4 leading-7">
        <p>
          Tratamos os dados necessários para autenticação, operação da conta e prestação do serviço,
          com controles de acesso e registros de segurança.
        </p>
        <p>
          Você pode solicitar informações sobre dados pessoais pelos canais de suporte da
          plataforma.
        </p>
      </section>
      <Link className="mt-8 inline-block text-brand-600 font-semibold" href="/aceite">
        Voltar
      </Link>
    </main>
  );
}
