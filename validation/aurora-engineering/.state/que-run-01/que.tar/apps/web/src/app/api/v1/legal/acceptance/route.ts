import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import {
  acceptCurrentLegalDocuments,
  getLegalAcceptanceStatus,
} from "@/lib/server/legal-acceptance";

export async function GET(request: Request): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const identity = await authenticateApiRequest(request);
      return Response.json({ data: await getLegalAcceptanceStatus(identity.userId) });
    },
    { legalAcceptance: false },
  );
}

export async function POST(request: Request): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const identity = await authenticateApiRequest(request);
      return Response.json({ data: await acceptCurrentLegalDocuments(identity.userId) });
    },
    { legalAcceptance: false },
  );
}
