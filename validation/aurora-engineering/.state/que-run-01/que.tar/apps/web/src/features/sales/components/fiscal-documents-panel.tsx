"use client";

import {
  cancelFiscalDocumentBodySchema,
  fiscalDocumentDownloadViewSchema,
  fiscalDocumentListSchema,
  fiscalDocumentViewSchema,
  type FiscalDocumentType,
  type FiscalDocumentView,
  type ProblemDetails,
  type SaleDetailView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";

export function FiscalDocumentsPanel({
  organizationId,
  sale,
  setFeedback,
}: {
  organizationId: string;
  sale: Pick<SaleDetailView, "id" | "number" | "status">;
  setFeedback: (message: string) => void;
}) {
  const [documents, setDocuments] = useState<readonly FiscalDocumentView[]>([]);
  const [cancellationReason, setCancellationReason] = useState("");
  const [fiscalType, setFiscalType] = useState<FiscalDocumentType>("NFCE");
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [issuing, setIssuing] = useState(false);
  const [reissuingId, setReissuingId] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/v1/organizations/${organizationId}/sales/${sale.id}/fiscal-documents`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
        if (!response.ok)
          throw new Error(payload.detail ?? "Não foi possível carregar os documentos fiscais.");
        setDocuments(fiscalDocumentListSchema.parse(payload.data));
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar o fiscal.",
          );
      });
    return () => controller.abort();
  }, [organizationId, sale.id, setFeedback]);

  async function issue() {
    if (!window.confirm(`Confirma a emissão de ${fiscalType} para a venda #${sale.number}?`))
      return;
    setIssuing(true);
    setFeedback("");
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/fiscal-documents`,
        {
          body: JSON.stringify({ type: fiscalType }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        setFeedback(payload.detail ?? "Não foi possível emitir o documento fiscal.");
        return;
      }
      const document = fiscalDocumentViewSchema.parse(payload.data);
      setDocuments((current) => mergeDocument(current, document));
      setFeedback(
        document.status === "AUTHORIZED"
          ? `${document.type} autorizada. Protocolo ${document.protocol}.`
          : `${document.type}: ${document.rejectionMessage ?? document.status}.`,
      );
    } finally {
      setIssuing(false);
    }
  }

  async function cancel(document: FiscalDocumentView) {
    const parsed = cancelFiscalDocumentBodySchema.safeParse({ reason: cancellationReason });
    if (!parsed.success) {
      setFeedback(parsed.error.issues[0]?.message ?? "Informe o motivo do cancelamento fiscal.");
      return;
    }
    if (!window.confirm(`Confirma o cancelamento da ${document.type} desta venda?`)) return;
    setCancellingId(document.id);
    setFeedback("");
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/fiscal-documents/${document.id}/cancel`,
        {
          body: JSON.stringify(parsed.data),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        setFeedback(payload.detail ?? "Não foi possível cancelar o documento fiscal.");
        return;
      }
      const cancelled = fiscalDocumentViewSchema.parse(payload.data);
      setDocuments((current) => mergeDocument(current, cancelled));
      setCancellationReason("");
      setFeedback(`${cancelled.type} cancelada. A venda agora pode seguir para cancelamento.`);
    } finally {
      setCancellingId(null);
    }
  }

  async function reissue(document: FiscalDocumentView) {
    if (!window.confirm(`Confirma o reenvio da ${document.type} desta venda?`)) return;
    setReissuingId(document.id);
    setFeedback("");
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/fiscal-documents/${document.id}/reissue`,
        { headers: { "idempotency-key": crypto.randomUUID() }, method: "POST" },
      );
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        setFeedback(payload.detail ?? "Não foi possível reenviar o documento fiscal.");
        return;
      }
      const reissued = fiscalDocumentViewSchema.parse(payload.data);
      setDocuments((current) => mergeDocument(current, reissued));
      setFeedback(
        reissued.status === "AUTHORIZED"
          ? `${reissued.type} autorizada no reenvio. Protocolo ${reissued.protocol}.`
          : `${reissued.type}: ${reissued.rejectionMessage ?? reissued.status}.`,
      );
    } finally {
      setReissuingId(null);
    }
  }

  async function download(document: FiscalDocumentView, artifactKind: "document" | "xml") {
    setDownloading(`${document.id}:${artifactKind}`);
    setFeedback("");
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/fiscal-documents/${document.id}/artifacts/${artifactKind}`,
      );
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        setFeedback(payload.detail ?? "Não foi possível preparar o artefato fiscal.");
        return;
      }
      const artifact = fiscalDocumentDownloadViewSchema.parse(payload.data);
      window.open(artifact.url, "_blank", "noopener,noreferrer");
    } finally {
      setDownloading(null);
    }
  }

  if (sale.status !== "COMPLETED" && documents.length === 0) return null;
  return (
    <div className="grid gap-3 border-t pt-5">
      <div>
        <h4 className="font-semibold">Documentos fiscais</h4>
        <p className="text-sm text-slate-600">
          O perfil fiscal ativo da filial define quais tipos podem ser autorizados.
        </p>
      </div>
      {sale.status === "COMPLETED" ? (
        <div className="flex flex-wrap items-end gap-3">
          <label className="grid gap-1 text-sm font-medium">
            Tipo
            <select
              className="h-10 rounded-md border border-slate-300 bg-white px-3 text-sm"
              onChange={(event) => setFiscalType(event.target.value as FiscalDocumentType)}
              value={fiscalType}
            >
              <option value="NFCE">NFC-e</option>
              <option value="NFE">NF-e</option>
              <option value="NFSE">NFS-e</option>
            </select>
          </label>
          <Button disabled={issuing} onClick={() => void issue()} type="button">
            {issuing ? "Emitindo..." : "Emitir documento"}
          </Button>
        </div>
      ) : null}
      {documents.map((document) => (
        <div className="grid gap-3 rounded-xl border p-3" key={document.id}>
          <p className="text-sm">
            <strong>{document.type}</strong> · {document.status}
            {document.protocol ? ` · Protocolo ${document.protocol}` : ""}
          </p>
          {document.documentStorageKey || document.xmlStorageKey ? (
            <div className="flex flex-wrap gap-2">
              {document.documentStorageKey ? (
                <Button
                  disabled={downloading === `${document.id}:document`}
                  onClick={() => void download(document, "document")}
                  type="button"
                  variant="outline"
                >
                  {downloading === `${document.id}:document` ? "Preparando..." : "Baixar PDF"}
                </Button>
              ) : null}
              {document.xmlStorageKey ? (
                <Button
                  disabled={downloading === `${document.id}:xml`}
                  onClick={() => void download(document, "xml")}
                  type="button"
                  variant="outline"
                >
                  {downloading === `${document.id}:xml` ? "Preparando..." : "Baixar XML"}
                </Button>
              ) : null}
            </div>
          ) : null}
          {document.status === "AUTHORIZED" ? (
            <div className="flex flex-wrap items-end gap-3">
              <label className="grid min-w-72 flex-1 gap-1 text-sm font-medium">
                Motivo do cancelamento fiscal
                <Input
                  onChange={(event) => setCancellationReason(event.target.value)}
                  value={cancellationReason}
                />
              </label>
              <Button
                disabled={cancellingId === document.id}
                onClick={() => void cancel(document)}
                type="button"
                variant="destructive"
              >
                {cancellingId === document.id ? "Cancelando..." : "Cancelar documento"}
              </Button>
            </div>
          ) : null}
          {["REJECTED", "TECHNICAL_ERROR"].includes(document.status) ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-red-700">
                {document.rejectionCode ? `${document.rejectionCode}: ` : ""}
                {document.rejectionMessage ?? "A tentativa anterior não foi concluída."}
              </p>
              <Button
                disabled={reissuingId === document.id}
                onClick={() => void reissue(document)}
                type="button"
              >
                {reissuingId === document.id ? "Reenviando..." : "Reenviar documento"}
              </Button>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

function mergeDocument(current: readonly FiscalDocumentView[], document: FiscalDocumentView) {
  return [document, ...current.filter(({ id }) => id !== document.id)];
}
