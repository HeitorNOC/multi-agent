import {
  organizationMemberParamsSchema,
  updateOrganizationMemberBodySchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ membershipId: string; organizationId: string }>;
};

export async function PATCH(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const params = organizationMemberParamsSchema.parse(await route.params);
    const body = updateOrganizationMemberBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.manageOrganizationUsers.updateMember({ ...body, ...params }, actor),
    });
  });
}
