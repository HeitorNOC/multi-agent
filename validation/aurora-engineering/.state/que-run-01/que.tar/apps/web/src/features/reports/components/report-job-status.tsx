import type { ReportJobView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

const statusPresentation = {
  COMPLETED: { label: "Concluído", tone: "text-emerald-700" },
  EXPIRED: { label: "Expirado", tone: "text-slate-600" },
  FAILED: { label: "Falhou", tone: "text-red-700" },
  PENDING: { label: "Na fila", tone: "text-amber-700" },
  PROCESSING: { label: "Processando", tone: "text-blue-700" },
} as const;

const reportTypePresentation: Record<ReportJobView["reportType"], string> = {
  CASH: "Caixa",
  CUSTOMERS: "Clientes",
  FINANCIAL_MOVEMENTS: "Movimentos financeiros",
  INVENTORY: "Estoque",
  PAYABLES: "Contas a pagar",
  PURCHASES: "Compras",
  RECEIVABLES: "Contas a receber",
  SALES: "Vendas",
  SIMPLIFIED_INCOME_STATEMENT: "DRE simplificada",
  SUPPLIERS: "Fornecedores",
};

export function ReportJobStatus({
  downloading,
  onDownload,
  report,
}: {
  downloading: boolean;
  onDownload: () => void;
  report: ReportJobView;
}) {
  const status = statusPresentation[report.status];
  return (
    <section
      className="rounded-2xl border bg-white p-5 shadow-sm"
      aria-labelledby="report-status-title"
    >
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold" id="report-status-title">
            Último relatório
          </h2>
          <p className="mt-1 text-sm text-slate-600">Protocolo: {report.id}</p>
        </div>
        <p className={`text-sm font-semibold ${status.tone}`} role="status">
          {status.label}
        </p>
      </div>
      <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-3">
        <Item label="Tipo" value={reportTypePresentation[report.reportType]} />
        <Item label="Formato" value={report.format} />
        <Item label="Progresso" value={`${report.progress}%`} />
      </dl>
      {report.status === "FAILED" ? (
        <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-800">
          Não foi possível gerar o arquivo. Solicite novamente ou informe o protocolo ao suporte.
        </p>
      ) : null}
      {report.status === "EXPIRED" ? (
        <p className="mt-4 rounded-lg bg-slate-50 p-3 text-sm text-slate-700">
          O período de retenção terminou. Solicite um novo relatório.
        </p>
      ) : null}
      {report.status === "COMPLETED" && report.fileAvailable ? (
        <Button className="mt-5" disabled={downloading} onClick={onDownload} type="button">
          {downloading ? "Preparando download..." : "Baixar arquivo"}
        </Button>
      ) : null}
    </section>
  );
}

function Item({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-slate-500">{label}</dt>
      <dd className="mt-1 font-medium">{value}</dd>
    </div>
  );
}
