import { moveFoodServiceTableSessionBodySchema, organizationParamsSchema } from "@gestor/contracts";
import { z } from "zod";

import { services } from "@/lib/server/container";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";

const paramsSchema = organizationParamsSchema.extend({ sessionId: z.uuid() });

export async function POST(
  request: Request,
  context: { params: Promise<{ organizationId: string; sessionId: string }> },
) {
  return handleApiRequest(request, async (api) => {
    const params = paramsSchema.parse(await context.params);
    const body = moveFoodServiceTableSessionBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.moveFoodServiceTableSession.execute({ ...params, ...body }, actor),
    });
  });
}
