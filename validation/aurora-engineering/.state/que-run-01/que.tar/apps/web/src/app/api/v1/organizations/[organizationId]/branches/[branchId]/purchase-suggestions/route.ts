import { inventoryBranchParamsSchema, stockBalanceListQuerySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ branchId: string; organizationId: string }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = inventoryBranchParamsSchema.parse(await route.params);
    const query = stockBalanceListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.listPurchaseSuggestions.execute({ ...params, ...query }, actor),
    });
  });
}
