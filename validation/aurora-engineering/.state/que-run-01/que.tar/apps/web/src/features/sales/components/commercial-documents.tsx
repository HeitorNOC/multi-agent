"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  createQuoteBodySchema,
  customerListSchema,
  productListSchema,
  quoteListSchema,
  salesOrderListSchema,
  serviceListSchema,
  type BranchView,
  type CustomerView,
  type ProblemDetails,
  type ProductView,
  type QuoteView,
  type SalesOrderView,
  type ServiceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { z } from "zod";
import { CommercialDocumentLists as DocumentLists } from "./commercial-document-lists";
import { fetchData, type CatalogEntry } from "./direct-sale-data";

const formSchema = z.object({
  branchId: z.string().min(1),
  customerId: z.string().min(1),
  discountAmount: z.string(),
  items: z.array(z.object({ catalogEntry: z.string().min(1), quantity: z.string().min(1) })).min(1),
  notes: z.string(),
  validUntil: z.string(),
});
type Form = z.infer<typeof formSchema>;

export function CommercialDocuments({
  onCompleteOrder,
  organizationId,
}: {
  onCompleteOrder: (order: SalesOrderView) => void;
  organizationId: string;
}) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [customers, setCustomers] = useState<readonly CustomerView[]>([]);
  const [products, setProducts] = useState<readonly ProductView[]>([]);
  const [services, setServices] = useState<readonly ServiceView[]>([]);
  const [quotes, setQuotes] = useState<readonly QuoteView[]>([]);
  const [orders, setOrders] = useState<readonly SalesOrderView[]>([]);
  const [feedback, setFeedback] = useState("");
  const form = useForm<Form>({
    defaultValues: {
      branchId: "",
      customerId: "",
      discountAmount: "0",
      items: [{ catalogEntry: "", quantity: "1" }],
      notes: "",
      validUntil: "",
    },
    resolver: zodResolver(formSchema),
  });
  const fields = useFieldArray({ control: form.control, name: "items" });
  const catalog = useMemo<readonly CatalogEntry[]>(
    () => [
      ...products.map((p) => ({
        id: p.id,
        kind: "PRODUCT" as const,
        label: `${p.name} (${p.sku})`,
        price: p.defaultPrice,
      })),
      ...services.map((s) => ({
        id: s.id,
        kind: "SERVICE" as const,
        label: `${s.name} (${s.code})`,
        price: s.defaultPrice,
      })),
    ],
    [products, services],
  );
  const load = useCallback(
    async (signal?: AbortSignal) => {
      const controller = signal ?? new AbortController().signal;
      const base = `/api/v1/organizations/${organizationId}`;
      const [b, c, p, s, q, o] = await Promise.all([
        fetchData(`${base}/branches`, branchListSchema, controller),
        fetchData(`${base}/customers?limit=100&status=ACTIVE`, customerListSchema, controller),
        fetchData(`${base}/products?limit=100&status=ACTIVE`, productListSchema, controller),
        fetchData(`${base}/services?limit=100&status=ACTIVE`, serviceListSchema, controller),
        fetchData(`${base}/quotes`, quoteListSchema, controller),
        fetchData(`${base}/sales-orders`, salesOrderListSchema, controller),
      ]);
      setBranches(b.filter((x) => x.status === "ACTIVE"));
      setCustomers(c);
      setProducts(p);
      setServices(s);
      setQuotes(q);
      setOrders(o);
      if (!form.getValues("branchId")) form.setValue("branchId", b[0]?.id ?? "");
    },
    [form, organizationId],
  );
  useEffect(() => {
    const controller = new AbortController();
    async function loadInitial() {
      try {
        await load(controller.signal);
      } catch (error) {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar os documentos.",
          );
      }
    }
    void loadInitial();
    return () => controller.abort();
  }, [load]);
  async function request(path: string, method: string, body: object) {
    const response = await fetch(path, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method,
    });
    const payload = (await response.json()) as Partial<ProblemDetails>;
    if (!response.ok) throw new Error(payload.detail ?? "Não foi possível concluir a operação.");
    await load();
  }
  async function actionRequest(path: string, method: string, body: object) {
    try {
      setFeedback("");
      await request(path, method, body);
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível alterar o documento.");
    }
  }
  return (
    <section className="grid gap-5 rounded-2xl border bg-white p-5 shadow-sm">
      <div>
        <h2 className="text-lg font-semibold">Orçamentos e pedidos</h2>
        <p className="text-sm text-slate-600">
          Estoque e financeiro são alterados somente quando o pedido vira venda.
        </p>
      </div>
      {feedback ? (
        <p role="status" className="text-sm text-red-700">
          {feedback}
        </p>
      ) : null}
      <form
        className="grid gap-3 md:grid-cols-2"
        onSubmit={form.handleSubmit(async (value) => {
          try {
            setFeedback("");
            const items = value.items.map(({ catalogEntry, quantity }) => {
              const [kind, id] = catalogEntry.split(":");
              return {
                productId: kind === "PRODUCT" ? id : null,
                quantity,
                serviceId: kind === "SERVICE" ? id : null,
              };
            });
            const body = createQuoteBodySchema.parse({
              ...value,
              items,
              notes: value.notes || null,
              validUntil: value.validUntil || null,
            });
            await request(`/api/v1/organizations/${organizationId}/quotes`, "POST", body);
            form.reset({
              ...value,
              discountAmount: "0",
              items: [{ catalogEntry: "", quantity: "1" }],
              notes: "",
            });
          } catch (error) {
            setFeedback(
              error instanceof Error ? error.message : "Não foi possível criar o orçamento.",
            );
          }
        })}
      >
        <Select
          label="Filial"
          options={branches.map((x) => ({ label: x.name, value: x.id }))}
          registration={form.register("branchId")}
        />
        <Select
          label="Cliente"
          options={customers.map((x) => ({ label: x.name, value: x.id }))}
          registration={form.register("customerId")}
        />
        <label className="grid gap-1 text-sm">
          Validade
          <Input type="date" {...form.register("validUntil")} />
        </label>
        <label className="grid gap-1 text-sm">
          Desconto
          <Input inputMode="decimal" {...form.register("discountAmount")} />
        </label>
        {fields.fields.map((field, index) => (
          <div className="flex gap-2 md:col-span-2" key={field.id}>
            <select
              className="flex-1 rounded-md border px-3 py-2 text-sm"
              {...form.register(`items.${index}.catalogEntry`)}
            >
              <option value="">Selecione um item</option>
              {catalog.map((x) => (
                <option key={`${x.kind}:${x.id}`} value={`${x.kind}:${x.id}`}>
                  {x.label}
                </option>
              ))}
            </select>
            <Input
              className="w-28"
              inputMode="decimal"
              {...form.register(`items.${index}.quantity`)}
            />
            <Button type="button" variant="outline" onClick={() => fields.remove(index)}>
              Remover
            </Button>
          </div>
        ))}
        <label className="grid gap-1 text-sm md:col-span-2">
          Observações
          <Input {...form.register("notes")} />
        </label>
        <div className="flex gap-2 md:col-span-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => fields.append({ catalogEntry: "", quantity: "1" })}
          >
            Adicionar item
          </Button>
          <Button disabled={form.formState.isSubmitting} type="submit">
            Criar orçamento
          </Button>
        </div>
      </form>
      <DocumentLists
        onCompleteOrder={onCompleteOrder}
        orders={orders}
        quotes={quotes}
        request={actionRequest}
        organizationId={organizationId}
      />
    </section>
  );
}

function Select({
  label,
  options,
  registration,
}: {
  label: string;
  options: readonly { label: string; value: string }[];
  registration: ReturnType<ReturnType<typeof useForm<Form>>["register"]>;
}) {
  return (
    <label className="grid gap-1 text-sm">
      {label}
      <select className="rounded-md border px-3 py-2" {...registration}>
        <option value="">Selecione</option>
        {options.map((x) => (
          <option key={x.value} value={x.value}>
            {x.label}
          </option>
        ))}
      </select>
    </label>
  );
}
