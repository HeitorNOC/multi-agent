"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { authClient } from "@gestor/auth/client";
import { Button, buttonVariants } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { cn } from "@gestor/ui/lib/utils";
import Link from "next/link";
import { useState } from "react";
import { useForm } from "react-hook-form";

import { getAuthenticationErrorMessage } from "../authentication-error";
import {
  recoverPasswordSchema,
  type RecoverPasswordInput,
  type RecoverPasswordValues,
} from "../schemas";
import { FormFeedback } from "./form-feedback";

const inputClassName = "h-11 rounded-xl bg-white px-3";

export function RecoverPasswordForm() {
  const [wasSent, setWasSent] = useState(false);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
  } = useForm<RecoverPasswordInput, undefined, RecoverPasswordValues>({
    defaultValues: { email: "" },
    resolver: zodResolver(recoverPasswordSchema),
  });

  const submit = handleSubmit(async (values) => {
    try {
      const result = await authClient.requestPasswordReset({
        email: values.email,
        redirectTo: `${window.location.origin}/redefinir-senha`,
      });

      if (result.error) {
        setError("root", {
          message: getAuthenticationErrorMessage(
            result.error,
            "Não foi possível enviar as instruções agora. Tente novamente.",
          ),
          type: result.error.code ?? "server",
        });
        return;
      }

      setWasSent(true);
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  if (wasSent) {
    return (
      <div className="grid gap-6">
        <FormFeedback kind="success">
          Se existir uma conta com esse e-mail, enviaremos um link para redefinir a senha.
        </FormFeedback>
        <p className="text-sm leading-6 text-slate-600">
          Confira também a pasta de spam. O link expira em 1 hora e só pode ser usado uma vez.
        </p>
        <Link className={cn(buttonVariants(), "h-11 rounded-xl")} href="/login">
          Voltar para o login
        </Link>
      </div>
    );
  }

  return (
    <form className="grid gap-5" noValidate onSubmit={submit}>
      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="recover-email">
          E-mail
        </Label>
        <Input
          aria-describedby={errors.email ? "recover-email-error" : undefined}
          aria-invalid={Boolean(errors.email)}
          autoComplete="email"
          className={inputClassName}
          id="recover-email"
          inputMode="email"
          placeholder="voce@empresa.com.br"
          type="email"
          {...register("email")}
        />
        {errors.email ? (
          <p className="text-sm text-red-700" id="recover-email-error" role="alert">
            {errors.email.message}
          </p>
        ) : null}
      </div>

      {errors.root?.message ? (
        <FormFeedback kind="error">{errors.root.message}</FormFeedback>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSubmitting} type="submit">
        {isSubmitting ? "Enviando..." : "Enviar instruções"}
      </Button>

      <Link
        className="text-brand-600 hover:text-brand-700 text-center text-sm font-semibold"
        href="/login"
      >
        Voltar para o login
      </Link>
    </form>
  );
}
