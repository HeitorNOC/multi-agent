import { beforeEach, describe, expect, it, vi } from "vitest";

const runReportJobs = vi.fn();

vi.mock("@gestor/config", () => ({
  getSupabaseJobsEnv: () => ({ SUPABASE_JOBS_SECRET: "s".repeat(32) }),
}));
vi.mock("@/lib/server/report-jobs", () => ({ runReportJobs }));

describe("Supabase report jobs route", () => {
  beforeEach(() => {
    runReportJobs.mockReset().mockResolvedValue({
      expiration: { expired: 0, failed: 0 },
      outbox: { failed: 0, published: 2, rounds: 2 },
    });
  });

  it("rejects unauthenticated invocations", async () => {
    const { POST } = await import("./route");
    const response = await POST(
      new Request("https://hml.test/api/internal/jobs/reports", { method: "POST" }),
    );

    expect(response.status).toBe(401);
    expect(runReportJobs).not.toHaveBeenCalled();
  });

  it("processes report jobs for the configured Supabase cron secret", async () => {
    const { POST } = await import("./route");
    const response = await POST(
      new Request("https://hml.test/api/internal/jobs/reports", {
        headers: { authorization: `Bearer ${"s".repeat(32)}` },
        method: "POST",
      }),
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ outbox: { published: 2 } });
  });
});
