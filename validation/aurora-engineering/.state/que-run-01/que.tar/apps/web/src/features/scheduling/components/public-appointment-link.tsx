"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

type PublicAppointmentLinkProps = { token: string };
type State = "checking" | "ready" | "unavailable" | "verification";

type ProblemResponse = { code?: string };
type Options = {
  branches: readonly { id: string; name: string }[];
  services: readonly {
    durationMinutes: number;
    id: string;
    name: string;
    professionals: readonly { id: string; name: string }[];
  }[];
};
type Slots = { startsAt: readonly string[]; timeZone: string };
type PortalAppointment = {
  branchId: string;
  id: string;
  professionalName: string;
  professionalUserId: string;
  serviceId: string;
  startsAt: string;
  status: string;
  updatedAt: string;
};

export function PublicAppointmentLink({ token }: PublicAppointmentLinkProps) {
  const router = useRouter();
  const [state, setState] = useState<State>("checking");

  useEffect(() => {
    const controller = new AbortController();
    async function resolve() {
      try {
        const link = await fetch(`/api/public/appointment-links/${encodeURIComponent(token)}`, {
          signal: controller.signal,
        });
        if (!link.ok) {
          setState("unavailable");
          return;
        }
        const access = await fetch(
          `/api/public/appointment-links/${encodeURIComponent(token)}/access`,
          { method: "POST", signal: controller.signal },
        );
        if (access.status === 401) {
          router.replace(`/login?returnTo=${encodeURIComponent(`/p/${token}`)}`);
          return;
        }
        if (access.status === 403) {
          const problem = (await access.json().catch(() => ({}))) as ProblemResponse;
          setState(
            problem.code === "CUSTOMER_PORTAL_EMAIL_NOT_VERIFIED" ? "verification" : "unavailable",
          );
          return;
        }
        setState(access.ok ? "ready" : "unavailable");
      } catch {
        if (!controller.signal.aborted) setState("unavailable");
      }
    }
    void resolve();
    return () => controller.abort();
  }, [router, token]);

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-lg items-center px-5 py-10">
      <section className="w-full rounded-2xl border bg-white p-6 shadow-sm">
        {state === "checking" ? (
          <>
            <p className="text-sm text-slate-600">Preparando seu agendamento...</p>
            <div className="mt-4">
              <LoadingRows rows={2} />
            </div>
          </>
        ) : state === "ready" ? (
          <PublicAppointmentBooking token={token} />
        ) : state === "verification" ? (
          <>
            <h1 className="text-2xl font-semibold text-slate-950">Confirme seu e-mail</h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Confirme seu e-mail para usar o agendamento. Depois, abra este link novamente.
            </p>
          </>
        ) : (
          <>
            <h1 className="text-2xl font-semibold text-slate-950">Link indisponível</h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Este link não está disponível. Solicite um novo link à empresa.
            </p>
          </>
        )}
      </section>
    </main>
  );
}

function PublicAppointmentBooking({ token }: { token: string }) {
  const [options, setOptions] = useState<Options | null>(null);
  const [branchId, setBranchId] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [professionalUserId, setProfessionalUserId] = useState("");
  const [date, setDate] = useState("");
  const [slots, setSlots] = useState<Slots | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [appointments, setAppointments] = useState<readonly PortalAppointment[] | null>(null);
  const [appointmentsTimeZone, setAppointmentsTimeZone] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState("");
  const [rescheduleSlots, setRescheduleSlots] = useState<Slots | null>(null);

  const selectedService = options?.services.find((service) => service.id === serviceId) ?? null;

  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/public/appointment-links/${encodeURIComponent(token)}/options`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("OPTIONS_UNAVAILABLE");
        return (await response.json()) as { data: Options };
      })
      .then(({ data }) => {
        setOptions(data);
        setBranchId(data.branches[0]?.id ?? "");
        const service = data.services[0];
        setServiceId(service?.id ?? "");
        setProfessionalUserId(service?.professionals[0]?.id ?? "");
      })
      .catch(() => {
        if (!controller.signal.aborted) setMessage("Não foi possível carregar as opções.");
      });
    return () => controller.abort();
  }, [token]);

  useEffect(() => {
    const appointment = appointments?.find((item) => item.id === reschedulingId);
    if (!appointment || !rescheduleDate) return;
    const controller = new AbortController();
    setRescheduleSlots(null);
    const query = new URLSearchParams({ branchId: appointment.branchId, date: rescheduleDate, professionalUserId: appointment.professionalUserId, serviceId: appointment.serviceId });
    void fetch(`/api/public/appointment-links/${encodeURIComponent(token)}/slots?${query}`, { signal: controller.signal })
      .then(async (response) => response.ok ? (await response.json()) as { data: Slots } : Promise.reject())
      .then(({ data }) => setRescheduleSlots(data))
      .catch(() => { if (!controller.signal.aborted) setMessage("Não foi possível consultar horários."); });
    return () => controller.abort();
  }, [appointments, rescheduleDate, reschedulingId, token]);

  useEffect(() => {
    const controller = new AbortController();
    void fetch(`/api/public/appointment-links/${encodeURIComponent(token)}/appointments`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("APPOINTMENTS_UNAVAILABLE");
        return (await response.json()) as { data: { appointments: readonly PortalAppointment[]; timeZone: string } };
      })
      .then(({ data }) => { setAppointments(data.appointments); setAppointmentsTimeZone(data.timeZone); })
      .catch(() => {
        if (!controller.signal.aborted) setAppointments([]);
      });
    return () => controller.abort();
  }, [token]);

  useEffect(() => {
    if (!branchId || !serviceId || !professionalUserId || !date) return;
    const controller = new AbortController();
    setSlots(null);
    setMessage(null);
    const query = new URLSearchParams({ branchId, date, professionalUserId, serviceId });
    void fetch(`/api/public/appointment-links/${encodeURIComponent(token)}/slots?${query}`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("SLOTS_UNAVAILABLE");
        return (await response.json()) as { data: Slots };
      })
      .then(({ data }) => setSlots(data))
      .catch(() => {
        if (!controller.signal.aborted) setMessage("Não foi possível consultar horários.");
      });
    return () => controller.abort();
  }, [branchId, date, professionalUserId, serviceId, token]);

  function selectService(nextServiceId: string) {
    const service = options?.services.find((item) => item.id === nextServiceId);
    setServiceId(nextServiceId);
    setProfessionalUserId(service?.professionals[0]?.id ?? "");
  }

  async function book(startsAt: string) {
    if (!branchId || !serviceId || !professionalUserId) return;
    setSubmitting(true);
    setMessage(null);
    try {
      const response = await fetch(
        `/api/public/appointment-links/${encodeURIComponent(token)}/appointments`,
        {
          body: JSON.stringify({ branchId, professionalUserId, serviceId, startsAt }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      if (!response.ok) throw new Error("BOOKING_UNAVAILABLE");
      const result = (await response.json()) as { data: PortalAppointment };
      setMessage("Agendamento confirmado. Você receberá as próximas informações pela empresa.");
      setAppointments((current) => (current ? [...current, result.data] : [result.data]));
      setSlots((current) =>
        current ? { ...current, startsAt: current.startsAt.filter((value) => value !== startsAt) } : current,
      );
    } catch {
      setMessage("Este horário não está mais disponível. Escolha outra opção.");
    } finally {
      setSubmitting(false);
    }
  }

  async function cancel(appointment: PortalAppointment) {
    if (cancellationReason.trim().length < 2) {
      setMessage("Informe o motivo do cancelamento.");
      return;
    }
    setSubmitting(true);
    setMessage(null);
    try {
      const response = await fetch(
        `/api/public/appointment-links/${encodeURIComponent(token)}/appointments`,
        {
          body: JSON.stringify({
            appointmentId: appointment.id,
            cancellationReason: cancellationReason.trim(),
            expectedUpdatedAt: appointment.updatedAt,
          }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );
      if (!response.ok) throw new Error("CANCELLATION_UNAVAILABLE");
      setAppointments((current) => current?.filter((item) => item.id !== appointment.id) ?? []);
      setCancellingId(null);
      setCancellationReason("");
      setMessage("Agendamento cancelado.");
    } catch {
      setMessage("Não foi possível cancelar este agendamento. Atualize a página e tente novamente.");
    } finally {
      setSubmitting(false);
    }
  }

  if (!options)
    return <><p className="text-sm text-slate-600">Carregando opções...</p><div className="mt-4"><LoadingRows rows={3} /></div></>;

  return (
    <>
      <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Agendamento</p>
      <h1 className="mt-2 text-2xl font-semibold text-slate-950">Escolha seu horário</h1>
      <div className="mt-5 grid gap-4">
        <label className="grid gap-1 text-sm font-medium text-slate-700">Filial
          <select value={branchId} onChange={(event) => setBranchId(event.target.value)} className="rounded-lg border px-3 py-2">
            {options.branches.map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-medium text-slate-700">Serviço
          <select value={serviceId} onChange={(event) => selectService(event.target.value)} className="rounded-lg border px-3 py-2">
            {options.services.map((service) => <option key={service.id} value={service.id}>{service.name} · {service.durationMinutes} min</option>)}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-medium text-slate-700">Profissional
          <select value={professionalUserId} onChange={(event) => setProfessionalUserId(event.target.value)} className="rounded-lg border px-3 py-2">
            {selectedService?.professionals.map((professional) => <option key={professional.id} value={professional.id}>{professional.name}</option>)}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-medium text-slate-700">Data
          <input type="date" min={today()} value={date} onChange={(event) => setDate(event.target.value)} className="rounded-lg border px-3 py-2" />
        </label>
      </div>
      <section className="mt-6" aria-live="polite">
        <h2 className="text-sm font-semibold text-slate-900">Horários disponíveis</h2>
        {!date ? <p className="mt-2 text-sm text-slate-600">Selecione uma data para consultar os horários.</p> : !slots ? <div className="mt-3"><LoadingRows rows={2} /></div> : slots.startsAt.length === 0 ? <p className="mt-2 text-sm text-slate-600">Não há horários disponíveis nesta data.</p> :
          <div className="mt-3 flex flex-wrap gap-2">{slots.startsAt.map((startsAt) => <button key={startsAt} type="button" disabled={submitting} onClick={() => void book(startsAt)} className="rounded-lg border border-brand-600 px-3 py-2 text-sm font-medium text-brand-700 disabled:opacity-50">{formatTime(startsAt, slots.timeZone)}</button>)}</div>}
      </section>
      <section className="mt-8 border-t pt-6" aria-live="polite">
        <h2 className="text-sm font-semibold text-slate-900">Meus próximos agendamentos</h2>
        {!appointments ? <div className="mt-3"><LoadingRows rows={2} /></div> : appointments.length === 0 ? <p className="mt-2 text-sm text-slate-600">Você não possui agendamentos futuros.</p> :
          <div className="mt-3 grid gap-3">{appointments.map((appointment) => <article key={appointment.id} className="rounded-lg border p-3">
            <p className="font-medium text-slate-900">{formatDateTime(appointment.startsAt, appointmentsTimeZone ?? undefined)}</p>
            <p className="mt-1 text-sm text-slate-600">{appointment.professionalName}</p>
            {reschedulingId === appointment.id ? <div className="mt-3 grid gap-2"><input type="date" min={today()} value={rescheduleDate} onChange={(event) => setRescheduleDate(event.target.value)} className="rounded-lg border px-3 py-2" />{rescheduleDate && !rescheduleSlots ? <LoadingRows rows={1} /> : null}{rescheduleSlots?.startsAt.map((startsAt) => <button key={startsAt} type="button" disabled={submitting} onClick={() => void fetch(`/api/public/appointment-links/${encodeURIComponent(token)}/appointments/${appointment.id}/reschedule`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ expectedUpdatedAt: appointment.updatedAt, startsAt }) }).then((response) => { if (!response.ok) throw new Error(); return response.json(); }).then(({ data }) => { setAppointments((current) => current?.map((item) => item.id === appointment.id ? data : item) ?? []); setReschedulingId(null); setRescheduleDate(""); setMessage("Agendamento reagendado."); }).catch(() => setMessage("Não foi possível reagendar. Atualize a página e tente novamente."))} className="rounded-lg border border-brand-600 px-3 py-2 text-sm text-brand-700">{formatTime(startsAt, rescheduleSlots.timeZone)}</button>)}<button type="button" onClick={() => { setReschedulingId(null); setRescheduleDate(""); }} className="text-sm">Voltar</button></div> : <button type="button" onClick={() => setReschedulingId(appointment.id)} className="mt-3 text-sm font-medium text-brand-700">Reagendar</button>}
            {cancellingId === appointment.id ? <div className="mt-3 grid gap-2"><label className="grid gap-1 text-sm text-slate-700">Motivo do cancelamento<textarea value={cancellationReason} onChange={(event) => setCancellationReason(event.target.value)} className="rounded-lg border px-3 py-2" /></label><div className="flex gap-2"><button type="button" disabled={submitting} onClick={() => void cancel(appointment)} className="rounded-lg bg-red-700 px-3 py-2 text-sm font-medium text-white disabled:opacity-50">Confirmar cancelamento</button><button type="button" disabled={submitting} onClick={() => { setCancellingId(null); setCancellationReason(""); }} className="rounded-lg border px-3 py-2 text-sm">Voltar</button></div></div> : <button type="button" onClick={() => setCancellingId(appointment.id)} className="mt-3 text-sm font-medium text-red-700">Cancelar agendamento</button>}
          </article>)}</div>}
      </section>
      {message ? <p className="mt-4 text-sm text-slate-700" role="status">{message}</p> : null}
    </>
  );
}

function formatTime(value: string, timeZone: string) {
  return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone }).format(new Date(value));
}

function formatDateTime(value: string, timeZone?: string) {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short", timeZone }).format(new Date(value));
}

function today() {
  return new Date().toISOString().slice(0, 10);
}
