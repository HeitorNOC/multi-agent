import { beforeEach, describe, expect, it, vi } from "vitest";

const { acceptCurrentLegalDocuments, authenticate, getLegalAcceptanceStatus } = vi.hoisted(() => ({
  acceptCurrentLegalDocuments: vi.fn(),
  authenticate: vi.fn(),
  getLegalAcceptanceStatus: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({ services: { identityProvider: { authenticate } } }));
vi.mock("@/lib/server/legal-acceptance", () => ({
  acceptCurrentLegalDocuments,
  getLegalAcceptanceStatus,
}));

import { GET, POST } from "./route";

describe("legal acceptance route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    getLegalAcceptanceStatus.mockReset().mockResolvedValue({ accepted: false, documents: {} });
    acceptCurrentLegalDocuments.mockReset().mockResolvedValue({ accepted: true, documents: {} });
  });

  it("returns the pending document versions for the authenticated user", async () => {
    const response = await GET(new Request("http://localhost/api/v1/legal/acceptance"));
    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ data: { accepted: false, documents: {} } });
    expect(getLegalAcceptanceStatus).toHaveBeenCalledWith("user-1");
  });

  it("records acceptance only for the authenticated user", async () => {
    const response = await POST(
      new Request("http://localhost/api/v1/legal/acceptance", { method: "POST" }),
    );
    expect(response.status).toBe(200);
    expect(acceptCurrentLegalDocuments).toHaveBeenCalledWith("user-1");
  });
});
