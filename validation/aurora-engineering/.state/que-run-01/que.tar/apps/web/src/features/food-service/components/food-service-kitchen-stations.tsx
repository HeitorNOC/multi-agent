import type { FoodServiceKitchenStationView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

export function FoodServiceKitchenStations({
  branchId,
  onAdd,
  onSetDefault,
  stations,
}: {
  branchId: string;
  onAdd: (event: React.FormEvent<HTMLFormElement>) => void;
  onSetDefault: (station: FoodServiceKitchenStationView) => void;
  stations: readonly FoodServiceKitchenStationView[];
}) {
  const activeStations = stations.filter(
    (station) => station.branchId === branchId && station.status === "ACTIVE",
  );
  return (
    <section className="grid gap-4 rounded-xl border bg-white p-4">
      <div>
        <h2 className="font-semibold">Estações de cozinha</h2>
        <p className="text-sm text-slate-600">
          Organize onde cada etapa do preparo será acompanhada.
        </p>
      </div>
      <form className="grid gap-2 sm:grid-cols-4" onSubmit={onAdd}>
        <input
          className="h-10 rounded-xl border px-3"
          maxLength={100}
          name="name"
          placeholder="Ex.: Cozinha quente"
          required
        />
        <input
          className="h-10 rounded-xl border px-3"
          maxLength={40}
          name="code"
          placeholder="Código: COZ"
          required
        />
        <input
          className="h-10 rounded-xl border px-3"
          defaultValue="0"
          min="0"
          name="displayOrder"
          type="number"
        />
        <Button disabled={!branchId} type="submit">
          Adicionar estação
        </Button>
      </form>
      <div className="grid gap-2 sm:grid-cols-2">
        {activeStations.length === 0 ? (
          <p className="text-sm text-slate-600">Nenhuma estação cadastrada nesta filial.</p>
        ) : (
          activeStations.map((station) => (
            <div className="rounded-lg bg-slate-50 px-3 py-2 text-sm" key={station.id}>
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold">{station.name}</span>
                <span className="text-slate-600">{station.code}</span>
              </div>
              <div className="mt-2 flex items-center justify-between gap-2">
                <span className="text-xs text-slate-600">
                  {station.isDefault ? "Estação padrão" : "Rota específica ou padrão da filial"}
                </span>
                <Button
                  disabled={station.isDefault}
                  onClick={() => onSetDefault(station)}
                  size="sm"
                  type="button"
                  variant="outline"
                >
                  {station.isDefault ? "Padrão" : "Definir como padrão"}
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}
