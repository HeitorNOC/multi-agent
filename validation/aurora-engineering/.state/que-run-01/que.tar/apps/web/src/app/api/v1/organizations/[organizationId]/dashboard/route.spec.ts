import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, getDashboard, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  getDashboard: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    getDashboard: { execute: getDashboard },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const branchId = "20000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ organizationId }) };

describe("dashboard route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    getDashboard.mockReset().mockResolvedValue({ metrics: {} });
  });

  it("forwards the validated branch filter and resolved actor", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/dashboard?branchId=${branchId}`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(200);
    expect(getDashboard).toHaveBeenCalledWith({ branchId, organizationId }, { role: "OWNER" });
  });

  it("rejects an invalid branch after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/dashboard?branchId=invalid`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
  });
});
