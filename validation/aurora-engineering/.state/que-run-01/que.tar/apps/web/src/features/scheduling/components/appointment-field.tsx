import { Label } from "@gestor/ui/components/label";
import type { ReactNode } from "react";

export function AppointmentField({
  children,
  className,
  error,
  id,
  label,
}: {
  children: ReactNode;
  className?: string | undefined;
  error?: string | undefined;
  id: string;
  label: string;
}) {
  return (
    <div className={`grid gap-1.5 ${className ?? ""}`}>
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? (
        <p className="text-sm text-red-700" id={`${id}-error`} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
