import { getFileStorageEnv, getFiscalProviderEnv, getNationalNfseEnv } from "@gestor/config";
import { prisma } from "@gestor/database";
import {
  CancelFiscalDocument,
  CreateFiscalDocumentDownload,
  DefaultFiscalProfileValidator,
  DefaultFiscalProviderRegistry,
  HttpFiscalProvider,
  IssueFiscalDocument,
  ListFiscalDocuments,
  ListFiscalProfiles,
  NationalNfseProvider,
  ReissueFiscalDocument,
  UpsertFiscalProfile,
} from "@gestor/fiscal";
import {
  PrismaFiscalDocumentUnitOfWork,
  PrismaFiscalProfileUnitOfWork,
} from "@gestor/fiscal/prisma";
import { SupabaseFiscalArtifactStorage } from "@gestor/fiscal/storage";

const profilePersistence = new PrismaFiscalProfileUnitOfWork(prisma);
const documentPersistence = new PrismaFiscalDocumentUnitOfWork(prisma);
const httpEnvironment = getFiscalProviderEnv();
const nationalEnvironment = getNationalNfseEnv();
const providers = new DefaultFiscalProviderRegistry(
  undefined,
  httpEnvironment
    ? new HttpFiscalProvider({
        baseUrl: httpEnvironment.FISCAL_HTTP_PROVIDER_URL,
        timeoutMs: httpEnvironment.FISCAL_HTTP_TIMEOUT_MS,
        token: httpEnvironment.FISCAL_HTTP_PROVIDER_TOKEN,
      })
    : undefined,
  nationalEnvironment
    ? new NationalNfseProvider({
        baseUrl: nationalEnvironment.baseUrl,
        environment: nationalEnvironment.NFSE_NACIONAL_ENVIRONMENT,
        timeoutMs: nationalEnvironment.NFSE_NACIONAL_TIMEOUT_MS,
      })
    : undefined,
);
const artifacts = new SupabaseFiscalArtifactStorage(() => {
  const environment = getFileStorageEnv();
  return {
    bucket: environment.SUPABASE_STORAGE_BUCKET,
    secretKey: environment.SUPABASE_STORAGE_SECRET_KEY,
    url: environment.SUPABASE_STORAGE_URL,
  };
});

export const fiscalServices = {
  cancelFiscalDocument: new CancelFiscalDocument(documentPersistence, providers, artifacts),
  createFiscalDocumentDownload: new CreateFiscalDocumentDownload(
    documentPersistence,
    artifacts,
    () => getFileStorageEnv().FILE_SIGNED_URL_TTL_SECONDS,
  ),
  issueFiscalDocument: new IssueFiscalDocument(documentPersistence, providers, artifacts),
  listFiscalDocuments: new ListFiscalDocuments(documentPersistence),
  listFiscalProfiles: new ListFiscalProfiles(profilePersistence),
  reissueFiscalDocument: new ReissueFiscalDocument(documentPersistence, providers, artifacts),
  upsertFiscalProfile: new UpsertFiscalProfile(
    profilePersistence,
    new DefaultFiscalProfileValidator(),
  ),
};
