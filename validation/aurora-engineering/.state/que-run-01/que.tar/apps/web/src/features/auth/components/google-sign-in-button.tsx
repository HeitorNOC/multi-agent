"use client";

import { authClient } from "@gestor/auth/client";
import { Button } from "@gestor/ui/components/button";
import { useState } from "react";

import { getAuthenticationErrorMessage } from "../authentication-error";
import { getGoogleAuthNavigation } from "../google-auth-navigation";
import { FormFeedback } from "./form-feedback";

export function GoogleSignInButton({
  errorPath,
  returnTo,
}: {
  errorPath: "/cadastro" | "/login";
  returnTo?: string;
}) {
  const [feedback, setFeedback] = useState("");
  const [isPending, setIsPending] = useState(false);

  async function signIn() {
    setFeedback("");
    setIsPending(true);
    const navigation = getGoogleAuthNavigation(window.location.origin, errorPath, returnTo);

    try {
      const result = await authClient.signIn.social({
        ...navigation,
        provider: "google",
      });
      if (result.error) {
        setFeedback(
          getAuthenticationErrorMessage(
            result.error,
            "Não foi possível entrar com o Google. Tente novamente.",
          ),
        );
        setIsPending(false);
      }
    } catch {
      setFeedback("Não foi possível conectar ao Google. Tente novamente.");
      setIsPending(false);
    }
  }

  return (
    <div className="grid gap-3">
      <div className="flex items-center gap-3" aria-hidden="true">
        <span className="h-px flex-1 bg-slate-200" />
        <span className="text-xs font-medium uppercase tracking-wide text-slate-500">ou</span>
        <span className="h-px flex-1 bg-slate-200" />
      </div>
      <Button
        className="h-11 rounded-xl"
        disabled={isPending}
        onClick={() => void signIn()}
        type="button"
        variant="outline"
      >
        <GoogleMark />
        {isPending ? "Redirecionando..." : "Continuar com Google"}
      </Button>
      {feedback ? <FormFeedback kind="error">{feedback}</FormFeedback> : null}
    </div>
  );
}

function GoogleMark() {
  return (
    <svg aria-hidden="true" className="size-5" viewBox="0 0 24 24">
      <path
        d="M21.6 12.23c0-.71-.06-1.4-.18-2.06H12v3.9h5.38a4.6 4.6 0 0 1-2 3.02v2.53h3.24c1.9-1.75 2.98-4.33 2.98-7.39Z"
        fill="#4285F4"
      />
      <path
        d="M12 22c2.7 0 4.98-.9 6.63-2.38l-3.24-2.53c-.9.6-2.05.96-3.39.96-2.61 0-4.82-1.76-5.61-4.13H3.04v2.61A10 10 0 0 0 12 22Z"
        fill="#34A853"
      />
      <path
        d="M6.39 13.92A6.02 6.02 0 0 1 6.07 12c0-.67.12-1.32.32-1.92V7.47H3.04A10 10 0 0 0 2 12c0 1.61.39 3.14 1.04 4.53l3.35-2.61Z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.95c1.47 0 2.78.5 3.82 1.5l2.87-2.87A9.62 9.62 0 0 0 12 2a10 10 0 0 0-8.96 5.47l3.35 2.61C7.18 7.71 9.39 5.95 12 5.95Z"
        fill="#EA4335"
      />
    </svg>
  );
}
