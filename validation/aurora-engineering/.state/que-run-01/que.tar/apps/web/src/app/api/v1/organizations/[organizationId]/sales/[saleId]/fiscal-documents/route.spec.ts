import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, issueFiscalDocument, listFiscalDocuments, resolveTenantActor } = vi.hoisted(
  () => ({
    authenticate: vi.fn(),
    issueFiscalDocument: vi.fn(),
    listFiscalDocuments: vi.fn(),
    resolveTenantActor: vi.fn(),
  }),
);
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    issueFiscalDocument: { execute: issueFiscalDocument },
    listFiscalDocuments: { execute: listFiscalDocuments },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
const saleId = "10000000-0000-4000-8000-000000000002";

it("lists fiscal documents through the resolved tenant actor", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  listFiscalDocuments.mockResolvedValue([]);
  const response = await GET(
    new Request(
      `http://localhost/api/v1/organizations/${organizationId}/sales/${saleId}/fiscal-documents`,
    ),
    { params: Promise.resolve({ organizationId, saleId }) },
  );
  expect(response.status).toBe(200);
  expect(listFiscalDocuments).toHaveBeenCalledWith({ organizationId, saleId }, { role: "OWNER" });
});

it("requires idempotency and forwards a validated fiscal issuance", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  issueFiscalDocument.mockResolvedValue({ id: "document" });
  const response = await POST(
    new Request(
      `http://localhost/api/v1/organizations/${organizationId}/sales/${saleId}/fiscal-documents`,
      {
        body: JSON.stringify({ type: "NFCE" }),
        headers: { "content-type": "application/json", "idempotency-key": "issue-key-001" },
        method: "POST",
      },
    ),
    { params: Promise.resolve({ organizationId, saleId }) },
  );
  expect(response.status).toBe(200);
  expect(issueFiscalDocument).toHaveBeenCalledWith(
    { idempotencyKey: "issue-key-001", organizationId, saleId, type: "NFCE" },
    { role: "OWNER" },
  );
});
