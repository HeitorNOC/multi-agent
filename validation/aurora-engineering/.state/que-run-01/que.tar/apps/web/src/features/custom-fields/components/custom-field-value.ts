import type {
  CustomerCustomFieldDefinitionView,
  CustomerCustomFieldPrimitive,
} from "@gestor/contracts";

export function valueForApi(
  definition: CustomerCustomFieldDefinitionView,
  raw: boolean | number | string | undefined,
): CustomerCustomFieldPrimitive {
  if (raw === undefined || raw === "") return null;
  if (definition.fieldType === "BOOLEAN") return raw === true || raw === "true";
  if (definition.fieldType === "NUMBER") return Number(raw);
  return raw;
}
