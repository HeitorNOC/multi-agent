import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, listCashRegisters, openCashRegister, resolveTenantActor } = vi.hoisted(
  () => ({
    authenticate: vi.fn(),
    listCashRegisters: vi.fn(),
    openCashRegister: vi.fn(),
    resolveTenantActor: vi.fn(),
  }),
);

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listCashRegisters: { execute: listCashRegisters },
    openCashRegister: { execute: openCashRegister },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "50000000-0000-4000-8000-000000000001";
const branchId = "50000000-0000-4000-8000-000000000002";
const financialAccountId = "50000000-0000-4000-8000-000000000003";
const register = {
  branchId,
  closedAt: null,
  countedAmount: null,
  createdAt: "2026-08-12T12:00:00.000Z",
  currentExpectedAmount: "100.0000",
  differenceAmount: null,
  differenceReason: null,
  expectedAmount: null,
  financialAccountId,
  id: "50000000-0000-4000-8000-000000000004",
  openedAt: "2026-08-12T12:00:00.000Z",
  openingAmount: "100.0000",
  openingDifferenceAmount: "0.0000",
  openingDifferenceReason: null,
  openingExpectedAmount: "100.0000",
  operatorUserId: "50000000-0000-4000-8000-000000000005",
  reconciliationStartedAt: null,
  status: "OPEN",
  updatedAt: "2026-08-12T12:00:00.000Z",
  version: 0,
} as const;
const route = { params: Promise.resolve({ organizationId }) };

describe("cash register collection routes", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: register.operatorUserId });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OPERATOR" });
    listCashRegisters.mockReset().mockResolvedValue([register]);
    openCashRegister.mockReset().mockResolvedValue(register);
  });

  it("lists only registers returned by the tenant use case", async () => {
    const response = await GET(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/cash-registers`),
      route,
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ data: [register] });
    expect(listCashRegisters).toHaveBeenCalledWith({ organizationId }, { role: "OPERATOR" });
  });

  it("opens a register with idempotency and tenant actor", async () => {
    const body = {
      branchId,
      financialAccountId,
      openingAmount: "100",
      openingDifferenceReason: null,
    };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "open-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(openCashRegister).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "open-key", organizationId },
      { role: "OPERATOR" },
    );
  });

  it("rejects negative opening amounts after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers`,
      {
        body: JSON.stringify({
          branchId,
          financialAccountId,
          openingAmount: "-1",
          openingDifferenceReason: null,
        }),
        headers: { "content-type": "application/json", "idempotency-key": "open-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(openCashRegister).not.toHaveBeenCalled();
  });
});
