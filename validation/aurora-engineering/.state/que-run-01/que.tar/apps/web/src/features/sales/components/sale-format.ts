import type { SaleSummaryView } from "@gestor/contracts";

export function remainingQuantity(quantity: string, returnedQuantity: string): string {
  const remaining = decimalUnits(quantity) - decimalUnits(returnedQuantity);
  const safe = remaining > 0n ? remaining : 0n;
  return `${safe / 10_000n}.${String(safe % 10_000n).padStart(4, "0")}`;
}

function decimalUnits(value: string): bigint {
  const [integer = "0", fraction = ""] = value.replace(",", ".").split(".");
  return BigInt(integer) * 10_000n + BigInt(fraction.padEnd(4, "0").slice(0, 4));
}

export function statusLabel(status: SaleSummaryView["status"]): string {
  return {
    CANCELLED: "Cancelada",
    COMPLETED: "Concluída",
    DRAFT: "Rascunho",
    FULLY_RETURNED: "Devolvida",
    PARTIALLY_RETURNED: "Parcialmente devolvida",
  }[status];
}
