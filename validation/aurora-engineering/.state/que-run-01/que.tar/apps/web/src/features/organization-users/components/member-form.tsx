"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createOrganizationInvitationBodySchema,
  organizationInvitationViewSchema,
  type BranchView,
  type OrganizationRoleView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useForm, useWatch } from "react-hook-form";
import { z } from "zod";

const formSchema = z.object({
  branchIds: z.array(z.string()),
  branchScope: z.enum(["ALL", "SELECTED"]),
  email: z.email("Informe um e-mail válido."),
  roleId: z.string().min(1, "Selecione o papel."),
});
type Values = z.infer<typeof formSchema>;

export function MemberForm({
  branches,
  onCompleted,
  organizationId,
  roles,
}: {
  branches: readonly BranchView[];
  onCompleted: () => void;
  organizationId: string;
  roles: readonly OrganizationRoleView[];
}) {
  const form = useForm<Values>({
    defaultValues: { branchIds: [], branchScope: "ALL", email: "", roleId: "" },
    resolver: zodResolver(formSchema),
  });
  const scope = useWatch({ control: form.control, name: "branchScope" });

  async function submit(values: Values) {
    form.clearErrors("root");
    const body = createOrganizationInvitationBodySchema.parse({
      ...values,
      branchIds: values.branchScope === "ALL" ? [] : values.branchIds,
    });
    const response = await fetch(`/api/v1/organizations/${organizationId}/invitations`, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method: "POST",
    });
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok)
      return form.setError("root", {
        message: payload.detail ?? "Não foi possível enviar o convite.",
      });
    organizationInvitationViewSchema.parse(payload.data);
    form.reset();
    onCompleted();
  }

  return (
    <form
      className="grid content-start gap-4 rounded-2xl border bg-white p-5 shadow-sm"
      onSubmit={form.handleSubmit(submit)}
    >
      <div>
        <h2 className="text-lg font-semibold">Convidar usuário</h2>
        <p className="mt-1 text-sm text-slate-600">
          O acesso somente será ativado depois que a pessoa confirmar o próprio e-mail e aceitar.
        </p>
      </div>
      <Input aria-label="E-mail" placeholder="email@empresa.com" {...form.register("email")} />
      <select
        aria-label="Papel"
        className="rounded-md border px-3 py-2 text-sm"
        {...form.register("roleId")}
      >
        <option value="">Selecione o papel</option>
        {roles
          .filter(({ isSystem }) => !isSystem)
          .map((role) => (
            <option key={role.id} value={role.id}>
              {role.name}
            </option>
          ))}
      </select>
      <select
        aria-label="Escopo de filial"
        className="rounded-md border px-3 py-2 text-sm"
        {...form.register("branchScope")}
      >
        <option value="ALL">Todas as filiais</option>
        <option value="SELECTED">Filiais selecionadas</option>
      </select>
      {scope === "SELECTED" ? (
        <div className="grid gap-2">
          {branches.map((branch) => (
            <label className="flex gap-2 text-sm" key={branch.id}>
              <input type="checkbox" value={branch.id} {...form.register("branchIds")} />
              {branch.name}
            </label>
          ))}
        </div>
      ) : null}
      {form.formState.errors.root ? (
        <p className="text-sm text-red-700" role="alert">
          {form.formState.errors.root.message}
        </p>
      ) : null}
      <Button disabled={form.formState.isSubmitting || roles.length === 0} type="submit">
        Enviar convite
      </Button>
    </form>
  );
}
