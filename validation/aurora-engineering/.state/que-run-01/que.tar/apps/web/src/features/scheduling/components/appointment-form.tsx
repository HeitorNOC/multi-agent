"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createAppointmentBodySchema,
  customerListSchema,
  appointmentViewSchema,
  schedulingProfessionalListSchema,
  serviceListSchema,
  type AppointmentView,
  type BranchView,
  type CreateAppointmentBody,
  type CustomerView,
  type ProblemDetails,
  type SchedulingProfessionalView,
  type ServiceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";
import { useForm, useWatch } from "react-hook-form";
import { AppointmentField as Field } from "./appointment-field";
import {
  appointmentDefaults as defaults,
  appointmentValues as valuesFromAppointment,
  localDateTimeToIso,
} from "./appointment-form-values";

type AppointmentFormProps = {
  branches: readonly BranchView[];
  defaultBranchId: string;
  defaultDate: string;
  appointment?: AppointmentView;
  onSaved: (appointment: AppointmentView) => void;
  organizationId: string;
};

type ReferenceData = {
  customers: readonly CustomerView[];
  professionals: readonly SchedulingProfessionalView[];
  services: readonly ServiceView[];
};

export function AppointmentForm({
  branches,
  defaultBranchId,
  defaultDate,
  appointment,
  onSaved,
  organizationId,
}: AppointmentFormProps) {
  const [referenceData, setReferenceData] = useState<ReferenceData | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const {
    formState: { errors, isSubmitting },
    control,
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateAppointmentBody>({
    defaultValues: appointment
      ? valuesFromAppointment(appointment)
      : defaults(defaultDate, defaultBranchId),
    resolver: zodResolver(createAppointmentBodySchema),
  });

  useEffect(() => {
    const controller = new AbortController();
    async function loadReferenceData() {
      try {
        const [customerResponse, professionalResponse, serviceResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/customers?limit=100&status=ACTIVE`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/scheduling-professionals`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/services?limit=100&status=ACTIVE`, {
            signal: controller.signal,
          }),
        ]);
        const response = [customerResponse, professionalResponse, serviceResponse].find(
          (item) => !item.ok,
        );
        if (response) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }
        const [customers, professionals, services] = await Promise.all([
          customerResponse.json(),
          professionalResponse.json(),
          serviceResponse.json(),
        ]);
        setReferenceData({
          customers: customerListSchema.parse((customers as { data: unknown }).data),
          professionals: schedulingProfessionalListSchema.parse(
            (professionals as { data: unknown }).data,
          ),
          services: serviceListSchema.parse((services as { data: unknown }).data),
        });
        setLoadError(null);
      } catch (cause) {
        if (!controller.signal.aborted)
          setLoadError(
            cause instanceof Error
              ? cause.message
              : "Não foi possível carregar os dados do agendamento.",
          );
      }
    }
    void loadReferenceData();
    return () => controller.abort();
  }, [organizationId]);

  useEffect(() => {
    reset(
      appointment ? valuesFromAppointment(appointment) : defaults(defaultDate, defaultBranchId),
    );
  }, [appointment, defaultBranchId, defaultDate, reset]);

  const serviceId = useWatch({ control, name: "serviceId" });
  const professionalUserId = useWatch({ control, name: "professionalUserId" });
  const availableProfessionals = referenceData?.professionals.filter((professional) => {
    const service = referenceData.services.find((item) => item.id === serviceId);
    return !service || service.professionalUserIds.includes(professional.id);
  });

  useEffect(() => {
    const service = referenceData?.services.find((item) => item.id === serviceId);
    if (service) setValue("durationMinutes", service.durationMinutes, { shouldValidate: true });
  }, [referenceData?.services, serviceId, setValue]);

  useEffect(() => {
    if (
      professionalUserId &&
      !availableProfessionals?.some((item) => item.id === professionalUserId)
    )
      setValue("professionalUserId", "", { shouldValidate: true });
  }, [availableProfessionals, professionalUserId, setValue]);

  const submit = handleSubmit(async (values) => {
    setSuccessMessage(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/appointments${appointment ? `/${appointment.id}` : ""}`,
        {
          body: JSON.stringify(
            appointment ? { ...values, expectedUpdatedAt: appointment.updatedAt } : values,
          ),
          headers: appointment
            ? { "content-type": "application/json" }
            : { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: appointment ? "PATCH" : "POST",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const savedAppointment = createAppointmentResponse(payload.data);
      onSaved(savedAppointment);
      reset(
        appointment
          ? valuesFromAppointment(savedAppointment)
          : defaults(defaultDate, values.branchId),
      );
      setSuccessMessage(
        appointment ? "Agendamento atualizado com sucesso." : "Agendamento criado com sucesso.",
      );
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <section className="rounded-2xl border bg-white p-5" aria-labelledby="appointment-form-title">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          {appointment ? "Editar atendimento" : "Novo atendimento"}
        </p>
        <h3 className="mt-2 text-lg font-semibold text-slate-950" id="appointment-form-title">
          {appointment ? "Editar agendamento" : "Criar agendamento"}
        </h3>
        <p className="mt-1 text-sm text-slate-600">
          {appointment
            ? "Altere os dados necessários e salve para atualizar a agenda."
            : "Selecione o cliente, serviço, profissional e horário desejados."}
        </p>
      </div>
      {loadError ? (
        <p
          className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
          role="alert"
        >
          {loadError}
        </p>
      ) : null}
      {!referenceData && !loadError ? (
        <div className="mt-4">
          <LoadingRows rows={2} />
        </div>
      ) : null}
      {referenceData ? (
        <form className="mt-5 grid gap-4 sm:grid-cols-2" noValidate onSubmit={submit}>
          <Field error={errors.branchId?.message} id="appointment-branch" label="Filial">
            <select
              className="h-11 w-full rounded-xl border bg-white px-3 text-sm"
              id="appointment-branch"
              {...register("branchId")}
            >
              <option value="">Selecione uma filial</option>
              {branches
                .filter((branch) => branch.status === "ACTIVE")
                .map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name}
                  </option>
                ))}
            </select>
          </Field>
          <Field error={errors.customerId?.message} id="appointment-customer" label="Cliente">
            <select
              className="h-11 w-full rounded-xl border bg-white px-3 text-sm"
              id="appointment-customer"
              {...register("customerId")}
            >
              <option value="">Selecione um cliente</option>
              {referenceData.customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </select>
          </Field>
          <Field error={errors.serviceId?.message} id="appointment-service" label="Serviço">
            <select
              className="h-11 w-full rounded-xl border bg-white px-3 text-sm"
              id="appointment-service"
              {...register("serviceId")}
            >
              <option value="">Selecione um serviço</option>
              {referenceData.services.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.name} · {service.durationMinutes} min
                </option>
              ))}
            </select>
          </Field>
          <Field
            error={errors.professionalUserId?.message}
            id="appointment-professional"
            label="Profissional"
          >
            <select
              className="h-11 w-full rounded-xl border bg-white px-3 text-sm"
              id="appointment-professional"
              {...register("professionalUserId")}
            >
              <option value="">Selecione um profissional</option>
              {availableProfessionals?.map((professional) => (
                <option key={professional.id} value={professional.id}>
                  {professional.name}
                </option>
              ))}
            </select>
          </Field>
          <Field error={errors.startsAt?.message} id="appointment-starts-at" label="Data e horário">
            <Input
              className="h-11 rounded-xl px-3"
              id="appointment-starts-at"
              type="datetime-local"
              {...register("startsAt", { setValueAs: localDateTimeToIso })}
            />
          </Field>
          <Field
            error={errors.durationMinutes?.message}
            id="appointment-duration"
            label="Duração (minutos)"
          >
            <Input
              className="h-11 rounded-xl px-3"
              id="appointment-duration"
              min={5}
              step={5}
              type="number"
              {...register("durationMinutes", { valueAsNumber: true })}
            />
          </Field>
          <Field
            className="sm:col-span-2"
            error={errors.notes?.message}
            id="appointment-notes"
            label="Observações (opcional)"
          >
            <textarea
              className="min-h-24 w-full rounded-xl border px-3 py-2 text-sm"
              id="appointment-notes"
              {...register("notes")}
            />
          </Field>
          {errors.root?.message ? (
            <p
              className="sm:col-span-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </p>
          ) : null}
          {successMessage ? (
            <p
              className="border-brand-100 bg-brand-50 text-brand-700 sm:col-span-2 rounded-xl border p-3 text-sm"
              role="status"
            >
              {successMessage}
            </p>
          ) : null}
          <div className="sm:col-span-2">
            <Button disabled={isSubmitting} type="submit">
              {isSubmitting
                ? appointment
                  ? "Salvando..."
                  : "Agendando..."
                : appointment
                  ? "Salvar alterações"
                  : "Criar agendamento"}
            </Button>
          </div>
        </form>
      ) : null}
    </section>
  );
}

function createAppointmentResponse(value: unknown): AppointmentView {
  return appointmentViewSchema.parse(value);
}
