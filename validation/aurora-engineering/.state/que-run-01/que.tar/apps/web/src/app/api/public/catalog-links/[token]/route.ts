import { handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ token: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const { token } = await route.params;
      const link = await services.resolvePublicCatalogPortalLink.execute(token);
      return Response.json({ data: { available: true, commercialPolicy: link.commercialPolicy } });
    },
    {
      // A catalog link is deliberately public: visitors must be able to verify
      // that a shared link exists before the portal asks them to sign in. Every
      // operation that exposes customer data or changes a cart remains authenticated.
      authentication: "PUBLIC",
      legalAcceptance: false,
      rateLimit: apiRateLimitPolicies.publicPortalLink,
    },
  );
}
