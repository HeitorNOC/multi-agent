import { createInitialStockBodySchema, inventoryBranchParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ branchId: string; organizationId: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = inventoryBranchParamsSchema.parse(await route.params);
    const body = createInitialStockBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const result = await services.createInitialStock.execute(
      { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
      actor,
    );
    return Response.json({ data: result }, { status: 201 });
  });
}
