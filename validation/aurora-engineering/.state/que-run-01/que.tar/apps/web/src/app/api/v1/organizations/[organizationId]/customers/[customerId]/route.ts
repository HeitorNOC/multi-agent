import { customerParamsSchema, updateCustomerBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ customerId: string; organizationId: string }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = customerParamsSchema.parse(await route.params);
    const body = updateCustomerBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const customer = await services.updateCustomer.execute(
      {
        ...body,
        customerId: params.customerId,
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json({ data: customer });
  });
}
