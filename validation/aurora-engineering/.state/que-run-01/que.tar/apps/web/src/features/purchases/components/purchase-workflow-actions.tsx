"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  financialCategoryListSchema,
  purchaseDetailViewSchema,
  purchaseReceiptViewSchema,
  receivePurchaseOrderBodySchema,
  type FinancialCategoryView,
  type ProblemDetails,
  type PurchaseDetailView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { fetchData } from "../../sales/components/direct-sale-data";
import { SelectField } from "../../sales/components/direct-sale-support";

const formSchema = z.object({
  dueDate: z.string().min(1, "Informe o vencimento."),
  expenseCategoryId: z.string().min(1, "Selecione a categoria."),
  items: z.array(z.object({ purchaseItemId: z.string(), quantity: z.string() })),
});
type FormValues = z.infer<typeof formSchema>;

export function PurchaseWorkflowActions({
  onChanged,
  organizationId,
  purchase,
}: {
  onChanged: (purchase: PurchaseDetailView, message: string) => void;
  organizationId: string;
  purchase: PurchaseDetailView;
}) {
  const [categories, setCategories] = useState<readonly FinancialCategoryView[]>([]);
  const [feedback, setFeedback] = useState("");
  const receivableItems = purchase.items.filter(
    (item) => Number(item.quantityReceived) < Number(item.quantityOrdered),
  );
  const form = useForm<FormValues>({
    defaultValues: {
      dueDate: "",
      expenseCategoryId: "",
      items: receivableItems.map((item) => ({
        purchaseItemId: item.id,
        quantity: (Number(item.quantityOrdered) - Number(item.quantityReceived)).toFixed(4),
      })),
    },
    resolver: zodResolver(formSchema),
  });

  useEffect(() => {
    if (!["ORDERED", "PARTIALLY_RECEIVED"].includes(purchase.status)) return;
    const controller = new AbortController();
    void fetchData(
      `/api/v1/organizations/${organizationId}/financial-categories`,
      financialCategoryListSchema,
      controller.signal,
    ).then((items) => {
      const active = items.filter(({ status, type }) => status === "ACTIVE" && type === "EXPENSE");
      setCategories(active);
      form.setValue("expenseCategoryId", active[0]?.id ?? "");
    });
    return () => controller.abort();
  }, [form, organizationId, purchase.status]);

  async function order() {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/purchases/${purchase.id}/order`,
      {
        body: JSON.stringify({ expectedUpdatedAt: purchase.updatedAt }),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      },
    );
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível emitir o pedido.");
    onChanged(purchaseDetailViewSchema.parse(payload.data), "Pedido de compra emitido.");
  }

  async function receive(values: FormValues) {
    const body = receivePurchaseOrderBodySchema.parse({
      ...values,
      expectedUpdatedAt: purchase.updatedAt,
      items: values.items.filter(({ quantity }) => Number(quantity) > 0),
    });
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/purchases/${purchase.id}/receipts`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      },
    );
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível receber o pedido.");
    const receipt = purchaseReceiptViewSchema.parse(payload.data);
    onChanged(
      receipt.purchase,
      `Recebimento registrado em R$ ${receipt.totalAmount}. Estoque e financeiro atualizados.`,
    );
  }

  if (purchase.status === "DRAFT")
    return (
      <div className="grid gap-2 border-t pt-4">
        {feedback ? <p className="text-sm text-red-700">{feedback}</p> : null}
        <Button onClick={() => void order()} type="button">
          Emitir pedido de compra
        </Button>
      </div>
    );
  if (!["ORDERED", "PARTIALLY_RECEIVED"].includes(purchase.status)) return null;
  return (
    <form className="grid gap-4 border-t pt-4" onSubmit={form.handleSubmit(receive)}>
      <h4 className="font-semibold">Registrar recebimento</h4>
      <div className="grid gap-3 sm:grid-cols-2">
        <SelectField label="Categoria de despesa">
          <select
            className="rounded-md border px-3 py-2 text-sm"
            {...form.register("expenseCategoryId")}
          >
            <option value="">Selecione</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </SelectField>
        <SelectField label="Vencimento">
          <Input type="date" {...form.register("dueDate")} />
        </SelectField>
      </div>
      {receivableItems.map((item, index) => (
        <SelectField
          key={item.id}
          label={`${item.description} (restante: ${(Number(item.quantityOrdered) - Number(item.quantityReceived)).toFixed(4)})`}
        >
          <input type="hidden" {...form.register(`items.${index}.purchaseItemId`)} />
          <Input inputMode="decimal" {...form.register(`items.${index}.quantity`)} />
        </SelectField>
      ))}
      {feedback ? <p className="text-sm text-red-700">{feedback}</p> : null}
      <Button disabled={form.formState.isSubmitting || categories.length === 0} type="submit">
        Confirmar recebimento
      </Button>
    </form>
  );
}
