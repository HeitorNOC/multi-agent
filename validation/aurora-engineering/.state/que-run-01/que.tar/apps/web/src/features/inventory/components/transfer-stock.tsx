"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  stockBalanceListSchema,
  stockTransferResultSchema,
  transferStockBodySchema,
  type BranchView,
  type ProblemDetails,
  type StockBalanceView,
  type TransferStockBody,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useForm } from "react-hook-form";

export function StockTransferForm({
  balance,
  branches,
  onChanged,
  organizationId,
  setFeedback,
}: {
  balance: StockBalanceView;
  branches: readonly BranchView[];
  onChanged: () => Promise<void>;
  organizationId: string;
  setFeedback: (message: string) => void;
}) {
  const targets = branches.filter(({ id }) => id !== balance.branchId);
  const form = useForm<TransferStockBody>({
    defaultValues: {
      expectedSourceVersion: balance.version,
      expectedTargetVersion: 0,
      productId: balance.productId,
      quantity: "",
      reason: "",
      sourceBranchId: balance.branchId,
      targetBranchId: targets[0]?.id ?? "",
    },
    resolver: zodResolver(transferStockBodySchema),
  });
  return (
    <section className="rounded-2xl border bg-white p-5 shadow-sm">
      <h2 className="text-lg font-semibold">Transferir entre filiais: {balance.productName}</h2>
      <p className="mb-4 mt-1 text-sm text-slate-600">Disponível: {balance.quantityOnHand}</p>
      <form
        className="grid gap-4 sm:grid-cols-4"
        onSubmit={form.handleSubmit(async (body) => {
          try {
            setFeedback("");
            const expectedTargetVersion = await loadTargetVersion(organizationId, body);
            const response = await fetch(
              `/api/v1/organizations/${organizationId}/stock-transfers`,
              {
                body: JSON.stringify({ ...body, expectedTargetVersion }),
                headers: {
                  "content-type": "application/json",
                  "idempotency-key": crypto.randomUUID(),
                },
                method: "POST",
              },
            );
            const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
            if (!response.ok) {
              setFeedback(payload.detail ?? "Não foi possível transferir o estoque.");
              return;
            }
            stockTransferResultSchema.parse(payload.data);
            await onChanged();
          } catch (error) {
            setFeedback(
              error instanceof Error ? error.message : "Não foi possível transferir o estoque.",
            );
          }
        })}
      >
        <input type="hidden" {...form.register("productId")} />
        <input type="hidden" {...form.register("sourceBranchId")} />
        <input type="hidden" {...form.register("expectedSourceVersion", { valueAsNumber: true })} />
        <input type="hidden" {...form.register("expectedTargetVersion", { valueAsNumber: true })} />
        <label className="grid gap-1 text-sm font-medium">
          Filial de destino
          <select
            className="rounded-md border px-3 py-2 text-sm"
            {...form.register("targetBranchId")}
          >
            {targets.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
          <ErrorText message={form.formState.errors.targetBranchId?.message} />
        </label>
        <label className="grid gap-1 text-sm font-medium">
          Quantidade
          <Input inputMode="decimal" {...form.register("quantity")} />
          <ErrorText message={form.formState.errors.quantity?.message} />
        </label>
        <label className="grid gap-1 text-sm font-medium">
          Motivo
          <Input {...form.register("reason")} />
          <ErrorText message={form.formState.errors.reason?.message} />
        </label>
        <div className="flex items-end">
          <Button disabled={form.formState.isSubmitting || targets.length === 0} type="submit">
            Concluir transferência
          </Button>
        </div>
      </form>
    </section>
  );
}

async function loadTargetVersion(organizationId: string, body: TransferStockBody): Promise<number> {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/branches/${body.targetBranchId}/stock-balances?limit=100`,
  );
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok)
    throw new Error(payload.detail ?? "Não foi possível consultar o estoque de destino.");
  return (
    stockBalanceListSchema.parse(payload.data).find(({ productId }) => productId === body.productId)
      ?.version ?? 0
  );
}

function ErrorText({ message }: { message: string | undefined }) {
  return message ? <span className="text-xs text-red-700">{message}</span> : null;
}
