import type { CompletedSaleView } from "@gestor/contracts";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { DirectSaleFeedback } from "./direct-sale-feedback";

describe("DirectSaleFeedback", () => {
  it("renders neither status nor summary without feedback", () => {
    expect(renderToStaticMarkup(<DirectSaleFeedback completed={null} feedback="" />)).toBe("");
  });

  it("renders completion amounts and due date", () => {
    const completed = {
      receivable: { dueDate: "2026-08-20", openAmount: "25.00" },
      total: "100.00",
    } as CompletedSaleView;
    const markup = renderToStaticMarkup(
      <DirectSaleFeedback completed={completed} feedback="Venda concluída." />,
    );

    expect(markup).toContain('role="status"');
    expect(markup).toContain("Venda concluída.");
    expect(markup).toContain("Total: R$ 100.00");
    expect(markup).toContain("Em aberto: R$ 25.00");
    expect(markup).toContain("2026-08-20");
  });
});
