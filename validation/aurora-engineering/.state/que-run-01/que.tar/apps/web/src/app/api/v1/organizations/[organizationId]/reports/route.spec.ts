import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({
  requireCurrentLegalAcceptance: vi.fn(),
}));

const {
  authenticate,
  consume,
  listReports,
  reportRequestPolicy,
  requestReport,
  resolveTenantActor,
} = vi.hoisted(() => ({
  authenticate: vi.fn(),
  consume: vi.fn(),
  listReports: vi.fn(),
  reportRequestPolicy: { limit: 5, namespace: "api.report-request", windowMs: 600_000 },
  requestReport: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@/lib/server/rate-limit", () => ({
  apiRateLimiter: { consume },
  apiRateLimitPolicies: {
    default: { limit: 120, namespace: "api.default", windowMs: 60_000 },
    reportRequest: reportRequestPolicy,
  },
  createRateLimitSubject: () => "test-subject",
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listReports: { execute: listReports },
    requestReport: { execute: requestReport },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const reportId = "30000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ organizationId }) };

describe("report request route", () => {
  beforeEach(() => {
    consume.mockReset().mockResolvedValue({
      allowed: true,
      limit: 5,
      remaining: 4,
      resetAt: new Date("2026-08-13T20:10:00.000Z"),
    });
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    requestReport.mockReset().mockResolvedValue({ id: reportId });
    listReports.mockReset().mockResolvedValue({
      data: [],
      page: { hasMore: false, nextCursor: null },
    });
  });

  it("lists the authorized persisted report history", async () => {
    const response = await GET(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/reports?limit=10`),
      route,
    );

    expect(response.status).toBe(200);
    expect(listReports).toHaveBeenCalledWith({ limit: 10, organizationId }, { role: "OWNER" });
  });

  it("queues a report with idempotency and the restricted rate limit", async () => {
    const body = { filters: {}, format: "XLSX", reportType: "SALES" };
    const response = await POST(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/reports`, {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "report-key" },
        method: "POST",
      }),
      route,
    );

    expect(response.status).toBe(202);
    expect(response.headers.get("location")).toContain(`/reports/${reportId}`);
    expect(consume).toHaveBeenCalledWith(expect.objectContaining({ policy: reportRequestPolicy }));
    expect(requestReport).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "report-key", organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects an unsupported report type after authentication", async () => {
    const response = await POST(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/reports`, {
        body: JSON.stringify({ filters: {}, format: "CSV", reportType: "ADVANCED_AI" }),
        headers: { "content-type": "application/json", "idempotency-key": "report-key" },
        method: "POST",
      }),
      route,
    );

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(requestReport).not.toHaveBeenCalled();
  });
});
