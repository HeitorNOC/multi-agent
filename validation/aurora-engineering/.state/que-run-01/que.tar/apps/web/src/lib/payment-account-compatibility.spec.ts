import { describe, expect, it } from "vitest";

import { accountTypeForPayment } from "./payment-account-compatibility";

describe("accountTypeForPayment", () => {
  it("routes payment links to an acquirer like card receipts", () => {
    expect(accountTypeForPayment("PAYMENT_LINK")).toBe("ACQUIRER");
    expect(accountTypeForPayment("CARD")).toBe("ACQUIRER");
  });

  it("preserves the cash and bank destinations", () => {
    expect(accountTypeForPayment("CASH")).toBe("CASH");
    expect(accountTypeForPayment("PIX")).toBe("BANK");
  });
});
