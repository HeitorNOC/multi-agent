import { describe, expect, it } from "vitest";

import { formatBrl, formatDate } from "./bank-statement-format";

describe("bank statement formatting", () => {
  it("formats canonical amounts and dates for pt-BR", () => {
    expect(formatBrl("1234.50")).toBe("R$ 1.234,50");
    expect(formatBrl("-10.25")).toBe("-R$ 10,25");
    expect(formatDate("2026-08-11T12:00:00.000Z")).toBe("11/08/2026");
  });
});
