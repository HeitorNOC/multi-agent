import { getSupabaseJobsEnv } from "@gestor/config";

import { handleApiRequest } from "@/lib/server/api-request";
import { requireInternalJobAccess } from "@/lib/server/internal-job-access";
import { runReportJobs } from "@/lib/server/report-jobs";

export const maxDuration = 300;
export const runtime = "nodejs";

export async function POST(request: Request): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      requireInternalJobAccess(request, getSupabaseJobsEnv().SUPABASE_JOBS_SECRET);
      return Response.json(await runReportJobs(), {
        headers: { "cache-control": "no-store" },
      });
    },
    { authentication: "PUBLIC", rateLimit: false },
  );
}
