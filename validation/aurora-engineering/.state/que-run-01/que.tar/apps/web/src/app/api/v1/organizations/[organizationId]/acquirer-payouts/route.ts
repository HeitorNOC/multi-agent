import { acquirerPayoutParamsSchema, createAcquirerPayoutBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

async function actorFor(
  request: Request,
  route: RouteParameters,
  api: { correlationId: string; requestId: string },
) {
  const params = acquirerPayoutParamsSchema.parse(await route.params);
  const identity = await authenticateApiRequest(request);
  const actor = await services.resolveTenantActor.execute({
    correlationId: api.correlationId,
    organizationId: params.organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
  return { actor, organizationId: params.organizationId };
}

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { actor, organizationId } = await actorFor(request, route, api);
    const data = await services.listAcquirerPayouts.execute(organizationId, actor);
    return Response.json({ data });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { actor, organizationId } = await actorFor(request, route, api);
    const body = createAcquirerPayoutBodySchema.parse(await readJsonBody(request));
    const data = await services.settleAcquirerPayout.execute({ ...body, organizationId }, actor);
    return Response.json({ data }, { status: 201 });
  });
}
