"use client";

import { useState } from "react";

import { PurchaseForm } from "./purchase-form";
import { PurchaseList } from "./purchase-list";

export function PurchaseManagement({ organizationId }: { organizationId: string }) {
  const [revision, setRevision] = useState(0);
  return (
    <div className="grid gap-10">
      <PurchaseForm
        mode="plan"
        onCompleted={() => setRevision((current) => current + 1)}
        organizationId={organizationId}
      />
      <PurchaseForm
        onCompleted={() => setRevision((current) => current + 1)}
        organizationId={organizationId}
      />
      <PurchaseList
        onChanged={() => setRevision((current) => current + 1)}
        organizationId={organizationId}
        revision={revision}
      />
    </div>
  );
}
