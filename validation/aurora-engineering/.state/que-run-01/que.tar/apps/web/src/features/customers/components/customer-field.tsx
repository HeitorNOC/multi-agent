import { Label } from "@gestor/ui/components/label";
import type { ReactNode } from "react";

export function CustomerField({
  children,
  error,
  id,
  label,
}: {
  children: ReactNode;
  error: string | undefined;
  id: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? (
        <p className="text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
