"use client";

import {
  appointmentListSchema,
  branchListSchema,
  type AppointmentView,
  type BranchView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

import { AppointmentActions } from "./appointment-actions";
import { AppointmentForm } from "./appointment-form";
import { AppointmentPortalLinkManager } from "./appointment-portal-link-manager";
import { AvailabilityManager } from "./availability-manager";
import { AppointmentSettingsManager } from "./appointment-settings-manager";

type ScheduleBoardProps = { organizationId: string };

const statusLabels: Record<AppointmentView["status"], string> = {
  CANCELLED: "Cancelado",
  COMPLETED: "Concluído",
  CONFIRMED: "Confirmado",
  IN_SERVICE: "Em atendimento",
  NO_SHOW: "Não compareceu",
  SCHEDULED: "Agendado",
};

export function ScheduleBoard({ organizationId }: ScheduleBoardProps) {
  const [date, setDate] = useState(() => toDateInput(new Date()));
  const [branchId, setBranchId] = useState("");
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [appointments, setAppointments] = useState<readonly AppointmentView[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editingAppointment, setEditingAppointment] = useState<AppointmentView | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const dayStart = new Date(`${date}T00:00:00`);
        const dayEnd = new Date(`${date}T23:59:59.999`);
        const query = new URLSearchParams({
          startsAfter: dayStart.toISOString(),
          endsBefore: dayEnd.toISOString(),
        });
        if (branchId) query.set("branchId", branchId);
        const [branchResponse, appointmentResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/branches`, { signal: controller.signal }),
          fetch(`/api/v1/organizations/${organizationId}/appointments?${query}`, {
            signal: controller.signal,
          }),
        ]);
        if (!branchResponse.ok || !appointmentResponse.ok) {
          const response = branchResponse.ok ? appointmentResponse : branchResponse;
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }
        const branchPayload = (await branchResponse.json()) as { data: unknown };
        const appointmentPayload = (await appointmentResponse.json()) as { data: unknown };
        setBranches(branchListSchema.parse(branchPayload.data));
        setAppointments(appointmentListSchema.parse(appointmentPayload.data));
        setError(null);
      } catch (cause) {
        if (!controller.signal.aborted)
          setError(cause instanceof Error ? cause.message : "Não foi possível carregar a agenda.");
      }
    }
    void load();
    return () => controller.abort();
  }, [branchId, date, organizationId]);

  const appointmentsByHour = useMemo(() => {
    const groups = new Map<number, AppointmentView[]>();
    for (const appointment of appointments ?? []) {
      const hour = new Date(appointment.startsAt).getHours();
      groups.set(hour, [...(groups.get(hour) ?? []), appointment]);
    }
    return groups;
  }, [appointments]);

  function moveDay(amount: number) {
    const next = new Date(`${date}T12:00:00`);
    next.setDate(next.getDate() + amount);
    setDate(toDateInput(next));
  }

  return (
    <section className="grid gap-5" aria-labelledby="schedule-board-title">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Operação</p>
          <h2 className="mt-2 text-xl font-semibold text-slate-950" id="schedule-board-title">
            Agenda diária
          </h2>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => moveDay(-1)} type="button" variant="outline">
            Dia anterior
          </Button>
          <Button onClick={() => setDate(toDateInput(new Date()))} type="button" variant="outline">
            Hoje
          </Button>
          <Button onClick={() => moveDay(1)} type="button" variant="outline">
            Próximo dia
          </Button>
        </div>
      </div>
      <div className="grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-2">
        <div className="grid gap-1.5">
          <Label htmlFor="schedule-date">Data</Label>
          <input
            className="h-10 rounded-xl border px-3"
            id="schedule-date"
            onChange={(event) => setDate(event.target.value)}
            type="date"
            value={date}
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="schedule-branch">Filial</Label>
          <select
            className="h-10 rounded-xl border px-3"
            id="schedule-branch"
            onChange={(event) => setBranchId(event.target.value)}
            value={branchId}
          >
            <option value="">Todas as filiais permitidas</option>
            {branches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <AppointmentForm
        branches={branches}
        defaultBranchId={
          branchId || branches.find((branch) => branch.status === "ACTIVE")?.id || ""
        }
        defaultDate={date}
        onSaved={(appointment) => {
          const appointmentDate = toDateInput(new Date(appointment.startsAt));
          if (appointmentDate === date && (!branchId || appointment.branchId === branchId))
            setAppointments((current) =>
              current
                ? [...current.filter((item) => item.id !== appointment.id), appointment]
                : [appointment],
            );
        }}
        organizationId={organizationId}
      />
      <AvailabilityManager branches={branches} organizationId={organizationId} />
      <AppointmentSettingsManager organizationId={organizationId} />
      <AppointmentPortalLinkManager branches={branches} organizationId={organizationId} />
      {error ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"
          role="alert"
        >
          {error}
        </p>
      ) : null}
      {!appointments && !error ? <LoadingRows rows={3} /> : null}
      {appointments && appointments.length === 0 ? (
        <p className="rounded-2xl border border-dashed bg-white p-6 text-sm text-slate-600">
          Nenhum atendimento neste dia.
        </p>
      ) : null}
      <div className="grid gap-3">
        {[...appointmentsByHour.entries()]
          .sort(([a], [b]) => a - b)
          .map(([hour, items]) => (
            <div className="grid gap-2 sm:grid-cols-[5rem_1fr]" key={hour}>
              <p className="pt-3 text-sm font-semibold text-slate-500">
                {String(hour).padStart(2, "0")}:00
              </p>
              <div className="grid gap-2">
                {items.map((appointment) => (
                  <article className="rounded-xl border bg-white p-4" key={appointment.id}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-semibold text-slate-950">
                        {formatTime(appointment.startsAt)} – {formatTime(appointment.endsAt)}
                      </p>
                      <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700">
                        {statusLabels[appointment.status]}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-slate-600">
                      Profissional: {appointment.professionalName}
                    </p>
                    {appointment.notes ? (
                      <p className="mt-2 text-sm text-slate-500">{appointment.notes}</p>
                    ) : null}
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button
                        onClick={() =>
                          setEditingAppointment((current) =>
                            current?.id === appointment.id ? null : appointment,
                          )
                        }
                        type="button"
                        variant="outline"
                      >
                        {editingAppointment?.id === appointment.id ? "Fechar edição" : "Editar"}
                      </Button>
                    </div>
                    <AppointmentActions
                      appointment={appointment}
                      onUpdated={(updated) =>
                        setAppointments(
                          (current) =>
                            current?.map((item) => (item.id === updated.id ? updated : item)) ??
                            current,
                        )
                      }
                      organizationId={organizationId}
                    />
                    {editingAppointment?.id === appointment.id ? (
                      <div className="mt-5 border-t pt-5">
                        <AppointmentForm
                          appointment={editingAppointment}
                          branches={branches}
                          defaultBranchId={appointment.branchId}
                          defaultDate={date}
                          onSaved={(updated) => {
                            setAppointments(
                              (current) =>
                                current?.map((item) => (item.id === updated.id ? updated : item)) ??
                                current,
                            );
                            setEditingAppointment(updated);
                          }}
                          organizationId={organizationId}
                        />
                      </div>
                    ) : null}
                  </article>
                ))}
              </div>
            </div>
          ))}
      </div>
    </section>
  );
}
function toDateInput(value: Date) {
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
}
function formatTime(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit" }).format(
    new Date(value),
  );
}
