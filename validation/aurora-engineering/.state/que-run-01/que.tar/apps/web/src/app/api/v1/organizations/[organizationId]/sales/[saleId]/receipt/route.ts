import { saleParamsSchema, sendSaleReceiptBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string; saleId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = saleParamsSchema.parse(await route.params);
    const actor = await resolveActor(request, params.organizationId, api);
    const receipt = await services.createSaleReceipt.execute(params, actor);
    return new Response(receipt.html, {
      headers: {
        "cache-control": "private, no-store",
        "content-disposition": `inline; filename="${receipt.fileName}"`,
        "content-security-policy":
          "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        "content-type": "text/html; charset=utf-8",
        "x-content-type-options": "nosniff",
      },
    });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = saleParamsSchema.parse(await route.params);
    const body = sendSaleReceiptBodySchema.parse(await readJsonBody(request));
    const actor = await resolveActor(request, params.organizationId, api);
    return Response.json({
      data: await services.sendSaleReceipt.execute(
        { ...params, ...body, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}

async function resolveActor(
  request: Request,
  organizationId: string,
  api: { correlationId: string; requestId: string },
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({
    correlationId: api.correlationId,
    organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
}
