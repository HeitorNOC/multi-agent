"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createOrganizationRoleBodySchema,
  organizationRoleViewSchema,
  type PermissionView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useForm } from "react-hook-form";
import { z } from "zod";

const schema = z.object({ name: z.string().min(2), permissions: z.array(z.string()) });
type Values = z.infer<typeof schema>;

export function RoleForm({
  onCompleted,
  organizationId,
  permissions,
}: {
  onCompleted: () => void;
  organizationId: string;
  permissions: readonly PermissionView[];
}) {
  const form = useForm<Values>({
    defaultValues: { name: "", permissions: [] },
    resolver: zodResolver(schema),
  });
  async function submit(values: Values) {
    form.clearErrors("root");
    const response = await fetch(`/api/v1/organizations/${organizationId}/roles`, {
      body: JSON.stringify(createOrganizationRoleBodySchema.parse(values)),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method: "POST",
    });
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok)
      return form.setError("root", {
        message: payload.detail ?? "Não foi possível criar o papel.",
      });
    organizationRoleViewSchema.parse(payload.data);
    form.reset();
    onCompleted();
  }
  return (
    <form
      className="grid content-start gap-4 rounded-2xl border bg-white p-5 shadow-sm"
      onSubmit={form.handleSubmit(submit)}
    >
      <div>
        <h2 className="text-lg font-semibold">Novo papel</h2>
        <p className="mt-1 text-sm text-slate-600">Conceda somente as permissões necessárias.</p>
      </div>
      <Input
        aria-label="Nome do papel"
        placeholder="Ex.: Operador de caixa"
        {...form.register("name")}
      />
      <div className="grid max-h-64 gap-2 overflow-auto rounded-lg border p-3">
        {permissions.map((permission) => (
          <label className="flex items-start gap-2 text-sm" key={permission.code}>
            <input
              className="mt-1"
              type="checkbox"
              value={permission.code}
              {...form.register("permissions")}
            />
            <span>
              <strong className="font-medium">{permission.code}</strong>
              <span className="block text-xs text-slate-500">{permission.description}</span>
            </span>
          </label>
        ))}
      </div>
      {form.formState.errors.root ? (
        <p className="text-sm text-red-700" role="alert">
          {form.formState.errors.root.message}
        </p>
      ) : null}
      <Button disabled={form.formState.isSubmitting} type="submit">
        Criar papel
      </Button>
    </form>
  );
}
