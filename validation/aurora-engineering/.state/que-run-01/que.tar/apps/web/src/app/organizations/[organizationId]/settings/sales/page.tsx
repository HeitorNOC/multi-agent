import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { ModuleGate } from "@/features/modules/components/module-gate";
import { SalesManagement } from "@/features/sales/components/sales-management";

export const metadata: Metadata = { title: "Vendas | Gestor" };

export default async function SalesPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Operação
        </p>
        <h1 className="mt-2 text-3xl font-semibold">Nova venda</h1>
        <p className="mt-2 text-sm text-slate-600">
          Conclua uma venda a prazo com preço calculado no servidor, baixa atômica de estoque e
          geração automática do contas a receber.
        </p>
      </header>
      <ModuleGate moduleCode="sales" organizationId={organizationId}>
        <SalesManagement organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
