"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  createPurchaseDocumentBodySchema,
  financialAccountListSchema,
  financialCategoryListSchema,
  paymentMethodConfigurationListSchema,
  productListSchema,
  purchaseDetailViewSchema,
  receivedPurchaseViewSchema,
  receivePurchaseBodySchema,
  supplierListSchema,
  type BranchView,
  type FinancialCategoryView,
  type FinancialAccountView,
  type PaymentMethodConfigurationView,
  type ProblemDetails,
  type ProductView,
  type SupplierView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useFieldArray, useForm, useWatch } from "react-hook-form";
import { z } from "zod";

import { fetchData } from "../../sales/components/direct-sale-data";
import { SelectField } from "../../sales/components/direct-sale-support";
import { PurchaseFinancialFields } from "./purchase-financial-fields";

const formSchema = z
  .object({
    branchId: z.string().min(1, "Selecione a filial."),
    discountAmount: z.string().min(1),
    dueDate: z.string(),
    expenseCategoryId: z.string(),
    freightAmount: z.string().min(1),
    items: z
      .array(
        z.object({
          productId: z.string().min(1),
          quantity: z.string().min(1),
          taxAmount: z.string().min(1),
          unitCost: z.string().min(1),
        }),
      )
      .min(1),
    financialAccountId: z.string(),
    payNow: z.boolean(),
    paymentMethodConfigurationId: z.string(),
    supplierDocumentNumber: z.string(),
    supplierId: z.string().min(1, "Selecione o fornecedor."),
  })
  .superRefine((value, context) => {
    if (value.payNow && !value.paymentMethodConfigurationId)
      context.addIssue({
        code: "custom",
        message: "Selecione a forma de pagamento.",
        path: ["paymentMethodConfigurationId"],
      });
    if (value.payNow && !value.financialAccountId)
      context.addIssue({
        code: "custom",
        message: "Selecione a conta financeira.",
        path: ["financialAccountId"],
      });
  });
export type PurchaseFormValues = z.infer<typeof formSchema>;

export function PurchaseForm({
  mode = "receive",
  onCompleted,
  organizationId,
}: {
  mode?: "plan" | "receive";
  onCompleted: () => void;
  organizationId: string;
}) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [categories, setCategories] = useState<readonly FinancialCategoryView[]>([]);
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<readonly PaymentMethodConfigurationView[]>(
    [],
  );
  const [products, setProducts] = useState<readonly ProductView[]>([]);
  const [suppliers, setSuppliers] = useState<readonly SupplierView[]>([]);
  const [feedback, setFeedback] = useState("Carregando dados da compra...");
  const form = useForm<PurchaseFormValues>({
    defaultValues: {
      branchId: "",
      discountAmount: "0",
      dueDate: "",
      expenseCategoryId: "",
      financialAccountId: "",
      freightAmount: "0",
      items: [{ productId: "", quantity: "1", taxAmount: "0", unitCost: "" }],
      payNow: false,
      paymentMethodConfigurationId: "",
      supplierDocumentNumber: "",
      supplierId: "",
    },
    resolver: zodResolver(formSchema),
  });
  const itemFields = useFieldArray({ control: form.control, name: "items" });
  const payNow = useWatch({ control: form.control, name: "payNow" });

  useEffect(() => {
    const controller = new AbortController();
    const base = `/api/v1/organizations/${organizationId}`;
    void Promise.all([
      fetchData(`${base}/branches`, branchListSchema, controller.signal),
      fetchData(`${base}/financial-categories`, financialCategoryListSchema, controller.signal),
      fetchData(`${base}/financial-accounts`, financialAccountListSchema, controller.signal),
      fetchData(`${base}/payment-methods`, paymentMethodConfigurationListSchema, controller.signal),
      fetchData(`${base}/products?limit=100&status=ACTIVE`, productListSchema, controller.signal),
      fetchData(`${base}/suppliers?limit=100&status=ACTIVE`, supplierListSchema, controller.signal),
    ])
      .then(([branchData, categoryData, accountData, paymentData, productData, supplierData]) => {
        const expenseCategories = categoryData.filter(
          ({ status, type }) => status === "ACTIVE" && type === "EXPENSE",
        );
        setBranches(branchData.filter(({ status }) => status === "ACTIVE"));
        setCategories(expenseCategories);
        setAccounts(accountData.filter(({ status }) => status === "ACTIVE"));
        setPaymentMethods(
          paymentData.filter(({ allowsPayments, status }) => allowsPayments && status === "ACTIVE"),
        );
        setProducts(
          productData.filter(({ kind, status }) => kind === "STOCKABLE" && status === "ACTIVE"),
        );
        setSuppliers(supplierData.filter(({ status }) => status === "ACTIVE"));
        form.setValue("branchId", branchData.find(({ status }) => status === "ACTIVE")?.id ?? "");
        form.setValue("expenseCategoryId", expenseCategories[0]?.id ?? "");
        setFeedback("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível preparar a compra.",
          );
      });
    return () => controller.abort();
  }, [form, organizationId]);

  async function submit(values: PurchaseFormValues) {
    setFeedback("");
    const { financialAccountId, payNow, paymentMethodConfigurationId, ...document } = values;
    const candidate = {
      ...document,
      ...(mode === "receive" && payNow
        ? { payment: { financialAccountId, paymentMethodConfigurationId } }
        : {}),
      supplierDocumentNumber: values.supplierDocumentNumber.trim() || null,
    };
    const body =
      mode === "plan"
        ? createPurchaseDocumentBodySchema.parse(candidate)
        : receivePurchaseBodySchema.parse(candidate);
    const resource = mode === "plan" ? "purchase-documents" : "purchases";
    const response = await fetch(`/api/v1/organizations/${organizationId}/${resource}`, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method: "POST",
    });
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível receber a compra.");
    const purchase =
      mode === "plan"
        ? purchaseDetailViewSchema.parse(payload.data)
        : receivedPurchaseViewSchema.parse(payload.data);
    setFeedback(
      mode === "plan"
        ? `Cotação de compra #${purchase.number} criada como rascunho.`
        : `Compra #${purchase.number} recebida. Estoque e conta a pagar atualizados.`,
    );
    form.reset({
      ...values,
      discountAmount: "0",
      freightAmount: "0",
      items: [{ productId: "", quantity: "1", taxAmount: "0", unitCost: "" }],
      supplierDocumentNumber: "",
    });
    onCompleted();
  }

  const blocked =
    branches.length === 0 ||
    (mode === "receive" && categories.length === 0) ||
    products.length === 0 ||
    suppliers.length === 0;
  return (
    <section className="grid gap-5">
      <div>
        <h2 className="text-2xl font-semibold">
          {mode === "plan" ? "Planejar compra" : "Recebimento imediato"}
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          {mode === "plan"
            ? "Crie uma cotação para depois emitir o pedido e receber em uma ou mais etapas."
            : "Registre uma compra que já chegou e atualize estoque e financeiro de uma vez."}
        </p>
      </div>
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <form className="grid gap-6" onSubmit={form.handleSubmit(submit)}>
        <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm sm:grid-cols-2">
          <SelectField label="Filial">
            <select className="rounded-md border px-3 py-2 text-sm" {...form.register("branchId")}>
              <option value="">Selecione</option>
              {branches.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </SelectField>
          <SelectField label="Fornecedor">
            <select
              className="rounded-md border px-3 py-2 text-sm"
              {...form.register("supplierId")}
            >
              <option value="">Selecione</option>
              {suppliers.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </SelectField>
          {mode === "receive" ? (
            <PurchaseFinancialFields
              accounts={accounts}
              categories={categories}
              payNow={payNow}
              paymentMethods={paymentMethods}
              register={form.register}
            />
          ) : null}
          <SelectField label="Documento do fornecedor">
            <Input {...form.register("supplierDocumentNumber")} />
          </SelectField>
          <SelectField label="Frete">
            <Input inputMode="decimal" {...form.register("freightAmount")} />
          </SelectField>
          <SelectField label="Desconto">
            <Input inputMode="decimal" {...form.register("discountAmount")} />
          </SelectField>
        </div>
        <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm">
          <div className="flex justify-between gap-4">
            <h3 className="text-lg font-semibold">
              {mode === "plan" ? "Produtos cotados" : "Produtos recebidos"}
            </h3>
            <Button
              onClick={() =>
                itemFields.append({ productId: "", quantity: "1", taxAmount: "0", unitCost: "" })
              }
              type="button"
              variant="outline"
            >
              Adicionar
            </Button>
          </div>
          {itemFields.fields.map((field, index) => (
            <div className="grid gap-3 border-t pt-4 sm:grid-cols-5" key={field.id}>
              <SelectField label="Produto">
                <select
                  className="rounded-md border px-3 py-2 text-sm"
                  {...form.register(`items.${index}.productId`)}
                >
                  <option value="">Selecione</option>
                  {products.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} ({item.sku})
                    </option>
                  ))}
                </select>
              </SelectField>
              <SelectField label="Quantidade">
                <Input inputMode="decimal" {...form.register(`items.${index}.quantity`)} />
              </SelectField>
              <SelectField label="Custo unitário">
                <Input inputMode="decimal" {...form.register(`items.${index}.unitCost`)} />
              </SelectField>
              <SelectField label="Imposto">
                <Input inputMode="decimal" {...form.register(`items.${index}.taxAmount`)} />
              </SelectField>
              <div className="flex items-end">
                <Button
                  disabled={itemFields.fields.length === 1}
                  onClick={() => itemFields.remove(index)}
                  type="button"
                  variant="outline"
                >
                  Remover
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-end">
          <Button disabled={blocked || form.formState.isSubmitting} type="submit">
            {mode === "plan" ? "Salvar cotação" : "Confirmar recebimento"}
          </Button>
        </div>
      </form>
    </section>
  );
}
