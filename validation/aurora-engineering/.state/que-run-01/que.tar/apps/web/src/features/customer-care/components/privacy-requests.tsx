"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createDataSubjectRequestBodySchema,
  customerListSchema,
  dataSubjectRequestListSchema,
  reportJobViewSchema,
  type CustomerView,
  type DataSubjectRequestView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import {
  createPrivacyExportReportBody,
  privacyExportIdempotencyKey,
} from "./request-privacy-export";

type FormValues = z.infer<typeof createDataSubjectRequestBodySchema>;
const typeLabels = {
  ACCESS: "Acesso",
  ANONYMIZATION: "Anonimização",
  CORRECTION: "Correção",
  DELETION: "Exclusão",
  EXPORT: "Exportação",
} as const;
const statusLabels = {
  CANCELLED: "Cancelada",
  COMPLETED: "Concluída",
  OPEN: "Aberta",
  PROCESSING: "Em processamento",
  REJECTED: "Recusada",
  VERIFYING: "Em verificação",
} as const;

export function PrivacyRequests({ organizationId }: { organizationId: string }) {
  const [customers, setCustomers] = useState<readonly CustomerView[]>([]);
  const [requests, setRequests] = useState<readonly DataSubjectRequestView[]>([]);
  const [feedback, setFeedback] = useState("");
  const [revision, setRevision] = useState(0);
  const form = useForm<FormValues>({
    defaultValues: { customerId: "", identityVerification: "", requestDetails: "", type: "ACCESS" },
    resolver: zodResolver(createDataSubjectRequestBodySchema),
  });
  useEffect(() => {
    const controller = new AbortController();
    const base = `/api/v1/organizations/${organizationId}`;
    void Promise.all([
      fetch(`${base}/customers?limit=100&status=ACTIVE`, { signal: controller.signal }).then(read),
      fetch(`${base}/data-subject-requests`, { signal: controller.signal }).then(read),
    ])
      .then(([customerData, requestData]) => {
        setCustomers(customerListSchema.parse(customerData));
        setRequests(dataSubjectRequestListSchema.parse(requestData));
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Falha ao carregar privacidade.");
      });
    return () => controller.abort();
  }, [organizationId, revision]);
  async function create(values: FormValues) {
    await read(
      await fetch(`/api/v1/organizations/${organizationId}/data-subject-requests`, {
        body: JSON.stringify(values),
        headers: jsonHeaders(),
        method: "POST",
      }),
    );
    form.reset({ ...values, identityVerification: "", requestDetails: "" });
    setFeedback("Solicitação registrada e prazo calculado.");
    setRevision((current) => current + 1);
  }
  return (
    <section className="grid gap-5" aria-labelledby="privacy-title">
      <div>
        <h2 className="text-2xl font-semibold" id="privacy-title">
          Privacidade e LGPD
        </h2>
        <p className="text-sm text-slate-600">
          Registre, acompanhe e documente solicitações de titulares.
        </p>
      </div>
      <form
        className="grid gap-3 rounded-2xl border bg-white p-5 md:grid-cols-2"
        onSubmit={form.handleSubmit(create)}
      >
        <select className="rounded-md border px-3 py-2 text-sm" {...form.register("customerId")}>
          <option value="">Selecione o cliente</option>
          {customers.map((customer) => (
            <option key={customer.id} value={customer.id}>
              {customer.name}
            </option>
          ))}
        </select>
        <select className="rounded-md border px-3 py-2 text-sm" {...form.register("type")}>
          <option value="ACCESS">Acesso</option>
          <option value="CORRECTION">Correção</option>
          <option value="EXPORT">Exportação</option>
          <option value="ANONYMIZATION">Anonimização</option>
          <option value="DELETION">Exclusão</option>
        </select>
        <textarea
          className="min-h-24 rounded-md border p-3 text-sm"
          placeholder="Como a identidade foi verificada"
          {...form.register("identityVerification")}
        />
        <textarea
          className="min-h-24 rounded-md border p-3 text-sm"
          placeholder="Detalhes e fundamento"
          {...form.register("requestDetails")}
        />
        <Button disabled={form.formState.isSubmitting} type="submit">
          Registrar solicitação
        </Button>
      </form>
      {feedback ? (
        <p className="text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <div className="grid gap-3">
        {requests.map((request) => (
          <PrivacyRequest
            key={request.id}
            onChanged={() => setRevision((current) => current + 1)}
            organizationId={organizationId}
            request={request}
          />
        ))}
      </div>
    </section>
  );
}

function PrivacyRequest({
  onChanged,
  organizationId,
  request,
}: {
  onChanged: () => void;
  organizationId: string;
  request: DataSubjectRequestView;
}) {
  const [notes, setNotes] = useState("");
  const [exportFeedback, setExportFeedback] = useState("");
  const [requestingExport, setRequestingExport] = useState(false);
  async function change(
    status: "VERIFYING" | "PROCESSING" | "COMPLETED" | "REJECTED" | "CANCELLED",
  ) {
    await read(
      await fetch(`/api/v1/organizations/${organizationId}/data-subject-requests/${request.id}`, {
        body: JSON.stringify({
          expectedUpdatedAt: request.updatedAt,
          rejectionReason: status === "REJECTED" ? notes : null,
          resultSummary: status === "COMPLETED" ? notes : null,
          status,
        }),
        headers: jsonHeaders(),
        method: "PATCH",
      }),
    );
    onChanged();
  }
  async function requestExport() {
    setRequestingExport(true);
    setExportFeedback("");
    try {
      const payload = await read(
        await fetch(`/api/v1/organizations/${organizationId}/reports`, {
          body: JSON.stringify({
            ...createPrivacyExportReportBody(request.customerId),
          }),
          headers: {
            "content-type": "application/json",
            "idempotency-key": privacyExportIdempotencyKey(request.id),
          },
          method: "POST",
        }),
      );
      const report = z.object({ data: reportJobViewSchema }).parse(payload).data;
      setExportFeedback(
        `Exportação solicitada. Protocolo ${report.id}. O arquivo será processado e enviado por e-mail.`,
      );
    } catch (error) {
      setExportFeedback(error instanceof Error ? error.message : "Falha ao solicitar exportação.");
    } finally {
      setRequestingExport(false);
    }
  }
  const final = ["COMPLETED", "REJECTED", "CANCELLED"].includes(request.status);
  return (
    <article className="grid gap-3 rounded-2xl border bg-white p-5">
      <div>
        <h3 className="font-semibold">
          {request.customerName} · {typeLabels[request.type]}
        </h3>
        <p className="text-sm text-slate-600">
          {statusLabels[request.status]} · prazo{" "}
          {new Date(request.dueAt).toLocaleDateString("pt-BR")}
        </p>
      </div>
      <p className="text-sm">{request.requestDetails}</p>
      {request.resultSummary ? (
        <p className="rounded-lg bg-emerald-50 p-3 text-sm">Resultado: {request.resultSummary}</p>
      ) : null}
      {request.rejectionReason ? (
        <p className="rounded-lg bg-red-50 p-3 text-sm">Recusa: {request.rejectionReason}</p>
      ) : null}
      {exportFeedback ? (
        <p className="rounded-lg bg-blue-50 p-3 text-sm" role="status">
          {exportFeedback}
        </p>
      ) : null}
      {!final ? (
        <>
          <Input
            onChange={(event) => setNotes(event.target.value)}
            placeholder="Resultado ou justificativa para recusa"
            value={notes}
          />
          <div className="flex flex-wrap gap-2">
            {request.status === "OPEN" ? (
              <Button onClick={() => void change("VERIFYING")}>Iniciar verificação</Button>
            ) : null}
            {request.status === "VERIFYING" ? (
              <Button onClick={() => void change("PROCESSING")}>Confirmar e processar</Button>
            ) : null}
            {request.status === "PROCESSING" ? (
              <>
                {request.type === "EXPORT" ? (
                  <Button
                    disabled={requestingExport}
                    onClick={() => void requestExport()}
                    variant="outline"
                  >
                    {requestingExport ? "Solicitando..." : "Gerar exportação privada"}
                  </Button>
                ) : null}
                <Button
                  disabled={notes.trim().length < 10}
                  onClick={() => void change("COMPLETED")}
                >
                  Concluir
                </Button>
              </>
            ) : null}
            {["VERIFYING", "PROCESSING"].includes(request.status) ? (
              <Button
                disabled={notes.trim().length < 10}
                onClick={() => void change("REJECTED")}
                variant="destructive"
              >
                Recusar
              </Button>
            ) : null}
            <Button onClick={() => void change("CANCELLED")} variant="outline">
              Cancelar
            </Button>
          </div>
        </>
      ) : null}
    </article>
  );
}
function jsonHeaders() {
  return { "content-type": "application/json", "idempotency-key": crypto.randomUUID() };
}
async function read(response: Response): Promise<unknown> {
  const payload = (await response.json()) as Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "A operação falhou.");
  return payload;
}
