"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  bankAccountListSchema,
  bankAccountViewSchema,
  createBankAccountBodySchema,
  financialAccountListSchema,
  type BankAccountView,
  type CreateBankAccountBody,
  type FinancialAccountView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";

type BankAccountConfigurationsProps = {
  organizationId: string;
};

export function BankAccountConfigurations({ organizationId }: BankAccountConfigurationsProps) {
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[] | null>(null);
  const [bankAccounts, setBankAccounts] = useState<readonly BankAccountView[] | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateBankAccountBody>({
    defaultValues: {
      accountLastFour: "",
      financialAccountId: "",
      institutionCode: "",
      institutionName: "",
    },
    resolver: zodResolver(createBankAccountBodySchema),
  });
  const linkedFinancialAccountIds = useMemo(
    () => new Set(bankAccounts?.map(({ financialAccountId }) => financialAccountId) ?? []),
    [bankAccounts],
  );
  const eligibleAccounts = useMemo(
    () =>
      accounts?.filter(
        ({ id, status, type }) =>
          type === "BANK" && status === "ACTIVE" && !linkedFinancialAccountIds.has(id),
      ) ?? [],
    [accounts, linkedFinancialAccountIds],
  );
  const accountNames = useMemo(
    () => new Map(accounts?.map((account) => [account.id, account.name]) ?? []),
    [accounts],
  );

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const [financialResponse, bankResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/bank-accounts`, {
            signal: controller.signal,
          }),
        ]);

        if (!financialResponse.ok || !bankResponse.ok) {
          const response = !financialResponse.ok ? financialResponse : bankResponse;
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const financialPayload = (await financialResponse.json()) as { data: unknown };
        const bankPayload = (await bankResponse.json()) as { data: unknown };
        setAccounts(financialAccountListSchema.parse(financialPayload.data));
        setBankAccounts(bankAccountListSchema.parse(bankPayload.data));
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar as contas bancárias.",
          );
        }
      }
    }

    void load();
    return () => controller.abort();
  }, [organizationId, reloadVersion]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/bank-accounts`, {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": idempotencyKey,
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const created = bankAccountViewSchema.parse(payload.data);
      setBankAccounts((current) => [...(current ?? []), created]);
      setIdempotencyKey(crypto.randomUUID());
      setFeedback("Identificação bancária cadastrada sem armazenar dados completos da conta.");
      reset({
        accountLastFour: "",
        financialAccountId: "",
        institutionCode: "",
        institutionName: "",
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7">
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Novo cadastro manual
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Identificar conta bancária</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          O cadastro identifica uma conta financeira já existente. Ele não altera saldo e não
          conecta ao banco.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="bank-financial-account">Conta financeira bancária</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="bank-financial-account"
              {...register("financialAccountId")}
            >
              <option value="">Selecione uma conta</option>
              {eligibleAccounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </select>
            {errors.financialAccountId ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.financialAccountId.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="bank-institution-name">Instituição</Label>
            <Input
              autoComplete="organization"
              id="bank-institution-name"
              placeholder="Ex.: Banco do Brasil"
              {...register("institutionName")}
            />
            {errors.institutionName ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.institutionName.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="bank-institution-code">Código da instituição</Label>
              <Input
                id="bank-institution-code"
                placeholder="Opcional. Ex.: 001"
                {...register("institutionCode")}
              />
              {errors.institutionCode ? (
                <p className="text-sm text-red-700" role="alert">
                  {errors.institutionCode.message}
                </p>
              ) : null}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="bank-account-last-four">Últimos 4 dígitos</Label>
              <Input
                autoComplete="off"
                id="bank-account-last-four"
                inputMode="numeric"
                maxLength={4}
                placeholder="1234"
                {...register("accountLastFour")}
              />
              {errors.accountLastFour ? (
                <p className="text-sm text-red-700" role="alert">
                  {errors.accountLastFour.message}
                </p>
              ) : null}
            </div>
          </div>

          <p className="rounded-xl bg-slate-50 px-4 py-3 text-xs leading-5 text-slate-600">
            Nunca informe senha, token, agência ou número completo. Somente a máscara será
            armazenada.
          </p>

          {eligibleAccounts.length === 0 && accounts && bankAccounts ? (
            <p className="rounded-xl border border-dashed px-4 py-3 text-sm text-slate-600">
              Não há conta financeira bancária ativa e ainda não identificada.
            </p>
          ) : null}

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button disabled={isSubmitting || eligibleAccounts.length === 0} type="submit">
            {isSubmitting ? "Cadastrando..." : "Cadastrar identificação"}
          </Button>
        </form>
      </section>

      <section className="grid content-start gap-4">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
            Cadastradas
          </p>
          <h2 className="mt-2 text-xl font-semibold text-slate-950">Contas identificadas</h2>
        </div>

        {feedback ? (
          <div
            className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700"
            role="status"
          >
            {feedback}
          </div>
        ) : null}

        {!accounts || !bankAccounts ? (
          <div className="grid gap-3 rounded-2xl border bg-white p-5">
            <p className="text-sm text-slate-600">
              {loadError ?? "Carregando identificações bancárias..."}
            </p>
            {loadError ? (
              <div>
                <Button
                  onClick={() => {
                    setLoadError(null);
                    setReloadVersion((version) => version + 1);
                  }}
                  size="sm"
                  variant="outline"
                >
                  Tentar novamente
                </Button>
              </div>
            ) : null}
          </div>
        ) : bankAccounts.length === 0 ? (
          <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
            Nenhuma conta bancária foi identificada.
          </div>
        ) : (
          <ul className="grid gap-3">
            {bankAccounts.map((bankAccount) => (
              <li className="rounded-2xl border bg-white p-5" key={bankAccount.id}>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-950">
                      {bankAccount.institutionName}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {accountNames.get(bankAccount.financialAccountId) ?? "Conta financeira"}
                      {bankAccount.institutionCode
                        ? ` · código ${bankAccount.institutionCode}`
                        : ""}
                    </p>
                  </div>
                  <p className="font-mono text-sm font-semibold text-slate-700">
                    {bankAccount.accountMask}
                  </p>
                </div>
                <p className="mt-4 text-xs font-medium text-emerald-700">Cadastro manual</p>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
