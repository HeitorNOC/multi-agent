import type { CustomerCustomFieldDefinitionView } from "@gestor/contracts";
import { describe, expect, it } from "vitest";

import { valueForApi } from "./custom-field-value";

function definition(
  fieldType: CustomerCustomFieldDefinitionView["fieldType"],
): CustomerCustomFieldDefinitionView {
  return { fieldType } as CustomerCustomFieldDefinitionView;
}

describe("custom field API values", () => {
  it("normalizes empty, boolean and number values", () => {
    expect(valueForApi(definition("TEXT"), undefined)).toBeNull();
    expect(valueForApi(definition("TEXT"), "")).toBeNull();
    expect(valueForApi(definition("BOOLEAN"), true)).toBe(true);
    expect(valueForApi(definition("BOOLEAN"), "true")).toBe(true);
    expect(valueForApi(definition("BOOLEAN"), "false")).toBe(false);
    expect(valueForApi(definition("NUMBER"), "12.5")).toBe(12.5);
    expect(valueForApi(definition("TEXT"), "conteúdo")).toBe("conteúdo");
  });
});
