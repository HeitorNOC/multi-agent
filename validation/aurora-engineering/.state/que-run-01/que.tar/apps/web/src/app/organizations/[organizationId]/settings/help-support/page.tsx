import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { CustomerCareManagement } from "@/features/customer-care/components/customer-care-management";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = { title: "Ajuda, suporte e privacidade | Gestor" };
export default async function CustomerCarePage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Atendimento e conformidade
        </p>
        <h1 className="mt-2 text-3xl font-semibold">Ajuda, suporte e privacidade</h1>
        <p className="mt-2 text-sm text-slate-600">
          Orientações, chamados e solicitações LGPD em um único lugar.
        </p>
      </header>
      <ModuleGate moduleCode="core" organizationId={organizationId}>
        <CustomerCareManagement organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
