import { supplierParamsSchema, updateSupplierBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ organizationId: string; supplierId: string }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = supplierParamsSchema.parse(await route.params);
    const body = updateSupplierBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const supplier = await services.updateSupplier.execute(
      {
        ...body,
        organizationId: params.organizationId,
        supplierId: params.supplierId,
      },
      actor,
    );
    return Response.json({ data: supplier });
  });
}
