import { onboardingStepParamsSchema, updateOnboardingStepBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
    stepCode: string;
  }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = onboardingStepParamsSchema.parse(await route.params);
    const body = updateOnboardingStepBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const checklist = await services.changeOnboardingStep.execute({ ...params, ...body }, actor);

    return Response.json({ data: checklist });
  });
}
