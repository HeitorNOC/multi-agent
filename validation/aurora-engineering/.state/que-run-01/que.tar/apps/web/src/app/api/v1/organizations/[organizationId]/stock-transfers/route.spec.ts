import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, resolveTenantActor, transferStock } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  resolveTenantActor: vi.fn(),
  transferStock: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
    transferStock: { execute: transferStock },
  },
}));

import { POST } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const sourceBranchId = "30000000-0000-4000-8000-000000000002";
const targetBranchId = "30000000-0000-4000-8000-000000000003";
const productId = "30000000-0000-4000-8000-000000000004";
const route = { params: Promise.resolve({ organizationId }) };

describe("stock transfer route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "MANAGER" });
    transferStock.mockReset().mockResolvedValue({ status: "COMPLETED" });
  });

  it("forwards both balance versions and idempotency", async () => {
    const body = {
      expectedSourceVersion: 4,
      expectedTargetVersion: 2,
      productId,
      quantity: "3",
      reason: "Reposição semanal",
      sourceBranchId,
      targetBranchId,
    };
    const request = new Request("http://localhost/stock-transfers", {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": "transfer-key" },
      method: "POST",
    });
    const response = await POST(request, route);

    expect(response.status).toBe(200);
    expect(transferStock).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "transfer-key", organizationId },
      { role: "MANAGER" },
    );
  });

  it("rejects equal branches before invoking the command", async () => {
    const request = new Request("http://localhost/stock-transfers", {
      body: JSON.stringify({
        expectedSourceVersion: 1,
        expectedTargetVersion: 1,
        productId,
        quantity: "1",
        reason: "Inválida",
        sourceBranchId,
        targetBranchId: sourceBranchId,
      }),
      headers: { "content-type": "application/json", "idempotency-key": "transfer-key" },
      method: "POST",
    });
    const response = await POST(request, route);
    expect(response.status).toBe(400);
    expect(transferStock).not.toHaveBeenCalled();
  });
});
