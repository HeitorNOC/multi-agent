import Link from "next/link";

export default function TermsOfUsePage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-14 text-slate-800">
      <h1 className="text-3xl font-semibold">Termos de Uso</h1>
      <p className="mt-3 text-sm text-slate-500">Versão 2026-10-18</p>
      <section className="mt-8 grid gap-4 leading-7">
        <p>
          O Gestor fornece recursos para gestão comercial e operacional. Você é responsável pelas
          informações cadastradas e por manter suas credenciais em segurança.
        </p>
        <p>
          O acesso depende do aceite desta versão. Atualizações relevantes poderão exigir novo
          aceite antes do uso continuado.
        </p>
      </section>
      <Link className="mt-8 inline-block text-brand-600 font-semibold" href="/aceite">
        Voltar
      </Link>
    </main>
  );
}
