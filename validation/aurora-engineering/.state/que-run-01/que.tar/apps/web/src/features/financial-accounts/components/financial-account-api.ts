import {
  branchListSchema,
  financialAccountListSchema,
  financialAccountViewSchema,
  type CreateFinancialAccountBody,
  type FinancialAccountView,
  type ProblemDetails,
} from "@gestor/contracts";

async function requireOk(response: Response): Promise<Response> {
  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }
  return response;
}

export async function loadFinancialAccountConfiguration(
  organizationId: string,
  signal: AbortSignal,
) {
  const [accountsResponse, branchesResponse] = await Promise.all([
    fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, { signal }),
    fetch(`/api/v1/organizations/${organizationId}/branches`, { signal }),
  ]);
  const [accountsPayload, branchesPayload] = await Promise.all([
    requireOk(accountsResponse).then((response) => response.json() as Promise<{ data: unknown }>),
    requireOk(branchesResponse).then((response) => response.json() as Promise<{ data: unknown }>),
  ]);
  return {
    accounts: financialAccountListSchema.parse(accountsPayload.data),
    branches: branchListSchema.parse(branchesPayload.data),
  };
}

export async function createFinancialAccount(
  organizationId: string,
  values: CreateFinancialAccountBody,
  idempotencyKey: string,
) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
    body: JSON.stringify(values),
    headers: { "content-type": "application/json", "idempotency-key": idempotencyKey },
    method: "POST",
  });
  if (!response.ok) {
    return { data: null, problem: (await response.json()) as ProblemDetails } as const;
  }
  const payload = (await response.json()) as { data: unknown };
  return { data: financialAccountViewSchema.parse(payload.data), problem: null } as const;
}

export async function toggleFinancialAccountStatus(
  organizationId: string,
  account: FinancialAccountView,
) {
  const status = account.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
  const response = await requireOk(
    await fetch(`/api/v1/organizations/${organizationId}/financial-accounts/${account.id}`, {
      body: JSON.stringify({ status }),
      headers: { "content-type": "application/json" },
      method: "PATCH",
    }),
  );
  const payload = (await response.json()) as { data: unknown };
  return { status, updated: financialAccountViewSchema.parse(payload.data) };
}
