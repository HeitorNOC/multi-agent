import { createHash } from "node:crypto";

import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({
  requireCurrentLegalAcceptance: vi.fn(),
}));

const { authenticate, consume, fileImportPolicy, importBankStatement, resolveTenantActor } =
  vi.hoisted(() => ({
    authenticate: vi.fn(),
    consume: vi.fn(),
    fileImportPolicy: { limit: 12, namespace: "api.file-import", windowMs: 300_000 },
    importBankStatement: vi.fn(),
    resolveTenantActor: vi.fn(),
  }));
vi.mock("@/lib/server/rate-limit", () => ({
  apiRateLimiter: { consume },
  apiRateLimitPolicies: {
    default: { limit: 120, namespace: "api.default", windowMs: 60_000 },
    fileImport: fileImportPolicy,
  },
  createRateLimitSubject: () => "test-subject",
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    importBankStatement: { execute: importBankStatement },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "40000000-0000-4000-8000-000000000001";
const bankAccountId = "40000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ bankAccountId, organizationId }) };

describe("bank statement import route", () => {
  beforeEach(() => {
    consume.mockReset().mockResolvedValue({
      allowed: true,
      limit: 12,
      remaining: 11,
      resetAt: new Date("2026-08-12T12:05:00.000Z"),
    });
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    importBankStatement.mockReset().mockResolvedValue({ id: "import-1" });
  });

  it("imports a decoded CSV with checksum, idempotency and the restricted policy", async () => {
    const content = "date,description,amount\n2026-08-12,Recebimento,100.00";
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/bank-accounts/${bankAccountId}/statement-imports`,
      {
        body: content,
        headers: {
          "content-type": "text/csv; charset=utf-8",
          "idempotency-key": "statement-key",
          "x-file-name": encodeURIComponent("extrato agosto.csv"),
        },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(response.headers.get("location")).toContain("/statement-imports/import-1");
    expect(consume).toHaveBeenCalledWith(expect.objectContaining({ policy: fileImportPolicy }));
    expect(importBankStatement).toHaveBeenCalledWith(
      {
        bankAccountId,
        checksumSha256: createHash("sha256").update(content).digest("hex"),
        content,
        format: "CSV",
        idempotencyKey: "statement-key",
        organizationId,
        originalFileName: "extrato agosto.csv",
      },
      { role: "OWNER" },
    );
  });

  it("rejects unsupported extensions after centralized authentication and before body parsing", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/bank-accounts/${bankAccountId}/statement-imports`,
      {
        body: "content",
        headers: {
          "content-type": "text/plain",
          "idempotency-key": "statement-key",
          "x-file-name": "extrato.pdf",
        },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      code: "BANK_STATEMENT_EXTENSION_UNSUPPORTED",
    });
    expect(authenticate).toHaveBeenCalledOnce();
    expect(importBankStatement).not.toHaveBeenCalled();
  });

  it("rejects malformed encoded names and unsupported content types", async () => {
    const base = `http://localhost/api/v1/organizations/${organizationId}/bank-accounts/${bankAccountId}/statement-imports`;
    const malformed = await POST(
      new Request(base, {
        body: "content",
        headers: { "content-type": "text/csv", "x-file-name": "%E0%A4%A" },
        method: "POST",
      }),
      route,
    );
    const unsupported = await POST(
      new Request(base, {
        body: "content",
        headers: { "content-type": "application/pdf", "x-file-name": "extrato.ofx" },
        method: "POST",
      }),
      route,
    );

    expect(malformed.status).toBe(400);
    expect(unsupported.status).toBe(400);
    await expect(malformed.json()).resolves.toMatchObject({
      code: "BANK_STATEMENT_FILE_NAME_INVALID",
    });
    await expect(unsupported.json()).resolves.toMatchObject({
      code: "BANK_STATEMENT_CONTENT_TYPE_UNSUPPORTED",
    });
  });
});
