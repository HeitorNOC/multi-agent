import { convertCustomerPortalOrderBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ customerPortalOrderId: string; organizationId: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const routeParams = await route.params;
    const params = organizationParamsSchema.parse(routeParams);
    const body = convertCustomerPortalOrderBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const sale = await services.convertCustomerPortalOrder.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        orderId: routeParams.customerPortalOrderId,
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json(
      { data: sale },
      {
        headers: { location: `/api/v1/organizations/${params.organizationId}/sales/${sale.id}` },
        status: 201,
      },
    );
  });
}
