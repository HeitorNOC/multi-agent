import { z } from "zod";

const emailSchema = z
  .email("Digite um e-mail válido.")
  .max(254, "O e-mail deve ter no máximo 254 caracteres.")
  .transform((value) => value.trim().toLowerCase());

const passwordSchema = z
  .string()
  .min(10, "A senha deve ter pelo menos 10 caracteres.")
  .max(128, "A senha deve ter no máximo 128 caracteres.");

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Digite sua senha."),
  rememberMe: z.boolean(),
});

export type LoginInput = z.input<typeof loginSchema>;
export type LoginValues = z.output<typeof loginSchema>;

export const signUpSchema = z
  .object({
    confirmPassword: z.string(),
    email: emailSchema,
    name: z
      .string()
      .trim()
      .min(2, "Digite seu nome.")
      .max(100, "O nome deve ter no máximo 100 caracteres."),
    password: passwordSchema,
  })
  .refine((values) => values.password === values.confirmPassword, {
    message: "As senhas não coincidem.",
    path: ["confirmPassword"],
  });

export type SignUpInput = z.input<typeof signUpSchema>;
export type SignUpValues = z.output<typeof signUpSchema>;

export const recoverPasswordSchema = z.object({
  email: emailSchema,
});

export type RecoverPasswordInput = z.input<typeof recoverPasswordSchema>;
export type RecoverPasswordValues = z.output<typeof recoverPasswordSchema>;

export const resetPasswordSchema = z
  .object({
    confirmPassword: z.string(),
    password: passwordSchema,
  })
  .refine((values) => values.password === values.confirmPassword, {
    message: "As senhas não coincidem.",
    path: ["confirmPassword"],
  });

export type ResetPasswordInput = z.input<typeof resetPasswordSchema>;
export type ResetPasswordValues = z.output<typeof resetPasswordSchema>;
