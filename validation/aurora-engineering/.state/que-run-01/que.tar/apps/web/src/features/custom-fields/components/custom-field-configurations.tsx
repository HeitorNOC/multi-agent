"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { type CustomerCustomFieldDefinitionView, type ProblemDetails } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { z } from "zod";

import {
  CustomValueInput,
  FormField,
  customFieldEntityConfig,
  parseDefinition,
  parseDefinitionList,
  parseEntity,
  parseEntityList,
  parseValues,
  type CustomFieldEntity,
  type CustomFieldEntityView,
  type CustomFieldValueForm,
} from "./custom-field-support";
import { valueForApi } from "./custom-field-value";

const definitionFormSchema = z
  .object({
    code: z
      .string()
      .trim()
      .regex(/^[a-z][a-z0-9_]*$/),
    fieldType: z.enum(["TEXT", "NUMBER", "DATE", "SELECT", "BOOLEAN"]),
    label: z.string().trim().min(2).max(120),
    optionsText: z.string(),
    required: z.boolean(),
  })
  .superRefine((value, context) => {
    if (value.fieldType === "SELECT" && value.optionsText.split("\n").filter(Boolean).length < 2) {
      context.addIssue({
        code: "custom",
        message: "Informe ao menos duas opções, uma por linha.",
        path: ["optionsText"],
      });
    }
  });

type DefinitionForm = z.infer<typeof definitionFormSchema>;

export function CustomFieldConfigurations({
  entity,
  organizationId,
}: {
  entity: CustomFieldEntity;
  organizationId: string;
}) {
  const {
    label: entityLabel,
    labelPlural: entityLabelPlural,
    segment,
  } = customFieldEntityConfig[entity];
  const [entities, setEntities] = useState<readonly CustomFieldEntityView[]>([]);
  const [definitions, setDefinitions] = useState<readonly CustomerCustomFieldDefinitionView[]>([]);
  const [selectedEntity, setSelectedEntity] = useState<CustomFieldEntityView | null>(null);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<DefinitionForm>({
    defaultValues: { code: "", fieldType: "TEXT", label: "", optionsText: "", required: false },
    resolver: zodResolver(definitionFormSchema),
  });
  const {
    formState: { isSubmitting: isSavingValues },
    handleSubmit: handleValuesSubmit,
    register: registerValue,
    reset: resetValues,
  } = useForm<CustomFieldValueForm>({ defaultValues: { fields: {} } });
  const selectedType = useWatch({ control, name: "fieldType" });

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const [entityResponse, definitionResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/${segment}`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/${segment}/custom-fields`, {
            signal: controller.signal,
          }),
        ]);
        if (!entityResponse.ok || !definitionResponse.ok) {
          const failed = entityResponse.ok ? definitionResponse : entityResponse;
          throw new Error(((await failed.json()) as ProblemDetails).detail);
        }
        const entityPayload = (await entityResponse.json()) as { data: unknown };
        const definitionPayload = (await definitionResponse.json()) as { data: unknown };
        setEntities(parseEntityList(entity, entityPayload.data));
        setDefinitions(parseDefinitionList(entity, definitionPayload.data));
      } catch (error) {
        if (!controller.signal.aborted) {
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar os campos.",
          );
        }
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    void load();
    return () => controller.abort();
  }, [entity, organizationId, segment]);

  const createDefinition = handleSubmit(async (values) => {
    setFeedback(null);
    const options = values.optionsText
      .split("\n")
      .map((option) => option.trim())
      .filter(Boolean);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/${segment}/custom-fields`,
        {
          body: JSON.stringify({
            code: values.code,
            fieldType: values.fieldType,
            label: values.label,
            ...(values.fieldType === "SELECT" ? { options } : {}),
            position: definitions.length,
            required: values.required,
          }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const definition = parseDefinition(entity, payload.data);
      setDefinitions((current) => [...current, definition]);
      reset({ code: "", fieldType: "TEXT", label: "", optionsText: "", required: false });
      setFeedback("Campo personalizado criado.");
    } catch {
      setError("root", { message: "Não foi possível criar o campo.", type: "network" });
    }
  });

  async function chooseEntity(entityId: string) {
    const selected = entities.find(({ id }) => id === entityId) ?? null;
    setSelectedEntity(selected);
    resetValues({ fields: {} });
    if (!selected) return;
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/${segment}/${selected.id}/custom-fields`,
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      const values = parseValues(entity, payload.data);
      resetValues({
        fields: Object.fromEntries(
          values.map((item) => [
            item.definitionId,
            typeof item.value === "boolean" ? String(item.value) : item.value,
          ]),
        ),
      });
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível carregar os valores.");
    }
  }

  const saveValues = handleValuesSubmit(async ({ fields }) => {
    if (!selectedEntity) return;
    const values = definitions.map((definition) => ({
      definitionId: definition.id,
      value: valueForApi(definition, fields[definition.id]),
    }));
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/${segment}/${selectedEntity.id}/custom-fields`,
        {
          body: JSON.stringify({ expectedUpdatedAt: selectedEntity.updatedAt, values }),
          headers: { "content-type": "application/json" },
          method: "PUT",
        },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      const updated = parseEntity(entity, payload.data);
      setSelectedEntity(updated);
      setEntities((current) => current.map((item) => (item.id === updated.id ? updated : item)));
      setFeedback("Campos personalizados atualizados.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível salvar os valores.");
    }
  });

  return (
    <section className="mt-8 grid gap-6 rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] lg:grid-cols-2">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Configuração</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Campos personalizados</h2>
        <p className="mt-2 text-sm text-slate-600">
          Até 20 campos para {entityLabelPlural} desta empresa.
        </p>
        <form className="mt-5 grid gap-4" noValidate onSubmit={createDefinition}>
          <FormField error={errors.label?.message} id="custom-field-label" label="Rótulo">
            <Input id="custom-field-label" {...register("label")} />
          </FormField>
          <FormField error={errors.code?.message} id="custom-field-code" label="Código">
            <Input id="custom-field-code" placeholder="ex.: tipo_cabelo" {...register("code")} />
          </FormField>
          <FormField id="custom-field-type" label="Tipo">
            <select
              className="h-10 rounded-xl border bg-white px-3 text-sm"
              id="custom-field-type"
              {...register("fieldType")}
            >
              <option value="TEXT">Texto</option>
              <option value="NUMBER">Número</option>
              <option value="DATE">Data</option>
              <option value="SELECT">Seleção</option>
              <option value="BOOLEAN">Sim ou não</option>
            </select>
          </FormField>
          {selectedType === "SELECT" ? (
            <FormField
              error={errors.optionsText?.message}
              id="custom-field-options"
              label="Opções, uma por linha"
            >
              <textarea
                className="min-h-24 rounded-xl border px-3 py-2 text-sm"
                id="custom-field-options"
                {...register("optionsText")}
              />
            </FormField>
          ) : null}
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" {...register("required")} /> Obrigatório
          </label>
          {errors.root?.message ? (
            <p className="text-sm text-red-700" role="alert">
              {errors.root.message}
            </p>
          ) : null}
          <Button disabled={isSubmitting || definitions.length >= 20} type="submit">
            {isSubmitting ? "Criando..." : "Criar campo"}
          </Button>
        </form>
      </div>
      <div>
        <Label htmlFor={`custom-field-${entityLabel}`}>{entityLabel}</Label>
        <select
          className="mt-2 h-10 w-full rounded-xl border bg-white px-3 text-sm"
          id={`custom-field-${entityLabel}`}
          onChange={(event) => void chooseEntity(event.target.value)}
          value={selectedEntity?.id ?? ""}
        >
          <option value="">Selecione um {entityLabel}</option>
          {entities.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </select>
        {selectedEntity ? (
          <form className="mt-5 grid gap-4" onSubmit={saveValues}>
            {definitions.map((definition) => (
              <CustomValueInput
                definition={definition}
                key={definition.id}
                register={registerValue}
              />
            ))}
            {definitions.length === 0 ? (
              <p className="text-sm text-slate-500">Crie o primeiro campo personalizado.</p>
            ) : null}
            <Button disabled={isSavingValues || definitions.length === 0} type="submit">
              {isSavingValues ? "Salvando..." : "Salvar valores"}
            </Button>
          </form>
        ) : (
          <p className="mt-5 text-sm text-slate-500">
            Selecione um {entityLabel} para preencher os campos.
          </p>
        )}
        {loading ? <p className="mt-4 text-sm text-slate-500">Carregando...</p> : null}
        {feedback ? (
          <p className="mt-4 rounded-xl border px-4 py-3 text-sm" role="status">
            {feedback}
          </p>
        ) : null}
      </div>
    </section>
  );
}
