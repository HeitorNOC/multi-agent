import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { adjustStock, authenticate, resolveTenantActor } = vi.hoisted(() => ({
  adjustStock: vi.fn(),
  authenticate: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    adjustStock: { execute: adjustStock },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const branchId = "30000000-0000-4000-8000-000000000002";
const productId = "30000000-0000-4000-8000-000000000003";
const route = { params: Promise.resolve({ branchId, organizationId }) };

describe("stock adjustment route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "MANAGER" });
    adjustStock.mockReset().mockResolvedValue({ balance: {}, movement: {} });
  });

  it("passes expected version, reason and idempotency to the stock command", async () => {
    const body = { expectedVersion: 4, productId, quantityDelta: "-2", reason: "Perda apurada" };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/branches/${branchId}/stock-movements/adjustments`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "adjustment-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(200);
    expect(adjustStock).toHaveBeenCalledWith(
      { ...body, branchId, idempotencyKey: "adjustment-key", organizationId },
      { role: "MANAGER" },
    );
  });

  it("rejects a zero adjustment after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/branches/${branchId}/stock-movements/adjustments`,
      {
        body: JSON.stringify({
          expectedVersion: 4,
          productId,
          quantityDelta: "0",
          reason: "Ajuste inválido",
        }),
        headers: { "content-type": "application/json", "idempotency-key": "adjustment-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(adjustStock).not.toHaveBeenCalled();
  });
});
