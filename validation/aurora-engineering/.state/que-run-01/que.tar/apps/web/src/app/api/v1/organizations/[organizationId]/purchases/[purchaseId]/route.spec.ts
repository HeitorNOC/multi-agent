import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, getPurchase, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  getPurchase: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    getPurchase: { execute: getPurchase },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const purchaseId = "20000000-0000-4000-8000-000000000002";

describe("purchase detail route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    getPurchase.mockReset().mockResolvedValue({ id: purchaseId });
  });

  it("returns a tenant-scoped purchase", async () => {
    const response = await GET(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/purchases/${purchaseId}`,
      ),
      { params: Promise.resolve({ organizationId, purchaseId }) },
    );
    expect(response.status).toBe(200);
    expect(getPurchase).toHaveBeenCalledWith({ organizationId, purchaseId }, { role: "OWNER" });
  });
});
