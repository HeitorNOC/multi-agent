"use client";

import {
  onboardingChecklistViewSchema,
  type OnboardingChecklistView,
  type OnboardingStepAction,
  type OnboardingStepCode,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import Link from "next/link";
import { useEffect, useState } from "react";

type StepContent = {
  description: string;
  label: string;
};

const stepContent: Record<OnboardingStepCode, StepContent> = {
  COMPANY_PROFILE: {
    description: "Revise nome, documento e informações principais da empresa.",
    label: "Completar dados da empresa",
  },
  USERS: {
    description: "Convide as pessoas que vão operar e administrar o sistema.",
    label: "Cadastrar usuários",
  },
  FIRST_BRANCH: {
    description: "Confira os dados da matriz criada durante o primeiro acesso.",
    label: "Configurar filial matriz",
  },
  IMPORT_CONTACTS: {
    description: "Traga clientes e fornecedores existentes quando for necessário.",
    label: "Importar clientes e fornecedores",
  },
  IMPORT_CATALOG: {
    description: "Cadastre ou importe os produtos e serviços oferecidos.",
    label: "Preparar catálogo",
  },
  IMPORT_INITIAL_STOCK: {
    description: "Registre as quantidades atuais sem criar compras fictícias.",
    label: "Informar estoque inicial",
  },
  IMPORT_OPEN_ACCOUNTS: {
    description: "Traga contas pendentes preservando valor, vencimento e origem.",
    label: "Importar contas em aberto",
  },
  PAYMENT_METHODS: {
    description: "Defina como a empresa recebe e paga no dia a dia.",
    label: "Criar formas de pagamento",
  },
  FINANCIAL_CATEGORIES: {
    description: "Organize receitas, custos, despesas e impostos.",
    label: "Criar categorias financeiras",
  },
  INITIAL_BALANCES: {
    description: "Registre os saldos atuais de caixa e banco como implantação.",
    label: "Registrar saldos iniciais",
  },
  FIRST_SALE: {
    description: "Valide o fluxo operacional registrando a primeira venda.",
    label: "Realizar primeira venda",
  },
};

const automaticSteps = new Set<OnboardingStepCode>([
  "COMPANY_PROFILE",
  "FIRST_BRANCH",
  "FINANCIAL_CATEGORIES",
  "INITIAL_BALANCES",
  "PAYMENT_METHODS",
]);

type OnboardingChecklistProps = {
  organizationId: string;
};

export function OnboardingChecklist({ organizationId }: OnboardingChecklistProps) {
  const [checklist, setChecklist] = useState<OnboardingChecklistView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyStep, setBusyStep] = useState<OnboardingStepCode | null>(null);
  const [reloadVersion, setReloadVersion] = useState(0);

  useEffect(() => {
    const controller = new AbortController();

    async function loadChecklist() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/onboarding`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const payload = (await response.json()) as { data: unknown };
        setChecklist(onboardingChecklistViewSchema.parse(payload.data));
      } catch (loadError) {
        if (!controller.signal.aborted) {
          setError(
            loadError instanceof Error
              ? loadError.message
              : "Não foi possível carregar o checklist.",
          );
        }
      }
    }

    void loadChecklist();

    return () => controller.abort();
  }, [organizationId, reloadVersion]);

  async function changeStep(stepCode: OnboardingStepCode, action: OnboardingStepAction) {
    setBusyStep(stepCode);
    setError(null);

    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/onboarding/${stepCode}`,
        {
          body: JSON.stringify({ action }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        throw new Error(problem.detail);
      }

      const payload = (await response.json()) as { data: unknown };
      setChecklist(onboardingChecklistViewSchema.parse(payload.data));
    } catch (changeError) {
      setError(
        changeError instanceof Error ? changeError.message : "Não foi possível atualizar a etapa.",
      );
    } finally {
      setBusyStep(null);
    }
  }

  if (!checklist) {
    return (
      <div className="grid gap-3 rounded-2xl border bg-slate-50 p-5" aria-live="polite">
        <p className="text-sm text-slate-600">
          {error ?? "Carregando seu checklist de implantação..."}
        </p>
        {error ? (
          <div>
            <Button
              onClick={() => {
                setError(null);
                setReloadVersion((version) => version + 1);
              }}
              variant="outline"
            >
              Tentar novamente
            </Button>
          </div>
        ) : null}
      </div>
    );
  }

  const progress = Math.round((checklist.resolvedSteps / checklist.totalSteps) * 100);

  return (
    <section className="grid gap-6" aria-labelledby="onboarding-checklist-title">
      <div className="rounded-2xl border bg-slate-50 p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
              Implantação
            </p>
            <h2
              className="mt-2 text-xl font-semibold text-slate-950"
              id="onboarding-checklist-title"
            >
              Checklist operacional
            </h2>
            <p className="mt-1 text-sm leading-6 text-slate-600">
              {checklist.resolvedSteps} de {checklist.totalSteps} etapas concluídas ou adiadas
            </p>
          </div>
          <span
            className={
              checklist.readyToOperate
                ? "rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800"
                : "rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800"
            }
          >
            {checklist.readyToOperate ? "Pronto para operar" : "Configuração em andamento"}
          </span>
        </div>
        <div
          aria-label={`${progress}% do checklist resolvido`}
          aria-valuemax={100}
          aria-valuemin={0}
          aria-valuenow={progress}
          className="mt-5 h-2 overflow-hidden rounded-full bg-slate-200"
          role="progressbar"
        >
          <div className="bg-brand-600 h-full rounded-full" style={{ width: `${progress}%` }} />
        </div>
      </div>

      {error ? (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      ) : null}

      <ol className="grid gap-3">
        {checklist.steps.map((step) => {
          const content = stepContent[step.stepCode];
          const isBusy = busyStep === step.stepCode;
          const isAutomatic = automaticSteps.has(step.stepCode);

          return (
            <li
              className="rounded-2xl border bg-white p-4 shadow-[0_5px_20px_rgb(15_23_42/0.03)] sm:p-5"
              key={step.stepCode}
            >
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <span
                    aria-hidden="true"
                    className={
                      step.status === "COMPLETED"
                        ? "grid size-7 shrink-0 place-items-center rounded-full bg-emerald-100 text-sm font-bold text-emerald-700"
                        : step.status === "SKIPPED"
                          ? "grid size-7 shrink-0 place-items-center rounded-full bg-slate-200 text-sm font-bold text-slate-600"
                          : "border-brand-200 text-brand-700 grid size-7 shrink-0 place-items-center rounded-full border bg-white text-sm font-bold"
                    }
                  >
                    {step.status === "COMPLETED" ? "✓" : step.status === "SKIPPED" ? "–" : "•"}
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-semibold text-slate-950">{content.label}</h3>
                      {step.requiredForOperation ? (
                        <span className="rounded-full bg-amber-50 px-2 py-0.5 text-[0.68rem] font-semibold text-amber-800">
                          Essencial
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1 text-xs leading-5 text-slate-600">{content.description}</p>
                  </div>
                </div>

                <div className="flex shrink-0 flex-wrap gap-2 sm:justify-end">
                  {step.stepCode === "IMPORT_OPEN_ACCOUNTS" ? (
                    <>
                      <Link
                        className="border-input bg-background hover:bg-accent hover:text-accent-foreground inline-flex h-8 items-center rounded-lg border px-3 text-xs font-medium transition"
                        href={`/organizations/${organizationId}/settings/financial-obligations`}
                      >
                        Gerenciar contas
                      </Link>
                      {step.status === "PENDING" ? (
                        <>
                          <Button
                            disabled={isBusy}
                            onClick={() => void changeStep(step.stepCode, "COMPLETE")}
                            size="sm"
                          >
                            {isBusy ? "Salvando..." : "Marcar como concluída"}
                          </Button>
                          <Button
                            disabled={isBusy}
                            onClick={() => void changeStep(step.stepCode, "SKIP")}
                            size="sm"
                            variant="outline"
                          >
                            Não tenho contas
                          </Button>
                        </>
                      ) : (
                        <Button
                          disabled={isBusy}
                          onClick={() => void changeStep(step.stepCode, "RESUME")}
                          size="sm"
                          variant="outline"
                        >
                          {isBusy ? "Salvando..." : "Retomar etapa"}
                        </Button>
                      )}
                    </>
                  ) : step.stepCode === "PAYMENT_METHODS" ||
                    step.stepCode === "FINANCIAL_CATEGORIES" ||
                    step.stepCode === "INITIAL_BALANCES" ? (
                    <Link
                      className="border-input bg-background hover:bg-accent hover:text-accent-foreground inline-flex h-8 items-center rounded-lg border px-3 text-xs font-medium transition"
                      href={`/organizations/${organizationId}/settings/${
                        step.stepCode === "PAYMENT_METHODS"
                          ? "payment-methods"
                          : step.stepCode === "FINANCIAL_CATEGORIES"
                            ? "financial-categories"
                            : "financial-accounts"
                      }`}
                    >
                      {step.status === "COMPLETED" ? "Gerenciar" : "Configurar"}
                    </Link>
                  ) : isAutomatic ? (
                    <span className="px-1 py-2 text-xs font-medium text-slate-500">
                      Concluída automaticamente
                    </span>
                  ) : step.status === "PENDING" ? (
                    <>
                      <Button
                        disabled={isBusy}
                        onClick={() => void changeStep(step.stepCode, "COMPLETE")}
                        size="sm"
                      >
                        {isBusy ? "Salvando..." : "Marcar como concluída"}
                      </Button>
                      <Button
                        disabled={isBusy}
                        onClick={() => void changeStep(step.stepCode, "SKIP")}
                        size="sm"
                        variant="outline"
                      >
                        Agora não
                      </Button>
                    </>
                  ) : (
                    <Button
                      disabled={isBusy}
                      onClick={() => void changeStep(step.stepCode, "RESUME")}
                      size="sm"
                      variant="outline"
                    >
                      {isBusy ? "Salvando..." : "Retomar etapa"}
                    </Button>
                  )}
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
