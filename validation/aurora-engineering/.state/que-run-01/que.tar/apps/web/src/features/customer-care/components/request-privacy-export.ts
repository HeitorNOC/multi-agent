import { requestReportBodySchema, type RequestReportBody } from "@gestor/contracts";
import { z } from "zod";

const privacyExportIdSchema = z.uuid();

export function createPrivacyExportReportBody(customerId: string): RequestReportBody {
  return requestReportBodySchema.parse({
    filters: { customerId },
    format: "XLSX",
    reportType: "CUSTOMERS",
  });
}

export function privacyExportIdempotencyKey(requestId: string): string {
  return `lgpd-export-${privacyExportIdSchema.parse(requestId)}`;
}
