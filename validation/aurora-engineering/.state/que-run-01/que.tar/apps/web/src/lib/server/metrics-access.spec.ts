import { describe, expect, it } from "vitest";

import { requireMetricsAccess } from "./metrics-access";

describe("requireMetricsAccess", () => {
  it("accepts the configured bearer token", () => {
    const token = "a".repeat(32);
    const request = new Request("http://localhost/api/v1/metrics", {
      headers: { authorization: `Bearer ${token}` },
    });

    expect(() => requireMetricsAccess(request, token)).not.toThrow();
  });

  it("fails closed when the token is absent or invalid", () => {
    expect(() =>
      requireMetricsAccess(new Request("http://localhost/api/v1/metrics"), undefined),
    ).toThrowError(expect.objectContaining({ code: "METRICS_AUTHENTICATION_REQUIRED" }));
  });
});
