import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const {
  authenticate,
  getCatalogCommercialPolicy,
  resolveTenantActor,
  updateCatalogCommercialPolicy,
} = vi.hoisted(() => ({
  authenticate: vi.fn(),
  getCatalogCommercialPolicy: vi.fn(),
  resolveTenantActor: vi.fn(),
  updateCatalogCommercialPolicy: vi.fn(),
}));

vi.mock("@/lib/server/container", () => ({
  services: {
    getCatalogCommercialPolicy: { execute: getCatalogCommercialPolicy },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
    updateCatalogCommercialPolicy: { execute: updateCatalogCommercialPolicy },
  },
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));

import { GET, PUT } from "./route";

const organizationId = "00000000-0000-4000-8000-000000000001";
const route = { params: Promise.resolve({ organizationId }) };
const policy = {
  allowsDelivery: true,
  allowsPickup: true,
  cartExpiresAfterMinutes: 60,
  catalogOpen: true,
  createdAt: "2026-10-22T12:00:00.000Z",
  fulfillmentNotice: "Retire em até 30 minutos.",
  id: "00000000-0000-4000-8000-000000000002",
  minimumOrderAmount: 25,
  updatedAt: "2026-10-22T12:00:00.000Z",
} as const;

describe("catalog commercial policy route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    getCatalogCommercialPolicy.mockReset().mockResolvedValue(policy);
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    updateCatalogCommercialPolicy.mockReset().mockResolvedValue(policy);
  });

  it("returns the policy within the authenticated organization", async () => {
    const response = await GET(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/catalog-commercial-policy`,
      ),
      route,
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ data: policy });
    expect(resolveTenantActor).toHaveBeenCalledWith(
      expect.objectContaining({ organizationId, userId: "user-1" }),
    );
    expect(getCatalogCommercialPolicy).toHaveBeenCalledWith({ organizationId }, { role: "OWNER" });
  });

  it("updates the policy with the validated body", async () => {
    const body = {
      allowsDelivery: true,
      allowsPickup: false,
      cartExpiresAfterMinutes: 120,
      catalogOpen: true,
      fulfillmentNotice: "Entregas até as 18h.",
      minimumOrderAmount: 50,
    };
    const response = await PUT(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/catalog-commercial-policy`,
        {
          body: JSON.stringify(body),
          headers: { "content-type": "application/json" },
          method: "PUT",
        },
      ),
      route,
    );

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ data: policy });
    expect(updateCatalogCommercialPolicy).toHaveBeenCalledWith(
      { ...body, organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects an invalid policy body", async () => {
    const response = await PUT(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/catalog-commercial-policy`,
        {
          body: JSON.stringify({
            allowsDelivery: false,
            allowsPickup: false,
            cartExpiresAfterMinutes: 10,
            catalogOpen: true,
            minimumOrderAmount: null,
          }),
          headers: { "content-type": "application/json" },
          method: "PUT",
        },
      ),
      route,
    );

    expect(response.status).toBe(400);
    expect(updateCatalogCommercialPolicy).not.toHaveBeenCalled();
  });
});
