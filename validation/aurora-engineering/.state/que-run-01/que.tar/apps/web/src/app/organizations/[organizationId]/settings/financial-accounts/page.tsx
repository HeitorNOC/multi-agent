import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { FinancialAccountConfigurations } from "@/features/financial-accounts/components/financial-account-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Contas financeiras | Gestor",
};

type FinancialAccountsPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function FinancialAccountsPage({ params }: FinancialAccountsPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao checklist
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Implantação financeira
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Contas e saldos iniciais
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Cadastre caixas e bancos com a posição conferida na data de início. Depois disso, o saldo
          será consequência exclusiva dos movimentos financeiros.
        </p>
      </header>

      <ModuleGate moduleCode="financial" organizationId={organizationId}>
        <FinancialAccountConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
