import { expect, it, vi } from "vitest";

const { loggerError, processWebhook } = vi.hoisted(() => ({
  loggerError: vi.fn(),
  processWebhook: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({
    LOG_LEVEL: "silent",
    NODE_ENV: "test",
    RATE_LIMIT_HASH_SECRET: "test-secret",
    TRUST_PROXY_HEADERS: false,
  }),
}));
vi.mock("@/lib/server/container", () => ({
  services: { processTerminalPaymentWebhook: { execute: processWebhook } },
}));
vi.mock("@gestor/observability", () => ({
  getLogger: () => ({ error: loggerError }),
  metrics: { increment: vi.fn(), observe: vi.fn() },
}));

import { POST } from "./route";

it("forwards the exact signed provider payload without session authentication", async () => {
  const rawBody = JSON.stringify({ eventId: "event-001", status: "CONFIRMED" });
  processWebhook.mockResolvedValue({ id: "charge", status: "CONFIRMED" });
  const params = {
    chargeId: "10000000-0000-4000-8000-000000000003",
    organizationId: "10000000-0000-4000-8000-000000000001",
    provider: "SANDBOX",
  };
  const response = await POST(
    new Request("http://localhost/api/webhooks/payments", {
      body: rawBody,
      headers: { "x-payment-signature": "signature" },
      method: "POST",
    }),
    { params: Promise.resolve(params) },
  );
  const payload = await response.json();
  const logged = loggerError.mock.calls[0]?.[0] as { err?: Error } | undefined;
  expect(response.status, `${logged?.err?.message ?? "unknown"}: ${JSON.stringify(payload)}`).toBe(
    200,
  );
  expect(processWebhook).toHaveBeenCalledWith({
    ...params,
    rawBody,
    signature: "signature",
  });
});
