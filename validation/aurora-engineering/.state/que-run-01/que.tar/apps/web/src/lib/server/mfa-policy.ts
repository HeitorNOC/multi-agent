import type { AuthenticatedIdentity } from "@gestor/auth";
import type { ActorContext, PermissionCode } from "@gestor/identity";
import { AuthorizationError } from "@gestor/kernel";

const sensitivePlatformRoles = new Set(["OWNER", "ADMIN"]);

export function requireMfaForPlatformRole(identity: AuthenticatedIdentity, role: string): void {
  if (!sensitivePlatformRoles.has(role) || identity.mfaEnabled) return;

  throw new AuthorizationError(
    "MFA_REQUIRED",
    "Ative a autenticação em duas etapas para realizar ações administrativas.",
  );
}

const sensitiveFinancialPermissions = new Set<PermissionCode>([
  "bank_account.manage",
  "bank_transaction.import",
  "cash_register.manage",
  "financial_account.manage",
  "financial_transfer.manage",
]);

export function requireMfaForFinancialMutation(
  identity: AuthenticatedIdentity,
  actor: ActorContext,
  permission: PermissionCode,
): void {
  if (!sensitiveFinancialPermissions.has(permission) || !actor.permissions?.has(permission)) return;
  if (identity.mfaEnabled !== false) return;

  throw new AuthorizationError(
    "MFA_REQUIRED",
    "Ative a autenticação em duas etapas para realizar esta operação financeira.",
  );
}
