import { requestReportBodySchema, type RequestReportBody } from "@gestor/contracts";
import { z } from "zod";

export const requestReportFormSchema = z
  .object({
    branchId: z.string(),
    format: z.enum(["CSV", "XLSX", "PDF"]),
    from: z.string(),
    reportType: z.enum([
      "SALES",
      "PURCHASES",
      "INVENTORY",
      "PAYABLES",
      "RECEIVABLES",
      "CASH",
      "FINANCIAL_MOVEMENTS",
      "CUSTOMERS",
      "SUPPLIERS",
      "SIMPLIFIED_INCOME_STATEMENT",
    ]),
    status: z.string().max(80),
    to: z.string(),
  })
  .refine(({ from, reportType, to }) => reportType === "INVENTORY" || !from || !to || from <= to, {
    message: "A data inicial não pode ser posterior à data final.",
    path: ["to"],
  });

export type RequestReportFormValues = z.infer<typeof requestReportFormSchema>;

export const requestReportFormDefaults: RequestReportFormValues = {
  branchId: "",
  format: "CSV",
  from: "",
  reportType: "SALES",
  status: "",
  to: "",
};

export function createBasicReportBody(values: RequestReportFormValues): RequestReportBody {
  return requestReportBodySchema.parse({
    filters: compactFilters(values),
    format: values.format,
    reportType: values.reportType,
  });
}

export function reportRequestFingerprint(body: RequestReportBody): string {
  return JSON.stringify(body);
}

function compactFilters({
  branchId,
  from,
  status,
  to,
  reportType,
}: RequestReportFormValues): RequestReportBody["filters"] {
  return {
    ...(branchId ? { branchId } : {}),
    ...(from && reportType !== "INVENTORY" ? { from } : {}),
    ...(status ? { status } : {}),
    ...(to && reportType !== "INVENTORY" ? { to } : {}),
  };
}
