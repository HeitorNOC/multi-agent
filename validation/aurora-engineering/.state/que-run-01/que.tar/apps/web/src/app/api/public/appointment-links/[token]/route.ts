import { handleApiRequest } from "@/lib/server/api-request";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ token: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async () => {
      const { token } = await route.params;
      await services.resolvePublicAppointmentPortalLink.execute(token);
      return Response.json({ data: { available: true, type: "APPOINTMENT" } });
    },
    {
      authentication: "PUBLIC",
      legalAcceptance: false,
      rateLimit: apiRateLimitPolicies.publicPortalLink,
    },
  );
}
