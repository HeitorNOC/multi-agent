import { ApplicationIdentityProvider, ResendAuthenticationEmailSender } from "@gestor/auth";
import { CompleteFoodServiceCheckout } from "@/lib/server/complete-food-service-checkout";
import { createCustomerPortalServices } from "@/lib/server/customer-portal-services";
import {
  CreateCatalogCategory,
  CreateCatalogPortalLink,
  CreateCatalogFileDownload,
  CreateCatalogCustomField,
  CreateProduct,
  CreatePriceList,
  CreateService,
  DeleteCatalogFile,
  ListCatalogCategories,
  ListCatalogPortalLinks,
  ListCatalogFiles,
  GetCatalogCustomFieldValues,
  GetCatalogCommercialPolicy,
  ListCatalogCustomFields,
  ListProducts,
  ListPriceLists,
  ListProductPriceHistory,
  ListServices,
  ListServicePriceHistory,
  ResolveCatalogPrice,
  UploadCatalogFile,
  RevokeCatalogPortalLink,
  UpdateCatalogCategory,
  UpdateCatalogCustomFields,
  UpdateCatalogCommercialPolicy,
  UpdateProduct,
  UpdatePriceList,
  UpdateService,
} from "@gestor/catalog";
import { getAuthEnv, getFileStorageEnv, getReportStorageEnv } from "@gestor/config";
import {
  PrismaCatalogCommercialPolicyUnitOfWork,
  PrismaCatalogPortalLinkUnitOfWork,
  PrismaCatalogUnitOfWork,
} from "@gestor/catalog/prisma";
import {
  CreateCustomer,
  CreateCustomerCustomField,
  CreateCustomerTag,
  CreateSupplier,
  CreateSupplierCustomField,
  GetCustomerCustomFieldValues,
  GetSupplierCustomFieldValues,
  ListCustomers,
  ListCustomerCustomFields,
  ListCustomerTags,
  ListSuppliers,
  ListSupplierCustomFields,
  UpdateCustomer,
  UpdateCustomerCustomFields,
  UpdateCustomerTags,
  UpdateSupplier,
  UpdateSupplierCustomFields,
} from "@gestor/crm";
import {
  PrismaCustomerCustomFieldUnitOfWork,
  PrismaCustomerUnitOfWork,
  PrismaSupplierUnitOfWork,
  PrismaSupplierCustomFieldUnitOfWork,
} from "@gestor/crm/prisma";
import { prisma } from "@gestor/database";
import { ManageCustomerCare } from "@gestor/customer-care";
import { PrismaCustomerCareUnitOfWork } from "@gestor/customer-care/prisma";
import {
  CreateFoodServiceDiningArea,
  CreateFoodServiceDiningTable,
  CreateFoodServiceKitchenStation,
  ListFoodServiceKitchenProductRoutes,
  ListFoodServiceRecipe,
  SetFoodServiceKitchenDefaultStation,
  SetFoodServiceKitchenProductRoute,
  SaveFoodServiceRecipe,
  CreateFoodServiceOrder,
  CancelFoodServiceOrder,
  ListFoodServiceOrders,
  AcceptFoodServiceOrder,
  BeginFoodServiceOrderCheckout,
  AddFoodServiceOrderItem,
  MoveFoodServiceOrderItem,
  RemoveFoodServiceOrderItem,
  OpenFoodServiceTableSession,
  CancelFoodServiceTableSession,
  MoveFoodServiceTableSession,
  GetFoodServiceSettings,
  ListFoodServiceDiningAreas,
  ListFoodServiceDiningTables,
  ListFoodServiceKitchenStations,
  ListFoodServiceKitchenTickets,
  ListFoodServiceTableSessions,
  UpdateFoodServiceSettings,
  TransitionFoodServiceKitchenTicket,
  ResolveFoodServiceKitchenTicketIngredients,
  ListFoodServiceProductModifierGroups,
  ReplaceFoodServiceProductModifierGroups,
} from "@gestor/food-service";
import { PrismaFoodServiceUnitOfWork } from "@gestor/food-service/prisma";
import { GetDashboard } from "@gestor/dashboard";
import { PrismaDashboardQueryRepository } from "@gestor/dashboard/prisma";
import {
  BeginCashReconciliation,
  CancelFinancialObligation,
  CloseCashRegister,
  CreateBankAccount,
  CreateCashOperation,
  CreateFinancialAccount,
  CreateFinancialCategory,
  CreateFinancialObligation,
  CreateFinancialTransfer,
  ImportBankStatement,
  CreatePaymentMethodConfiguration,
  ListFinancialAccounts,
  ListBankAccounts,
  ListCashRegisters,
  ListFinancialCategories,
  ListFinancialObligations,
  ListFinancialTransfers,
  ListAcquirerPayouts,
  ListBankTransactions,
  ListPaymentMethodConfigurations,
  SettleFinancialObligation,
  SettleAcquirerPayout,
  OpenCashRegister,
  ResumeCashRegister,
  ReverseFinancialObligation,
  UpdateFinancialAccount,
  UpdateFinancialCategory,
  UpdatePaymentMethodConfiguration,
} from "@gestor/financial";
import {
  PrismaCashRegisterUnitOfWork,
  PrismaFinancialObligationUnitOfWork,
  PrismaFinancialTransferUnitOfWork,
  PrismaBankStatementUnitOfWork,
  PrismaFinancialUnitOfWork,
  PrismaAcquirerPayoutUnitOfWork,
} from "@gestor/financial/prisma";
import {
  AcceptOrganizationInvitation,
  CreateOrganizationInvitation,
  ListOrganizationInvitations,
  ManageOrganizationUsers,
  RevokeOrganizationInvitation,
  ResolvePlatformActor,
  ResolveTenantActor,
} from "@gestor/identity";
import { NodeOrganizationInvitationTokenService } from "@gestor/identity/crypto";
import {
  AdjustStock,
  CountInventory,
  CreateInitialStock,
  ListPurchaseSuggestions,
  ListStockBalances,
  ListStockMovements,
  TransferStock,
  ListInventoryCountSessions,
  OpenInventoryCountSession,
  RecordInventoryCountSessionItem,
  CloseInventoryCountSession,
} from "@gestor/inventory";
import { PrismaInventoryUnitOfWork } from "@gestor/inventory/prisma";
import {
  CancelSale,
  ChangeQuoteStatus,
  ChangeSalesOrderStatus,
  CompleteSale,
  ConvertCustomerPortalOrder,
  ConvertQuote,
  CreateSaleReceipt,
  CreateQuote,
  GetSale,
  ListQuotes,
  ListSales,
  ListSalesOrders,
  ReturnSale,
  SendSaleReceipt,
} from "@gestor/sales";
import { PrismaSalesUnitOfWork } from "@gestor/sales/prisma";
import {
  ChangeAppointmentStatus,
  CreateAppointment,
  CreateAppointmentPortalLink,
  ResolvePublicAppointmentPortalLink,
  CreateAvailabilityRule,
  RemoveAvailabilityRule,
  RevokeAppointmentPortalLink,
  UpdateAvailabilityRule,
  ListAvailabilityRules,
  ListSchedulingProfessionals,
  CreateAppointmentResource,
  GetAppointmentSettings,
  ListAppointments,
  ListAppointmentResources,
  ListAppointmentPortalLinks,
  UpdateAppointment,
  UpdateAppointmentSettings,
} from "@gestor/scheduling";
import { PrismaSchedulingUnitOfWork } from "@gestor/scheduling/prisma";
import {
  CancelPurchase,
  CreatePurchaseDocument,
  GetPurchase,
  ListPurchases,
  OrderPurchase,
  ReceivePurchase,
  ReceivePurchaseOrder,
} from "@gestor/purchases";
import { PrismaPurchaseUnitOfWork } from "@gestor/purchases/prisma";
import { CreateReportDownload, GetReport, ListReports, RequestReport } from "@gestor/reporting";
import { PrismaReportUnitOfWork } from "@gestor/reporting/prisma";
import { SupabaseReportArtifactStorage } from "@gestor/reporting/storage";
import {
  PrismaOrganizationUserAdministration,
  PrismaOrganizationInvitationAdministration,
  PrismaPlatformActorResolver,
  PrismaTenantActorResolver,
} from "@gestor/identity/prisma";
import {
  ChangeOrganizationModule,
  ChangeOnboardingStep,
  CreateBranch,
  GetOnboardingChecklist,
  GetBranch,
  ListBranches,
  ListOrganizationModules,
  ListPlatformOrganizationModules,
  ProvisionOrganization,
} from "@gestor/organizations";
import {
  PrismaOnboardingUnitOfWork,
  PrismaOrganizationModuleUnitOfWork,
  PrismaOrganizationProvisioner,
  PrismaOrganizationUnitOfWork,
  PrismaPlatformOrganizationModuleUnitOfWork,
} from "@gestor/organizations/prisma";
import { HttpCatalogMalwareScanner, SupabaseCatalogObjectStorage } from "./catalog-file-gateway";
import { fiscalServices } from "./fiscal-services";
import { posServices } from "./pos-services";
import { ResendSaleReceiptEmailSender } from "./sale-receipt-email";
const organizationUnitOfWork = new PrismaOrganizationUnitOfWork(prisma);
const catalogUnitOfWork = new PrismaCatalogUnitOfWork(prisma);
const catalogCommercialPolicyUnitOfWork = new PrismaCatalogCommercialPolicyUnitOfWork(prisma);
const catalogPortalLinkUnitOfWork = new PrismaCatalogPortalLinkUnitOfWork(prisma);
const catalogObjectStorage = new SupabaseCatalogObjectStorage();
const catalogMalwareScanner = new HttpCatalogMalwareScanner();
const customerUnitOfWork = new PrismaCustomerUnitOfWork(prisma);
const customerCustomFieldUnitOfWork = new PrismaCustomerCustomFieldUnitOfWork(prisma);
const supplierUnitOfWork = new PrismaSupplierUnitOfWork(prisma);
const supplierCustomFieldUnitOfWork = new PrismaSupplierCustomFieldUnitOfWork(prisma);
const onboardingUnitOfWork = new PrismaOnboardingUnitOfWork(prisma);
const organizationModuleUnitOfWork = new PrismaOrganizationModuleUnitOfWork(prisma);
const platformOrganizationModuleUnitOfWork = new PrismaPlatformOrganizationModuleUnitOfWork(prisma);
const financialUnitOfWork = new PrismaFinancialUnitOfWork(prisma);
const financialObligationUnitOfWork = new PrismaFinancialObligationUnitOfWork(prisma);
const financialTransferUnitOfWork = new PrismaFinancialTransferUnitOfWork(prisma);
const acquirerPayoutUnitOfWork = new PrismaAcquirerPayoutUnitOfWork(prisma);
const bankStatementUnitOfWork = new PrismaBankStatementUnitOfWork(prisma);
const cashRegisterUnitOfWork = new PrismaCashRegisterUnitOfWork(prisma);
const organizationProvisioner = new PrismaOrganizationProvisioner(prisma);
const inventoryUnitOfWork = new PrismaInventoryUnitOfWork(prisma);
const salesUnitOfWork = new PrismaSalesUnitOfWork(prisma);
const schedulingUnitOfWork = new PrismaSchedulingUnitOfWork(prisma);
const foodServiceUnitOfWork = new PrismaFoodServiceUnitOfWork(prisma);
const getSale = new GetSale(salesUnitOfWork);
const createSaleReceipt = new CreateSaleReceipt(getSale);
const saleReceiptEmailSender = new ResendSaleReceiptEmailSender();
const purchaseUnitOfWork = new PrismaPurchaseUnitOfWork(prisma);
const customerCareUnitOfWork = new PrismaCustomerCareUnitOfWork(prisma);
const reportUnitOfWork = new PrismaReportUnitOfWork(prisma);
const reportArtifactStorage = new SupabaseReportArtifactStorage(() => {
  const environment = getReportStorageEnv();
  return {
    bucket: environment.SUPABASE_STORAGE_BUCKET,
    secretKey: environment.SUPABASE_STORAGE_SECRET_KEY,
    url: environment.SUPABASE_STORAGE_URL,
  };
});
const dashboardQueryRepository = new PrismaDashboardQueryRepository(prisma);
const organizationUserAdministration = new PrismaOrganizationUserAdministration(prisma);
const organizationInvitationAdministration = new PrismaOrganizationInvitationAdministration(prisma);
const organizationInvitationTokens = new NodeOrganizationInvitationTokenService();
const organizationInvitationEmailSender = new ResendAuthenticationEmailSender();
export const services = {
  ...createCustomerPortalServices(prisma),
  ...fiscalServices,
  ...posServices,
  customerCare: new ManageCustomerCare(customerCareUnitOfWork),
  acceptOrganizationInvitation: new AcceptOrganizationInvitation(
    organizationInvitationAdministration,
    organizationInvitationTokens,
  ),
  createOrganizationInvitation: new CreateOrganizationInvitation(
    organizationInvitationAdministration,
    organizationInvitationTokens,
    organizationInvitationEmailSender,
    () => getAuthEnv().BETTER_AUTH_URL,
  ),
  getDashboard: new GetDashboard(dashboardQueryRepository),
  manageOrganizationUsers: new ManageOrganizationUsers(organizationUserAdministration),
  adjustStock: new AdjustStock(inventoryUnitOfWork),
  beginCashReconciliation: new BeginCashReconciliation(cashRegisterUnitOfWork),
  cancelFinancialObligation: new CancelFinancialObligation(financialObligationUnitOfWork),
  closeCashRegister: new CloseCashRegister(cashRegisterUnitOfWork),
  cancelSale: new CancelSale(salesUnitOfWork),
  changeQuoteStatus: new ChangeQuoteStatus(salesUnitOfWork),
  changeSalesOrderStatus: new ChangeSalesOrderStatus(salesUnitOfWork),
  completeSale: new CompleteSale(salesUnitOfWork),
  completeFoodServiceCheckout: new CompleteFoodServiceCheckout(prisma),
  convertCustomerPortalOrder: new ConvertCustomerPortalOrder(salesUnitOfWork),
  createSaleReceipt,
  createAppointment: new CreateAppointment(schedulingUnitOfWork),
  createFoodServiceDiningArea: new CreateFoodServiceDiningArea(foodServiceUnitOfWork),
  createFoodServiceDiningTable: new CreateFoodServiceDiningTable(foodServiceUnitOfWork),
  createFoodServiceKitchenStation: new CreateFoodServiceKitchenStation(foodServiceUnitOfWork),
  listFoodServiceKitchenProductRoutes: new ListFoodServiceKitchenProductRoutes(
    foodServiceUnitOfWork,
  ),
  listFoodServiceRecipe: new ListFoodServiceRecipe(foodServiceUnitOfWork),
  saveFoodServiceRecipe: new SaveFoodServiceRecipe(foodServiceUnitOfWork),
  setFoodServiceKitchenDefaultStation: new SetFoodServiceKitchenDefaultStation(
    foodServiceUnitOfWork,
  ),
  setFoodServiceKitchenProductRoute: new SetFoodServiceKitchenProductRoute(foodServiceUnitOfWork),
  createFoodServiceOrder: new CreateFoodServiceOrder(foodServiceUnitOfWork),
  cancelFoodServiceOrder: new CancelFoodServiceOrder(foodServiceUnitOfWork),
  listFoodServiceOrders: new ListFoodServiceOrders(foodServiceUnitOfWork),
  acceptFoodServiceOrder: new AcceptFoodServiceOrder(foodServiceUnitOfWork),
  beginFoodServiceOrderCheckout: new BeginFoodServiceOrderCheckout(foodServiceUnitOfWork),
  addFoodServiceOrderItem: new AddFoodServiceOrderItem(foodServiceUnitOfWork),
  moveFoodServiceOrderItem: new MoveFoodServiceOrderItem(foodServiceUnitOfWork),
  removeFoodServiceOrderItem: new RemoveFoodServiceOrderItem(foodServiceUnitOfWork),
  openFoodServiceTableSession: new OpenFoodServiceTableSession(foodServiceUnitOfWork),
  cancelFoodServiceTableSession: new CancelFoodServiceTableSession(foodServiceUnitOfWork),
  moveFoodServiceTableSession: new MoveFoodServiceTableSession(foodServiceUnitOfWork),
  getAppointmentSettings: new GetAppointmentSettings(schedulingUnitOfWork),
  getFoodServiceSettings: new GetFoodServiceSettings(foodServiceUnitOfWork),
  listFoodServiceKitchenStations: new ListFoodServiceKitchenStations(foodServiceUnitOfWork),
  listFoodServiceKitchenTickets: new ListFoodServiceKitchenTickets(foodServiceUnitOfWork),
  transitionFoodServiceKitchenTicket: new TransitionFoodServiceKitchenTicket(foodServiceUnitOfWork),
  resolveFoodServiceKitchenTicketIngredients: new ResolveFoodServiceKitchenTicketIngredients(
    foodServiceUnitOfWork,
  ),
  listFoodServiceProductModifierGroups: new ListFoodServiceProductModifierGroups(
    foodServiceUnitOfWork,
  ),
  replaceFoodServiceProductModifierGroups: new ReplaceFoodServiceProductModifierGroups(
    foodServiceUnitOfWork,
  ),
  updateAppointmentSettings: new UpdateAppointmentSettings(schedulingUnitOfWork),
  createAppointmentPortalLink: new CreateAppointmentPortalLink(schedulingUnitOfWork),
  createAvailabilityRule: new CreateAvailabilityRule(schedulingUnitOfWork),
  removeAvailabilityRule: new RemoveAvailabilityRule(schedulingUnitOfWork),
  revokeAppointmentPortalLink: new RevokeAppointmentPortalLink(schedulingUnitOfWork),
  updateAvailabilityRule: new UpdateAvailabilityRule(schedulingUnitOfWork),
  listAvailabilityRules: new ListAvailabilityRules(schedulingUnitOfWork),
  listSchedulingProfessionals: new ListSchedulingProfessionals(schedulingUnitOfWork),
  createAppointmentResource: new CreateAppointmentResource(schedulingUnitOfWork),
  updateAppointment: new UpdateAppointment(schedulingUnitOfWork),
  changeAppointmentStatus: new ChangeAppointmentStatus(schedulingUnitOfWork),
  listAppointments: new ListAppointments(schedulingUnitOfWork),
  listAppointmentResources: new ListAppointmentResources(schedulingUnitOfWork),
  listAppointmentPortalLinks: new ListAppointmentPortalLinks(schedulingUnitOfWork),
  listFoodServiceDiningAreas: new ListFoodServiceDiningAreas(foodServiceUnitOfWork),
  listFoodServiceDiningTables: new ListFoodServiceDiningTables(foodServiceUnitOfWork),
  listFoodServiceTableSessions: new ListFoodServiceTableSessions(foodServiceUnitOfWork),
  convertQuote: new ConvertQuote(salesUnitOfWork),
  countInventory: new CountInventory(inventoryUnitOfWork),
  listInventoryCountSessions: new ListInventoryCountSessions(inventoryUnitOfWork),
  openInventoryCountSession: new OpenInventoryCountSession(inventoryUnitOfWork),
  recordInventoryCountSessionItem: new RecordInventoryCountSessionItem(inventoryUnitOfWork),
  closeInventoryCountSession: new CloseInventoryCountSession(inventoryUnitOfWork),
  returnSale: new ReturnSale(salesUnitOfWork),
  receivePurchase: new ReceivePurchase(purchaseUnitOfWork),
  receivePurchaseOrder: new ReceivePurchaseOrder(purchaseUnitOfWork),
  requestReport: new RequestReport(reportUnitOfWork),
  cancelPurchase: new CancelPurchase(purchaseUnitOfWork),
  createPurchaseDocument: new CreatePurchaseDocument(purchaseUnitOfWork),
  getPurchase: new GetPurchase(purchaseUnitOfWork),
  getReport: new GetReport(reportUnitOfWork),
  listReports: new ListReports(reportUnitOfWork),
  createReportDownload: new CreateReportDownload(
    reportUnitOfWork,
    reportArtifactStorage,
    () => getReportStorageEnv().FILE_SIGNED_URL_TTL_SECONDS,
  ),
  listPurchases: new ListPurchases(purchaseUnitOfWork),
  orderPurchase: new OrderPurchase(purchaseUnitOfWork),
  changeOnboardingStep: new ChangeOnboardingStep(onboardingUnitOfWork),
  changeOrganizationModule: new ChangeOrganizationModule(platformOrganizationModuleUnitOfWork),
  createCatalogCategory: new CreateCatalogCategory(catalogUnitOfWork),
  createCatalogPortalLink: new CreateCatalogPortalLink(catalogPortalLinkUnitOfWork),
  createCatalogFileDownload: new CreateCatalogFileDownload(
    catalogUnitOfWork,
    catalogObjectStorage,
    () => getFileStorageEnv().FILE_SIGNED_URL_TTL_SECONDS,
  ),
  createCatalogCustomField: new CreateCatalogCustomField(catalogUnitOfWork),
  createBranch: new CreateBranch(organizationUnitOfWork),
  createCustomer: new CreateCustomer(customerUnitOfWork),
  createCustomerCustomField: new CreateCustomerCustomField(customerCustomFieldUnitOfWork),
  createCustomerTag: new CreateCustomerTag(customerUnitOfWork),
  createProduct: new CreateProduct(catalogUnitOfWork),
  createPriceList: new CreatePriceList(catalogUnitOfWork),
  createService: new CreateService(catalogUnitOfWork),
  deleteCatalogFile: new DeleteCatalogFile(catalogUnitOfWork),
  createSupplier: new CreateSupplier(supplierUnitOfWork),
  createSupplierCustomField: new CreateSupplierCustomField(supplierCustomFieldUnitOfWork),
  createBankAccount: new CreateBankAccount(financialUnitOfWork),
  createCashOperation: new CreateCashOperation(cashRegisterUnitOfWork),
  createFinancialAccount: new CreateFinancialAccount(financialUnitOfWork),
  createFinancialCategory: new CreateFinancialCategory(financialUnitOfWork),
  createFinancialObligation: new CreateFinancialObligation(financialObligationUnitOfWork),
  createFinancialTransfer: new CreateFinancialTransfer(financialTransferUnitOfWork),
  createInitialStock: new CreateInitialStock(inventoryUnitOfWork),
  createQuote: new CreateQuote(salesUnitOfWork),
  createPaymentMethodConfiguration: new CreatePaymentMethodConfiguration(financialUnitOfWork),
  importBankStatement: new ImportBankStatement(bankStatementUnitOfWork),
  getOnboardingChecklist: new GetOnboardingChecklist(onboardingUnitOfWork),
  getCatalogCustomFieldValues: new GetCatalogCustomFieldValues(catalogUnitOfWork),
  getCatalogCommercialPolicy: new GetCatalogCommercialPolicy(catalogCommercialPolicyUnitOfWork),
  getBranch: new GetBranch(organizationUnitOfWork),
  getCustomerCustomFieldValues: new GetCustomerCustomFieldValues(customerCustomFieldUnitOfWork),
  getSupplierCustomFieldValues: new GetSupplierCustomFieldValues(supplierCustomFieldUnitOfWork),
  getSale,
  identityProvider: new ApplicationIdentityProvider(),
  listBranches: new ListBranches(organizationUnitOfWork),
  listCatalogCategories: new ListCatalogCategories(catalogUnitOfWork),
  listCatalogPortalLinks: new ListCatalogPortalLinks(catalogPortalLinkUnitOfWork),
  listCatalogFiles: new ListCatalogFiles(catalogUnitOfWork),
  listCatalogCustomFields: new ListCatalogCustomFields(catalogUnitOfWork),
  listCustomers: new ListCustomers(customerUnitOfWork),
  listCustomerCustomFields: new ListCustomerCustomFields(customerCustomFieldUnitOfWork),
  listCustomerTags: new ListCustomerTags(customerUnitOfWork),
  listSuppliers: new ListSuppliers(supplierUnitOfWork),
  listSupplierCustomFields: new ListSupplierCustomFields(supplierCustomFieldUnitOfWork),
  updateCustomer: new UpdateCustomer(customerUnitOfWork),
  updateCustomerCustomFields: new UpdateCustomerCustomFields(customerCustomFieldUnitOfWork),
  updateCustomerTags: new UpdateCustomerTags(customerUnitOfWork),
  updateSupplier: new UpdateSupplier(supplierUnitOfWork),
  updateSupplierCustomFields: new UpdateSupplierCustomFields(supplierCustomFieldUnitOfWork),
  listOrganizationModules: new ListOrganizationModules(organizationModuleUnitOfWork),
  listOrganizationInvitations: new ListOrganizationInvitations(
    organizationInvitationAdministration,
  ),
  revokeCatalogPortalLink: new RevokeCatalogPortalLink(catalogPortalLinkUnitOfWork),
  revokeOrganizationInvitation: new RevokeOrganizationInvitation(
    organizationInvitationAdministration,
  ),
  listPlatformOrganizationModules: new ListPlatformOrganizationModules(
    platformOrganizationModuleUnitOfWork,
  ),
  listBankAccounts: new ListBankAccounts(financialUnitOfWork),
  listCashRegisters: new ListCashRegisters(cashRegisterUnitOfWork),
  listFinancialAccounts: new ListFinancialAccounts(financialUnitOfWork),
  listFinancialCategories: new ListFinancialCategories(financialUnitOfWork),
  listFinancialObligations: new ListFinancialObligations(financialObligationUnitOfWork),
  listFinancialTransfers: new ListFinancialTransfers(financialTransferUnitOfWork),
  listAcquirerPayouts: new ListAcquirerPayouts(acquirerPayoutUnitOfWork),
  listPaymentMethodConfigurations: new ListPaymentMethodConfigurations(financialUnitOfWork),
  listProducts: new ListProducts(catalogUnitOfWork),
  listPriceLists: new ListPriceLists(catalogUnitOfWork),
  listStockBalances: new ListStockBalances(inventoryUnitOfWork),
  listStockMovements: new ListStockMovements(inventoryUnitOfWork),
  listPurchaseSuggestions: new ListPurchaseSuggestions(inventoryUnitOfWork),
  listProductPriceHistory: new ListProductPriceHistory(catalogUnitOfWork),
  listServices: new ListServices(catalogUnitOfWork),
  listSales: new ListSales(salesUnitOfWork),
  listQuotes: new ListQuotes(salesUnitOfWork),
  listSalesOrders: new ListSalesOrders(salesUnitOfWork),
  listServicePriceHistory: new ListServicePriceHistory(catalogUnitOfWork),
  listBankTransactions: new ListBankTransactions(bankStatementUnitOfWork),
  provisionOrganization: new ProvisionOrganization(organizationProvisioner),
  openCashRegister: new OpenCashRegister(cashRegisterUnitOfWork),
  resolveTenantActor: new ResolveTenantActor(new PrismaTenantActorResolver(prisma)),
  resolveCatalogPrice: new ResolveCatalogPrice(catalogUnitOfWork),
  resolvePlatformActor: new ResolvePlatformActor(new PrismaPlatformActorResolver(prisma)),
  resumeCashRegister: new ResumeCashRegister(cashRegisterUnitOfWork),
  reverseFinancialObligation: new ReverseFinancialObligation(financialObligationUnitOfWork),
  settleFinancialObligation: new SettleFinancialObligation(financialObligationUnitOfWork),
  settleAcquirerPayout: new SettleAcquirerPayout(acquirerPayoutUnitOfWork),
  sendSaleReceipt: new SendSaleReceipt(createSaleReceipt, saleReceiptEmailSender),
  transferStock: new TransferStock(inventoryUnitOfWork),
  updateFinancialAccount: new UpdateFinancialAccount(financialUnitOfWork),
  updateFinancialCategory: new UpdateFinancialCategory(financialUnitOfWork),
  updateCatalogCategory: new UpdateCatalogCategory(catalogUnitOfWork),
  updateFoodServiceSettings: new UpdateFoodServiceSettings(foodServiceUnitOfWork),
  updateCatalogCustomFields: new UpdateCatalogCustomFields(catalogUnitOfWork),
  updateCatalogCommercialPolicy: new UpdateCatalogCommercialPolicy(
    catalogCommercialPolicyUnitOfWork,
  ),
  updateProduct: new UpdateProduct(catalogUnitOfWork),
  updatePriceList: new UpdatePriceList(catalogUnitOfWork),
  updateService: new UpdateService(catalogUnitOfWork),
  updatePaymentMethodConfiguration: new UpdatePaymentMethodConfiguration(financialUnitOfWork),
  uploadCatalogFile: new UploadCatalogFile(
    catalogUnitOfWork,
    catalogObjectStorage,
    catalogMalwareScanner,
  ),
};
