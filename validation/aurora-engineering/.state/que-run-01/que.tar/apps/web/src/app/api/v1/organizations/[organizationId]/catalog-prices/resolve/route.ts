import { organizationParamsSchema, resolveCatalogPriceQuerySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = resolveCatalogPriceQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.resolveCatalogPrice.execute(
        {
          branchId: query.branchId,
          organizationId: params.organizationId,
          ...(query.at ? { at: query.at } : {}),
          ...(query.productId ? { productId: query.productId } : {}),
          ...(query.serviceId ? { serviceId: query.serviceId } : {}),
        },
        actor,
      ),
    });
  });
}
