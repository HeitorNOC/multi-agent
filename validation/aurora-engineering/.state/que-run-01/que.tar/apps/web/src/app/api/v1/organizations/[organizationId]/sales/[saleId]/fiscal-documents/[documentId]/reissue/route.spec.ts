import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, reissueFiscalDocument, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  reissueFiscalDocument: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    reissueFiscalDocument: { execute: reissueFiscalDocument },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
const saleId = "10000000-0000-4000-8000-000000000002";
const documentId = "10000000-0000-4000-8000-000000000003";

it("requires idempotency and forwards a validated fiscal reissue", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  reissueFiscalDocument.mockResolvedValue({ id: documentId });
  const response = await POST(
    new Request(
      `http://localhost/api/v1/organizations/${organizationId}/sales/${saleId}/fiscal-documents/${documentId}/reissue`,
      { headers: { "idempotency-key": "reissue-key-001" }, method: "POST" },
    ),
    { params: Promise.resolve({ documentId, organizationId, saleId }) },
  );
  expect(response.status).toBe(200);
  expect(reissueFiscalDocument).toHaveBeenCalledWith(
    { documentId, idempotencyKey: "reissue-key-001", organizationId, saleId },
    { role: "OWNER" },
  );
});
