import { publicCartItemBodySchema } from "@gestor/contracts";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
async function context(
  request: Request,
  token: string,
  api: { correlationId: string; requestId: string },
) {
  const link = await services.resolvePublicCatalogPortalLink.execute(token);
  const identity = await authenticateApiRequest(request);
  const actor = await services.resolveCustomerPortalActor.execute({
    correlationId: api.correlationId,
    organizationId: link.organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
  return { actor, link };
}
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ token: string; productId: string }> },
) {
  return handleApiRequest(request, async (api) => {
    const routeParams = await params;
    const body = publicCartItemBodySchema.parse(await readJsonBody(request));
    const { actor, link } = await context(request, routeParams.token, api);
    return Response.json({
      data: await services.setPublicCartItem.execute(
        { ...body, branchId: link.branchId, linkId: link.id, productId: routeParams.productId },
        actor,
      ),
    });
  });
}
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ token: string; productId: string }> },
) {
  return handleApiRequest(request, async (api) => {
    const routeParams = await params;
    const { actor, link } = await context(request, routeParams.token, api);
    return Response.json({
      data: await services.removePublicCartItem.execute(
        { branchId: link.branchId, linkId: link.id, productId: routeParams.productId },
        actor,
      ),
    });
  });
}
