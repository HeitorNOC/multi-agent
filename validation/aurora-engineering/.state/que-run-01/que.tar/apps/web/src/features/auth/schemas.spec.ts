import { describe, expect, it } from "vitest";

import { loginSchema, recoverPasswordSchema, resetPasswordSchema, signUpSchema } from "./schemas";

describe("authentication form schemas", () => {
  it("normalizes e-mail addresses before sending them to authentication", () => {
    const login = loginSchema.parse({
      email: "OWNER@EXAMPLE.COM",
      password: "secret",
      rememberMe: true,
    });
    const recovery = recoverPasswordSchema.parse({
      email: "OWNER@EXAMPLE.COM",
    });

    expect(login.email).toBe("owner@example.com");
    expect(recovery.email).toBe("owner@example.com");
  });

  it("enforces the same password boundaries as the server", () => {
    const tooShort = signUpSchema.safeParse({
      confirmPassword: "short",
      email: "owner@example.com",
      name: "Owner",
      password: "short",
    });
    const tooLong = resetPasswordSchema.safeParse({
      confirmPassword: "a".repeat(129),
      password: "a".repeat(129),
    });

    expect(tooShort.success).toBe(false);
    expect(tooLong.success).toBe(false);
  });

  it("rejects password confirmation mismatches", () => {
    const result = resetPasswordSchema.safeParse({
      confirmPassword: "another-password",
      password: "valid-password",
    });

    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues[0]?.path).toEqual(["confirmPassword"]);
    }
  });
});
