"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  changeOrganizationModuleBodySchema,
  organizationModuleListSchema,
  organizationModuleViewSchema,
  type OrganizationModuleView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import {
  organizationModuleConfigurationSchema,
  type OrganizationModuleConfigurationForm,
} from "../organization-modules";

type OrganizationModulesProps = {
  organizationId: string;
};

export function OrganizationModules({ organizationId }: OrganizationModulesProps) {
  const [modules, setModules] = useState<readonly OrganizationModuleView[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    async function loadModules() {
      try {
        const response = await fetch(`/api/v1/platform/organizations/${organizationId}/modules`, {
          signal: controller.signal,
        });
        if (!response.ok) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }
        const payload = (await response.json()) as { data: unknown };
        const nextModules = organizationModuleListSchema.parse(payload.data);
        if (!controller.signal.aborted) setModules(nextModules);
      } catch (loadError) {
        if (!controller.signal.aborted) {
          setError(
            loadError instanceof Error
              ? loadError.message
              : "Não foi possível carregar os módulos.",
          );
        }
      }
    }

    void loadModules();
    return () => controller.abort();
  }, [organizationId]);

  if (!modules) {
    return (
      <div className="rounded-2xl border bg-slate-50 p-5 text-sm text-slate-600" aria-live="polite">
        {error ?? "Carregando módulos da empresa..."}
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      {error ? (
        <div
          className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"
          role="alert"
        >
          {error}
        </div>
      ) : null}
      {modules.map((organizationModule) => (
        <OrganizationModuleForm
          key={organizationModule.code}
          organizationId={organizationId}
          organizationModule={organizationModule}
          onChanged={(changed) => {
            setError(null);
            setModules(
              (current) =>
                current?.map((item) => (item.code === changed.code ? changed : item)) ?? null,
            );
          }}
          onError={setError}
        />
      ))}
    </div>
  );
}

type OrganizationModuleFormProps = {
  onChanged: (organizationModule: OrganizationModuleView) => void;
  onError: (message: string) => void;
  organizationId: string;
  organizationModule: OrganizationModuleView;
};

function OrganizationModuleForm({
  onChanged,
  onError,
  organizationId,
  organizationModule,
}: OrganizationModuleFormProps) {
  const [saved, setSaved] = useState(false);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
  } = useForm<OrganizationModuleConfigurationForm>({
    defaultValues: formValues(organizationModule),
    resolver: zodResolver(organizationModuleConfigurationSchema),
  });
  const source = useWatch({ control, name: "source" });

  useEffect(() => reset(formValues(organizationModule)), [organizationModule, reset]);

  async function submit(values: OrganizationModuleConfigurationForm) {
    setSaved(false);
    onError("");

    try {
      const body = changeOrganizationModuleBodySchema.parse({
        expectedVersion: organizationModule.assignment?.version ?? 0,
        expiresAt: values.expiresAt ? new Date(values.expiresAt).toISOString() : null,
        reason: values.reason || null,
        source: values.source,
        status: values.status,
      });
      const response = await fetch(
        `/api/v1/platform/organizations/${organizationId}/modules/${encodeURIComponent(organizationModule.code)}`,
        {
          body: JSON.stringify(body),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "PATCH",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        throw new Error(problem.detail);
      }

      const payload = (await response.json()) as { data: unknown };
      onChanged(organizationModuleViewSchema.parse(payload.data));
      setSaved(true);
    } catch (submitError) {
      onError(
        submitError instanceof Error ? submitError.message : "Não foi possível alterar o módulo.",
      );
    }
  }

  return (
    <form
      className="rounded-2xl border bg-white p-5 shadow-[0_5px_20px_rgb(15_23_42/0.03)]"
      onSubmit={handleSubmit(submit)}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-semibold text-slate-950">{organizationModule.name}</h2>
            <span className="rounded-full bg-slate-100 px-2 py-0.5 font-mono text-xs text-slate-600">
              {organizationModule.code}
            </span>
            {organizationModule.isCore ? (
              <span className="rounded-full bg-blue-50 px-2 py-0.5 text-xs font-semibold text-blue-800">
                Núcleo obrigatório
              </span>
            ) : null}
          </div>
          <p className="mt-1 text-sm text-slate-600">{organizationModule.description}</p>
          <p className="mt-2 text-xs text-slate-500">
            Acesso efetivo: <strong>{organizationModule.access.mode}</strong>
            {organizationModule.access.reason ? ` · ${organizationModule.access.reason}` : ""}
          </p>
        </div>
      </div>

      <fieldset
        className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        disabled={organizationModule.isCore}
      >
        <div className="grid gap-1.5">
          <Label htmlFor={`${organizationModule.code}-status`}>Status</Label>
          <select
            className="border-input h-9 rounded-lg border bg-white px-3 text-sm"
            id={`${organizationModule.code}-status`}
            {...register("status")}
          >
            <option value="ENABLED">Habilitado</option>
            <option value="READ_ONLY">Somente leitura</option>
            <option value="DISABLED">Desabilitado</option>
          </select>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor={`${organizationModule.code}-source`}>Origem</Label>
          <select
            className="border-input h-9 rounded-lg border bg-white px-3 text-sm"
            id={`${organizationModule.code}-source`}
            {...register("source")}
          >
            <option value="PLAN">Plano</option>
            <option value="ADD_ON">Módulo adicional</option>
            <option value="TRIAL">Avaliação</option>
            <option value="ADMIN_GRANT">Concessão administrativa</option>
          </select>
        </div>
        <div className="grid gap-1.5 lg:col-span-2">
          <Label htmlFor={`${organizationModule.code}-reason`}>Motivo</Label>
          <Input id={`${organizationModule.code}-reason`} {...register("reason")} />
          {errors.reason ? <p className="text-xs text-red-700">{errors.reason.message}</p> : null}
        </div>
        {source === "ADMIN_GRANT" ? (
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor={`${organizationModule.code}-expires-at`}>Expira em</Label>
            <Input
              id={`${organizationModule.code}-expires-at`}
              type="datetime-local"
              {...register("expiresAt")}
            />
            {errors.expiresAt ? (
              <p className="text-xs text-red-700">{errors.expiresAt.message}</p>
            ) : null}
          </div>
        ) : null}
      </fieldset>

      <div className="mt-5 flex items-center gap-3">
        <Button disabled={isSubmitting || organizationModule.isCore} type="submit">
          {isSubmitting ? "Salvando..." : "Salvar módulo"}
        </Button>
        {saved ? (
          <span className="text-sm font-medium text-emerald-700">Alteração salva.</span>
        ) : null}
      </div>
    </form>
  );
}

function formValues(
  organizationModule: OrganizationModuleView,
): OrganizationModuleConfigurationForm {
  return {
    expiresAt: organizationModule.assignment?.expiresAt?.slice(0, 16) ?? "",
    reason: organizationModule.assignment?.reason ?? "",
    source: organizationModule.assignment?.source ?? "ADD_ON",
    status: organizationModule.assignment?.status ?? "DISABLED",
  };
}
