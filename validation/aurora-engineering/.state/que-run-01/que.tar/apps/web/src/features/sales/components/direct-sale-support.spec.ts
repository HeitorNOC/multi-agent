import { afterEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";

import { fetchData, saleFormSchema } from "./direct-sale-data";

afterEach(() => vi.unstubAllGlobals());

describe("direct sale support", () => {
  it("parses valid form data and rejects missing required selections", () => {
    const valid = {
      branchId: "branch-1",
      customerId: "",
      discountAmount: "0",
      dueDate: "2026-08-12",
      items: [{ catalogEntry: "PRODUCT:product-1", quantity: "1" }],
      payments: [],
      revenueCategoryId: "category-1",
      salesOrderId: null,
      salesOrderUpdatedAt: null,
    };
    expect(saleFormSchema.parse(valid)).toEqual(valid);
    expect(() => saleFormSchema.parse({ ...valid, branchId: "" })).toThrow();
  });

  it("parses API data and forwards the abort signal", async () => {
    const signal = new AbortController().signal;
    const fetchMock = vi.fn().mockResolvedValue(Response.json({ data: ["item"] }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchData("/catalog", z.array(z.string()), signal)).resolves.toEqual(["item"]);
    expect(fetchMock).toHaveBeenCalledWith("/catalog", { signal });
  });

  it("uses the API problem or fallback message on failure", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(Response.json({ detail: "Catálogo indisponível." }, { status: 503 }))
      .mockResolvedValueOnce(Response.json({}, { status: 500 }));
    vi.stubGlobal("fetch", fetchMock);
    const signal = new AbortController().signal;

    await expect(fetchData("/catalog", z.unknown(), signal)).rejects.toThrow(
      "Catálogo indisponível.",
    );
    await expect(fetchData("/catalog", z.unknown(), signal)).rejects.toThrow(
      "Não foi possível carregar os dados.",
    );
  });
});
