import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { FinancialCategoryConfigurations } from "@/features/financial-categories/components/financial-category-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Categorias financeiras | Gestor",
};

type FinancialCategoriesPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function FinancialCategoriesPage({ params }: FinancialCategoriesPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao checklist
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Configuração financeira
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Categorias financeiras
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Monte uma estrutura curta para classificar receitas e saídas. Essas categorias serão
          usadas nas contas e relatórios, sem criar qualquer lançamento por conta própria.
        </p>
      </header>

      <ModuleGate moduleCode="financial" organizationId={organizationId}>
        <FinancialCategoryConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
