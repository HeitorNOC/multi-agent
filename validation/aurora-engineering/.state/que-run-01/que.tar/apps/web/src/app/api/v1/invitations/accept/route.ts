import { acceptOrganizationInvitationBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

export async function POST(request: Request) {
  return handleApiRequest(request, async (api) => {
    const body = acceptOrganizationInvitationBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const accepted = await services.acceptOrganizationInvitation.execute(body, {
      ...api,
      userId: identity.userId,
    });
    return Response.json({ data: accepted });
  });
}
