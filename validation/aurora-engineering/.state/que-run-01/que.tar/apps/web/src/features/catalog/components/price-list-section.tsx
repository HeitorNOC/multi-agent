"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  createPriceListBodySchema,
  priceListListSchema,
  priceListViewSchema,
  type BranchView,
  type CreatePriceListBody,
  type PriceListView,
  type ProblemDetails,
  type ProductView,
  type ServiceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";

import { CatalogSection, ErrorText, Field } from "./catalog-layout";
import { active, patch, post, setProblem } from "./catalog-helpers";

export function PriceListSection({
  organizationId,
  products,
  services,
  setFeedback,
}: {
  organizationId: string;
  products: readonly ProductView[];
  services: readonly ServiceView[];
  setFeedback: (message: string | null) => void;
}) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [priceLists, setPriceLists] = useState<readonly PriceListView[]>([]);
  const [selectedItem, setSelectedItem] = useState("");
  const defaults: CreatePriceListBody = {
    branchId: "",
    endsAt: null,
    items: [],
    name: "",
    startsAt: null,
  };
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreatePriceListBody>({
    defaultValues: defaults,
    resolver: zodResolver(createPriceListBodySchema),
  });
  const { append, fields, remove } = useFieldArray({ control, name: "items" });
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      const responses = await Promise.all([
        fetch(`/api/v1/organizations/${organizationId}/branches`, {
          signal: controller.signal,
        }),
        fetch(`/api/v1/organizations/${organizationId}/price-lists`, {
          signal: controller.signal,
        }),
      ]);
      const failed = responses.find((response) => !response.ok);
      if (failed) {
        if (!controller.signal.aborted)
          setFeedback(((await failed.json()) as ProblemDetails).detail);
        return;
      }
      const payloads = await Promise.all(
        responses.map((response) => response.json() as Promise<{ data: unknown }>),
      );
      setBranches(branchListSchema.parse(payloads[0]?.data));
      setPriceLists(priceListListSchema.parse(payloads[1]?.data));
    }
    void load();
    return () => controller.abort();
  }, [organizationId, setFeedback]);
  const submit = handleSubmit(async (values) => {
    const response = await post(`/api/v1/organizations/${organizationId}/price-lists`, values);
    if (!response.ok) return setProblem(response, setError);
    const priceList = priceListViewSchema.parse(
      ((await response.json()) as { data: unknown }).data,
    );
    setPriceLists((current) => [priceList, ...current]);
    reset(defaults);
    setSelectedItem("");
    setFeedback("Tabela de preços cadastrada.");
  });
  function addItem() {
    const [kind, id] = selectedItem.split(":");
    if (!id) return;
    append({
      price: "0",
      productId: kind === "product" ? id : null,
      serviceId: kind === "service" ? id : null,
    });
    setSelectedItem("");
  }
  async function togglePriceList(item: PriceListView) {
    const response = await patch(`/api/v1/organizations/${organizationId}/price-lists/${item.id}`, {
      expectedUpdatedAt: item.updatedAt,
      status: item.status === "ACTIVE" ? "INACTIVE" : "ACTIVE",
    });
    if (!response.ok) return setFeedback(((await response.json()) as ProblemDetails).detail);
    const updated = priceListViewSchema.parse(((await response.json()) as { data: unknown }).data);
    setPriceLists((current) =>
      current.map((priceList) => (priceList.id === updated.id ? updated : priceList)),
    );
    setFeedback(updated.status === "ACTIVE" ? "Tabela ativada." : "Tabela inativada.");
  }
  const choices = [
    ...products.filter(active).map((item) => ({ key: `product:${item.id}`, name: item.name })),
    ...services.filter(active).map((item) => ({ key: `service:${item.id}`, name: item.name })),
  ].filter(
    (choice) =>
      !fields.some(
        (field) =>
          choice.key ===
          (field.productId ? `product:${field.productId}` : `service:${field.serviceId}`),
      ),
  );
  return (
    <CatalogSection
      title="Tabelas de preço por filial"
      description="A tabela ativa da filial prevalece; itens ausentes continuam usando o preço padrão. Vigências não podem se sobrepor."
    >
      <form className="grid gap-4" onSubmit={submit}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field error={errors.name?.message} id="price-list-name" label="Nome">
            <Input id="price-list-name" {...register("name")} />
          </Field>
          <Field error={errors.branchId?.message} id="price-list-branch" label="Filial">
            <select
              className="h-10 rounded-xl border bg-white px-3 text-sm"
              id="price-list-branch"
              {...register("branchId")}
            >
              <option value="">Selecione</option>
              {branches.filter(active).map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </Field>
          <Field error={errors.startsAt?.message} id="price-list-start" label="Início opcional">
            <Input
              id="price-list-start"
              type="datetime-local"
              {...register("startsAt", {
                setValueAs: (value) => (value ? new Date(value).toISOString() : null),
              })}
            />
          </Field>
          <Field error={errors.endsAt?.message} id="price-list-end" label="Fim opcional">
            <Input
              id="price-list-end"
              type="datetime-local"
              {...register("endsAt", {
                setValueAs: (value) => (value ? new Date(value).toISOString() : null),
              })}
            />
          </Field>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <select
            className="h-10 grow rounded-xl border bg-white px-3 text-sm"
            onChange={(event) => setSelectedItem(event.target.value)}
            value={selectedItem}
          >
            <option value="">Adicionar produto ou serviço</option>
            {choices.map((choice) => (
              <option key={choice.key} value={choice.key}>
                {choice.name}
              </option>
            ))}
          </select>
          <Button onClick={addItem} type="button" variant="outline">
            Adicionar
          </Button>
        </div>
        <div className="grid gap-2">
          {fields.map((field, index) => {
            const item = field.productId
              ? products.find(({ id }) => id === field.productId)
              : services.find(({ id }) => id === field.serviceId);
            return (
              <div className="flex items-end gap-3 rounded-xl border p-3" key={field.id}>
                <input type="hidden" {...register(`items.${index}.productId`)} />
                <input type="hidden" {...register(`items.${index}.serviceId`)} />
                <Field
                  error={errors.items?.[index]?.price?.message}
                  id={`price-list-item-${index}`}
                  label={item?.name ?? "Item"}
                >
                  <Input
                    id={`price-list-item-${index}`}
                    inputMode="decimal"
                    {...register(`items.${index}.price`)}
                  />
                </Field>
                <Button onClick={() => remove(index)} type="button" variant="outline">
                  Remover
                </Button>
              </div>
            );
          })}
          {errors.items?.root?.message ? <ErrorText>{errors.items.root.message}</ErrorText> : null}
        </div>
        <div>
          <Button disabled={isSubmitting} type="submit">
            Cadastrar tabela
          </Button>
          {errors.root ? <ErrorText>{errors.root.message}</ErrorText> : null}
        </div>
      </form>
      <div className="mt-5 grid gap-2">
        {priceLists.map((item) => (
          <div
            className="flex items-center justify-between rounded-xl border px-4 py-3"
            key={item.id}
          >
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-xs text-slate-500">
                {item.branchName} · {item.items.length} preços · {priceListPeriod(item)}
              </p>
            </div>
            <Button onClick={() => void togglePriceList(item)} type="button" variant="outline">
              {item.status === "ACTIVE" ? "Inativar" : "Ativar"}
            </Button>
          </div>
        ))}
      </div>
    </CatalogSection>
  );
}

function priceListPeriod(item: PriceListView) {
  const starts = item.startsAt ? new Date(item.startsAt).toLocaleString("pt-BR") : "sem início";
  const ends = item.endsAt ? new Date(item.endsAt).toLocaleString("pt-BR") : "sem fim";
  return `${starts} até ${ends}`;
}
