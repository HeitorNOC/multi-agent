import { organizationParamsSchema, removeFoodServiceOrderItemBodySchema } from "@gestor/contracts";
import { z } from "zod";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

const parametersSchema = organizationParamsSchema.extend({ itemId: z.uuid(), orderId: z.uuid() });

export async function DELETE(
  request: Request,
  route: { params: Promise<{ organizationId: string; orderId: string; itemId: string }> },
): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = parametersSchema.parse(await route.params);
    const body = removeFoodServiceOrderItemBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.removeFoodServiceOrderItem.execute({ ...body, ...params }, actor),
    });
  });
}
