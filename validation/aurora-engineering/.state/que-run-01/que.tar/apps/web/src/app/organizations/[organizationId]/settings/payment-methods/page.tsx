import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { PaymentMethodConfigurations } from "@/features/payment-methods/components/payment-method-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Formas de pagamento | Gestor",
};

type PaymentMethodsPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function PaymentMethodsPage({ params }: PaymentMethodsPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao checklist
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Configuração financeira
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Formas de pagamento
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Escolha as opções usadas pela empresa em vendas, compras e despesas. Recebimentos e
          pagamentos reais serão registrados somente nas operações financeiras correspondentes.
        </p>
      </header>

      <ModuleGate moduleCode="financial" organizationId={organizationId}>
        <PaymentMethodConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
