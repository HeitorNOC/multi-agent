import { describe, expect, it } from "vitest";

import { GET } from "./route";

describe("GET /api/v1/health/live", () => {
  it("reports process liveness without allowing caches", async () => {
    const response = await GET();

    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    await expect(response.json()).resolves.toEqual({ service: "web", status: "ok" });
  });
});
