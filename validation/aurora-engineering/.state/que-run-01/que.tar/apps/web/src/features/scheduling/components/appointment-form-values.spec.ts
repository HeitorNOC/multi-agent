import { describe, expect, it } from "vitest";

import { isoToLocalDateTime, localDateTimeToIso } from "./appointment-form-values";

describe("appointment form date values", () => {
  it("converts a stored ISO instant into a datetime-local value without changing its instant", () => {
    const startsAt = "2026-10-19T12:30:00.000Z";

    const formValue = isoToLocalDateTime(startsAt);

    expect(formValue).toMatch(/^2026-10-19T\d{2}:30$/);
    expect(localDateTimeToIso(formValue)).toBe(startsAt);
  });
});
