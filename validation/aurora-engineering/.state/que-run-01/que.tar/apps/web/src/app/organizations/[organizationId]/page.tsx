import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";

import { Dashboard } from "@/features/dashboard/components/dashboard";
import { OrganizationNavigation } from "@/features/modules/components/organization-navigation";
import { OnboardingChecklist } from "@/features/onboarding/components/onboarding-checklist";
import { CatalogFilesButton } from "@/features/catalog/components/catalog-files-button";

export const metadata: Metadata = {
  title: "Empresa criada | Gestor",
};

type OrganizationPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function OrganizationPage({ params }: OrganizationPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto grid min-h-screen w-full max-w-6xl gap-8 px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8 rounded-3xl border bg-white p-7 shadow-[0_12px_40px_rgb(15_23_42/0.06)] sm:p-9">
        <div className="flex items-start gap-4">
          <span
            aria-hidden="true"
            className="bg-brand-100 text-brand-700 grid size-12 shrink-0 place-items-center rounded-2xl text-xl font-bold"
          >
            ✓
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-brand-600 text-xs font-bold tracking-[0.16em] uppercase">
              Configuração salva
            </p>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950 sm:text-3xl">
              Prepare sua empresa para operar
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
              Empresa, matriz, acesso de proprietário e avaliação foram criados juntos. Agora avance
              no seu ritmo e retome qualquer etapa depois.
            </p>
          </div>
          <CatalogFilesButton
            allowImage={false}
            itemId={organizationId}
            organizationId={organizationId}
            segment="organization"
          />
        </div>

        <div className="mt-6">
          <OrganizationNavigation organizationId={organizationId} />
        </div>
      </header>

      <Dashboard organizationId={organizationId} />
      <OnboardingChecklist organizationId={organizationId} />
    </main>
  );
}
