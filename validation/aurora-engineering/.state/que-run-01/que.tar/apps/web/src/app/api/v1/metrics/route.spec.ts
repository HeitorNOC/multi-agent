import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { getServerEnv, increment, loggerError, observe, renderPrometheus } = vi.hoisted(() => ({
  getServerEnv: vi.fn(),
  increment: vi.fn(),
  loggerError: vi.fn(),
  observe: vi.fn(),
  renderPrometheus: vi.fn(),
}));

vi.mock("@gestor/config", () => ({ getServerEnv }));
vi.mock("@gestor/observability", () => ({
  getLogger: () => ({ error: loggerError }),
  metrics: { increment, observe, renderPrometheus },
}));

import { GET } from "./route";

describe("GET /api/v1/metrics", () => {
  beforeEach(() => {
    getServerEnv.mockReset();
    increment.mockReset();
    loggerError.mockReset();
    observe.mockReset();
    renderPrometheus.mockReset();
    getServerEnv.mockReturnValue({ METRICS_BEARER_TOKEN: "metrics-secret" });
    renderPrometheus.mockReturnValue("gestor_requests_total 1\n");
  });

  it("returns Prometheus text to an authenticated monitor", async () => {
    const response = await GET(
      new Request("http://localhost/api/v1/metrics", {
        headers: { authorization: "Bearer metrics-secret" },
      }),
    );

    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    expect(response.headers.get("content-type")).toContain("text/plain");
    await expect(response.text()).resolves.toBe("gestor_requests_total 1\n");
  });

  it("does not expose metrics with an invalid token", async () => {
    const response = await GET(new Request("http://localhost/api/v1/metrics"));

    expect(response.status).toBe(401);
    expect(renderPrometheus).not.toHaveBeenCalled();
    await expect(response.json()).resolves.toMatchObject({
      code: "METRICS_AUTHENTICATION_REQUIRED",
      status: 401,
    });
  });
});
