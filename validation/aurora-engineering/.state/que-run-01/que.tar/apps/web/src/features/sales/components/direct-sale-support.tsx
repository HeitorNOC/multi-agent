import { Label } from "@gestor/ui/components/label";

export function SelectField({
  children,
  error,
  label,
}: {
  children: React.ReactNode;
  error?: string | undefined;
  label: string;
}) {
  return (
    <Label className="grid gap-1">
      {label}
      {children}
      {error ? <span className="text-xs text-red-700">{error}</span> : null}
    </Label>
  );
}
