import { timingSafeEqual } from "node:crypto";

import { AuthenticationError } from "@gestor/kernel";

export function requireMetricsAccess(request: Request, expectedToken: string | undefined): void {
  const authorization = request.headers.get("authorization");
  const suppliedToken = authorization?.startsWith("Bearer ")
    ? authorization.slice("Bearer ".length)
    : "";

  if (!expectedToken || !safeEqual(suppliedToken, expectedToken)) {
    throw new AuthenticationError(
      "METRICS_AUTHENTICATION_REQUIRED",
      "Autenticação de métricas inválida.",
    );
  }
}

function safeEqual(left: string, right: string): boolean {
  const leftBytes = Buffer.from(left);
  const rightBytes = Buffer.from(right);
  return leftBytes.length === rightBytes.length && timingSafeEqual(leftBytes, rightBytes);
}
