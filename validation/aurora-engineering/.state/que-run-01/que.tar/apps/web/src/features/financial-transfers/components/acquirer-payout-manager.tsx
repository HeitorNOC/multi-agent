"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  acquirerPayoutListSchema,
  acquirerPayoutViewSchema,
  bankAccountListSchema,
  createAcquirerPayoutBodySchema,
  financialAccountListSchema,
  type AcquirerPayoutView,
  type BankAccountView,
  type CreateAcquirerPayoutBody,
  type FinancialAccountView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";

import { formatBrl, formatDateTime } from "./financial-transfer-format";

export function AcquirerPayoutManager({ organizationId }: { organizationId: string }) {
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[]>([]);
  const [bankAccounts, setBankAccounts] = useState<readonly BankAccountView[]>([]);
  const [payouts, setPayouts] = useState<readonly AcquirerPayoutView[]>([]);
  const [feedback, setFeedback] = useState<string | null>(null);
  const today = useMemo(() => new Date().toLocaleDateString("en-CA"), []);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateAcquirerPayoutBody>({
    defaultValues: {
      expectedDate: today,
      externalId: "",
      feeAmount: "0",
      grossAmount: "",
      provider: "",
      sourceFinancialAccountId: "",
      targetBankAccountId: "",
    },
    resolver: zodResolver(createAcquirerPayoutBodySchema),
  });
  const acquirerAccounts = accounts.filter(
    (account) => account.status === "ACTIVE" && account.type === "ACQUIRER",
  );

  useEffect(() => {
    const controller = new AbortController();
    void Promise.all([
      fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
        signal: controller.signal,
      }),
      fetch(`/api/v1/organizations/${organizationId}/bank-accounts`, { signal: controller.signal }),
      fetch(`/api/v1/organizations/${organizationId}/acquirer-payouts`, {
        signal: controller.signal,
      }),
    ])
      .then(async ([accountsResponse, banksResponse, payoutsResponse]) => {
        const failed = [accountsResponse, banksResponse, payoutsResponse].find(
          (response) => !response.ok,
        );
        if (failed) throw new Error(((await failed.json()) as ProblemDetails).detail);
        const accountPayload = (await accountsResponse.json()) as { data: unknown };
        const bankPayload = (await banksResponse.json()) as { data: unknown };
        const payoutPayload = (await payoutsResponse.json()) as { data: unknown };
        setAccounts(financialAccountListSchema.parse(accountPayload.data));
        setBankAccounts(bankAccountListSchema.parse(bankPayload.data));
        setPayouts(acquirerPayoutListSchema.parse(payoutPayload.data));
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) {
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar os repasses.",
          );
        }
      });
    return () => controller.abort();
  }, [organizationId]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);
    const response = await fetch(`/api/v1/organizations/${organizationId}/acquirer-payouts`, {
      body: JSON.stringify(values),
      headers: { "content-type": "application/json" },
      method: "POST",
    });
    if (!response.ok) {
      const problem = (await response.json()) as ProblemDetails;
      setError("root", { message: problem.detail, type: problem.code });
      return;
    }
    const payload = (await response.json()) as { data: unknown };
    const payout = acquirerPayoutViewSchema.parse(payload.data);
    setPayouts((current) => [payout, ...current]);
    setFeedback("Repasse liquidado: o bruto saiu da adquirente e o líquido entrou no banco.");
    reset({ ...values, externalId: "", feeAmount: "0", grossAmount: "" });
  });

  return (
    <section className="mt-10 rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7">
      <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Adquirentes</p>
      <h2 className="mt-2 text-xl font-semibold text-slate-950">Liquidar repasse</h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        Registre o bruto recebido, a taxa descontada e a conta bancária que recebeu o líquido.
      </p>
      <form className="mt-6 grid gap-4 md:grid-cols-2" noValidate onSubmit={submit}>
        <Field label="Provedor" error={errors.provider?.message}>
          <Input placeholder="Ex.: Stone" {...register("provider")} />
        </Field>
        <Field label="Identificador do repasse" error={errors.externalId?.message}>
          <Input placeholder="Código informado pela adquirente" {...register("externalId")} />
        </Field>
        <Field label="Conta da adquirente" error={errors.sourceFinancialAccountId?.message}>
          <select
            className="h-11 rounded-xl border bg-white px-3 text-sm"
            {...register("sourceFinancialAccountId")}
          >
            <option value="">Selecione</option>
            {acquirerAccounts.map((account) => (
              <option key={account.id} value={account.id}>
                {account.name} — {formatBrl(account.currentBalance)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Conta bancária de destino" error={errors.targetBankAccountId?.message}>
          <select
            className="h-11 rounded-xl border bg-white px-3 text-sm"
            {...register("targetBankAccountId")}
          >
            <option value="">Selecione</option>
            {bankAccounts.map((account) => (
              <option key={account.id} value={account.id}>
                {account.institutionName} — {account.accountMask}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Valor bruto" error={errors.grossAmount?.message}>
          <Input inputMode="decimal" placeholder="0,00" {...register("grossAmount")} />
        </Field>
        <Field label="Taxa descontada" error={errors.feeAmount?.message}>
          <Input inputMode="decimal" placeholder="0,00" {...register("feeAmount")} />
        </Field>
        <Field label="Data prevista" error={errors.expectedDate?.message}>
          <Input type="date" {...register("expectedDate")} />
        </Field>
        <div className="flex items-end">
          <Button
            disabled={isSubmitting || !acquirerAccounts.length || !bankAccounts.length}
            type="submit"
          >
            {isSubmitting ? "Liquidando..." : "Confirmar repasse"}
          </Button>
        </div>
        {errors.root?.message ? (
          <p className="text-sm text-red-700 md:col-span-2" role="alert">
            {errors.root.message}
          </p>
        ) : null}
      </form>
      {feedback ? (
        <p className="mt-4 rounded-xl border px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <div className="mt-8 grid gap-3">
        <h3 className="text-sm font-semibold text-slate-950">Repasses liquidados</h3>
        {payouts.length ? (
          payouts.map((payout) => (
            <div className="rounded-2xl border p-4" key={payout.id}>
              <div className="flex flex-wrap justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">
                    {payout.provider} · {payout.externalId}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">{formatDateTime(payout.settledAt)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">Líquido {formatBrl(payout.netAmount)}</p>
                  <p className="mt-1 text-xs text-slate-500">
                    Bruto {formatBrl(payout.grossAmount)} · Taxa {formatBrl(payout.feeAmount)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-sm text-slate-500">Nenhum repasse liquidado.</p>
        )}
      </div>
    </section>
  );
}

function Field({
  children,
  error,
  label,
}: {
  children: React.ReactNode;
  error: string | undefined;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label>{label}</Label>
      {children}
      {error ? <p className="text-sm text-red-700">{error}</p> : null}
    </div>
  );
}
