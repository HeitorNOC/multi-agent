import type { ReportJobView } from "@gestor/contracts";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { ReportHistory } from "./report-history";

describe("ReportHistory", () => {
  it("renders persisted protocols with their derived status", () => {
    const report = {
      completedAt: null,
      createdAt: "2026-08-14T03:00:00.000Z",
      expiresAt: null,
      failureCode: null,
      fileAvailable: false,
      filters: {},
      format: "CSV",
      id: "30000000-0000-4000-8000-000000000002",
      progress: 0,
      recipientUserId: "30000000-0000-4000-8000-000000000003",
      reportType: "SALES",
      requestedByUserId: "30000000-0000-4000-8000-000000000003",
      status: "PENDING",
    } satisfies ReportJobView;

    const markup = renderToStaticMarkup(
      <ReportHistory onSelect={() => undefined} reports={[report]} />,
    );
    expect(markup).toContain("Na fila");
    expect(markup).toContain("Acompanhar");
  });
});
