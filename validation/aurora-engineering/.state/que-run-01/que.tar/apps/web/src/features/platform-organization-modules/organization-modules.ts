import { z } from "zod";

export const organizationModuleConfigurationSchema = z
  .object({
    expiresAt: z.string(),
    reason: z.string().trim().max(240, "O motivo deve possuir no máximo 240 caracteres."),
    source: z.enum(["PLAN", "ADD_ON", "TRIAL", "ADMIN_GRANT"]),
    status: z.enum(["ENABLED", "READ_ONLY", "DISABLED"]),
  })
  .superRefine((value, context) => {
    if (value.status !== "ENABLED" && value.reason.length < 3) {
      context.addIssue({
        code: "custom",
        message: "Informe um motivo com pelo menos 3 caracteres.",
        path: ["reason"],
      });
    }

    if (value.source === "ADMIN_GRANT" && value.reason.length < 3) {
      context.addIssue({
        code: "custom",
        message: "A concessão administrativa exige justificativa.",
        path: ["reason"],
      });
    }

    if (value.source === "ADMIN_GRANT" && !value.expiresAt) {
      context.addIssue({
        code: "custom",
        message: "A concessão administrativa exige expiração.",
        path: ["expiresAt"],
      });
    }
  });

export type OrganizationModuleConfigurationForm = z.infer<
  typeof organizationModuleConfigurationSchema
>;
