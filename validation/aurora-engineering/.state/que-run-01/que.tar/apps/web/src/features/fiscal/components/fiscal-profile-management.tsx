"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  fiscalProfileListSchema,
  fiscalProfileViewSchema,
  upsertFiscalProfileBodySchema,
  type BranchView,
  type FiscalProfileView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useForm, useWatch } from "react-hook-form";
import type { z } from "zod";

type FormValues = z.infer<typeof upsertFiscalProfileBodySchema>;

export function FiscalProfileManagement({ organizationId }: { organizationId: string }) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [profiles, setProfiles] = useState<readonly FiscalProfileView[]>([]);
  const [branchId, setBranchId] = useState("");
  const [feedback, setFeedback] = useState("Carregando configuração fiscal...");
  const profile = useMemo(
    () => profiles.find((item) => item.branchId === branchId) ?? null,
    [branchId, profiles],
  );
  const form = useForm<FormValues>({
    defaultValues: defaults(),
    resolver: zodResolver(upsertFiscalProfileBodySchema),
  });
  const selectedProvider = useWatch({ control: form.control, name: "provider" });

  useEffect(() => {
    const controller = new AbortController();
    const base = `/api/v1/organizations/${organizationId}`;
    void Promise.all([
      fetch(`${base}/branches`, { signal: controller.signal }).then(read),
      fetch(`${base}/fiscal-profiles`, { signal: controller.signal }).then(read),
    ])
      .then(([branchPayload, profilePayload]) => {
        const activeBranches = branchListSchema
          .parse(dataFrom(branchPayload))
          .filter(({ status }) => status === "ACTIVE");
        const loadedProfiles = fiscalProfileListSchema.parse(dataFrom(profilePayload));
        setBranches(activeBranches);
        setProfiles(loadedProfiles);
        const first = activeBranches[0];
        if (first) setBranchId(first.id);
        setFeedback(first ? "" : "Cadastre uma filial ativa antes de configurar o fiscal.");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Falha ao carregar o fiscal.");
      });
    return () => controller.abort();
  }, [organizationId]);

  useEffect(() => {
    form.reset(profile ? fromProfile(profile) : defaults());
  }, [form, profile]);

  async function save(values: FormValues) {
    if (!branchId) return;
    setFeedback("");
    try {
      const payload = await read(
        await fetch(`/api/v1/organizations/${organizationId}/branches/${branchId}/fiscal-profile`, {
          body: JSON.stringify({ ...values, expectedUpdatedAt: profile?.updatedAt ?? null }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "PUT",
        }),
      );
      const saved = fiscalProfileViewSchema.parse(dataFrom(payload));
      setProfiles((current) => [...current.filter(({ branchId: id }) => id !== branchId), saved]);
      setFeedback(saved.status === "ACTIVE" ? "Perfil fiscal ativo." : "Rascunho fiscal salvo.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Falha ao salvar o perfil fiscal.");
    }
  }

  return (
    <section className="grid gap-6">
      <div className="rounded-2xl border bg-white p-5">
        <Label htmlFor="fiscal-branch">Filial</Label>
        <select
          className="mt-2 w-full rounded-md border px-3 py-2 text-sm sm:max-w-sm"
          id="fiscal-branch"
          onChange={(event) => setBranchId(event.target.value)}
          value={branchId}
        >
          {branches.map((branch) => (
            <option key={branch.id} value={branch.id}>
              {branch.name}
            </option>
          ))}
        </select>
      </div>
      <form
        className="grid gap-5 rounded-2xl border bg-white p-5"
        onSubmit={form.handleSubmit(save)}
      >
        <div className="grid gap-4 md:grid-cols-2">
          <Field error={form.formState.errors.issuerData?.legalName?.message} label="Razão social">
            <Input {...form.register("issuerData.legalName")} />
          </Field>
          <Field
            error={form.formState.errors.issuerData?.taxId?.message}
            label="CNPJ (somente números)"
          >
            <Input inputMode="numeric" {...form.register("issuerData.taxId")} />
          </Field>
          <Field label="Inscrição estadual">
            <Input {...form.register("issuerData.stateRegistration", { setValueAs: nullable })} />
          </Field>
          <Field label="Inscrição municipal">
            <Input
              {...form.register("issuerData.municipalRegistration", { setValueAs: nullable })}
            />
          </Field>
          <Field label="Regime tributário">
            <Input {...form.register("taxRegime")} />
          </Field>
          <Field label="Provedor fiscal">
            <select className="rounded-md border px-3 py-2 text-sm" {...form.register("provider")}>
              <option value="SANDBOX">Ambiente de testes</option>
              <option value="NFSE_NACIONAL">Portal Nacional da NFS-e</option>
              <option value="HTTP">Outro integrador homologado</option>
            </select>
          </Field>
          <Field label="Referência segura da credencial">
            <Input
              autoComplete="off"
              placeholder={
                profile?.credentialConfigured ? "Credencial já configurada" : "Opcional no sandbox"
              }
              {...form.register("credentialReference", { setValueAs: nullable })}
            />
          </Field>
          <Field label="CEP">
            <Input inputMode="numeric" {...form.register("issuerData.postalCode")} />
          </Field>
          <Field label="Logradouro">
            <Input {...form.register("issuerData.street")} />
          </Field>
          <Field label="Número">
            <Input {...form.register("issuerData.number")} />
          </Field>
          <Field label="Bairro">
            <Input {...form.register("issuerData.district")} />
          </Field>
          <Field label="Cidade">
            <Input {...form.register("issuerData.city")} />
          </Field>
          <Field label="Código IBGE do município">
            <Input inputMode="numeric" {...form.register("issuerData.cityCode")} />
          </Field>
          <Field label="UF">
            <Input
              maxLength={2}
              {...form.register("issuerData.state", {
                setValueAs: (value) => String(value).toUpperCase(),
              })}
            />
          </Field>
          {selectedProvider === "NFSE_NACIONAL" ? (
            <>
              <Field
                error={form.formState.errors.issuerData?.nationalNfse?.dpsSeries?.message}
                label="Série da DPS"
              >
                <Input
                  inputMode="numeric"
                  maxLength={5}
                  {...form.register("issuerData.nationalNfse.dpsSeries")}
                />
              </Field>
              <Field label="Situação no Simples Nacional">
                <select
                  className="rounded-md border px-3 py-2 text-sm"
                  {...form.register("issuerData.nationalNfse.simpleNationalOption")}
                >
                  <option value="1">Não optante</option>
                  <option value="2">MEI</option>
                  <option value="3">ME ou EPP</option>
                </select>
              </Field>
              <Field label="Apuração do Simples Nacional">
                <select
                  className="rounded-md border px-3 py-2 text-sm"
                  {...form.register("issuerData.nationalNfse.simpleNationalCalculationRegime", {
                    setValueAs: nullable,
                  })}
                >
                  <option value="">Não se aplica</option>
                  <option value="1">Tributos federais e ISS pelo Simples</option>
                  <option value="2">Federais pelo Simples e ISS por fora</option>
                  <option value="3">Tributos por fora do Simples</option>
                </select>
              </Field>
              <Field label="Regime especial municipal">
                <select
                  className="rounded-md border px-3 py-2 text-sm"
                  {...form.register("issuerData.nationalNfse.specialTaxRegime")}
                >
                  <option value="0">Nenhum</option>
                  <option value="1">Ato cooperado</option>
                  <option value="2">Estimativa</option>
                  <option value="3">Microempresa municipal</option>
                  <option value="4">Notário ou registrador</option>
                  <option value="5">Profissional autônomo</option>
                  <option value="6">Sociedade de profissionais</option>
                  <option value="9">Outros</option>
                </select>
              </Field>
            </>
          ) : null}
        </div>
        <fieldset className="grid gap-2">
          <legend className="text-sm font-medium">Documentos habilitados</legend>
          <div className="flex flex-wrap gap-4">
            {(["NFE", "NFCE", "NFSE"] as const).map((type) => (
              <label className="flex items-center gap-2 text-sm" key={type}>
                <input type="checkbox" value={type} {...form.register("enabledDocumentTypes")} />{" "}
                {type}
              </label>
            ))}
          </div>
        </fieldset>
        {profile?.validationErrors.length ? (
          <div className="rounded-lg bg-amber-50 p-4 text-sm">
            <p className="font-semibold">Pendências para ativação</p>
            <ul className="mt-2 list-disc pl-5">
              {profile.validationErrors.map((error) => (
                <li key={error.code}>{error.message}</li>
              ))}
            </ul>
          </div>
        ) : null}
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" {...form.register("activate")} /> Ativar após validar
        </label>
        <Button disabled={!branchId || form.formState.isSubmitting} type="submit">
          {form.formState.isSubmitting ? "Salvando..." : "Salvar perfil fiscal"}
        </Button>
      </form>
      {feedback ? (
        <p className="text-sm" role="status">
          {feedback}
        </p>
      ) : null}
    </section>
  );
}

function defaults(): FormValues {
  return {
    activate: false,
    credentialReference: null,
    enabledDocumentTypes: ["NFCE"],
    expectedUpdatedAt: null,
    issuerData: {
      city: "",
      cityCode: "",
      district: "",
      legalName: "",
      municipalRegistration: null,
      nationalNfse: {
        dpsSeries: "1",
        simpleNationalCalculationRegime: null,
        simpleNationalOption: "1",
        specialTaxRegime: "0",
      },
      number: "",
      postalCode: "",
      state: "",
      stateRegistration: null,
      street: "",
      taxId: "",
    },
    provider: "SANDBOX",
    taxRegime: "",
  };
}
function fromProfile(profile: FiscalProfileView): FormValues {
  return {
    activate: profile.status === "ACTIVE",
    credentialReference: null,
    enabledDocumentTypes: [...profile.enabledDocumentTypes],
    expectedUpdatedAt: profile.updatedAt,
    issuerData: {
      ...profile.issuerData,
      nationalNfse: profile.issuerData.nationalNfse ?? {
        dpsSeries: "1",
        simpleNationalCalculationRegime: null,
        simpleNationalOption: "1",
        specialTaxRegime: "0",
      },
    },
    provider: profile.provider,
    taxRegime: profile.taxRegime,
  };
}
function nullable(value: unknown) {
  return String(value ?? "").trim() || null;
}
function dataFrom(payload: unknown) {
  return (payload as { data?: unknown }).data;
}
async function read(response: Response): Promise<unknown> {
  const payload = (await response.json()) as Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "A operação fiscal falhou.");
  return payload;
}
function Field({
  children,
  error,
  label,
}: {
  children: ReactNode;
  error?: string | undefined;
  label: string;
}) {
  return (
    <label className="grid gap-1 text-sm">
      <span className="font-medium">{label}</span>
      {children}
      {error ? <span className="text-red-700">{error}</span> : null}
    </label>
  );
}
