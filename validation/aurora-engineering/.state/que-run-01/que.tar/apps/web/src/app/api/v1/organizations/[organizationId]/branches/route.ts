import { createBranchBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
  }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const branches = await services.listBranches.execute(params, actor);

    return Response.json({ data: branches });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createBranchBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const branch = await services.createBranch.execute(
      {
        ...(body.document ? { document: body.document } : {}),
        idempotencyKey: requireIdempotencyKey(request),
        name: body.name,
        organizationId: params.organizationId,
      },
      actor,
    );

    return Response.json(
      { data: branch },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/branches/${branch.id}`,
        },
        status: 201,
      },
    );
  });
}
