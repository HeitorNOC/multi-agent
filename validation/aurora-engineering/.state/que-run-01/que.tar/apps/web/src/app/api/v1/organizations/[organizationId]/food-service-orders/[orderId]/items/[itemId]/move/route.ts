import { moveFoodServiceOrderItemBodySchema, organizationParamsSchema } from "@gestor/contracts";
import { z } from "zod";
import { services } from "@/lib/server/container";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
const paramsSchema = organizationParamsSchema.extend({ itemId: z.uuid(), orderId: z.uuid() });
export async function POST(
  request: Request,
  context: { params: Promise<{ organizationId: string; orderId: string; itemId: string }> },
) {
  return handleApiRequest(request, async (api) => {
    const params = paramsSchema.parse(await context.params);
    const body = moveFoodServiceOrderItemBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const data = await services.moveFoodServiceOrderItem.execute(
      {
        ...params,
        ...(body.quantity ? { quantity: body.quantity } : {}),
        expectedSourceVersion: body.expectedSourceVersion,
        expectedTargetVersion: body.expectedTargetVersion,
        sourceOrderId: params.orderId,
        targetOrderId: body.targetOrderId,
      },
      actor,
    );
    return Response.json({ data });
  });
}
