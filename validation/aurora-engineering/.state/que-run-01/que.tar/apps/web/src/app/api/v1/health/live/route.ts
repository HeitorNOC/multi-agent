export async function GET(): Promise<Response> {
  return Response.json(
    {
      service: "web",
      status: "ok",
    },
    {
      headers: { "cache-control": "no-store" },
    },
  );
}
