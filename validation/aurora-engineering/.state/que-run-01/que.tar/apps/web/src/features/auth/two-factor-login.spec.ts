import { describe, expect, it } from "vitest";

import { isTwoFactorRedirect } from "./two-factor-login";

describe("isTwoFactorRedirect", () => {
  it("recognizes only a valid pending second-factor response", () => {
    expect(isTwoFactorRedirect({ twoFactorMethods: ["totp"], twoFactorRedirect: true })).toBe(true);
    expect(isTwoFactorRedirect({ twoFactorRedirect: true })).toBe(true);
    expect(isTwoFactorRedirect({ twoFactorRedirect: false })).toBe(false);
    expect(isTwoFactorRedirect({ twoFactorMethods: "totp", twoFactorRedirect: true })).toBe(false);
    expect(isTwoFactorRedirect(null)).toBe(false);
  });
});
