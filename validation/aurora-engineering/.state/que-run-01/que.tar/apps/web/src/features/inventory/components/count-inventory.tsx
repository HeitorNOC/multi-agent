"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  countInventoryBodySchema,
  stockMutationResultSchema,
  type CountInventoryBody,
  type ProblemDetails,
  type StockBalanceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useForm } from "react-hook-form";

export function InventoryCountForm({
  balance,
  branchId,
  onChanged,
  organizationId,
  setFeedback,
}: {
  balance: StockBalanceView;
  branchId: string;
  onChanged: (balance: StockBalanceView) => void;
  organizationId: string;
  setFeedback: (message: string) => void;
}) {
  const form = useForm<CountInventoryBody>({
    defaultValues: {
      countedQuantity: balance.quantityOnHand,
      expectedVersion: balance.version,
      productId: balance.productId,
      reason: "",
    },
    resolver: zodResolver(countInventoryBodySchema),
  });
  return (
    <section className="rounded-2xl border bg-white p-5 shadow-sm">
      <h2 className="text-lg font-semibold">Registrar inventário contado: {balance.productName}</h2>
      <p className="mb-4 mt-1 text-sm text-slate-600">Saldo esperado: {balance.quantityOnHand}</p>
      <form
        className="grid gap-4 sm:grid-cols-3"
        onSubmit={form.handleSubmit(async (body) => {
          setFeedback("");
          const response = await fetch(
            `/api/v1/organizations/${organizationId}/branches/${branchId}/stock-movements/inventory`,
            {
              body: JSON.stringify(body),
              headers: {
                "content-type": "application/json",
                "idempotency-key": crypto.randomUUID(),
              },
              method: "POST",
            },
          );
          const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
          if (!response.ok) {
            setFeedback(payload.detail ?? "Não foi possível conciliar o inventário.");
            return;
          }
          onChanged(stockMutationResultSchema.parse(payload.data).balance);
        })}
      >
        <input type="hidden" {...form.register("productId")} />
        <input type="hidden" {...form.register("expectedVersion", { valueAsNumber: true })} />
        <label className="grid gap-1 text-sm font-medium">
          Quantidade contada
          <Input inputMode="decimal" {...form.register("countedQuantity")} />
          <ErrorText message={form.formState.errors.countedQuantity?.message} />
        </label>
        <label className="grid gap-1 text-sm font-medium">
          Justificativa
          <Input {...form.register("reason")} />
          <ErrorText message={form.formState.errors.reason?.message} />
        </label>
        <div className="flex items-end">
          <Button disabled={form.formState.isSubmitting} type="submit">
            Conciliar inventário
          </Button>
        </div>
      </form>
    </section>
  );
}

function ErrorText({ message }: { message: string | undefined }) {
  return message ? <span className="text-xs text-red-700">{message}</span> : null;
}
