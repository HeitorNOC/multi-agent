import type { Metadata } from "next";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { VerifyEmailPanel } from "@/features/auth/components/verify-email-panel";

export const metadata: Metadata = {
  title: "Confirme seu e-mail | Gestor",
};

export default function VerifyEmailPage() {
  return (
    <AuthShell
      description="Essa etapa protege sua conta e confirma que o endereço pertence a você."
      eyebrow="Falta pouco"
      title="Confirme seu e-mail"
    >
      <VerifyEmailPanel />
    </AuthShell>
  );
}
