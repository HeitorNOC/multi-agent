import type { FileStorageEnv } from "@gestor/config";
import { describe, expect, it, vi } from "vitest";
import { HttpCatalogMalwareScanner, SupabaseCatalogObjectStorage } from "./catalog-file-gateway";

const environment: FileStorageEnv = {
  FILE_SIGNED_URL_TTL_SECONDS: 60,
  MALWARE_SCAN_TOKEN: "m".repeat(32),
  MALWARE_SCAN_URL: "https://scanner.example/scan",
  SUPABASE_STORAGE_BUCKET: "gestor-private-files",
  SUPABASE_STORAGE_SECRET_KEY: "s".repeat(32),
  SUPABASE_STORAGE_URL: "https://project.supabase.co",
};

describe("SupabaseCatalogObjectStorage", () => {
  it("encodes every path segment when requesting a signed URL", async () => {
    const request = vi.fn(async () =>
      Response.json({ signedURL: "/object/sign/gestor-private-files/signed?token=value" }),
    );
    const result = await new SupabaseCatalogObjectStorage(
      () => environment,
      request,
    ).createSignedDownloadUrl("organization/catalog/file name.pdf", 60);
    expect(request).toHaveBeenCalledWith(
      expect.stringContaining("organization/catalog/file%20name.pdf"),
      expect.objectContaining({ method: "POST" }),
    );
    expect(result).toBe(
      "https://project.supabase.co/storage/v1/object/sign/gestor-private-files/signed?token=value",
    );
  });

  it("reports unavailable storage when its environment is invalid", async () => {
    await expect(
      new SupabaseCatalogObjectStorage(() => {
        throw new Error("SUPABASE_STORAGE_SECRET_KEY is missing");
      }).remove("organization/catalog/file.pdf"),
    ).rejects.toMatchObject({ code: "CATALOG_FILE_DEPENDENCY_UNAVAILABLE" });
  });
});

describe("HttpCatalogMalwareScanner", () => {
  it("fails closed when the scanner response has no decision", async () => {
    const request = vi.fn(async () => Response.json({ engine: "test" }));
    await expect(
      new HttpCatalogMalwareScanner(() => environment, request).scan({
        bytes: Uint8Array.from([1]),
        checksumSha256: "1".repeat(64),
        mimeType: "application/pdf",
        originalName: "file.pdf",
      }),
    ).rejects.toMatchObject({ code: "CATALOG_FILE_DEPENDENCY_UNAVAILABLE" });
  });

  it("reports unavailable scanning when its environment is invalid", async () => {
    await expect(
      new HttpCatalogMalwareScanner(() => {
        throw new Error("MALWARE_SCAN_URL is missing");
      }).scan({
        bytes: Uint8Array.from([1]),
        checksumSha256: "1".repeat(64),
        mimeType: "application/pdf",
        originalName: "file.pdf",
      }),
    ).rejects.toMatchObject({ code: "CATALOG_FILE_DEPENDENCY_UNAVAILABLE" });
  });
});
