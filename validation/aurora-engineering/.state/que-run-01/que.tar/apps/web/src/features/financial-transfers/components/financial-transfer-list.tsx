import type { FinancialAccountView, FinancialTransferView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

import { formatBrl, formatDateTime } from "./financial-transfer-format";

type FinancialTransferListProps = {
  accountById: ReadonlyMap<string, FinancialAccountView>;
  accounts: readonly FinancialAccountView[] | null;
  feedback: string | null;
  hasMore: boolean;
  loadError: string | null;
  loadingMore: boolean;
  onLoadMore: () => void;
  onRetry: () => void;
  transfers: readonly FinancialTransferView[] | null;
};

export function FinancialTransferList({
  accountById,
  accounts,
  feedback,
  hasMore,
  loadError,
  loadingMore,
  onLoadMore,
  onRetry,
  transfers,
}: FinancialTransferListProps) {
  return (
    <section className="grid content-start gap-4">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Histórico</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Transferências concluídas</h2>
      </div>
      {feedback ? (
        <div className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700" role="status">
          {feedback}
        </div>
      ) : null}
      {!accounts || !transfers ? (
        <div className="grid gap-3 rounded-2xl border bg-white p-5">
          <p className="text-sm text-slate-600">
            {loadError ?? "Carregando contas e transferências..."}
          </p>
          {loadError ? (
            <div>
              <Button onClick={onRetry} size="sm" variant="outline">
                Tentar novamente
              </Button>
            </div>
          ) : null}
        </div>
      ) : transfers.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
          Nenhuma transferência financeira foi realizada.
        </div>
      ) : (
        <>
          <ul className="grid gap-3">
            {transfers.map((transfer) => (
              <li className="rounded-2xl border bg-white p-5" key={transfer.id}>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-950">
                      {accountById.get(transfer.sourceAccountId)?.name ?? "Conta de origem"}
                      <span className="mx-2 text-slate-400">→</span>
                      {accountById.get(transfer.targetAccountId)?.name ?? "Conta de destino"}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {formatDateTime(transfer.occurredAt)}
                    </p>
                  </div>
                  <p className="text-sm font-semibold text-slate-950">
                    {formatBrl(transfer.amount)}
                  </p>
                </div>
              </li>
            ))}
          </ul>
          {hasMore ? (
            <div>
              <Button disabled={loadingMore} onClick={onLoadMore} size="sm" variant="outline">
                {loadingMore ? "Carregando..." : "Carregar mais"}
              </Button>
            </div>
          ) : null}
        </>
      )}
    </section>
  );
}
