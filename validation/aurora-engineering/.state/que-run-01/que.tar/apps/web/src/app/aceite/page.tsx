import type { Metadata } from "next";
import { Suspense } from "react";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { LegalAcceptanceForm } from "@/features/legal/components/legal-acceptance-form";

export const metadata: Metadata = { title: "Termos e privacidade | Gestor" };

export default function LegalAcceptancePage() {
  return (
    <AuthShell
      eyebrow="Primeiro acesso"
      title="Termos e privacidade"
      description="Revise os documentos antes de configurar sua empresa."
    >
      <Suspense fallback={<p className="text-sm text-slate-600">Carregando documentos…</p>}>
        <LegalAcceptanceForm />
      </Suspense>
    </AuthShell>
  );
}
