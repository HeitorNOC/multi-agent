"use client";

import type { FinancialAccountView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

import { formatBrl, formatDate } from "./financial-account-format";

type FinancialAccountListProps = {
  accounts: readonly FinancialAccountView[] | null;
  branchesLoaded: boolean;
  branchNames: ReadonlyMap<string, string>;
  busyAccount: string | null;
  feedback: string | null;
  loadError: string | null;
  onChangeStatus: (account: FinancialAccountView) => Promise<void>;
  onRetry: () => void;
};

export function FinancialAccountList({
  accounts,
  branchesLoaded,
  branchNames,
  busyAccount,
  feedback,
  loadError,
  onChangeStatus,
  onRetry,
}: FinancialAccountListProps) {
  return (
    <section aria-labelledby="financial-account-list-title" className="grid content-start gap-4">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Posição financeira
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="financial-account-list-title">
          Contas financeiras
        </h2>
      </div>

      {feedback ? (
        <div className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700" role="status">
          {feedback}
        </div>
      ) : null}

      {!accounts || !branchesLoaded ? (
        <div className="grid gap-3 rounded-2xl border bg-white p-5">
          <p className="text-sm text-slate-600">{loadError ?? "Carregando contas e filiais..."}</p>
          {loadError ? (
            <div>
              <Button
                onClick={() => {
                  onRetry();
                }}
                size="sm"
                variant="outline"
              >
                Tentar novamente
              </Button>
            </div>
          ) : null}
        </div>
      ) : accounts.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
          Cadastre o primeiro caixa ou banco e informe o saldo conferido na implantação.
        </div>
      ) : (
        <ul className="grid gap-3">
          {accounts.map((account) => (
            <li className="rounded-2xl border bg-white p-5" key={account.id}>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm font-semibold text-slate-950">{account.name}</h3>
                    <StatusBadge status={account.status} />
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    {account.type === "CASH"
                      ? "Caixa físico"
                      : account.type === "BANK"
                        ? "Conta bancária"
                        : "Conta de adquirente"}
                    {" · "}
                    {account.branchId
                      ? (branchNames.get(account.branchId) ?? "Filial não disponível")
                      : "Compartilhada entre filiais"}
                  </p>
                  <p className="mt-4 text-xs font-medium text-slate-500">Saldo atual</p>
                  <p className="mt-1 text-2xl font-semibold tracking-tight text-slate-950">
                    {formatBrl(account.currentBalance)}
                  </p>
                  <p className="mt-2 text-xs leading-5 text-slate-500">
                    Implantação: {formatBrl(account.initialBalance)} em{" "}
                    {formatDate(account.initialBalanceDate)}
                  </p>
                </div>
                {account.type === "ACQUIRER" ? (
                  <span className="text-xs font-medium text-slate-500">
                    Gerenciada automaticamente
                  </span>
                ) : (
                  <Button
                    disabled={busyAccount === account.id}
                    onClick={() => void onChangeStatus(account)}
                    size="sm"
                    variant="outline"
                  >
                    {busyAccount === account.id
                      ? "Salvando..."
                      : account.status === "ACTIVE"
                        ? "Desativar"
                        : "Ativar"}
                  </Button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function StatusBadge({ status }: { status: FinancialAccountView["status"] }) {
  return (
    <span
      className={
        status === "ACTIVE"
          ? "rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-800"
          : "rounded-full bg-slate-200 px-2 py-0.5 text-xs font-semibold text-slate-700"
      }
    >
      {status === "ACTIVE" ? "Ativa" : "Inativa"}
    </span>
  );
}
