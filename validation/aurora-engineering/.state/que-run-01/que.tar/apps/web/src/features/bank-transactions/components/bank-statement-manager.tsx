"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  bankAccountListSchema,
  bankStatementImportSelectionSchema,
  bankStatementImportViewSchema,
  bankTransactionPageSchema,
  type BankAccountView,
  type BankStatementImportSelection,
  type BankTransactionView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { BankStatementList } from "./bank-statement-list";

const MAX_FILE_BYTES = 1024 * 1024;

type BankStatementManagerProps = {
  organizationId: string;
};

export function BankStatementManager({ organizationId }: BankStatementManagerProps) {
  const [bankAccounts, setBankAccounts] = useState<readonly BankAccountView[] | null>(null);
  const [transactions, setTransactions] = useState<readonly BankTransactionView[] | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileInputVersion, setFileInputVersion] = useState(0);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
    setValue,
  } = useForm<BankStatementImportSelection>({
    defaultValues: { bankAccountId: "" },
    resolver: zodResolver(bankStatementImportSelectionSchema),
  });
  const bankAccountId = useWatch({ control, name: "bankAccountId" });
  const accountNames = useMemo(
    () =>
      new Map(
        bankAccounts?.map((account) => [
          account.id,
          `${account.institutionName} ${account.accountMask}`,
        ]) ?? [],
      ),
    [bankAccounts],
  );

  useEffect(() => {
    const controller = new AbortController();

    async function loadAccounts() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/bank-accounts`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const payload = (await response.json()) as { data: unknown };
        const accounts = bankAccountListSchema.parse(payload.data);
        setBankAccounts(accounts);
        setLoadError(null);

        if (accounts.length === 0) {
          setTransactions([]);
        } else if (!bankAccountId && accounts[0]) {
          setValue("bankAccountId", accounts[0].id);
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error ? error.message : "Não foi possível carregar as contas.",
          );
        }
      }
    }

    void loadAccounts();
    return () => controller.abort();
  }, [bankAccountId, organizationId, setValue]);

  useEffect(() => {
    if (!bankAccountId) {
      return;
    }

    const controller = new AbortController();

    async function loadTransactions() {
      try {
        const page = await fetchTransactionPage(
          organizationId,
          bankAccountId,
          undefined,
          controller.signal,
        );
        setTransactions(page.data);
        setHasMore(page.page.hasMore);
        setNextCursor(page.page.nextCursor);
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setTransactions(null);
          setLoadError(
            error instanceof Error ? error.message : "Não foi possível carregar as transações.",
          );
        }
      }
    }

    void loadTransactions();
    return () => controller.abort();
  }, [bankAccountId, organizationId, reloadVersion]);

  const submit = handleSubmit(async ({ bankAccountId: selectedBankAccountId }) => {
    setFeedback(null);
    setFileError(null);
    const file = selectedFile;

    if (!file) {
      setFileError("Selecione um arquivo CSV ou OFX.");
      return;
    }

    const extension = file.name.split(".").at(-1)?.toLowerCase();

    if (extension !== "csv" && extension !== "ofx") {
      setFileError("Selecione um arquivo com extensão .csv ou .ofx.");
      return;
    }

    if (file.size === 0 || file.size > MAX_FILE_BYTES) {
      setFileError("O arquivo deve possuir entre 1 byte e 1 MiB.");
      return;
    }

    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/bank-accounts/${selectedBankAccountId}/statement-imports`,
        {
          body: file,
          headers: {
            "content-type": file.type || "application/octet-stream",
            "idempotency-key": idempotencyKey,
            "x-file-name": encodeURIComponent(file.name),
          },
          method: "POST",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const result = bankStatementImportViewSchema.parse(payload.data);
      setFeedback(
        `${result.importedTransactions} transação(ões) importada(s) e ${result.duplicateTransactions} duplicada(s) ignorada(s). Nenhum saldo foi alterado.`,
      );
      setIdempotencyKey(crypto.randomUUID());

      setSelectedFile(null);
      setFileInputVersion((version) => version + 1);
      setReloadVersion((version) => version + 1);
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function loadMore() {
    if (!bankAccountId || !nextCursor) {
      return;
    }

    setLoadingMore(true);

    try {
      const page = await fetchTransactionPage(organizationId, bankAccountId, nextCursor);
      setTransactions((current) => [...(current ?? []), ...page.data]);
      setHasMore(page.page.hasMore);
      setNextCursor(page.page.nextCursor);
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível carregar mais transações.",
      );
    } finally {
      setLoadingMore(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7">
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Novo extrato</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Importar CSV ou OFX</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          O arquivo é validado em memória e descartado. Somente os lançamentos e o resumo da
          importação são preservados.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="statement-bank-account">Conta bancária</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="statement-bank-account"
              {...register("bankAccountId")}
            >
              <option value="">Selecione uma conta</option>
              {bankAccounts?.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.institutionName} — {account.accountMask}
                </option>
              ))}
            </select>
            {errors.bankAccountId ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.bankAccountId.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="statement-file">Arquivo do extrato</Label>
            <input
              accept=".csv,.ofx,text/csv,application/x-ofx"
              className="file:bg-brand-50 file:text-brand-700 h-11 w-full rounded-xl border bg-white px-3 py-2 text-sm file:mr-3 file:rounded-lg file:border-0 file:px-3 file:py-1 file:text-xs file:font-semibold"
              id="statement-file"
              key={fileInputVersion}
              onChange={(event) => {
                setSelectedFile(event.target.files?.[0] ?? null);
                setFileError(null);
              }}
              type="file"
            />
            <p className="text-xs leading-5 text-slate-500">
              Máximo de 1 MiB e 5.000 transações. CSV: data, descrição e valor.
            </p>
            {fileError ? (
              <p className="text-sm text-red-700" role="alert">
                {fileError}
              </p>
            ) : null}
          </div>

          <p className="rounded-xl bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">
            Importar não movimenta dinheiro. A conferência e o vínculo financeiro acontecerão
            somente na conciliação.
          </p>

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button
            disabled={isSubmitting || !bankAccounts || bankAccounts.length === 0}
            type="submit"
          >
            {isSubmitting ? "Importando..." : "Importar extrato"}
          </Button>
        </form>
      </section>

      <BankStatementList
        accountNames={accountNames}
        bankAccountId={bankAccountId}
        bankAccounts={bankAccounts}
        feedback={feedback}
        hasMore={hasMore}
        loadError={loadError}
        loadingMore={loadingMore}
        onLoadMore={() => void loadMore()}
        onRetry={() => setReloadVersion((version) => version + 1)}
        transactions={transactions}
      />
    </div>
  );
}

async function fetchTransactionPage(
  organizationId: string,
  bankAccountId: string,
  cursor?: string,
  signal?: AbortSignal,
) {
  const search = new URLSearchParams({ limit: "20" });
  if (cursor) search.set("cursor", cursor);
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/bank-accounts/${bankAccountId}/transactions?${search}`,
    signal ? { signal } : undefined,
  );
  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }
  return bankTransactionPageSchema.parse(await response.json());
}
