"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";
import {
  PublicCatalogCheckout,
  type PublicCatalogCheckoutSubmission,
} from "./public-catalog-checkout";
import { formatCatalogItemCount, formatCatalogQuantity } from "./catalog-presentation";

type State = "checking" | "ready" | "unavailable" | "verification";
type ProblemResponse = { code?: string; detail?: string; problem?: { message?: string } };
type CommercialPolicy = {
  allowsArrangedDelivery: boolean;
  allowsDelivery: boolean;
  deliveryIssueWindowHours: number;
  allowsPickup: boolean;
  fulfillmentNotice: string | null;
  minimumOrderAmount: number | null;
};

function formatIssueWindow(hours: number) {
  if (hours % 24 === 0) {
    const days = hours / 24;
    return `${days} ${days === 1 ? "dia" : "dias"}`;
  }
  return `${hours} horas`;
}
type Cart = { id: string; items: readonly (Item & { quantity: string })[] };
type Order = {
  createdAt: string;
  deliveryCode: string | null;
  deliveryConfirmedAt: string | null;
  deliveryDispatchedAt: string | null;
  deliveryIssueReportedAt: string | null;
  deliveryStatus:
    | "NOT_REQUIRED"
    | "PENDING"
    | "OUT_FOR_DELIVERY"
    | "DELIVERED"
    | "RECEIPT_CONFIRMED"
    | "ISSUE_REPORTED"
    | "DELIVERY_FAILED";
  receiptConfirmedAt: string | null;
  fulfillmentMethod: "PICKUP" | "DELIVERY" | "ARRANGED";
  id: string;
  items: readonly { productName: string; quantity: string; unit: string }[];
  status: "PENDING" | "CONFIRMED" | "FULFILLED" | "CANCELLED";
  total: string;
};
type Item = {
  categoryName: string | null;
  description: string | null;
  id: string;
  name: string;
  price: string;
  unit: string;
};

export function PublicCatalogLink({ token }: { token: string }) {
  const router = useRouter();
  const [state, setState] = useState<State>("checking");
  const [items, setItems] = useState<readonly Item[] | null>(null);
  const [cart, setCart] = useState<Cart>({ id: "", items: [] });
  const cartCount = cart.items.reduce((total, item) => total + Number(item.quantity), 0);
  const [cartError, setCartError] = useState<string | null>(null);
  const [addingId, setAddingId] = useState<string | null>(null);
  const [commercialPolicy, setCommercialPolicy] = useState<CommercialPolicy | null>(null);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [submittingOrder, setSubmittingOrder] = useState(false);
  const [orderCreated, setOrderCreated] = useState(false);
  const [orders, setOrders] = useState<readonly Order[]>([]);
  const [issueOrderId, setIssueOrderId] = useState<string | null>(null);
  const [issueReason, setIssueReason] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const link = await fetch(`/api/public/catalog-links/${encodeURIComponent(token)}`, {
          signal: controller.signal,
        });
        if (!link.ok) return setState("unavailable");
        const linkPayload = (await link.json()) as {
          data: { commercialPolicy: CommercialPolicy | null };
        };
        setCommercialPolicy(linkPayload.data.commercialPolicy);
        const access = await fetch(
          `/api/public/catalog-links/${encodeURIComponent(token)}/access`,
          {
            method: "POST",
            signal: controller.signal,
          },
        );
        if (access.status === 401) {
          router.replace(`/login?returnTo=${encodeURIComponent(`/catalogo/${token}`)}`);
          return;
        }
        if (access.status === 403) {
          const problem = (await access.json().catch(() => ({}))) as ProblemResponse;
          return setState(
            problem.code === "CUSTOMER_PORTAL_EMAIL_NOT_VERIFIED" ? "verification" : "unavailable",
          );
        }
        if (!access.ok) return setState("unavailable");
        const response = await fetch(
          `/api/public/catalog-links/${encodeURIComponent(token)}/items`,
          {
            signal: controller.signal,
          },
        );
        if (!response.ok) return setState("unavailable");
        const payload = (await response.json()) as { data: readonly Item[] };
        setItems(payload.data);
        const cartResponse = await fetch(
          `/api/public/catalog-links/${encodeURIComponent(token)}/cart`,
          { signal: controller.signal },
        );
        if (cartResponse.ok) {
          setCart(((await cartResponse.json()) as { data: Cart }).data);
        } else {
          setCartError(
            "O catálogo foi carregado, mas não foi possível consultar seu carrinho agora.",
          );
        }
        const ordersResponse = await fetch(
          `/api/public/catalog-links/${encodeURIComponent(token)}/orders`,
          { signal: controller.signal },
        );
        if (ordersResponse.ok)
          setOrders(((await ordersResponse.json()) as { data: readonly Order[] }).data);
        setState("ready");
      } catch {
        if (!controller.signal.aborted) setState("unavailable");
      }
    }
    void load();
    return () => controller.abort();
  }, [router, token]);

  async function removeFromCart(productId: string) {
    setAddingId(productId);
    setCartError(null);
    try {
      const response = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/cart/items/${productId}`,
        { method: "DELETE" },
      );
      if (!response.ok) throw new Error("Não foi possível remover o item.");
      setCart(((await response.json()) as { data: Cart }).data);
    } catch (cause) {
      setCartError(cause instanceof Error ? cause.message : "Não foi possível remover o item.");
    } finally {
      setAddingId(null);
    }
  }

  async function updateCart(productId: string, quantity: number) {
    setAddingId(productId);
    setCartError(null);
    try {
      const response = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/cart/items/${productId}`,
        {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ quantity }),
        },
      );
      if (!response.ok) throw new Error("Não foi possível atualizar o carrinho.");
      setCart(((await response.json()) as { data: Cart }).data);
    } catch (cause) {
      setCartError(
        cause instanceof Error ? cause.message : "Não foi possível atualizar o carrinho.",
      );
    } finally {
      setAddingId(null);
    }
  }

  async function createOrder(submission: PublicCatalogCheckoutSubmission) {
    setSubmittingOrder(true);
    setCheckoutError(null);
    try {
      const response = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/orders`,
        {
          body: JSON.stringify(submission),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const payload = (await response.json().catch(() => ({}))) as ProblemResponse;
      if (!response.ok)
        throw new Error(
          payload.detail ?? payload.problem?.message ?? "Não foi possível confirmar o pedido.",
        );
      setOrderCreated(true);
      const ordersResponse = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/orders`,
      );
      if (ordersResponse.ok)
        setOrders(((await ordersResponse.json()) as { data: readonly Order[] }).data);
      setCart({ id: "", items: [] });
    } catch (cause) {
      setCheckoutError(
        cause instanceof Error ? cause.message : "Não foi possível confirmar o pedido.",
      );
    } finally {
      setSubmittingOrder(false);
    }
  }

  async function confirmReceipt(order: Order) {
    setCheckoutError(null);
    try {
      const response = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/orders/${order.id}/receipt`,
        { method: "POST" },
      );
      const payload = (await response.json()) as { data?: Order; detail?: string };
      if (!response.ok)
        throw new Error(payload.detail ?? "Não foi possível confirmar o recebimento.");
      setOrders((current) =>
        current.map((entry) => (entry.id === order.id ? payload.data! : entry)),
      );
    } catch (cause) {
      setCheckoutError(
        cause instanceof Error ? cause.message : "Não foi possível confirmar o recebimento.",
      );
    }
  }

  async function reportDeliveryIssue(order: Order) {
    const reason = issueReason.trim();
    if (reason.length < 5) {
      setCheckoutError("Descreva o problema com pelo menos 5 caracteres.");
      return;
    }
    setCheckoutError(null);
    try {
      const response = await fetch(
        `/api/public/catalog-links/${encodeURIComponent(token)}/orders/${order.id}/delivery-issue`,
        {
          body: JSON.stringify({ reason }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      const payload = (await response.json()) as { data?: Order; detail?: string };
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível registrar o problema.");
      setOrders((current) =>
        current.map((entry) => (entry.id === order.id ? payload.data! : entry)),
      );
      setIssueOrderId(null);
      setIssueReason("");
    } catch (cause) {
      setCheckoutError(
        cause instanceof Error ? cause.message : "Não foi possível registrar o problema.",
      );
    }
  }

  return (
    <main className="mx-auto min-h-screen w-full max-w-4xl px-5 py-10">
      <section className="rounded-2xl border bg-white p-6 shadow-sm">
        {state === "checking" ? (
          <>
            <p className="text-sm text-slate-600">Carregando catálogo...</p>
            <div className="mt-4">
              <LoadingRows rows={4} />
            </div>
          </>
        ) : null}
        {state === "verification" ? (
          <>
            <h1 className="text-2xl font-semibold text-slate-950">Confirme seu e-mail</h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Confirme seu e-mail para acessar este catálogo e abra o link novamente.
            </p>
          </>
        ) : null}
        {state === "unavailable" ? (
          <>
            <h1 className="text-2xl font-semibold text-slate-950">Link indisponível</h1>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Solicite um novo link à empresa.
            </p>
          </>
        ) : null}
        {state === "ready" ? (
          <>
            <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Catálogo</p>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h1 className="mt-2 text-2xl font-semibold text-slate-950">Produtos disponíveis</h1>
              <p className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-700">
                Carrinho: {formatCatalogItemCount(cartCount)}
              </p>
            </div>
            {commercialPolicy ? (
              <section className="mt-4 rounded-xl border border-brand-100 bg-brand-50 p-4 text-sm text-slate-700">
                <h2 className="font-semibold text-slate-950">
                  {commercialPolicy.allowsPickup ||
                  commercialPolicy.allowsDelivery ||
                  commercialPolicy.allowsArrangedDelivery
                    ? "Como receber seu pedido"
                    : "Catálogo para consulta"}
                </h2>
                <p className="mt-1">
                  {commercialPolicy.allowsPickup ||
                  commercialPolicy.allowsDelivery ||
                  commercialPolicy.allowsArrangedDelivery
                    ? [
                        commercialPolicy.allowsPickup ? "Retirada" : null,
                        commercialPolicy.allowsDelivery ? "Entrega pela empresa" : null,
                        commercialPolicy.allowsArrangedDelivery ? "Entrega a combinar" : null,
                      ]
                        .filter(Boolean)
                        .join(" e ")
                    : "A empresa não está recebendo pedidos por este catálogo no momento."}
                  {commercialPolicy.minimumOrderAmount !== null &&
                  (commercialPolicy.allowsPickup ||
                    commercialPolicy.allowsDelivery ||
                    commercialPolicy.allowsArrangedDelivery)
                    ? ` · Pedido mínimo de ${new Intl.NumberFormat("pt-BR", {
                        currency: "BRL",
                        style: "currency",
                      }).format(commercialPolicy.minimumOrderAmount)}`
                    : ""}
                </p>
                {commercialPolicy.fulfillmentNotice ? (
                  <p className="mt-2 leading-6">{commercialPolicy.fulfillmentNotice}</p>
                ) : null}
                <p className="mt-2 text-xs text-slate-600">
                  Após a entrega confirmada, problemas podem ser informados em até{" "}
                  {formatIssueWindow(commercialPolicy.deliveryIssueWindowHours)}.
                </p>
              </section>
            ) : null}
            {cartError ? (
              <p
                className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
                role="alert"
              >
                {cartError}
              </p>
            ) : null}
            {checkoutError ? (
              <p
                className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
                role="alert"
              >
                {checkoutError}
              </p>
            ) : null}
            {orderCreated ? (
              <section
                className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 p-4"
                role="status"
              >
                <h2 className="font-semibold text-emerald-950">Pedido recebido</h2>
                <p className="mt-1 text-sm leading-6 text-emerald-900">
                  A empresa confirmará disponibilidade, forma de pagamento e próximo passo.
                </p>
              </section>
            ) : null}
            {orders.length ? (
              <section
                className="mt-5 rounded-xl border bg-slate-50 p-4"
                aria-labelledby="orders-title"
              >
                <h2 className="font-semibold text-slate-950" id="orders-title">
                  Seus pedidos
                </h2>
                <ul className="mt-3 grid gap-3">
                  {orders.map((order) => (
                    <li className="rounded-lg border bg-white p-3" key={order.id}>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-sm font-medium text-slate-900">
                          {formatCatalogItemCount(order.items.length)} · R${" "}
                          {Number(order.total).toFixed(2).replace(".", ",")}
                        </p>
                        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                          {order.status === "PENDING"
                            ? "Recebido"
                            : order.status === "CONFIRMED"
                              ? "Em preparação"
                              : order.status === "FULFILLED"
                                ? "Concluído"
                                : "Cancelado"}
                        </span>
                      </div>
                      <p className="mt-2 text-sm text-slate-600">
                        {order.items
                          .map(
                            (item) =>
                              `${formatCatalogQuantity(item.quantity)} ${item.unit} · ${item.productName}`,
                          )
                          .join("; ")}
                      </p>
                      {order.deliveryStatus === "OUT_FOR_DELIVERY" && order.deliveryCode ? (
                        <div className="mt-3 rounded-lg border border-brand-200 bg-brand-50 p-3 text-sm text-brand-950">
                          <p className="font-medium">Código para confirmar a entrega</p>
                          <p className="mt-1 text-2xl font-bold tracking-[0.3em]">
                            {order.deliveryCode}
                          </p>
                          <p className="mt-2 text-brand-800">
                            Informe este código somente ao receber o pedido.
                          </p>
                          <button
                            className="mt-2 text-sm font-medium underline"
                            onClick={() => {
                              setIssueOrderId(order.id);
                              setIssueReason("");
                            }}
                            type="button"
                          >
                            Reportar problema
                          </button>
                        </div>
                      ) : null}
                      {order.fulfillmentMethod !== "PICKUP" &&
                      order.deliveryConfirmedAt &&
                      !order.receiptConfirmedAt ? (
                        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                          <p>
                            A empresa informou que seu pedido foi entregue. Confirme somente após
                            recebê-lo.
                          </p>
                          <div className="mt-2 flex flex-wrap gap-2">
                            <button
                              className="rounded-lg bg-brand-700 px-3 py-2 font-semibold text-white"
                              onClick={() => void confirmReceipt(order)}
                              type="button"
                            >
                              Confirmar recebimento
                            </button>
                            <button
                              className="rounded-lg border px-3 py-2 font-medium"
                              onClick={() => {
                                setIssueOrderId(order.id);
                                setIssueReason("");
                              }}
                              type="button"
                            >
                              Reportar problema
                            </button>
                          </div>
                        </div>
                      ) : null}
                      {issueOrderId === order.id ? (
                        <form
                          className="mt-3 grid gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3"
                          onSubmit={(event) => {
                            event.preventDefault();
                            void reportDeliveryIssue(order);
                          }}
                        >
                          <label
                            className="text-sm font-medium text-slate-950"
                            htmlFor={`delivery-issue-${order.id}`}
                          >
                            O que aconteceu?
                          </label>
                          <textarea
                            className="min-h-20 rounded-lg border bg-white p-2 text-sm"
                            id={`delivery-issue-${order.id}`}
                            maxLength={1200}
                            onChange={(event) => setIssueReason(event.target.value)}
                            placeholder="Ex.: o pedido não chegou ao endereço informado."
                            value={issueReason}
                          />
                          <div className="flex gap-2">
                            <button
                              className="rounded-lg bg-amber-700 px-3 py-2 text-sm font-semibold text-white"
                              type="submit"
                            >
                              Enviar para análise
                            </button>
                            <button
                              className="rounded-lg border px-3 py-2 text-sm"
                              onClick={() => setIssueOrderId(null)}
                              type="button"
                            >
                              Cancelar
                            </button>
                          </div>
                        </form>
                      ) : null}
                      {order.deliveryStatus === "ISSUE_REPORTED" ? (
                        <p className="mt-3 text-sm font-medium text-amber-800">
                          Seu problema foi registrado. A empresa analisará o caso.
                        </p>
                      ) : null}
                      {order.fulfillmentMethod !== "PICKUP" && order.receiptConfirmedAt ? (
                        <p className="mt-3 text-sm font-medium text-emerald-800">
                          Recebimento confirmado por você.
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </section>
            ) : null}
            {cart.items.length ? (
              <section className="mt-5 rounded-xl border bg-slate-50 p-4">
                <h2 className="font-semibold text-slate-950">Seu carrinho</h2>
                <ul className="mt-3 grid gap-2">
                  {cart.items.map((item) => (
                    <li
                      className="flex flex-wrap items-center justify-between gap-3 py-1"
                      key={item.id}
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-slate-900">{item.name}</p>
                        <p className="mt-1 text-xs text-slate-500">Quantidade no carrinho</p>
                      </div>
                      <div className="ml-auto flex flex-wrap items-center justify-end gap-2">
                        <span className="rounded-full bg-white px-2.5 py-1 text-sm font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200">
                          {formatCatalogQuantity(item.quantity)} {item.unit}
                        </span>
                        <button
                          aria-label={`Diminuir ${item.name}`}
                          className="rounded-lg border bg-white px-2.5 py-1.5 text-sm"
                          disabled={addingId === item.id}
                          onClick={() =>
                            void updateCart(item.id, Math.max(1, Number(item.quantity) - 1))
                          }
                          type="button"
                        >
                          −
                        </button>
                        <button
                          aria-label={`Aumentar ${item.name}`}
                          className="rounded-lg border bg-white px-2.5 py-1.5 text-sm"
                          disabled={addingId === item.id}
                          onClick={() => void updateCart(item.id, Number(item.quantity) + 1)}
                          type="button"
                        >
                          +
                        </button>
                        <button
                          className="rounded-lg border bg-white px-3 py-1.5 text-sm"
                          disabled={addingId === item.id}
                          onClick={() => void removeFromCart(item.id)}
                          type="button"
                        >
                          Remover
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-sm text-slate-600">
                  O preço e a disponibilidade serão confirmados antes do pedido.
                </p>
              </section>
            ) : null}
            {!orderCreated ? (
              <PublicCatalogCheckout
                cart={cart.items}
                onSubmit={(submission) => void createOrder(submission)}
                policy={commercialPolicy}
                submitting={submittingOrder}
              />
            ) : null}
            {items?.length ? (
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {items.map((item) => (
                  <li key={item.id} className="rounded-xl border p-4">
                    <p className="font-semibold text-slate-950">{item.name}</p>
                    {item.categoryName ? (
                      <p className="mt-1 text-xs text-slate-500">{item.categoryName}</p>
                    ) : null}
                    {item.description ? (
                      <p className="mt-3 text-sm leading-6 text-slate-600">{item.description}</p>
                    ) : null}
                    <p className="mt-4 font-medium text-slate-950">
                      {new Intl.NumberFormat("pt-BR", {
                        currency: "BRL",
                        style: "currency",
                      }).format(Number(item.price))}{" "}
                      <span className="text-sm font-normal text-slate-600">por {item.unit}</span>
                    </p>
                    <button
                      className="mt-4 rounded-lg border px-3 py-2 text-sm font-medium text-slate-900 disabled:opacity-60"
                      disabled={addingId === item.id}
                      onClick={() =>
                        void updateCart(
                          item.id,
                          Number(
                            cart.items.find((cartItem) => cartItem.id === item.id)?.quantity ?? 0,
                          ) + 1,
                        )
                      }
                      type="button"
                    >
                      {addingId === item.id ? "Atualizando..." : "Adicionar ao carrinho"}
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-4 text-sm text-slate-600">
                Nenhum produto está disponível neste catálogo.
              </p>
            )}
          </>
        ) : null}
      </section>
    </main>
  );
}
