"use client";

import { appointmentSettingsBodySchema, type ProblemDetails } from "@gestor/contracts";
import { useEffect, useState } from "react";

type Props = { organizationId: string };
const defaults = {
  defaultBufferAfterMinutes: 0,
  defaultBufferBeforeMinutes: 0,
  maximumAdvanceDays: 90,
  minimumLeadTimeMinutes: 60,
  slotIntervalMinutes: 15,
};

export function AppointmentSettingsManager({ organizationId }: Props) {
  const [values, setValues] = useState(defaults);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    void fetch(`/api/v1/organizations/${organizationId}/appointment-settings`)
      .then(async (r) => {
        if (!r.ok) throw new Error(((await r.json()) as ProblemDetails).detail);
        const data = ((await r.json()) as { data: typeof defaults | null }).data;
        if (data) setValues(data);
      })
      .catch((e) =>
        setError(e instanceof Error ? e.message : "Não foi possível carregar as regras."),
      );
  }, [organizationId]);
  async function save() {
    try {
      setSaving(true);
      const body = appointmentSettingsBodySchema.parse(values);
      const response = await fetch(`/api/v1/organizations/${organizationId}/appointment-settings`, {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "PUT",
      });
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível salvar as regras.");
    } finally {
      setSaving(false);
    }
  }
  return (
    <section className="rounded-2xl border bg-white p-5">
      <h2 className="text-xl font-semibold text-slate-950">Regras de reserva</h2>
      <p className="mt-1 text-sm text-slate-600">
        Defina como clientes visualizam e reservam horários.
      </p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {(
          [
            ["slotIntervalMinutes", "Intervalo entre horários (minutos)"],
            ["minimumLeadTimeMinutes", "Antecedência mínima (minutos)"],
            ["maximumAdvanceDays", "Máximo de dias à frente"],
            ["defaultBufferBeforeMinutes", "Buffer antes (minutos)"],
            ["defaultBufferAfterMinutes", "Buffer depois (minutos)"],
          ] as const
        ).map(([key, label]) => (
          <label className="grid gap-1 text-sm font-medium" key={key}>
            {label}
            <input
              className="rounded-lg border px-3 py-2"
              min="0"
              onChange={(e) =>
                setValues((current) => ({ ...current, [key]: Number(e.target.value) }))
              }
              type="number"
              value={values[key]}
            />
          </label>
        ))}
      </div>
      {error ? (
        <p className="mt-3 text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
      <button
        className="mt-4 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
        disabled={saving}
        onClick={() => void save()}
        type="button"
      >
        {saving ? "Salvando…" : "Salvar regras"}
      </button>
    </section>
  );
}
