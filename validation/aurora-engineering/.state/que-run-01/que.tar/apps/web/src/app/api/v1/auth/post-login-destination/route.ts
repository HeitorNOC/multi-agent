import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { getPostLoginDestination } from "@/lib/server/post-login-destination";

export async function GET(request: Request): Promise<Response> {
  return handleApiRequest(request, async () => {
    const identity = await authenticateApiRequest(request);
    return Response.json({ data: { destination: await getPostLoginDestination(identity.userId) } });
  });
}
