import {
  foodServiceModifierGroupListSchema,
  organizationParamsSchema,
  replaceFoodServiceProductModifierGroupsBodySchema,
} from "@gestor/contracts";
import { z } from "zod";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

const parametersSchema = organizationParamsSchema.extend({ productId: z.uuid() });
type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const url = new URL(request.url);
    const params = parametersSchema.parse({
      organizationId: (await route.params).organizationId,
      productId: url.searchParams.get("productId"),
    });
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const data = await services.listFoodServiceProductModifierGroups.execute(params, actor);
    return Response.json({ data: foodServiceModifierGroupListSchema.parse(data) });
  });
}

export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = replaceFoodServiceProductModifierGroupsBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const data = await services.replaceFoodServiceProductModifierGroups.execute(
      {
        groups: body.groups.map((group) => ({
          ...group,
          options: group.options.map((option) => ({ ...option, kitchenName: option.kitchenName ?? null })),
        })),
        organizationId: params.organizationId,
        productId: body.productId,
      },
      actor,
    );
    return Response.json({ data: foodServiceModifierGroupListSchema.parse(data) });
  });
}
