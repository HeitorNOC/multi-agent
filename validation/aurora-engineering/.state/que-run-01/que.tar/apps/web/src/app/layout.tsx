import type { Metadata } from "next";
import type { ReactNode } from "react";

import "@gestor/ui/globals.css";

export const metadata: Metadata = {
  description: "Gestão simples, segura e preparada para crescer.",
  title: "Gestor",
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
