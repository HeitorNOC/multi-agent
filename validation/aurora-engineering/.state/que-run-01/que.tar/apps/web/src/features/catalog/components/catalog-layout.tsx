import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import type { ReactNode } from "react";

import { CatalogFilesButton } from "./catalog-files-button";
import { PriceHistoryButton } from "./price-history-button";

export function CatalogSection({
  children,
  description,
  title,
}: {
  children: ReactNode;
  description: string;
  title: string;
}) {
  return (
    <section className="rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)]">
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mb-5 mt-1 text-sm text-slate-600">{description}</p>
      {children}
    </section>
  );
}
export function Field({
  children,
  error,
  id,
  label,
}: {
  children: ReactNode;
  error?: string | undefined;
  id: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? <ErrorText>{error}</ErrorText> : null}
    </div>
  );
}
export function ErrorText({ children }: { children: ReactNode }) {
  return (
    <p className="mt-1 text-sm text-red-700" role="alert">
      {children}
    </p>
  );
}
export function StatusPill<T extends { id: string; name: string; status: "ACTIVE" | "INACTIVE" }>({
  entity,
  onToggle,
}: {
  entity: T;
  onToggle: () => void;
}) {
  return (
    <button className="rounded-full border px-3 py-1 text-sm" onClick={onToggle} type="button">
      {entity.name} · {entity.status === "ACTIVE" ? "Ativa" : "Inativa"}
    </button>
  );
}
export function ItemList<T extends { id: string; name: string; status: "ACTIVE" | "INACTIVE" }>({
  files,
  items,
  onEdit,
  onToggle,
  priceHistory,
  secondary,
}: {
  files?:
    { allowImage: boolean; organizationId: string; segment: "products" | "services" } | undefined;
  items: readonly T[];
  onEdit?: ((item: T) => void) | undefined;
  onToggle: (item: T) => void;
  priceHistory?: { organizationId: string; segment: "products" | "services" } | undefined;
  secondary: (item: T) => string;
}) {
  return (
    <div className="mt-5 grid gap-2">
      {items.map((item) => (
        <div
          className="flex items-center justify-between rounded-xl border px-4 py-3"
          key={item.id}
        >
          <div>
            <p className="font-medium">{item.name}</p>
            <p className="text-xs text-slate-500">{secondary(item)}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {files ? <CatalogFilesButton itemId={item.id} {...files} /> : null}
            {priceHistory ? <PriceHistoryButton itemId={item.id} {...priceHistory} /> : null}
            {onEdit ? (
              <Button onClick={() => onEdit(item)} type="button" variant="outline">
                Editar
              </Button>
            ) : null}
            <Button onClick={() => onToggle(item)} type="button" variant="outline">
              {item.status === "ACTIVE" ? "Inativar" : "Reativar"}
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
