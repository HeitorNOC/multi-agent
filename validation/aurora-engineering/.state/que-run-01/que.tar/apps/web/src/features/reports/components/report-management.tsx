"use client";

import {
  reportDownloadViewSchema,
  reportJobViewSchema,
  reportListPageSchema,
  type BasicReportType,
  type ProblemDetails,
  type ReportJobView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useEffect, useState } from "react";

import { ReportJobStatus } from "./report-job-status";
import { ReportHistory } from "./report-history";
import { RequestReportForm } from "./request-report-form";

const TERMINAL_STATUSES = new Set<ReportJobView["status"]>(["COMPLETED", "FAILED", "EXPIRED"]);

export function ReportManagement({
  initialReportId,
  organizationId,
}: {
  initialReportId?: string | undefined;
  organizationId: string;
}) {
  const [report, setReport] = useState<ReportJobView | null>(null);
  const [reports, setReports] = useState<readonly ReportJobView[]>([]);
  const [availableReportTypes, setAvailableReportTypes] = useState<readonly BasicReportType[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [feedback, setFeedback] = useState("");
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    void getReports(organizationId, controller.signal)
      .then((page) => {
        setReports(page.data);
        setAvailableReportTypes(page.availableReportTypes);
        setNextCursor(page.page.nextCursor);
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(errorMessage(error, "Não foi possível carregar o histórico."));
      });
    return () => controller.abort();
  }, [organizationId]);

  useEffect(() => {
    if (!initialReportId) return;
    const controller = new AbortController();
    void getReport(organizationId, initialReportId, controller.signal)
      .then(setReport)
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(errorMessage(error, "Não foi possível abrir o relatório informado."));
      });
    return () => controller.abort();
  }, [initialReportId, organizationId]);

  useEffect(() => {
    if (!report || TERMINAL_STATUSES.has(report.status)) return;
    const controller = new AbortController();
    const reportId = report.id;
    let timer: ReturnType<typeof setTimeout> | undefined;

    async function refresh() {
      try {
        const current = await getReport(organizationId, reportId, controller.signal);
        if (controller.signal.aborted) return;
        setReport(current);
        setReports((reports) => replaceReport(reports, current));
        setFeedback("");
        if (!TERMINAL_STATUSES.has(current.status)) timer = setTimeout(refresh, 2_500);
      } catch (error) {
        if (controller.signal.aborted) return;
        setFeedback(errorMessage(error, "Não foi possível atualizar o andamento."));
        timer = setTimeout(refresh, 5_000);
      }
    }

    timer = setTimeout(refresh, 2_500);
    return () => {
      controller.abort();
      if (timer) clearTimeout(timer);
    };
  }, [organizationId, report]);

  async function download() {
    if (!report) return;
    setDownloading(true);
    setFeedback("");
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/reports/${report.id}/download`,
      );
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) throw new Error(payload.detail ?? "Não foi possível preparar o download.");
      window.location.assign(reportDownloadViewSchema.parse(payload.data).url);
    } catch (error) {
      setFeedback(errorMessage(error, "Não foi possível preparar o download."));
    } finally {
      setDownloading(false);
    }
  }

  async function loadMore(cursor: string) {
    setFeedback("");
    try {
      const page = await getReports(organizationId, undefined, cursor);
      setReports((current) => mergeReports(current, page.data));
      setNextCursor(page.page.nextCursor);
    } catch (error) {
      setFeedback(errorMessage(error, "Não foi possível carregar mais relatórios."));
    }
  }

  function requested(requestedReport: ReportJobView) {
    setReport(requestedReport);
    setReports((current) => replaceReport(current, requestedReport));
  }

  return (
    <div className="grid gap-6">
      <RequestReportForm
        availableReportTypes={availableReportTypes}
        onRequested={requested}
        organizationId={organizationId}
      />
      {feedback ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
          role="alert"
        >
          {feedback}
        </p>
      ) : null}
      {report ? (
        <ReportJobStatus
          downloading={downloading}
          onDownload={() => void download()}
          report={report}
        />
      ) : null}
      <ReportHistory onSelect={setReport} reports={reports} />
      {nextCursor ? (
        <div className="flex justify-center">
          <Button onClick={() => void loadMore(nextCursor)} type="button" variant="outline">
            Carregar mais
          </Button>
        </div>
      ) : null}
    </div>
  );
}

async function getReports(organizationId: string, signal?: AbortSignal, cursor?: string) {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/reports?limit=20${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
    signal ? { signal } : undefined,
  );
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar o histórico.");
  return reportListPageSchema.parse(payload.data);
}

async function getReport(organizationId: string, reportId: string, signal: AbortSignal) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/reports/${reportId}`, {
    signal,
  });
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível atualizar o andamento.");
  return reportJobViewSchema.parse(payload.data);
}

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

function replaceReport(
  reports: readonly ReportJobView[],
  report: ReportJobView,
): readonly ReportJobView[] {
  return [report, ...reports.filter(({ id }) => id !== report.id)];
}

function mergeReports(
  current: readonly ReportJobView[],
  incoming: readonly ReportJobView[],
): readonly ReportJobView[] {
  const known = new Set(current.map(({ id }) => id));
  return [...current, ...incoming.filter(({ id }) => !known.has(id))];
}
