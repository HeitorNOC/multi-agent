"use client";

import { authClient } from "@gestor/auth/client";
import { Button } from "@gestor/ui/components/button";
import Link from "next/link";
import { useState, useSyncExternalStore } from "react";

import { getAuthenticationErrorMessage } from "../authentication-error";
import { FormFeedback } from "./form-feedback";

const PENDING_EMAIL_STORAGE_KEY = "gestor.pendingVerificationEmail";

function subscribeToPendingEmail() {
  return () => undefined;
}

function getPendingEmailSnapshot() {
  return window.sessionStorage.getItem(PENDING_EMAIL_STORAGE_KEY);
}

function getPendingEmailServerSnapshot() {
  return null;
}

export function VerifyEmailPanel() {
  const email = useSyncExternalStore(
    subscribeToPendingEmail,
    getPendingEmailSnapshot,
    getPendingEmailServerSnapshot,
  );
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);
  const [isSending, setIsSending] = useState(false);

  async function resend() {
    if (!email) {
      setIsError(true);
      setFeedback("Volte ao login e informe seu e-mail novamente.");
      return;
    }

    setFeedback(null);
    setIsSending(true);

    try {
      const result = await authClient.sendVerificationEmail({
        callbackURL: `${window.location.origin}/login?emailVerified=1`,
        email,
      });

      if (result.error) {
        setIsError(true);
        setFeedback(
          getAuthenticationErrorMessage(
            result.error,
            "Não foi possível reenviar agora. Aguarde um pouco e tente novamente.",
          ),
        );
        return;
      }

      setIsError(false);
      setFeedback("Se a conta estiver pendente, um novo link será enviado.");
    } catch {
      setIsError(true);
      setFeedback("Não foi possível conectar ao servidor. Tente novamente.");
    } finally {
      setIsSending(false);
    }
  }

  return (
    <div className="grid gap-6">
      <div className="rounded-2xl border bg-white p-5">
        <span
          aria-hidden="true"
          className="bg-brand-50 text-brand-700 grid size-11 place-items-center rounded-full text-xl"
        >
          ✉
        </span>
        <p className="mt-4 text-sm leading-6 text-slate-600">
          Enviamos um link de confirmação
          {email ? (
            <>
              {" "}
              para <strong className="font-semibold text-slate-900">{email}</strong>
            </>
          ) : null}
          . O link expira em 1 hora.
        </p>
      </div>

      {feedback ? (
        <FormFeedback kind={isError ? "error" : "success"}>{feedback}</FormFeedback>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSending} onClick={resend} type="button">
        {isSending ? "Reenviando..." : "Reenviar e-mail"}
      </Button>

      <Link
        className="text-brand-600 hover:text-brand-700 text-center text-sm font-semibold"
        href="/login"
      >
        Voltar para o login
      </Link>
    </div>
  );
}
