import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, list, resolve, start } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  list: vi.fn(),
  resolve: vi.fn(),
  start: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listPaymentCharges: { execute: list },
    resolveTenantActor: { execute: resolve },
    startTerminalPayment: { execute: start },
  },
}));

import { POST } from "./route";

it("starts a validated idempotent terminal charge", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolve.mockResolvedValue({ role: "OWNER" });
  start.mockResolvedValue({ id: "charge" });
  const params = {
    organizationId: "10000000-0000-4000-8000-000000000001",
    saleId: "10000000-0000-4000-8000-000000000002",
  };
  const body = {
    amount: "10.0000",
    method: "CARD",
    receivableId: "10000000-0000-4000-8000-000000000003",
    terminalDeviceId: "10000000-0000-4000-8000-000000000004",
  };
  const response = await POST(
    new Request("http://localhost/payment-charges", {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": "charge-key" },
      method: "POST",
    }),
    { params: Promise.resolve(params) },
  );
  expect(response.status).toBe(201);
  expect(start).toHaveBeenCalledWith(
    { ...body, ...params, idempotencyKey: "charge-key" },
    { role: "OWNER" },
  );
});
