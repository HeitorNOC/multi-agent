import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, cancelPurchase, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  cancelPurchase: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    cancelPurchase: { execute: cancelPurchase },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const purchaseId = "20000000-0000-4000-8000-000000000002";

describe("cancel purchase route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    cancelPurchase.mockReset().mockResolvedValue({ id: purchaseId, status: "CANCELLED" });
  });

  it("requires optimistic version and external idempotency", async () => {
    const body = { expectedUpdatedAt: "2026-08-12T12:00:00.000Z", reason: "Compra duplicada" };
    const response = await POST(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/purchases/${purchaseId}/cancel`,
        {
          body: JSON.stringify(body),
          headers: { "content-type": "application/json", "idempotency-key": "cancel-key" },
          method: "POST",
        },
      ),
      { params: Promise.resolve({ organizationId, purchaseId }) },
    );
    expect(response.status).toBe(200);
    expect(cancelPurchase).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "cancel-key", organizationId, purchaseId },
      { role: "OWNER" },
    );
  });
});
