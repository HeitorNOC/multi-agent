"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { authClient } from "@gestor/auth/client";
import { Button, buttonVariants } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { cn } from "@gestor/ui/lib/utils";
import Link from "next/link";
import { useState } from "react";
import { useForm } from "react-hook-form";

import { getAuthenticationErrorMessage } from "../authentication-error";
import { resetPasswordSchema, type ResetPasswordInput, type ResetPasswordValues } from "../schemas";
import { FormFeedback } from "./form-feedback";
import { PasswordInput } from "./password-input";

type ResetPasswordFormProps = {
  error?: string | undefined;
  token?: string | undefined;
};

const inputClassName = "h-11 rounded-xl bg-white px-3";

export function ResetPasswordForm({ error, token }: ResetPasswordFormProps) {
  const [wasReset, setWasReset] = useState(false);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
  } = useForm<ResetPasswordInput, undefined, ResetPasswordValues>({
    defaultValues: {
      confirmPassword: "",
      password: "",
    },
    resolver: zodResolver(resetPasswordSchema),
  });

  const hasValidToken = Boolean(token) && !error;

  const submit = handleSubmit(async (values) => {
    if (!token) return;

    try {
      const result = await authClient.resetPassword({
        newPassword: values.password,
        token,
      });

      if (result.error) {
        setError("root", {
          message: getAuthenticationErrorMessage(
            result.error,
            "Não foi possível redefinir a senha. Solicite um novo link.",
          ),
          type: result.error.code ?? "server",
        });
        return;
      }

      setWasReset(true);
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  if (wasReset) {
    return (
      <div className="grid gap-6">
        <FormFeedback kind="success">
          Senha redefinida. As sessões anteriores foram encerradas por segurança.
        </FormFeedback>
        <Link className={cn(buttonVariants(), "h-11 rounded-xl")} href="/login">
          Entrar com a nova senha
        </Link>
      </div>
    );
  }

  if (!hasValidToken) {
    return (
      <div className="grid gap-6">
        <FormFeedback kind="error">
          Este link é inválido ou expirou. Solicite novas instruções.
        </FormFeedback>
        <Link className={cn(buttonVariants(), "h-11 rounded-xl")} href="/recuperar-senha">
          Solicitar novo link
        </Link>
      </div>
    );
  }

  return (
    <form className="grid gap-5" noValidate onSubmit={submit}>
      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="reset-password">
          Nova senha
        </Label>
        <PasswordInput
          aria-describedby={
            errors.password ? "reset-password-help reset-password-error" : "reset-password-help"
          }
          aria-invalid={Boolean(errors.password)}
          autoComplete="new-password"
          className={inputClassName}
          id="reset-password"
          {...register("password")}
        />
        <p className="text-xs text-slate-500" id="reset-password-help">
          Use de 10 a 128 caracteres.
        </p>
        {errors.password ? (
          <p className="text-sm text-red-700" id="reset-password-error" role="alert">
            {errors.password.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="reset-confirm-password">
          Confirme a nova senha
        </Label>
        <PasswordInput
          aria-describedby={errors.confirmPassword ? "reset-confirm-password-error" : undefined}
          aria-invalid={Boolean(errors.confirmPassword)}
          autoComplete="new-password"
          className={inputClassName}
          id="reset-confirm-password"
          {...register("confirmPassword")}
        />
        {errors.confirmPassword ? (
          <p className="text-sm text-red-700" id="reset-confirm-password-error" role="alert">
            {errors.confirmPassword.message}
          </p>
        ) : null}
      </div>

      {errors.root?.message ? (
        <FormFeedback kind="error">{errors.root.message}</FormFeedback>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSubmitting} type="submit">
        {isSubmitting ? "Salvando..." : "Redefinir senha"}
      </Button>
    </form>
  );
}
