import { afterEach, describe, expect, it, vi } from "vitest";

import {
  createFinancialAccount,
  loadFinancialAccountConfiguration,
  toggleFinancialAccountStatus,
} from "./financial-account-api";

const account = {
  branchId: "00000000-0000-4000-8000-000000000002",
  createdAt: "2026-08-11T12:00:00.000Z",
  currentBalance: "100.0000",
  id: "00000000-0000-4000-8000-000000000003",
  initialBalance: "100.0000",
  initialBalanceDate: "2026-08-11",
  name: "Caixa",
  status: "ACTIVE",
  type: "CASH",
  updatedAt: "2026-08-11T12:00:00.000Z",
} as const;

afterEach(() => vi.unstubAllGlobals());

describe("financial account API", () => {
  it("returns a structured creation problem and preserves idempotency", async () => {
    const problem = { code: "INVALID_ACCOUNT", detail: "Conta inválida." };
    const fetchMock = vi.fn().mockResolvedValue(Response.json(problem, { status: 422 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      createFinancialAccount("org-1", { name: "Conta" } as never, "key-1"),
    ).resolves.toEqual({ data: null, problem });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/org-1/financial-accounts",
      expect.objectContaining({
        headers: { "content-type": "application/json", "idempotency-key": "key-1" },
        method: "POST",
      }),
    );
  });

  it("sends the inverse status and exposes API errors", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(Response.json({ detail: "Conflito de versão." }, { status: 409 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(
      toggleFinancialAccountStatus("org-1", { id: "account-1", status: "ACTIVE" } as never),
    ).rejects.toThrow("Conflito de versão.");
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/org-1/financial-accounts/account-1",
      expect.objectContaining({ body: JSON.stringify({ status: "INACTIVE" }), method: "PATCH" }),
    );
  });

  it("parses loaded configuration and successful mutations", async () => {
    const branch = {
      document: null,
      id: account.branchId,
      isHeadquarters: true,
      name: "Matriz",
      status: "ACTIVE",
    };
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(Response.json({ data: [account] }))
      .mockResolvedValueOnce(Response.json({ data: [branch] }))
      .mockResolvedValueOnce(Response.json({ data: account }))
      .mockResolvedValueOnce(
        Response.json({
          data: { ...account, status: "INACTIVE", updatedAt: "2026-08-11T13:00:00.000Z" },
        }),
      );
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      loadFinancialAccountConfiguration("org-1", new AbortController().signal),
    ).resolves.toEqual({ accounts: [account], branches: [branch] });
    await expect(
      createFinancialAccount("org-1", { name: "Caixa" } as never, "key-2"),
    ).resolves.toEqual({ data: account, problem: null });
    await expect(toggleFinancialAccountStatus("org-1", account as never)).resolves.toEqual({
      status: "INACTIVE",
      updated: { ...account, status: "INACTIVE", updatedAt: "2026-08-11T13:00:00.000Z" },
    });
  });
});
