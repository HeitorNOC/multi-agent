import Link from "next/link";
import type { ReactNode } from "react";

type AuthShellProps = {
  children: ReactNode;
  description: string;
  eyebrow: string;
  title: string;
};

const benefits = [
  "Caixa, vendas e estoque no mesmo lugar",
  "Informação simples para decidir melhor",
  "Segurança preparada para sua empresa crescer",
] as const;

export function AuthShell({ children, description, eyebrow, title }: AuthShellProps) {
  return (
    <main className="grid min-h-screen lg:grid-cols-[minmax(20rem,0.85fr)_minmax(32rem,1.15fr)]">
      <section className="relative hidden overflow-hidden bg-[#123e31] p-10 text-white lg:flex lg:flex-col lg:justify-between xl:p-16">
        <div
          aria-hidden="true"
          className="absolute -top-32 -right-32 size-96 rounded-full border border-white/10"
        />
        <div
          aria-hidden="true"
          className="absolute right-20 bottom-20 size-64 rounded-full bg-emerald-300/10 blur-3xl"
        />

        <Link className="relative inline-flex w-fit items-center gap-3" href="/">
          <span className="grid size-10 place-items-center rounded-xl bg-white text-sm font-black text-[#123e31]">
            G
          </span>
          <span className="text-lg font-semibold tracking-[-0.02em]">Gestor</span>
        </Link>

        <div className="relative max-w-lg">
          <p className="text-xs font-bold tracking-[0.2em] text-emerald-200 uppercase">
            Gestão sem complicação
          </p>
          <h2 className="mt-5 text-4xl leading-tight font-semibold tracking-[-0.04em] text-balance xl:text-5xl">
            Seu negócio organizado. Seu tempo de volta.
          </h2>
          <ul className="mt-10 grid gap-4">
            {benefits.map((benefit) => (
              <li className="flex items-center gap-3 text-sm text-emerald-50/90" key={benefit}>
                <span
                  aria-hidden="true"
                  className="grid size-6 shrink-0 place-items-center rounded-full bg-emerald-300/15 text-xs text-emerald-200"
                >
                  ✓
                </span>
                {benefit}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-emerald-100/60">
          Feito para quem precisa cuidar da empresa, não do sistema.
        </p>
      </section>

      <section className="flex min-h-screen items-center justify-center px-5 py-10 sm:px-8 lg:px-12">
        <div className="w-full max-w-md">
          <Link className="mb-10 inline-flex items-center gap-2 lg:hidden" href="/">
            <span className="bg-brand-600 grid size-9 place-items-center rounded-xl text-sm font-black text-white">
              G
            </span>
            <span className="font-semibold">Gestor</span>
          </Link>

          <header className="mb-8">
            <p className="text-brand-600 text-xs font-bold tracking-[0.16em] uppercase">
              {eyebrow}
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-4xl">
              {title}
            </h1>
            <p className="mt-3 text-sm leading-6 text-slate-600">{description}</p>
          </header>

          {children}
        </div>
      </section>
    </main>
  );
}
