import { describe, expect, it } from "vitest";

import { formatBrl, formatDate } from "./financial-account-format";

describe("financial account formatting", () => {
  it("formats positive and negative canonical balances", () => {
    expect(formatBrl("1234.5000")).toBe("R$ 1.234,50");
    expect(formatBrl("-10.2500")).toBe("- R$ 10,25");
    expect(formatDate("2026-08-11")).toBe("11/08/2026");
  });
});
