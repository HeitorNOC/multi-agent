"use client";

import { useEffect, useState } from "react";

import { authClient } from "@gestor/auth/client";
import QRCode from "qrcode";

import { parseTotpEnrollmentUri } from "../mfa-totp";

export function MfaEnrollment() {
  const [password, setPassword] = useState("");
  const [secret, setSecret] = useState<{
    backupCodes: readonly string[];
    manualKey: string;
    totpURI: string;
  }>();
  const [message, setMessage] = useState<string>();
  const [qrCode, setQrCode] = useState<string>();
  const [code, setCode] = useState("");
  const [verified, setVerified] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!secret) {
      setQrCode(undefined);
      return;
    }

    let active = true;
    void QRCode.toDataURL(secret.totpURI, { margin: 1, width: 208 }).then((value) => {
      if (active) setQrCode(value);
    });

    return () => {
      active = false;
    };
  }, [secret]);

  async function enable() {
    setSubmitting(true);
    setMessage(undefined);
    const result = await authClient.twoFactor.enable({ password });
    setSubmitting(false);
    if (result.error || !result.data) {
      setMessage(
        "Não foi possível ativar a autenticação em duas etapas. Confira sua senha e tente novamente.",
      );
      return;
    }
    try {
      const enrollment = parseTotpEnrollmentUri(result.data.totpURI);
      setPassword("");
      setSecret({ ...result.data, manualKey: enrollment.manualKey });
    } catch {
      setMessage("Não foi possível preparar a chave do aplicativo autenticador. Tente novamente.");
    }
  }

  async function verify() {
    setSubmitting(true);
    setMessage(undefined);
    const result = await authClient.twoFactor.verifyTotp({ code });
    setSubmitting(false);
    if (result.error) {
      setMessage("O código não foi aceito. Confira o aplicativo autenticador e tente novamente.");
      return;
    }
    setVerified(true);
    setCode("");
  }

  return (
    <section
      className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
      aria-labelledby="mfa-title"
    >
      <p className="text-brand-600 text-xs font-bold tracking-[0.18em] uppercase">
        Proteção adicional
      </p>
      <h2 className="mt-2 text-xl font-semibold text-slate-950" id="mfa-title">
        Autenticação em duas etapas
      </h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        Use um aplicativo autenticador para proteger sua conta, especialmente se ela tiver
        permissões administrativas ou financeiras.
      </p>
      {secret ? (
        <div className="mt-4 grid gap-3 text-sm">
          <p className="font-medium text-slate-900">Adicione a conta no aplicativo autenticador.</p>
          <p className="text-slate-600">
            Escaneie o QR Code abaixo quando seu aplicativo oferecer essa opção. Para configurar
            manualmente, informe a chave Base32 — não use o link que começa com <code>otpauth://</code>.
          </p>
          {qrCode ? (
            <img
              alt="QR Code para configurar a autenticação em duas etapas"
              className="h-52 w-52 rounded-lg border border-slate-200 bg-white p-2"
              src={qrCode}
            />
          ) : (
            <p className="text-slate-600">Gerando QR Code…</p>
          )}
          <div className="grid gap-1">
            <p className="font-medium text-slate-900">Chave manual</p>
            <code className="overflow-x-auto rounded-lg bg-slate-100 p-3 text-xs text-slate-800">
              {secret.manualKey}
            </code>
          </div>
          <p className="font-medium text-slate-900">
            Guarde os códigos de recuperação em local seguro. Eles aparecem somente agora:
          </p>
          <ul className="grid grid-cols-2 gap-2 rounded-lg bg-amber-50 p-3 font-mono text-sm text-slate-900 sm:grid-cols-3">
            {secret.backupCodes.map((backupCode) => (
              <li key={backupCode}>{backupCode}</li>
            ))}
          </ul>
          {verified ? (
            <p className="font-medium text-emerald-700">Autenticação em duas etapas ativada.</p>
          ) : (
            <form
              className="grid max-w-sm gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                void verify();
              }}
            >
              <label className="grid gap-1 font-medium text-slate-800">
                Código de seis dígitos
                <input
                  autoComplete="one-time-code"
                  className="rounded-lg border border-slate-300 px-3 py-2"
                  inputMode="numeric"
                  onChange={(event) => setCode(event.target.value)}
                  pattern="[0-9]{6}"
                  required
                  value={code}
                />
              </label>
              <button
                className="bg-brand-600 hover:bg-brand-700 rounded-lg px-3 py-2 font-semibold text-white disabled:opacity-60"
                disabled={submitting}
                type="submit"
              >
                {submitting ? "Confirmando..." : "Confirmar código"}
              </button>
            </form>
          )}
        </div>
      ) : (
        <form
          className="mt-4 flex max-w-md flex-col gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            void enable();
          }}
        >
          <label className="grid gap-1 text-sm font-medium text-slate-800">
            Confirme sua senha
            <input
              autoComplete="current-password"
              className="rounded-lg border border-slate-300 px-3 py-2"
              onChange={(event) => setPassword(event.target.value)}
              required
              type="password"
              value={password}
            />
          </label>
          <button
            className="bg-brand-600 hover:bg-brand-700 rounded-lg px-3 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
            disabled={submitting}
            type="submit"
          >
            {submitting ? "Ativando..." : "Ativar autenticação em duas etapas"}
          </button>
        </form>
      )}
      {message ? (
        <p className="mt-3 text-sm text-red-700" role="alert">
          {message}
        </p>
      ) : null}
    </section>
  );
}
