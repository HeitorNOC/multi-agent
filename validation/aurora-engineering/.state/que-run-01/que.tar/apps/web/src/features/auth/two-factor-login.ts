export type TwoFactorRedirect = {
  twoFactorMethods?: string[];
  twoFactorRedirect: true;
};

export function isTwoFactorRedirect(value: unknown): value is TwoFactorRedirect {
  if (!isRecord(value) || value.twoFactorRedirect !== true) return false;
  return value.twoFactorMethods === undefined || Array.isArray(value.twoFactorMethods);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
