import type { OrganizationModuleView } from "@gestor/contracts";
import { describe, expect, it } from "vitest";

import { resolveModuleAccessPresentation } from "./module-access";

function moduleWith(mode: "ENABLED" | "READ_ONLY" | "DISABLED"): OrganizationModuleView {
  return {
    access: { mode, reason: mode === "ENABLED" ? null : "MODULE_DISABLED" },
    assignment: null,
    category: "FINANCE",
    code: "financial",
    description: "Financeiro",
    isCore: false,
    name: "Financeiro",
    requiredModuleCodes: ["core"],
  };
}

describe("resolveModuleAccessPresentation", () => {
  it("allows the complete interface for an enabled module", () => {
    expect(resolveModuleAccessPresentation([moduleWith("ENABLED")], "financial")).toEqual({
      mode: "ENABLED",
      reason: null,
    });
  });

  it("preserves read access after a downgrade", () => {
    expect(resolveModuleAccessPresentation([moduleWith("READ_ONLY")], "financial").mode).toBe(
      "READ_ONLY",
    );
  });

  it("fails closed when the module is disabled or absent", () => {
    expect(resolveModuleAccessPresentation([moduleWith("DISABLED")], "financial").mode).toBe(
      "DISABLED",
    );
    expect(resolveModuleAccessPresentation([], "financial").mode).toBe("DISABLED");
  });
});
