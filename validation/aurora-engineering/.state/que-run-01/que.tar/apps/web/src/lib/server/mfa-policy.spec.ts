import { describe, expect, it } from "vitest";

import { requireMfaForPlatformRole } from "./mfa-policy";

describe("MFA platform policy", () => {
  it("requires MFA for platform owners and administrators", () => {
    expect(() => requireMfaForPlatformRole({ mfaEnabled: false, userId: "user" }, "OWNER")).toThrow(
      /autenticação em duas etapas/i,
    );
  });

  it("keeps support access and MFA-protected administrators available", () => {
    expect(() =>
      requireMfaForPlatformRole({ mfaEnabled: false, userId: "user" }, "SUPPORT"),
    ).not.toThrow();
    expect(() =>
      requireMfaForPlatformRole({ mfaEnabled: true, userId: "user" }, "ADMIN"),
    ).not.toThrow();
  });
});

it("requires MFA before financial mutations when the actor has the sensitive permission", async () => {
  const { requireMfaForFinancialMutation } = await import("./mfa-policy");
  const actor = {
    permissions: new Set(["financial_transfer.manage"]),
  } as never;
  expect(() =>
    requireMfaForFinancialMutation(
      { mfaEnabled: false, userId: "user" },
      actor,
      "financial_transfer.manage",
    ),
  ).toThrow(/operação financeira/i);
});
