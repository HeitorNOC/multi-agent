import {
  financialCategoryParamsSchema,
  updateFinancialCategoryBodySchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{
    financialCategoryId: string;
    organizationId: string;
  }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = financialCategoryParamsSchema.parse(await route.params);
    const body = updateFinancialCategoryBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const category = await services.updateFinancialCategory.execute({ ...params, ...body }, actor);

    return Response.json({ data: category });
  });
}
