import { beforeEach, describe, expect, it, vi } from "vitest";

const { authenticate, requireCurrentLegalAcceptance, createCashOperation, resolveTenantActor } =
  vi.hoisted(() => ({
    authenticate: vi.fn(),
    requireCurrentLegalAcceptance: vi.fn(),
    createCashOperation: vi.fn(),
    resolveTenantActor: vi.fn(),
  }));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance }));
vi.mock("@/lib/server/container", () => ({
  services: {
    createCashOperation: { execute: createCashOperation },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "51000000-0000-4000-8000-000000000001";
const cashRegisterId = "51000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ cashRegisterId, organizationId }) };

describe("cash operation route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    requireCurrentLegalAcceptance.mockReset().mockResolvedValue(undefined);
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OPERATOR" });
    createCashOperation.mockReset().mockResolvedValue({ operation: { type: "WITHDRAWAL" } });
  });

  it("records a versioned and idempotent operation", async () => {
    const body = {
      amount: "25",
      expectedVersion: 3,
      reason: "Compra emergencial",
      type: "WITHDRAWAL",
    };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers/${cashRegisterId}/operations`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "operation-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(createCashOperation).toHaveBeenCalledWith(
      { ...body, cashRegisterId, idempotencyKey: "operation-key", organizationId },
      { role: "OPERATOR" },
    );
  });

  it("rejects zero amounts after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers/${cashRegisterId}/operations`,
      {
        body: JSON.stringify({
          amount: "0",
          expectedVersion: 3,
          reason: "Valor inválido",
          type: "SUPPLY",
        }),
        headers: { "content-type": "application/json", "idempotency-key": "operation-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
  });
});
