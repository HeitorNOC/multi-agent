import type { BranchView, FoodServiceDiningAreaView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";

export function FoodServiceDiningConfiguration({
  areas,
  branches,
  branchId,
  onAddArea,
  onAddTable,
  onBranchChange,
}: {
  areas: readonly FoodServiceDiningAreaView[];
  branches: readonly BranchView[];
  branchId: string;
  onAddArea: (event: React.FormEvent<HTMLFormElement>) => void;
  onAddTable: (event: React.FormEvent<HTMLFormElement>) => void;
  onBranchChange: (branchId: string) => void;
}) {
  return (
    <>
      <div>
        <h2 className="text-lg font-semibold">Salão</h2>
        <p className="mt-1 text-sm text-slate-600">
          Organize áreas e mesas por filial. A abertura só ocupa a mesa; ela ainda não cria venda,
          cobrança ou baixa de estoque.
        </p>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="branch">Filial</Label>
        <select
          className="h-10 max-w-md rounded-xl border px-3"
          id="branch"
          onChange={(event) => onBranchChange(event.target.value)}
          value={branchId}
        >
          {branches
            .filter((branch) => branch.status === "ACTIVE")
            .map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
        </select>
      </div>
      <details className="rounded-xl border bg-white p-4">
        <summary className="cursor-pointer font-semibold text-slate-900">
          Configurar áreas e mesas
        </summary>
        <p className="mt-2 text-sm text-slate-600">
          Cadastre ou ajuste a estrutura física apenas quando necessário. O atendimento do dia fica
          separado logo abaixo.
        </p>
        <div className="mt-4 grid gap-5 lg:grid-cols-2">
          <form className="grid gap-3 rounded-xl border p-4" onSubmit={onAddArea}>
            <h3 className="font-semibold">Nova área</h3>
            <input
              className="h-10 rounded-xl border px-3"
              name="name"
              placeholder="Ex.: Varanda"
              required
            />
            <input
              className="h-10 rounded-xl border px-3"
              min="0"
              name="displayOrder"
              placeholder="Ordem de exibição"
              type="number"
            />
            <Button disabled={!branchId} type="submit">
              Adicionar área
            </Button>
          </form>
          <form className="grid gap-3 rounded-xl border p-4" onSubmit={onAddTable}>
            <h3 className="font-semibold">Nova mesa</h3>
            <select className="h-10 rounded-xl border px-3" name="areaId" required>
              <option value="">Selecione uma área</option>
              {areas.map((area) => (
                <option key={area.id} value={area.id}>
                  {area.name}
                </option>
              ))}
            </select>
            <div className="grid grid-cols-2 gap-3">
              <input
                className="h-10 rounded-xl border px-3"
                name="code"
                placeholder="Mesa 01"
                required
              />
              <input
                className="h-10 rounded-xl border px-3"
                min="1"
                name="capacity"
                placeholder="Lugares"
                required
                type="number"
              />
            </div>
            <Button disabled={!branchId || areas.length === 0} type="submit">
              Adicionar mesa
            </Button>
          </form>
        </div>
      </details>
    </>
  );
}
