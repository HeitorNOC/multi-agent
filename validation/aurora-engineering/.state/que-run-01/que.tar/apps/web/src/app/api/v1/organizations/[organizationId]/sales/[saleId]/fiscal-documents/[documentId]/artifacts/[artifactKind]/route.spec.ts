import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createDownload, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createDownload: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    createFiscalDocumentDownload: { execute: createDownload },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const params = {
  artifactKind: "xml",
  documentId: "10000000-0000-4000-8000-000000000003",
  organizationId: "10000000-0000-4000-8000-000000000001",
  saleId: "10000000-0000-4000-8000-000000000002",
};

it("forwards a validated fiscal artifact download", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  createDownload.mockResolvedValue({ url: "https://storage.example/signed" });
  const response = await GET(new Request("http://localhost/fiscal-artifact"), {
    params: Promise.resolve(params),
  });
  expect(response.status).toBe(200);
  expect(createDownload).toHaveBeenCalledWith(params, { role: "OWNER" });
});
