import type {
  BranchView,
  CreateFinancialObligationBody,
  FinancialCategoryView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import type { FormEventHandler } from "react";
import type { FieldErrors, UseFormRegister } from "react-hook-form";

import { Field } from "./financial-obligation-ui";

type FinancialObligationFormProps = {
  activeBranches: readonly BranchView[];
  availableCategories: readonly FinancialCategoryView[];
  branchesLoaded: boolean;
  categoriesLoaded: boolean;
  errors: FieldErrors<CreateFinancialObligationBody>;
  isSubmitting: boolean;
  kind: CreateFinancialObligationBody["kind"];
  register: UseFormRegister<CreateFinancialObligationBody>;
  submit: FormEventHandler<HTMLFormElement>;
};

export function FinancialObligationForm({
  activeBranches,
  availableCategories,
  branchesLoaded,
  categoriesLoaded,
  errors,
  isSubmitting,
  kind,
  register,
  submit,
}: FinancialObligationFormProps) {
  return (
    <section
      aria-labelledby="new-obligation-title"
      className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7"
    >
      <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Nova conta</p>
      <h2 className="mt-2 text-xl font-semibold text-slate-950" id="new-obligation-title">
        Compromisso financeiro
      </h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        Registre o que precisa receber ou pagar. O caixa só será alterado quando houver uma
        liquidação confirmada.
      </p>

      <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field error={errors.kind?.message} htmlFor="obligation-kind" label="Tipo">
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="obligation-kind"
              {...register("kind")}
            >
              <option value="RECEIVABLE">Conta a receber</option>
              <option value="PAYABLE">Conta a pagar</option>
            </select>
          </Field>
          <Field error={errors.origin?.message} htmlFor="obligation-origin" label="Origem">
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="obligation-origin"
              {...register("origin")}
            >
              <option value="MANUAL">Cadastro manual</option>
              <option value="IMPORT">Implantação / importação</option>
            </select>
          </Field>
        </div>

        <Field
          error={errors.counterpartyName?.message}
          htmlFor="obligation-counterparty"
          label={kind === "RECEIVABLE" ? "Cliente" : "Fornecedor"}
        >
          <Input
            id="obligation-counterparty"
            placeholder={kind === "RECEIVABLE" ? "Nome do cliente" : "Nome do fornecedor"}
            {...register("counterpartyName")}
          />
        </Field>

        <Field
          error={errors.description?.message}
          htmlFor="obligation-description"
          label="Descrição"
        >
          <Input
            id="obligation-description"
            placeholder="Ex.: Mensalidade de julho"
            {...register("description")}
          />
        </Field>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field error={errors.branchId?.message} htmlFor="obligation-branch" label="Filial">
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="obligation-branch"
              {...register("branchId")}
            >
              <option value="">Selecione</option>
              {activeBranches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                  {branch.isHeadquarters ? " — Matriz" : ""}
                </option>
              ))}
            </select>
          </Field>
          <Field error={errors.categoryId?.message} htmlFor="obligation-category" label="Categoria">
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="obligation-category"
              {...register("categoryId")}
            >
              <option value="">Selecione</option>
              {availableCategories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </Field>
        </div>

        <Field error={errors.originalAmount?.message} htmlFor="obligation-amount" label="Valor">
          <Input
            id="obligation-amount"
            inputMode="decimal"
            placeholder="0,00"
            {...register("originalAmount")}
          />
        </Field>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field
            error={errors.competencyDate?.message}
            htmlFor="obligation-competency"
            label="Competência"
          >
            <Input id="obligation-competency" type="date" {...register("competencyDate")} />
          </Field>
          <Field error={errors.dueDate?.message} htmlFor="obligation-due-date" label="Vencimento">
            <Input id="obligation-due-date" type="date" {...register("dueDate")} />
          </Field>
        </div>

        {errors.root?.message ? (
          <div
            className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
            role="alert"
          >
            {errors.root.message}
          </div>
        ) : null}

        <Button disabled={isSubmitting || !branchesLoaded || !categoriesLoaded} type="submit">
          {isSubmitting ? "Registrando..." : "Registrar conta"}
        </Button>
      </form>
    </section>
  );
}
