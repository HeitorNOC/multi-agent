import { publicAppointmentSlotsQuerySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ token: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { token } = await route.params;
      const query = publicAppointmentSlotsQuerySchema.parse(
        Object.fromEntries(new URL(request.url).searchParams.entries()),
      );
      const identity = await authenticateApiRequest(request);
      const link = await services.resolvePublicAppointmentPortalLink.execute(token);
      if (link.branchId && link.branchId !== query.branchId)
        return Response.json({ data: { startsAt: [] } });
      const actor = await services.resolveCustomerPortalActor.execute({
        correlationId: api.correlationId,
        organizationId: link.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });
      return Response.json({
        data: await services.listPublicAppointmentSlots.execute(query, actor),
      });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}
