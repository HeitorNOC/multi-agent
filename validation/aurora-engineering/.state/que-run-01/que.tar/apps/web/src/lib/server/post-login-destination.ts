import { prisma, runInUserTransaction } from "@gestor/database";

/**
 * Returns the owner's most recently provisioned workspace. The query runs in
 * a user-scoped transaction, so the database policy only exposes rows owned
 * by the authenticated account.
 */
export async function getPostLoginDestination(userId: string): Promise<string> {
  return runInUserTransaction(prisma, userId, async (transaction) => {
    const provisioning = await transaction.organizationProvisioning.findFirst({
      orderBy: { createdAt: "desc" },
      select: { organizationId: true },
      where: { userId },
    });

    return provisioning ? `/organizations/${provisioning.organizationId}` : "/onboarding";
  });
}
