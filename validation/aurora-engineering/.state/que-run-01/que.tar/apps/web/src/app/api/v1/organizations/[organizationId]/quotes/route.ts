import { createQuoteBodySchema, organizationParamsSchema } from "@gestor/contracts";
import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ organizationId: string }> };
async function actor(
  request: Request,
  organizationId: string,
  correlationId: string,
  requestId: string,
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({
    correlationId,
    organizationId,
    requestId,
    userId: identity.userId,
  });
}
export async function GET(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    return Response.json({
      data: await services.listQuotes.execute(
        organizationId,
        await actor(request, organizationId, api.correlationId, api.requestId),
      ),
    });
  });
}
export async function POST(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    const body = createQuoteBodySchema.parse(await readJsonBody(request));
    return Response.json(
      {
        data: await services.createQuote.execute(
          { ...body, idempotencyKey: requireIdempotencyKey(request), organizationId },
          await actor(request, organizationId, api.correlationId, api.requestId),
        ),
      },
      { status: 201 },
    );
  });
}
