import { describe, expect, it } from "vitest";

import { requireInternalJobAccess } from "./internal-job-access";

describe("internal job access", () => {
  const secret = "s".repeat(32);

  it("accepts the configured bearer token", () => {
    expect(() =>
      requireInternalJobAccess(
        new Request("https://hml.test/internal", {
          headers: { authorization: `Bearer ${secret}` },
        }),
        secret,
      ),
    ).not.toThrow();
  });

  it("rejects absent or different tokens", () => {
    expect(() =>
      requireInternalJobAccess(new Request("https://hml.test/internal"), secret),
    ).toThrowError(expect.objectContaining({ code: "INTERNAL_JOB_AUTHENTICATION_REQUIRED" }));
    expect(() =>
      requireInternalJobAccess(
        new Request("https://hml.test/internal", {
          headers: { authorization: `Bearer ${"x".repeat(32)}` },
        }),
        secret,
      ),
    ).toThrowError(expect.objectContaining({ code: "INTERNAL_JOB_AUTHENTICATION_REQUIRED" }));
  });
});
