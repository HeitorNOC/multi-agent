export function canonicalMoney(value: string): string {
  const normalized = value.trim().replace(",", ".");
  const [integer = "0", fraction = ""] = normalized.split(".");
  return `${BigInt(integer || "0")}.${fraction.padEnd(4, "0").slice(0, 4)}`;
}

export function moneyEquals(left: string, right: string): boolean {
  try {
    return canonicalMoney(left) === canonicalMoney(right);
  } catch {
    return false;
  }
}

export function formatBrl(value: string): string {
  const normalized = canonicalMoney(value);
  const [integer = "0", fraction = "0000"] = normalized.split(".");
  return `R$ ${BigInt(integer).toLocaleString("pt-BR")},${fraction.slice(0, 2)}`;
}

export function formatSignedBrl(value: string): string {
  const formatted = formatBrl(value.replace("-", ""));
  return value.startsWith("-") ? `-${formatted}` : formatted;
}

export function formatDateTime(value: string): string {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(
    new Date(value),
  );
}
