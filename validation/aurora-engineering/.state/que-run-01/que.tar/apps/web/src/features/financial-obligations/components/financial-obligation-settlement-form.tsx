"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  settleFinancialObligationBodySchema,
  settleFinancialObligationResultSchema,
  type FinancialAccountView,
  type FinancialObligationView,
  type PaymentMethodConfigurationView,
  type ProblemDetails,
  type SettleFinancialObligationBody,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { Field } from "./financial-obligation-ui";
import {
  availableSettlementAccounts,
  availableSettlementMethods,
} from "./financial-obligation-settlement-options";

export function SettlementForm({
  financialAccounts,
  obligation,
  onCancel,
  onSettled,
  organizationId,
  paymentMethods,
  today,
}: {
  financialAccounts: readonly FinancialAccountView[];
  obligation: FinancialObligationView;
  onCancel: () => void;
  onSettled: (obligation: FinancialObligationView) => void;
  organizationId: string;
  paymentMethods: readonly PaymentMethodConfigurationView[];
  today: string;
}) {
  const [idempotencyKey] = useState(() => crypto.randomUUID());
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
    setValue,
  } = useForm<SettleFinancialObligationBody>({
    defaultValues: {
      amount: obligation.openAmount,
      expectedVersion: obligation.version,
      financialAccountId: "",
      kind: obligation.kind,
      occurredDate: today,
      paymentMethodConfigurationId: "",
    },
    resolver: zodResolver(settleFinancialObligationBodySchema),
  });
  const configurationId = useWatch({ control, name: "paymentMethodConfigurationId" });
  const availableMethods = useMemo(
    () => availableSettlementMethods(paymentMethods, obligation.kind),
    [obligation.kind, paymentMethods],
  );
  const selectedMethod = availableMethods.find(
    (configuration) => configuration.id === configurationId,
  )?.method;
  const availableAccounts = useMemo(
    () => availableSettlementAccounts(financialAccounts, obligation.branchId, selectedMethod),
    [financialAccounts, obligation.branchId, selectedMethod],
  );

  useEffect(() => {
    setValue("financialAccountId", "");
  }, [configurationId, setValue]);

  const submit = handleSubmit(async (values) => {
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/financial-obligations/${obligation.id}/settle`,
        {
          body: JSON.stringify(values),
          headers: {
            "content-type": "application/json",
            "idempotency-key": idempotencyKey,
          },
          method: "POST",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const result = settleFinancialObligationResultSchema.parse(payload.data);
      onSettled(result.obligation);
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <form className="mt-4 grid gap-4 border-t pt-4" noValidate onSubmit={submit}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          error={errors.amount?.message}
          htmlFor={`settlement-amount-${obligation.id}`}
          label="Valor"
        >
          <Input
            id={`settlement-amount-${obligation.id}`}
            inputMode="decimal"
            {...register("amount")}
          />
        </Field>
        <Field
          error={errors.occurredDate?.message}
          htmlFor={`settlement-date-${obligation.id}`}
          label="Data"
        >
          <Input
            id={`settlement-date-${obligation.id}`}
            max={today}
            type="date"
            {...register("occurredDate")}
          />
        </Field>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          error={errors.paymentMethodConfigurationId?.message}
          htmlFor={`settlement-method-${obligation.id}`}
          label="Forma de pagamento"
        >
          <select
            className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
            id={`settlement-method-${obligation.id}`}
            {...register("paymentMethodConfigurationId")}
          >
            <option value="">Selecione</option>
            {availableMethods.map((configuration) => (
              <option key={configuration.id} value={configuration.id}>
                {configuration.name}
              </option>
            ))}
          </select>
        </Field>
        <Field
          error={errors.financialAccountId?.message}
          htmlFor={`settlement-account-${obligation.id}`}
          label={obligation.kind === "RECEIVABLE" ? "Conta de entrada" : "Conta de saída"}
        >
          <select
            className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
            disabled={!selectedMethod}
            id={`settlement-account-${obligation.id}`}
            {...register("financialAccountId")}
          >
            <option value="">Selecione</option>
            {availableAccounts.map((account) => (
              <option key={account.id} value={account.id}>
                {account.name}
              </option>
            ))}
          </select>
        </Field>
      </div>

      {selectedMethod === "CASH" ? (
        <p className="text-xs leading-5 text-slate-500">
          O caixa físico deve estar aberto nesta filial pelo seu usuário.
        </p>
      ) : null}
      {selectedMethod && availableAccounts.length === 0 ? (
        <p className="text-xs leading-5 text-amber-800">
          Não há uma conta financeira compatível e ativa para esta forma de pagamento.
        </p>
      ) : null}
      {availableMethods.length === 0 ? (
        <p className="text-xs leading-5 text-amber-800">
          Cadastre uma forma de pagamento ativa para concluir a baixa.
        </p>
      ) : null}
      {errors.root?.message ? (
        <div
          className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
          role="alert"
        >
          {errors.root.message}
        </div>
      ) : null}

      <div className="flex flex-wrap gap-2">
        <Button disabled={isSubmitting || availableMethods.length === 0} size="sm" type="submit">
          {isSubmitting
            ? "Confirmando..."
            : obligation.kind === "RECEIVABLE"
              ? "Confirmar recebimento"
              : "Confirmar pagamento"}
        </Button>
        <Button
          disabled={isSubmitting}
          onClick={onCancel}
          size="sm"
          type="button"
          variant="outline"
        >
          Voltar
        </Button>
      </div>
    </form>
  );
}
