import { describe, expect, it, vi } from "vitest";

import { keyForPendingOperation } from "./idempotency-key";

describe("keyForPendingOperation", () => {
  it("reuses the key when an operation is retried", () => {
    const createKey = vi.fn(() => "new-key");
    expect(keyForPendingOperation({ "order-1": "existing-key" }, "order-1", createKey)).toBe(
      "existing-key",
    );
    expect(createKey).not.toHaveBeenCalled();
  });

  it("creates a key for a new operation", () => {
    expect(keyForPendingOperation({}, "order-1", () => "new-key")).toBe("new-key");
  });
});
