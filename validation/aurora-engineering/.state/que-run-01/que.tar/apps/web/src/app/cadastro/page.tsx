import type { Metadata } from "next";
import { isGoogleAuthConfigured } from "@gestor/config";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { SignUpForm } from "@/features/auth/components/sign-up-form";
import { FormFeedback } from "@/features/auth/components/form-feedback";
import { safeReturnTo } from "@/features/auth/return-to";

export const metadata: Metadata = {
  title: "Criar conta | Gestor",
};

export default async function SignUpPage({
  searchParams,
}: {
  searchParams: Promise<{ oauthError?: string; returnTo?: string }>;
}) {
  const params = await searchParams;
  return (
    <AuthShell
      description="Comece com seus dados de acesso. A configuração da empresa vem logo depois."
      eyebrow="Primeiro acesso"
      title="Crie sua conta"
    >
      <div className="grid gap-5">
        {params.oauthError === "1" ? (
          <FormFeedback kind="error">
            Não foi possível continuar com o Google. Tente novamente ou use seu e-mail.
          </FormFeedback>
        ) : null}
        <SignUpForm
          googleEnabled={isGoogleAuthConfigured()}
          {...(safeReturnTo(params.returnTo) ? { returnTo: params.returnTo } : {})}
        />
      </div>
    </AuthShell>
  );
}
