import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { CustomFieldConfigurations } from "@/features/custom-fields/components/custom-field-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";
import { SupplierConfigurations } from "@/features/suppliers/components/supplier-configurations";

export const metadata: Metadata = { title: "Fornecedores | Gestor" };

export default async function SuppliersPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">CRM</p>
        <h1 className="mt-2 text-3xl font-semibold">Fornecedores</h1>
        <p className="mt-2 text-sm text-slate-600">
          Cadastre os contatos que serão usados em compras, produtos fornecidos e contas a pagar.
        </p>
      </header>
      <ModuleGate moduleCode="crm" organizationId={organizationId}>
        <SupplierConfigurations organizationId={organizationId} />
        <CustomFieldConfigurations entity="SUPPLIER" organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
