import {
  GetPublicCart,
  ListPublicCatalog,
  ListPublicOrders,
  CreatePublicOrder,
  ListCustomerPortalOrders,
  UpdateCustomerPortalOrderStatus,
  ConfirmCustomerPortalOrderDelivery,
  ConfirmCustomerPortalOrderReceipt,
  DispatchCustomerPortalOrder,
  ReportCustomerPortalOrderDeliveryIssue,
  ResolveCustomerPortalOrderDeliveryIssue,
  AssumeCustomerPortalOrderDeliveryIssue,
  RemovePublicCartItem,
  ResolvePublicCatalogPortalLink,
  SetPublicCartItem,
} from "@gestor/catalog";
import {
  PrismaPublicCatalogPortalLinkRepository,
  PrismaPublicCatalogRepository,
  PrismaPublicCartRepository,
  PrismaPublicOrderRepository,
} from "@gestor/catalog/prisma";
import type { PrismaClient } from "@gestor/database";
import { getAuthEnv } from "@gestor/config";
import { EnsureCustomerPortalMembership, ResolveCustomerPortalActor } from "@gestor/identity";
import {
  PrismaCustomerPortalActorResolver,
  PrismaCustomerPortalMembershipProvisioner,
} from "@gestor/identity/prisma";
import {
  CreatePublicAppointment,
  CancelPublicAppointment,
  ListPublicAppointments,
  ListPublicAppointmentOptions,
  ListPublicAppointmentSlots,
  ResolvePublicAppointmentPortalLink,
  ReschedulePublicAppointment,
} from "@gestor/scheduling";
import {
  PrismaPublicAppointmentOptionsRepository,
  PrismaPublicAppointmentSlotsRepository,
  PrismaSchedulingUnitOfWork,
} from "@gestor/scheduling/prisma";
import { PrismaPublicAppointmentPortalLinkRepository } from "@gestor/scheduling/prisma";

export function createCustomerPortalServices(prisma: PrismaClient) {
  const memberships = new PrismaCustomerPortalMembershipProvisioner(prisma);
  const appointmentLinks = new PrismaPublicAppointmentPortalLinkRepository(prisma);
  const catalogLinks = new PrismaPublicCatalogPortalLinkRepository(prisma);
  const carts = new PrismaPublicCartRepository(prisma);
  const orders = new PrismaPublicOrderRepository(prisma, getAuthEnv().BETTER_AUTH_SECRET);

  return {
    ensureCustomerPortalMembership: new EnsureCustomerPortalMembership(memberships),
    listPublicCatalog: new ListPublicCatalog(new PrismaPublicCatalogRepository(prisma)),
    listPublicOrders: new ListPublicOrders(orders),
    getPublicCart: new GetPublicCart(carts),
    setPublicCartItem: new SetPublicCartItem(carts),
    removePublicCartItem: new RemovePublicCartItem(carts),
    createPublicOrder: new CreatePublicOrder(orders),
    listCustomerPortalOrders: new ListCustomerPortalOrders(orders),
    updateCustomerPortalOrderStatus: new UpdateCustomerPortalOrderStatus(orders),
    confirmCustomerPortalOrderDelivery: new ConfirmCustomerPortalOrderDelivery(orders),
    confirmCustomerPortalOrderReceipt: new ConfirmCustomerPortalOrderReceipt(orders),
    dispatchCustomerPortalOrder: new DispatchCustomerPortalOrder(orders),
    reportCustomerPortalOrderDeliveryIssue: new ReportCustomerPortalOrderDeliveryIssue(orders),
    resolveCustomerPortalOrderDeliveryIssue: new ResolveCustomerPortalOrderDeliveryIssue(orders),
    assumeCustomerPortalOrderDeliveryIssue: new AssumeCustomerPortalOrderDeliveryIssue(orders),
    createPublicAppointment: new CreatePublicAppointment(new PrismaSchedulingUnitOfWork(prisma)),
    cancelPublicAppointment: new CancelPublicAppointment(new PrismaSchedulingUnitOfWork(prisma)),
    listPublicAppointments: new ListPublicAppointments(new PrismaSchedulingUnitOfWork(prisma)),
    listPublicAppointmentOptions: new ListPublicAppointmentOptions(
      new PrismaPublicAppointmentOptionsRepository(prisma),
    ),
    listPublicAppointmentSlots: new ListPublicAppointmentSlots(
      new PrismaPublicAppointmentSlotsRepository(prisma),
    ),
    resolvePublicCatalogPortalLink: new ResolvePublicCatalogPortalLink(catalogLinks),
    resolveCustomerPortalActor: new ResolveCustomerPortalActor(
      new PrismaCustomerPortalActorResolver(prisma),
    ),
    reschedulePublicAppointment: new ReschedulePublicAppointment(
      new PrismaSchedulingUnitOfWork(prisma),
    ),
    resolvePublicAppointmentPortalLink: new ResolvePublicAppointmentPortalLink(appointmentLinks),
  };
}
