import { afterEach, describe, expect, it, vi } from "vitest";

import {
  createFinancialCategory,
  loadFinancialCategories,
  toggleFinancialCategoryStatus,
} from "./financial-category-api";

afterEach(() => vi.unstubAllGlobals());

const category = {
  createdAt: "2026-08-11T12:00:00.000Z",
  id: "00000000-0000-4000-8000-000000000010",
  name: "Vendas",
  parentId: null,
  status: "ACTIVE",
  type: "REVENUE",
  updatedAt: "2026-08-11T12:00:00.000Z",
} as const;

describe("financial category API", () => {
  it("surfaces loading errors", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValue(Response.json({ detail: "Categorias indisponíveis." }, { status: 503 })),
    );
    await expect(loadFinancialCategories("org-1", new AbortController().signal)).rejects.toThrow(
      "Categorias indisponíveis.",
    );
  });

  it("preserves creation idempotency", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(Response.json({ code: "INVALID", detail: "Inválida." }, { status: 422 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(
      createFinancialCategory("org-1", { name: "Receita" } as never, "key-1"),
    ).resolves.toEqual({
      data: null,
      problem: { code: "INVALID", detail: "Inválida." },
    });
    expect(fetchMock.mock.calls[0]?.[1]).toEqual(
      expect.objectContaining({
        headers: { "content-type": "application/json", "idempotency-key": "key-1" },
      }),
    );
  });

  it("uses the inverse status on update", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(Response.json({ detail: "Categoria em uso." }, { status: 409 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(
      toggleFinancialCategoryStatus("org-1", { id: "category-1", status: "INACTIVE" } as never),
    ).rejects.toThrow("Categoria em uso.");
    expect(fetchMock.mock.calls[0]?.[1]).toEqual(
      expect.objectContaining({ body: JSON.stringify({ status: "ACTIVE" }), method: "PATCH" }),
    );
  });

  it("parses successful loads, creation and updates", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(Response.json({ data: [category] }))
      .mockResolvedValueOnce(Response.json({ data: category }))
      .mockResolvedValueOnce(
        Response.json({
          data: { ...category, status: "INACTIVE", updatedAt: "2026-08-11T13:00:00.000Z" },
        }),
      );
    vi.stubGlobal("fetch", fetchMock);

    await expect(loadFinancialCategories("org-1", new AbortController().signal)).resolves.toEqual([
      category,
    ]);
    await expect(
      createFinancialCategory("org-1", { name: "Vendas" } as never, "key-2"),
    ).resolves.toEqual({ data: category, problem: null });
    await expect(toggleFinancialCategoryStatus("org-1", category as never)).resolves.toEqual({
      status: "INACTIVE",
      updated: { ...category, status: "INACTIVE", updatedAt: "2026-08-11T13:00:00.000Z" },
    });
  });
});
