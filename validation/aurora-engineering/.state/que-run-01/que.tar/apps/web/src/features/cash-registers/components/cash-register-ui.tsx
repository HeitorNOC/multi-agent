import type { CashRegisterView } from "@gestor/contracts";
import { Label } from "@gestor/ui/components/label";
import type { ReactNode } from "react";

export function Field({
  children,
  error,
  htmlFor,
  label,
}: {
  children: ReactNode;
  error: string | undefined;
  htmlFor: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {error ? (
        <p className="text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function ErrorBox({ children }: { children: ReactNode }) {
  return (
    <div
      className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
      role="alert"
    >
      {children}
    </div>
  );
}

export function StatusBadge({ status }: { status: CashRegisterView["status"] }) {
  const styles =
    status === "OPEN"
      ? "bg-emerald-100 text-emerald-800"
      : status === "RECONCILING"
        ? "bg-amber-100 text-amber-800"
        : "bg-slate-200 text-slate-700";
  const label =
    status === "OPEN" ? "Aberto" : status === "RECONCILING" ? "Em conferência" : "Fechado";
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${styles}`}>{label}</span>
  );
}
