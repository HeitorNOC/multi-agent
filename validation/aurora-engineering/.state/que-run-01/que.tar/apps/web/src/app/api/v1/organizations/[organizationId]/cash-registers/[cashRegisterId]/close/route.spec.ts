import { beforeEach, describe, expect, it, vi } from "vitest";

const { authenticate, requireCurrentLegalAcceptance, closeCashRegister, resolveTenantActor } =
  vi.hoisted(() => ({
    authenticate: vi.fn(),
    requireCurrentLegalAcceptance: vi.fn(),
    closeCashRegister: vi.fn(),
    resolveTenantActor: vi.fn(),
  }));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance }));
vi.mock("@/lib/server/container", () => ({
  services: {
    closeCashRegister: { execute: closeCashRegister },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "52000000-0000-4000-8000-000000000001";
const cashRegisterId = "52000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ cashRegisterId, organizationId }) };

describe("close cash register route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    requireCurrentLegalAcceptance.mockReset().mockResolvedValue(undefined);
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OPERATOR" });
    closeCashRegister.mockReset().mockResolvedValue({ id: cashRegisterId, status: "CLOSED" });
  });

  it("closes against the expected version with an idempotency key", async () => {
    const body = {
      countedAmount: "95",
      differenceReason: "Diferença conferida",
      expectedVersion: 7,
    };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers/${cashRegisterId}/close`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "close-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(200);
    expect(closeCashRegister).toHaveBeenCalledWith(
      { ...body, cashRegisterId, idempotencyKey: "close-key", organizationId },
      { role: "OPERATOR" },
    );
  });

  it("rejects invalid versions after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/cash-registers/${cashRegisterId}/close`,
      {
        body: JSON.stringify({ countedAmount: "95", differenceReason: null, expectedVersion: -1 }),
        headers: { "content-type": "application/json", "idempotency-key": "close-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
  });
});
