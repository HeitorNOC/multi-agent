export function formatBrl(value: string): string {
  const negative = value.startsWith("-");
  const [integer = "0", rawFraction = ""] = value.replace("-", "").split(".");
  const fraction = rawFraction.padEnd(2, "0").replace(/0+$/, "").padEnd(2, "0");
  const formattedInteger = BigInt(integer).toLocaleString("pt-BR");
  return `${negative ? "- " : ""}R$ ${formattedInteger},${fraction}`;
}

export function formatDateTime(value: string): string {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(
    new Date(value),
  );
}
