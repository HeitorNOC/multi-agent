import { organizationParamsSchema, resolveFoodServiceKitchenTicketIngredientsBodySchema } from "@gestor/contracts";
import { z } from "zod";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
const paramsSchema = organizationParamsSchema.extend({ ticketId: z.uuid() });
type RouteParameters = { params: Promise<{ organizationId: string; ticketId: string }> };
export async function POST(request: Request, route: RouteParameters): Promise<Response> { return handleApiRequest(request, async (api) => { const params = paramsSchema.parse(await route.params); const body = resolveFoodServiceKitchenTicketIngredientsBodySchema.parse(await readJsonBody(request)); const identity = await authenticateApiRequest(request); const actor = await services.resolveTenantActor.execute({ correlationId: api.correlationId, organizationId: params.organizationId, requestId: api.requestId, userId: identity.userId }); return Response.json({ data: await services.resolveFoodServiceKitchenTicketIngredients.execute({ ...body, ...params }, actor) }); }); }
