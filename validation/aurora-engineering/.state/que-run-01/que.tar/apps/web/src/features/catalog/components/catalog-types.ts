import type { CatalogCategoryView, ProductView, ServiceView } from "@gestor/contracts";
import type { Dispatch, SetStateAction } from "react";

export type CatalogState = {
  categories: readonly CatalogCategoryView[];
  products: readonly ProductView[];
  services: readonly ServiceView[];
};

export type CatalogSectionProps = {
  organizationId: string;
  setFeedback: (message: string | null) => void;
  setState: Dispatch<SetStateAction<CatalogState | null>>;
  state: CatalogState;
};
