import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, resolveTenantActor, revokeInvitation } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  resolveTenantActor: vi.fn(),
  revokeInvitation: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
    revokeOrganizationInvitation: { execute: revokeInvitation },
  },
}));

import { POST } from "./route";

describe("revoke organization invitation route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    revokeInvitation.mockReset().mockResolvedValue({ status: "REVOKED" });
  });

  it("revokes with tenant actor and idempotency", async () => {
    const organizationId = "20000000-0000-4000-8000-000000000001";
    const invitationId = "20000000-0000-4000-8000-000000000002";
    const response = await POST(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/invitations/${invitationId}/revoke`,
        { headers: { "idempotency-key": "revoke-key" }, method: "POST" },
      ),
      { params: Promise.resolve({ invitationId, organizationId }) },
    );
    expect(response.status).toBe(200);
    expect(revokeInvitation).toHaveBeenCalledWith(
      { idempotencyKey: "revoke-key", invitationId, organizationId },
      { role: "OWNER" },
    );
  });
});
