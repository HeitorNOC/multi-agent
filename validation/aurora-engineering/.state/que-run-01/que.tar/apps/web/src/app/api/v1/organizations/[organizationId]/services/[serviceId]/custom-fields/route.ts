import { serviceParamsSchema, updateCatalogCustomFieldsBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string; serviceId: string }> };
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = serviceParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.getCatalogCustomFieldValues.execute(
        params.serviceId,
        params.organizationId,
        "SERVICE",
        actor,
      ),
    });
  });
}
export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = serviceParamsSchema.parse(await route.params);
    const body = updateCatalogCustomFieldsBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.updateCatalogCustomFields.execute(
        {
          ...body,
          entityType: "SERVICE",
          organizationId: params.organizationId,
          targetId: params.serviceId,
        },
        actor,
      ),
    });
  });
}
