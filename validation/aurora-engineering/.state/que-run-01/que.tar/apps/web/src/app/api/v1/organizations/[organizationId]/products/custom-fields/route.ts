import { createCatalogCustomFieldBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.listCatalogCustomFields.execute(params.organizationId, "PRODUCT", actor),
    });
  });
}
export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createCatalogCustomFieldBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const definition = await services.createCatalogCustomField.execute(
      {
        ...body,
        entityType: "PRODUCT",
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json({ data: definition }, { status: 201 });
  });
}
