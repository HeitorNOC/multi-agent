"use client";

import { useMemo, useState } from "react";
import { customerAddressSchema, type CustomerAddress } from "@gestor/contracts";

import { formatCatalogQuantity } from "./catalog-presentation";

export type PublicCatalogCheckoutItem = {
  id: string;
  name: string;
  price: string;
  quantity: string;
  unit: string;
};

export type PublicCatalogCheckoutPolicy = {
  allowsArrangedDelivery: boolean;
  allowsDelivery: boolean;
  allowsPickup: boolean;
  minimumOrderAmount: number | null;
};

export type PublicCatalogFulfillmentMethod = "ARRANGED" | "DELIVERY" | "PICKUP";

export type PublicCatalogCheckoutSubmission = {
  deliveryAddress?: CustomerAddress;
  fulfillmentMethod: PublicCatalogFulfillmentMethod;
};

type Props = {
  cart: readonly PublicCatalogCheckoutItem[];
  policy: PublicCatalogCheckoutPolicy | null;
  submitting?: boolean;
  onSubmit(submission: PublicCatalogCheckoutSubmission): void;
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("pt-BR", { currency: "BRL", style: "currency" }).format(value);
}

function initialMethod(policy: PublicCatalogCheckoutPolicy | null): PublicCatalogFulfillmentMethod {
  return policy?.allowsPickup ? "PICKUP" : policy?.allowsDelivery ? "DELIVERY" : "ARRANGED";
}

function deliveryAddressMessage(path: PropertyKey | undefined, fallback: string) {
  const messages: Record<string, string> = {
    city: "Informe a cidade para a entrega.",
    district: "Informe o bairro para a entrega.",
    number: "Informe o número do endereço.",
    postalCode: "Informe um CEP válido.",
    state: "Informe a UF com duas letras.",
    street: "Informe a rua para a entrega.",
  };
  return typeof path === "string" ? (messages[path] ?? fallback) : fallback;
}

function missingDeliveryAddressMessage(address: CustomerAddress) {
  const fields = [
    ["street", "rua"],
    ["number", "número"],
    ["district", "bairro"],
    ["city", "cidade"],
    ["state", "UF"],
    ["postalCode", "CEP"],
  ] as const;
  const missing = fields.filter(([field]) => !address[field].trim()).map(([, label]) => label);
  return missing.length ? `Informe ${missing.join(", ")} para a entrega.` : null;
}

/**
 * A revisão do pedido não decide preço, estoque ou cria um pedido. Ela apenas
 * coleta a modalidade escolhida e deixa a confirmação transacional ao servidor.
 */
export function PublicCatalogCheckout({ cart, policy, submitting = false, onSubmit }: Props) {
  const [fulfillmentMethod, setFulfillmentMethod] = useState<PublicCatalogFulfillmentMethod>(() =>
    initialMethod(policy),
  );
  const [deliveryAddress, setDeliveryAddress] = useState<CustomerAddress>({
    city: "",
    complement: "",
    district: "",
    number: "",
    postalCode: "",
    state: "",
    street: "",
  });
  const [deliveryAddressError, setDeliveryAddressError] = useState<string | null>(null);
  const subtotal = useMemo(
    () => cart.reduce((total, item) => total + Number(item.price) * Number(item.quantity), 0),
    [cart],
  );
  const minimumOrderAmount = policy?.minimumOrderAmount ?? null;
  const meetsMinimum = minimumOrderAmount === null || subtotal >= minimumOrderAmount;
  const availableMethods = [
    policy?.allowsPickup || policy === null
      ? { label: "Retirada", value: "PICKUP" as const }
      : null,
    policy?.allowsDelivery ? { label: "Entrega pela empresa", value: "DELIVERY" as const } : null,
    policy?.allowsArrangedDelivery
      ? { label: "Entrega a combinar", value: "ARRANGED" as const }
      : null,
  ].filter((method): method is { label: string; value: PublicCatalogFulfillmentMethod } =>
    Boolean(method),
  );

  if (!cart.length) return null;

  function submitOrder() {
    if (fulfillmentMethod === "DELIVERY") {
      const parsedAddress = customerAddressSchema.safeParse(deliveryAddress);
      if (!parsedAddress.success) {
        const issue = parsedAddress.error.issues[0];
        setDeliveryAddressError(
          missingDeliveryAddressMessage(deliveryAddress) ??
            deliveryAddressMessage(issue?.path[0], issue?.message ?? "Revise o endereço."),
        );
        return;
      }
    }
    setDeliveryAddressError(null);
    onSubmit({
      fulfillmentMethod,
      ...(fulfillmentMethod === "DELIVERY" ? { deliveryAddress } : {}),
    });
  }

  return (
    <section
      className="mt-5 rounded-xl border border-slate-200 bg-white p-4"
      aria-labelledby="checkout-title"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="font-semibold text-slate-950" id="checkout-title">
          Revisar pedido
        </h2>
        <strong className="text-slate-950">{formatCurrency(subtotal)}</strong>
      </div>
      <p className="mt-1 text-sm leading-6 text-slate-600">
        O preço, estoque e condições do pedido serão confirmados antes da criação.
      </p>

      <ul className="mt-4 divide-y border-y text-sm" aria-label="Resumo dos itens">
        {cart.map((item) => (
          <li className="flex items-center justify-between gap-3 py-2" key={item.id}>
            <span className="text-slate-700">
              {item.name}{" "}
              <span className="text-slate-500">
                · {formatCatalogQuantity(item.quantity)} {item.unit}
              </span>
            </span>
            <span className="shrink-0 text-slate-950">
              {formatCurrency(Number(item.price) * Number(item.quantity))}
            </span>
          </li>
        ))}
      </ul>

      <fieldset className="mt-4">
        <legend className="text-sm font-medium text-slate-900">Como você quer receber?</legend>
        {availableMethods.length ? (
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            {availableMethods.map((method) => (
              <label
                className="flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm text-slate-700 has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50"
                key={method.value}
              >
                <input
                  checked={fulfillmentMethod === method.value}
                  name="fulfillment-method"
                  onChange={() => {
                    setDeliveryAddressError(null);
                    setFulfillmentMethod(method.value);
                  }}
                  type="radio"
                  value={method.value}
                />
                {method.label}
              </label>
            ))}
          </div>
        ) : (
          <p className="mt-2 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm leading-6 text-slate-700">
            Este catálogo está disponível para consulta. A empresa não está recebendo pedidos por
            aqui no momento.
          </p>
        )}
      </fieldset>

      {fulfillmentMethod === "DELIVERY" ? (
        <fieldset className="mt-4 grid gap-3 rounded-xl border border-slate-200 p-4">
          <legend className="px-1 text-sm font-medium text-slate-900">Endereço de entrega</legend>
          <p className="text-sm text-slate-600">Usaremos este endereço somente neste pedido.</p>
          {deliveryAddressError ? (
            <p className="text-sm text-red-700" role="alert">
              {deliveryAddressError}
            </p>
          ) : null}
          <div className="grid gap-3 sm:grid-cols-[1fr_110px]">
            <input
              aria-label="Rua"
              className="rounded-lg border px-3 py-2"
              placeholder="Rua"
              value={deliveryAddress.street}
              onChange={(event) =>
                setDeliveryAddress((current) => ({ ...current, street: event.target.value }))
              }
            />
            <input
              aria-label="Número"
              className="rounded-lg border px-3 py-2"
              placeholder="Número"
              value={deliveryAddress.number}
              onChange={(event) =>
                setDeliveryAddress((current) => ({ ...current, number: event.target.value }))
              }
            />
          </div>
          <input
            aria-label="Complemento"
            className="rounded-lg border px-3 py-2"
            placeholder="Complemento (opcional)"
            value={deliveryAddress.complement ?? ""}
            onChange={(event) =>
              setDeliveryAddress((current) => ({ ...current, complement: event.target.value }))
            }
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <input
              aria-label="Bairro"
              className="rounded-lg border px-3 py-2"
              placeholder="Bairro"
              value={deliveryAddress.district}
              onChange={(event) =>
                setDeliveryAddress((current) => ({ ...current, district: event.target.value }))
              }
            />
            <input
              aria-label="Cidade"
              className="rounded-lg border px-3 py-2"
              placeholder="Cidade"
              value={deliveryAddress.city}
              onChange={(event) =>
                setDeliveryAddress((current) => ({ ...current, city: event.target.value }))
              }
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <input
              aria-label="UF"
              className="rounded-lg border px-3 py-2"
              maxLength={2}
              placeholder="UF"
              value={deliveryAddress.state}
              onChange={(event) =>
                setDeliveryAddress((current) => ({
                  ...current,
                  state: event.target.value.toUpperCase(),
                }))
              }
            />
            <input
              aria-label="CEP"
              className="rounded-lg border px-3 py-2"
              placeholder="CEP"
              value={deliveryAddress.postalCode}
              onChange={(event) =>
                setDeliveryAddress((current) => ({ ...current, postalCode: event.target.value }))
              }
            />
          </div>
        </fieldset>
      ) : null}

      {!meetsMinimum && minimumOrderAmount !== null ? (
        <p
          className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900"
          role="status"
        >
          Faltam {formatCurrency(minimumOrderAmount - subtotal)} para atingir o pedido mínimo de{" "}
          {formatCurrency(minimumOrderAmount)}.
        </p>
      ) : null}

      <button
        className="mt-4 w-full rounded-lg bg-brand-700 px-4 py-3 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-60"
        disabled={submitting || !meetsMinimum || !availableMethods.length}
        onClick={submitOrder}
        type="button"
      >
        {submitting
          ? "Confirmando condições..."
          : availableMethods.length
            ? "Continuar para confirmação"
            : "Pedidos indisponíveis"}
      </button>
    </section>
  );
}
