import type { ProblemDetails } from "@gestor/contracts";

export function active(entity: { status: string }) {
  return entity.status === "ACTIVE";
}
export function money(value: string) {
  return Number(value).toLocaleString("pt-BR", { minimumFractionDigits: 2 });
}
export function mergeSupplierChoices(
  current: readonly { id: string; name: string }[],
  incoming: readonly { id: string; name: string }[],
) {
  return [...new Map([...current, ...incoming].map((item) => [item.id, item])).values()];
}
export async function post(url: string, body: unknown) {
  return fetch(url, {
    body: JSON.stringify(body),
    headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
    method: "POST",
  });
}
export async function patch(url: string, body: unknown) {
  return fetch(url, {
    body: JSON.stringify(body),
    headers: { "content-type": "application/json" },
    method: "PATCH",
  });
}

export async function setProblem(
  response: Response,
  setError: (name: "root", error: { message: string; type: string }) => void,
) {
  const problem = (await response.json()) as ProblemDetails;
  setError("root", { message: problem.detail, type: problem.code });
}
export async function toggle<
  T extends { id: string; status: "ACTIVE" | "INACTIVE"; updatedAt: string },
>(
  segment: string,
  item: T,
  organizationId: string,
  schema: { parse(value: unknown): T },
  update: (value: T) => void,
  feedback: (message: string) => void,
) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/${segment}/${item.id}`, {
    body: JSON.stringify({
      expectedUpdatedAt: item.updatedAt,
      status: item.status === "ACTIVE" ? "INACTIVE" : "ACTIVE",
    }),
    headers: { "content-type": "application/json" },
    method: "PATCH",
  });
  if (!response.ok) return feedback(((await response.json()) as ProblemDetails).detail);
  const updated = schema.parse(((await response.json()) as { data: unknown }).data);
  update(updated);
  feedback(updated.status === "ACTIVE" ? "Cadastro reativado." : "Cadastro inativado.");
}
