import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { BankAccountConfigurations } from "@/features/bank-accounts/components/bank-account-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Identificação bancária | Gestor",
};

type BankAccountsPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function BankAccountsPage({ params }: BankAccountsPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Financeiro
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Identificação das contas bancárias
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Identifique suas contas financeiras bancárias sem informar agência, número completo, senha
          ou qualquer credencial do banco.
        </p>
      </header>

      <ModuleGate moduleCode="banking" organizationId={organizationId}>
        <BankAccountConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
