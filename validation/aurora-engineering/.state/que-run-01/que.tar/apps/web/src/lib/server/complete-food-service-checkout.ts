import type { DirectSalePaymentInput } from "@gestor/contracts";
import { runInTenantTransaction, type PrismaClient } from "@gestor/database";
import {
  type ActorContext,
  requireModuleAccess,
  requireOrganization,
  requirePermission,
} from "@gestor/identity";
import { ConflictError } from "@gestor/kernel";
import { CompleteSale } from "@gestor/sales";
import { PrismaFoodServiceUnitOfWork } from "@gestor/food-service/prisma";
import { PrismaSalesUnitOfWork } from "@gestor/sales/prisma";

type Input = {
  dueDate: string;
  expectedVersion: number;
  idempotencyKey: string;
  orderId: string;
  organizationId: string;
  payments?: readonly DirectSalePaymentInput[] | undefined;
  revenueCategoryId: string;
};

/** Composes food-service and sales scopes over one tenant transaction. */
export class CompleteFoodServiceCheckout {
  private readonly foodService: PrismaFoodServiceUnitOfWork;
  private readonly sales: PrismaSalesUnitOfWork;

  constructor(private readonly prisma: PrismaClient) {
    this.foodService = new PrismaFoodServiceUnitOfWork(prisma);
    this.sales = new PrismaSalesUnitOfWork(prisma);
  }

  async execute(input: Input, actor: ActorContext) {
    requireOrganization(actor, input.organizationId);
    requirePermission(actor, "food_service.manage");
    requireModuleAccess(actor, "food_service", "WRITE");
    if (actor.organizationId !== input.organizationId)
      throw new ConflictError(
        "FOOD_SERVICE_ORGANIZATION_MISMATCH",
        "A organização da comanda mudou.",
      );
    const branchIds =
      actor.branchScope.kind === "SELECTED" ? [...actor.branchScope.branchIds] : null;
    return runInTenantTransaction(
      this.prisma,
      { organizationId: actor.organizationId, userId: actor.userId },
      async (transaction) => {
        const foodScope = this.foodService.scope(transaction, actor);
        const salesScope = this.sales.scope(transaction, actor);
        const order = await foodScope.orders.find(input.orderId, branchIds);
        if (
          !order ||
          order.status !== "CHECKOUT_PENDING" ||
          order.version !== input.expectedVersion
        )
          throw new ConflictError(
            "FOOD_SERVICE_ORDER_SETTLEMENT_CONFLICT",
            "A comanda mudou ou não está aguardando pagamento. Atualize a tela antes de concluir.",
          );
        const sale = await new CompleteSale({
          run: async (_actor, operation) => operation(salesScope),
        }).execute(
          {
            branchId: order.branchId,
            customerId: null,
            discountAmount: "0",
            dueDate: input.dueDate,
            idempotencyKey: `food-service-order:${order.id}:${input.idempotencyKey}`,
            itemPriceOverrides: order.items.map((item) => ({
              productId: item.productId,
              unitPrice: item.unitPrice,
            })),
            items: order.items.map((item) => ({
              productId: item.productId,
              quantity: item.quantity,
              serviceId: null,
            })),
            organizationId: input.organizationId,
            payments: input.payments ? [...input.payments] : undefined,
            revenueCategoryId: input.revenueCategoryId,
          },
          actor,
        );
        const settled = await foodScope.orders.settle({
          branchIds,
          expectedVersion: order.version,
          orderId: order.id,
          saleId: sale.id,
          settledAt: new Date(),
        });
        if (!settled)
          throw new ConflictError(
            "FOOD_SERVICE_ORDER_SETTLEMENT_CONFLICT",
            "A comanda mudou durante a confirmação do pagamento. Nenhuma alteração foi concluída.",
          );
        return { order: settled, sale };
      },
    );
  }
}
