import { catalogCommercialPolicyBodySchema, organizationParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });

    return Response.json({
      data: await services.getCatalogCommercialPolicy.execute(params, actor),
    });
  });
}

export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const body = catalogCommercialPolicyBodySchema.parse(await readJsonBody(request));
    return Response.json({
      data: await services.updateCatalogCommercialPolicy.execute({ ...body, ...params }, actor),
    });
  });
}
