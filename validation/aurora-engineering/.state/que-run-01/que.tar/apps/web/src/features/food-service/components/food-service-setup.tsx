"use client";

import {
  branchListSchema,
  foodServiceDiningAreaListSchema,
  foodServiceDiningTableListSchema,
  foodServiceKitchenProductRouteListSchema,
  foodServiceKitchenStationListSchema,
  foodServiceKitchenTicketListSchema,
  foodServiceSettingsViewSchema,
  foodServiceTableSessionListSchema,
  foodServiceOrderViewSchema,
  financialAccountListSchema,
  financialCategoryListSchema,
  paymentMethodConfigurationListSchema,
  completedSaleViewSchema,
  productListSchema,
  type BranchView,
  type FoodServiceDiningAreaView,
  type FoodServiceDiningTableView,
  type FoodServiceKitchenProductRouteView,
  type FoodServiceKitchenStationView,
  type FoodServiceKitchenTicketView,
  type FoodServiceSettingsView,
  type FoodServiceTableSessionView,
  type FoodServiceOrderView,
  type FinancialAccountView,
  type FinancialCategoryView,
  type PaymentMethodConfigurationView,
  type ProductView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useEffect, useMemo, useRef, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";
import { keyForPendingOperation } from "@/lib/idempotency-key";
import { compatiblePaymentAccounts } from "@/lib/payment-account-compatibility";
import { FoodServiceDiningConfiguration } from "./food-service-dining-configuration";
import { FoodServiceDiningTableOverview } from "./food-service-dining-table-overview";
import { FoodServiceKitchenQueue } from "./food-service-kitchen-queue";
import { FoodServiceKitchenRoutes } from "./food-service-kitchen-routes";
import { FoodServiceKitchenStations } from "./food-service-kitchen-stations";
import { FoodServiceRecipes } from "./food-service-recipes";
import {
  FoodServiceOrderCheckout,
  type FoodServiceCheckoutForm,
  type FoodServiceCheckoutPayment,
} from "./food-service-order-checkout";
import { FoodServiceOrderItemAdder } from "./food-service-order-item-adder";
import { FoodServiceModifierConfiguration } from "./food-service-modifier-configuration";
import { FoodServiceSettingsForm } from "./food-service-settings-form";
import { FoodServiceTableSessionCards } from "./food-service-table-session-cards";
import { FoodServiceTableSessionOpening } from "./food-service-table-session-opening";

type Props = { organizationId: string };
const defaults = {
  acceptsArrangedDelivery: false,
  acceptsCounter: true,
  acceptsDelivery: false,
  acceptsDineIn: true,
  acceptsPickup: false,
  defaultPreparationMinutes: 20,
  requiresManualAcceptance: true,
  requiresPrepayment: false,
  requiresInventoryCountBeforeCashClose: false,
  stockConsumptionMoment: "NONE" as const,
};
function formatCurrency(value: string) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    Number(value),
  );
}
function formatQuantity(value: string) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(Number(value));
}
function formatItemQuantity(quantity: string, unit: string) {
  const amount = Number(quantity);
  if (unit === "UN") return `${formatQuantity(quantity)} ${amount === 1 ? "unidade" : "unidades"}`;
  return `${formatQuantity(quantity)} ${unit.toLowerCase()}`;
}
export function FoodServiceSetup({ organizationId }: Props) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [areas, setAreas] = useState<readonly FoodServiceDiningAreaView[]>([]);
  const [tables, setTables] = useState<readonly FoodServiceDiningTableView[]>([]);
  const [kitchenStations, setKitchenStations] = useState<readonly FoodServiceKitchenStationView[]>(
    [],
  );
  const [kitchenTickets, setKitchenTickets] = useState<readonly FoodServiceKitchenTicketView[]>([]);
  const [ticketResolutionReasons, setTicketResolutionReasons] = useState<
    Readonly<Record<string, string>>
  >({});
  const [kitchenProductRoutes, setKitchenProductRoutes] = useState<
    readonly FoodServiceKitchenProductRouteView[]
  >([]);
  const [settings, setSettings] = useState<FoodServiceSettingsView | null>(null);
  const [sessions, setSessions] = useState<readonly FoodServiceTableSessionView[]>([]);
  const [products, setProducts] = useState<readonly ProductView[]>([]);
  const [revenueCategories, setRevenueCategories] = useState<readonly FinancialCategoryView[]>([]);
  const [financialAccounts, setFinancialAccounts] = useState<readonly FinancialAccountView[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<readonly PaymentMethodConfigurationView[]>(
    [],
  );
  const [checkoutForms, setCheckoutForms] = useState<Record<string, FoodServiceCheckoutForm>>({});
  const settlementIdempotencyKeysRef = useRef<Record<string, string>>({});
  const [settlingOrderId, setSettlingOrderId] = useState<string | null>(null);
  const [orders, setOrders] = useState<Record<string, readonly FoodServiceOrderView[]>>({});
  const [counterOrders, setCounterOrders] = useState<readonly FoodServiceOrderView[]>([]);
  const [ticketCancellationReasons, setTicketCancellationReasons] = useState<
    Record<string, string>
  >({});
  const [orderCancellationReasons, setOrderCancellationReasons] = useState<Record<string, string>>(
    {},
  );
  const [kitchenStationFilter, setKitchenStationFilter] = useState("");
  const [kitchenStatusFilter, setKitchenStatusFilter] = useState("");
  const [branchId, setBranchId] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);
  const current = settings ?? { ...defaults, createdAt: "", id: "", updatedAt: "" };
  function findDiningOrder(orderId: string) {
    return Object.values(orders)
      .flat()
      .find((order) => order.id === orderId);
  }
  function saveDiningOrder(saved: FoodServiceOrderView) {
    if (!saved.tableSessionId) return;
    setOrders((value) => {
      const sessionOrders = value[saved.tableSessionId!] ?? [];
      return {
        ...value,
        [saved.tableSessionId!]: [
          ...sessionOrders.filter((order) => order.id !== saved.id),
          saved,
        ].sort((left, right) => (left.tabNumber ?? 0) - (right.tabNumber ?? 0)),
      };
    });
  }
  function removeDiningOrder(orderId: string) {
    setOrders((value) =>
      Object.fromEntries(
        Object.entries(value).flatMap(([sessionId, sessionOrders]) => {
          const remaining = (sessionOrders ?? []).filter((order) => order.id !== orderId);
          return remaining.length ? [[sessionId, remaining] as const] : [];
        }),
      ),
    );
  }
  function compatibleAccounts(paymentMethodConfigurationId: string) {
    return compatiblePaymentAccounts({
      branchId,
      financialAccounts,
      paymentMethodConfigurationId,
      paymentMethods,
    });
  }
  function checkoutPaymentDefaults(): FoodServiceCheckoutPayment {
    const paymentMethodConfigurationId = paymentMethods[0]?.id ?? "";
    return {
      amount: "",
      financialAccountId: compatibleAccounts(paymentMethodConfigurationId)[0]?.id ?? "",
      paymentMethodConfigurationId,
    };
  }
  function checkoutDefaults(): FoodServiceCheckoutForm {
    return {
      dueDate: new Date().toISOString().slice(0, 10),
      payments: [],
      revenueCategoryId: revenueCategories[0]?.id ?? "",
    };
  }
  function paymentTotal(payments: readonly FoodServiceCheckoutPayment[]) {
    return payments.reduce(
      (total, payment) => total + (Number(payment.amount.replace(",", ".")) || 0),
      0,
    );
  }
  function paymentsAreComplete(payments: readonly FoodServiceCheckoutPayment[]) {
    return payments.every(
      (payment) =>
        Number(payment.amount.replace(",", ".")) > 0 &&
        Boolean(payment.financialAccountId) &&
        Boolean(payment.paymentMethodConfigurationId),
    );
  }
  function paymentsMatchOrderTotal(
    orderTotal: string,
    payments: readonly FoodServiceCheckoutPayment[],
  ) {
    return Math.abs(paymentTotal(payments) - Number(orderTotal)) <= 0.005;
  }
  function hasDuplicatePaymentDestination(payments: readonly FoodServiceCheckoutPayment[]) {
    const destinations = new Set<string>();
    return payments.some((payment) => {
      if (!payment.financialAccountId || !payment.paymentMethodConfigurationId) return false;
      const destination = `${payment.paymentMethodConfigurationId}:${payment.financialAccountId}`;
      if (destinations.has(destination)) return true;
      destinations.add(destination);
      return false;
    });
  }
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const [
          settingsResponse,
          branchesResponse,
          areasResponse,
          tablesResponse,
          sessionsResponse,
          productsResponse,
          stationsResponse,
          ticketsResponse,
          routesResponse,
          ordersResponse,
          categoryResponse,
          financialAccountResponse,
          paymentMethodResponse,
        ] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/food-service-settings`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/branches`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-dining-areas`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-dining-tables`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-table-sessions`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/products?status=ACTIVE`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-kitchen-stations`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-kitchen-tickets`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-kitchen-product-routes`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/food-service-orders`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-categories`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/payment-methods`, {
            signal: controller.signal,
          }),
        ]);
        if (
          ![
            settingsResponse,
            branchesResponse,
            areasResponse,
            tablesResponse,
            sessionsResponse,
            productsResponse,
            stationsResponse,
            ticketsResponse,
            routesResponse,
            ordersResponse,
            categoryResponse,
            financialAccountResponse,
            paymentMethodResponse,
          ].every((response) => response.ok)
        ) {
          const failed = [
            settingsResponse,
            branchesResponse,
            areasResponse,
            tablesResponse,
            sessionsResponse,
            productsResponse,
            stationsResponse,
            ticketsResponse,
            routesResponse,
            ordersResponse,
            categoryResponse,
            financialAccountResponse,
            paymentMethodResponse,
          ].find((response) => !response.ok);
          if (!failed) throw new Error("Não foi possível carregar a operação de alimentação.");
          throw new Error(((await failed.json()) as ProblemDetails).detail);
        }
        const [
          settingsPayload,
          branchesPayload,
          areasPayload,
          tablesPayload,
          sessionsPayload,
          productsPayload,
          stationsPayload,
          ticketsPayload,
          routesPayload,
          ordersPayload,
          categoryPayload,
          financialAccountPayload,
          paymentMethodPayload,
        ] = (await Promise.all([
          settingsResponse.json(),
          branchesResponse.json(),
          areasResponse.json(),
          tablesResponse.json(),
          sessionsResponse.json(),
          productsResponse.json(),
          stationsResponse.json(),
          ticketsResponse.json(),
          routesResponse.json(),
          ordersResponse.json(),
          categoryResponse.json(),
          financialAccountResponse.json(),
          paymentMethodResponse.json(),
        ])) as [
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
          { data: unknown },
        ];
        setSettings(
          settingsPayload.data === null
            ? null
            : foodServiceSettingsViewSchema.parse(settingsPayload.data),
        );
        const loadedBranches = branchListSchema.parse(branchesPayload.data);
        setBranches(loadedBranches);
        setBranchId(
          (currentBranch) =>
            currentBranch || loadedBranches.find((branch) => branch.status === "ACTIVE")?.id || "",
        );
        setAreas(foodServiceDiningAreaListSchema.parse(areasPayload.data));
        setTables(foodServiceDiningTableListSchema.parse(tablesPayload.data));
        setSessions(foodServiceTableSessionListSchema.parse(sessionsPayload.data));
        setProducts(productListSchema.parse(productsPayload.data));
        setRevenueCategories(
          financialCategoryListSchema
            .parse(categoryPayload.data)
            .filter((category) => category.status === "ACTIVE" && category.type === "REVENUE"),
        );
        setFinancialAccounts(
          financialAccountListSchema
            .parse(financialAccountPayload.data)
            .filter((account) => account.status === "ACTIVE"),
        );
        setPaymentMethods(
          paymentMethodConfigurationListSchema
            .parse(paymentMethodPayload.data)
            .filter((method) => method.status === "ACTIVE" && method.allowsReceipts),
        );
        setKitchenStations(foodServiceKitchenStationListSchema.parse(stationsPayload.data));
        setKitchenTickets(foodServiceKitchenTicketListSchema.parse(ticketsPayload.data));
        setKitchenProductRoutes(foodServiceKitchenProductRouteListSchema.parse(routesPayload.data));
        const loadedOrders = foodServiceOrderViewSchema.array().parse(ordersPayload.data);
        setOrders(
          loadedOrders
            .filter((order) => order.channel === "DINE_IN" && order.tableSessionId)
            .sort((left, right) => (left.tabNumber ?? 0) - (right.tabNumber ?? 0))
            .reduce<Record<string, readonly FoodServiceOrderView[]>>((grouped, order) => {
              const sessionId = order.tableSessionId!;
              return { ...grouped, [sessionId]: [...(grouped[sessionId] ?? []), order] };
            }, {}),
        );
        setCounterOrders(loadedOrders.filter((order) => order.channel === "COUNTER"));
      } catch (cause) {
        if (!controller.signal.aborted)
          setMessage(
            cause instanceof Error ? cause.message : "Não foi possível carregar a operação.",
          );
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId]);
  const branchAreas = useMemo(
    () => areas.filter((area) => area.branchId === branchId && area.status === "ACTIVE"),
    [areas, branchId],
  );
  const visibleKitchenTickets = useMemo(
    () =>
      kitchenTickets.filter(
        (ticket) =>
          ticket.branchId === branchId &&
          !["SERVED", "CANCELLED"].includes(ticket.status) &&
          (!kitchenStationFilter || ticket.kitchenStationId === kitchenStationFilter) &&
          (!kitchenStatusFilter || ticket.status === kitchenStatusFilter),
      ),
    [branchId, kitchenStationFilter, kitchenStatusFilter, kitchenTickets],
  );
  async function saveSettings(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage(null);
    const form = new FormData(event.currentTarget);
    const payload = {
      acceptsArrangedDelivery: form.has("acceptsArrangedDelivery"),
      acceptsCounter: form.has("acceptsCounter"),
      acceptsDelivery: form.has("acceptsDelivery"),
      acceptsDineIn: form.has("acceptsDineIn"),
      acceptsPickup: form.has("acceptsPickup"),
      defaultPreparationMinutes: Number(form.get("defaultPreparationMinutes")),
      requiresManualAcceptance: form.has("requiresManualAcceptance"),
      requiresPrepayment: form.has("requiresPrepayment"),
      requiresInventoryCountBeforeCashClose: form.has("requiresInventoryCountBeforeCashClose"),
      stockConsumptionMoment: form.get("stockConsumptionMoment"),
    };
    const response = await fetch(`/api/v1/organizations/${organizationId}/food-service-settings`, {
      body: JSON.stringify(payload),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method: "PUT",
    });
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    setSettings(foodServiceSettingsViewSchema.parse(result.data));
    setMessage("Configurações salvas.");
  }
  async function addArea(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-dining-areas`,
      {
        body: JSON.stringify({
          branchId,
          displayOrder: Number(form.get("displayOrder") || 0),
          name: form.get("name"),
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    setAreas((value) => [...value, foodServiceDiningAreaListSchema.element.parse(result.data)]);
    formElement.reset();
    setMessage("Área criada.");
  }
  async function addKitchenStation(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-stations`,
      {
        body: JSON.stringify({
          branchId,
          code: form.get("code"),
          displayOrder: Number(form.get("displayOrder") || 0),
          name: form.get("name"),
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    setKitchenStations((value) => [
      ...value,
      foodServiceKitchenStationListSchema.element.parse(result.data),
    ]);
    formElement.reset();
    setMessage("Estação de cozinha criada.");
  }
  async function setDefaultKitchenStation(station: FoodServiceKitchenStationView) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-stations/${station.id}/default`,
      {
        body: JSON.stringify({ branchId }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceKitchenStationListSchema.element.parse(result.data);
    setKitchenStations((value) =>
      value.map((item) =>
        item.branchId === saved.branchId ? { ...item, isDefault: item.id === saved.id } : item,
      ),
    );
    setMessage(`${saved.name} é a estação padrão desta filial.`);
  }
  async function saveKitchenProductRoute(productId: string, kitchenStationId: string | null) {
    setMessage(null);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-product-routes`,
      {
        body: JSON.stringify({ branchId, kitchenStationId, productId }),
        headers: { "content-type": "application/json" },
        method: "PUT",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const savedRoutes = foodServiceKitchenProductRouteListSchema.parse(result.data);
    setKitchenProductRoutes((value) => [
      ...value.filter((route) => route.branchId !== branchId),
      ...savedRoutes,
    ]);
    setMessage(
      kitchenStationId
        ? "Rota do produto salva para esta filial."
        : "A rota específica foi removida; o produto usará a estação padrão.",
    );
  }
  async function addTable(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-dining-tables`,
      {
        body: JSON.stringify({
          areaId: form.get("areaId"),
          branchId,
          capacity: Number(form.get("capacity")),
          code: form.get("code"),
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    setTables((value) => [...value, foodServiceDiningTableListSchema.element.parse(result.data)]);
    formElement.reset();
    setMessage("Mesa criada.");
  }
  async function openTableSession(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-table-sessions`,
      {
        body: JSON.stringify({
          branchId,
          diningTableId: form.get("diningTableId"),
          guestCount: form.get("guestCount") ? Number(form.get("guestCount")) : null,
          notes: form.get("notes") || null,
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    setSessions((value) => [
      foodServiceTableSessionListSchema.element.parse(result.data),
      ...value,
    ]);
    formElement.reset();
    setMessage("Mesa aberta. Os itens e o pagamento entram nos próximos blocos.");
  }
  async function cancelTableSession(sessionId: string) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-table-sessions/${sessionId}/cancel`,
      {
        body: JSON.stringify({ reason: "Abertura cancelada pela operação" }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceTableSessionListSchema.element.parse(result.data);
    setSessions((value) => value.map((session) => (session.id === saved.id ? saved : session)));
    setMessage("Abertura cancelada. A mesa está disponível novamente.");
  }
  async function moveTableSession(session: FoodServiceTableSessionView, diningTableId: string) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-table-sessions/${session.id}/move`,
      {
        body: JSON.stringify({ diningTableId }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceTableSessionListSchema.element.parse(result.data);
    setSessions((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    setMessage(`Atendimento transferido para a mesa ${saved.diningTableCode}.`);
  }
  async function createOrder(session: FoodServiceTableSessionView, tabLabel?: string) {
    const hasActiveTab = (orders[session.id]?.length ?? 0) > 0;
    const response = await fetch(`/api/v1/organizations/${organizationId}/food-service-orders`, {
      body: JSON.stringify({
        branchId: session.branchId,
        createSeparateTab: hasActiveTab,
        ...(tabLabel?.trim() ? { tabLabel: tabLabel.trim() } : {}),
        tableSessionId: session.id,
      }),
      headers: { "content-type": "application/json" },
      method: "POST",
    });
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceOrderViewSchema.parse(result.data);
    saveDiningOrder(saved);
    setMessage(
      hasActiveTab
        ? `Conta ${saved.tabNumber} criada para a mesa ${session.diningTableCode}.`
        : `Conta ${saved.tabNumber} da mesa ${session.diningTableCode} criada.`,
    );
  }
  async function moveOrderItem(
    itemId: string,
    sourceOrder: FoodServiceOrderView,
    targetOrderId: string,
    quantity: string,
  ) {
    const targetOrder = Object.values(orders)
      .flat()
      .find((order) => order.id === targetOrderId);
    if (!targetOrder) {
      setMessage("A conta de destino não está disponível. Atualize a tela.");
      return;
    }
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${sourceOrder.id}/items/${itemId}/move`,
      {
        body: JSON.stringify({
          expectedSourceVersion: sourceOrder.version,
          expectedTargetVersion: targetOrder.version,
          quantity,
          targetOrderId,
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) {
      setMessage(result.detail);
      return;
    }
    const saved = foodServiceOrderViewSchema.array().parse(result.data);
    setOrders((value) =>
      Object.fromEntries(
        Object.entries(value).map(([sessionId, sessionOrders]) => [
          sessionId,
          sessionOrders.map((order) => saved.find((item) => item.id === order.id) ?? order),
        ]),
      ),
    );
    setMessage("Item transferido para a outra conta.");
  }
  async function removeOrderItem(itemId: string, order: FoodServiceOrderView) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/items/${itemId}`,
      {
        body: JSON.stringify({ expectedVersion: order.version }),
        headers: { "content-type": "application/json" },
        method: "DELETE",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) {
      setMessage(result.detail);
      return;
    }
    const saved = foodServiceOrderViewSchema.parse(result.data);
    setOrders((value) =>
      Object.fromEntries(
        Object.entries(value).map(([sessionId, sessionOrders]) => [
          sessionId,
          sessionOrders.map((item) => (item.id === saved.id ? saved : item)),
        ]),
      ),
    );
    setCounterOrders((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    setMessage("Item removido da comanda.");
  }
  async function createCounterOrder() {
    const response = await fetch(`/api/v1/organizations/${organizationId}/food-service-orders`, {
      body: JSON.stringify({ branchId, channel: "COUNTER" }),
      headers: { "content-type": "application/json" },
      method: "POST",
    });
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const order = foodServiceOrderViewSchema.parse(result.data);
    setCounterOrders((value) => [order, ...value.filter((item) => item.id !== order.id)]);
    setMessage("Pedido de balcão iniciado.");
  }
  async function addCounterOrderItem(event: React.FormEvent<HTMLFormElement>, orderId: string) {
    event.preventDefault();
    const order = counterOrders.find((item) => item.id === orderId);
    if (!order) return;
    const form = new FormData(event.currentTarget);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/items`,
      {
        body: JSON.stringify({
          expectedVersion: order.version,
          modifierOptionIds: form.getAll("modifierOptionIds"),
          notes: form.get("notes") || null,
          productId: form.get("productId"),
          quantity: form.get("quantity"),
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceOrderViewSchema.parse(result.data);
    setCounterOrders((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    event.currentTarget.reset();
  }
  async function acceptCounterOrder(orderId: string) {
    const order = counterOrders.find((item) => item.id === orderId);
    if (!order) return;
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/accept`,
      {
        body: JSON.stringify({ expectedVersion: order.version }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceOrderViewSchema.parse(result.data);
    setCounterOrders((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    try {
      await refreshKitchenTickets();
      setMessage("Pedido de balcão enviado para a cozinha.");
    } catch (cause) {
      setMessage(
        cause instanceof Error
          ? `Pedido de balcão aceito, mas a fila não pôde ser atualizada: ${cause.message}`
          : "Pedido de balcão aceito, mas não foi possível atualizar a fila da cozinha.",
      );
    }
  }
  async function beginCounterOrderCheckout(orderId: string) {
    const order = counterOrders.find((item) => item.id === orderId);
    if (!order) return;
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/checkout`,
      {
        body: JSON.stringify({ expectedVersion: order.version }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceOrderViewSchema.parse(result.data);
    setCounterOrders((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    setCheckoutForms((value) => ({ ...value, [saved.id]: value[saved.id] ?? checkoutDefaults() }));
    setMessage("Pedido de balcão pronto para pagamento.");
  }
  async function cancelCounterOrder(orderId: string) {
    const order = counterOrders.find((item) => item.id === orderId);
    const reason = orderCancellationReasons[orderId]?.trim();
    if (!order || !reason) return setMessage("Informe o motivo do cancelamento do pedido.");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/cancel`,
      {
        body: JSON.stringify({ expectedVersion: order.version, reason }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail ?? "Não foi possível cancelar o pedido.");
    const saved = foodServiceOrderViewSchema.parse(result.data);
    setCounterOrders((value) => value.filter((item) => item.id !== saved.id));
    setOrderCancellationReasons((value) => {
      const next = { ...value };
      delete next[orderId];
      return next;
    });
    await refreshKitchenTickets();
    setMessage("Pedido de balcão cancelado. Os itens pendentes foram retirados da cozinha.");
  }
  async function cancelOrder(orderId: string, reason: string) {
    const order = findDiningOrder(orderId);
    if (!order || !reason.trim()) return setMessage("Informe o motivo do cancelamento do pedido.");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/cancel`,
      {
        body: JSON.stringify({ expectedVersion: order.version, reason: reason.trim() }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail ?? "Não foi possível cancelar o pedido.");
    const saved = foodServiceOrderViewSchema.parse(result.data);
    removeDiningOrder(saved.id);
    await refreshKitchenTickets();
    setMessage("Pedido cancelado. Os itens pendentes foram retirados da cozinha.");
  }
  async function addOrderItem(event: React.FormEvent<HTMLFormElement>, orderId: string) {
    event.preventDefault();
    const order = findDiningOrder(orderId);
    if (!order) return;
    const form = new FormData(event.currentTarget);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/items`,
      {
        body: JSON.stringify({
          expectedVersion: order.version,
          modifierOptionIds: form.getAll("modifierOptionIds"),
          notes: form.get("notes") || null,
          productId: form.get("productId"),
          quantity: form.get("quantity"),
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    saveDiningOrder(foodServiceOrderViewSchema.parse(result.data));
    event.currentTarget.reset();
  }
  async function transitionKitchenTicket(
    ticket: FoodServiceKitchenTicketView,
    status: "IN_PREPARATION" | "READY" | "SERVED" | "CANCELLED",
  ) {
    const cancellationReason = ticketCancellationReasons[ticket.id]?.trim();
    if (status === "CANCELLED" && !cancellationReason)
      return setMessage("Informe o motivo do cancelamento antes de retirar o item da fila.");
    setMessage(null);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-tickets/${ticket.id}/transition`,
      {
        body: JSON.stringify({
          ...(status === "CANCELLED" ? { cancellationReason } : {}),
          expectedVersion: ticket.version,
          status,
        }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceKitchenTicketListSchema.element.parse(result.data);
    setKitchenTickets((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    setMessage(
      status === "IN_PREPARATION"
        ? "Preparo iniciado."
        : status === "READY"
          ? "Item pronto para servir."
          : status === "SERVED"
            ? "Item marcado como servido."
            : "Item cancelado e retirado da fila.",
    );
  }
  async function resolveTicketIngredients(
    ticket: FoodServiceKitchenTicketView,
    resolution: "LOSS" | "RETURN_TO_STOCK",
  ) {
    const reason = ticketResolutionReasons[ticket.id]?.trim();
    if (!reason) return setMessage("Informe o motivo antes de resolver os insumos.");
    setMessage(null);
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-tickets/${ticket.id}/ingredient-resolution`,
      {
        body: JSON.stringify({ expectedVersion: ticket.version, reason, resolution }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const saved = foodServiceKitchenTicketListSchema.element.parse(result.data);
    setKitchenTickets((value) => value.map((item) => (item.id === saved.id ? saved : item)));
    setMessage(
      resolution === "LOSS"
        ? "Perda de insumos registrada. O item já pode ser cancelado."
        : "Insumos devolvidos ao estoque. O item já pode ser cancelado.",
    );
  }
  async function refreshKitchenTickets() {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-kitchen-tickets`,
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok)
      throw new Error(result.detail ?? "Não foi possível atualizar a fila da cozinha.");
    setKitchenTickets(foodServiceKitchenTicketListSchema.parse(result.data));
  }
  useEffect(() => {
    const interval = window.setInterval(() => {
      void refreshKitchenTickets().catch(() => undefined);
    }, 15_000);
    return () => window.clearInterval(interval);
  }, [organizationId]);
  async function acceptOrder(orderId: string) {
    const order = findDiningOrder(orderId);
    if (!order) return;
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/accept`,
      {
        body: JSON.stringify({ expectedVersion: order.version }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    saveDiningOrder(foodServiceOrderViewSchema.parse(result.data));
    try {
      await refreshKitchenTickets();
      setMessage("Pedido aceito. A produção já está na fila da cozinha.");
    } catch (cause) {
      setMessage(
        cause instanceof Error
          ? `Pedido aceito, mas a fila não pôde ser atualizada: ${cause.message}`
          : "Pedido aceito, mas não foi possível atualizar a fila da cozinha.",
      );
    }
  }
  async function beginOrderCheckout(orderId: string) {
    const order = findDiningOrder(orderId);
    if (!order) return;
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/checkout`,
      {
        body: JSON.stringify({ expectedVersion: order.version }),
        headers: { "content-type": "application/json" },
        method: "POST",
      },
    );
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok) return setMessage(result.detail);
    const checkoutOrder = foodServiceOrderViewSchema.parse(result.data);
    saveDiningOrder(checkoutOrder);
    setCheckoutForms((value) => ({
      ...value,
      [order.id]: value[order.id] ?? checkoutDefaults(),
    }));
    setMessage("Comanda pronta para pagamento. Conclua a cobrança para liberar a mesa.");
  }
  function updateCheckoutForm(orderId: string, changes: Partial<FoodServiceCheckoutForm>) {
    setCheckoutForms((value) => ({
      ...value,
      [orderId]: {
        ...checkoutDefaults(),
        ...value[orderId],
        ...changes,
      },
    }));
  }
  function updateCheckoutPayment(
    orderId: string,
    index: number,
    changes: Partial<FoodServiceCheckoutPayment>,
  ) {
    const checkout = checkoutForms[orderId] ?? checkoutDefaults();
    updateCheckoutForm(orderId, {
      payments: checkout.payments.map((payment, paymentIndex) =>
        paymentIndex === index ? { ...payment, ...changes } : payment,
      ),
    });
  }
  function addCheckoutPayment(orderId: string, orderTotal: string) {
    const checkout = checkoutForms[orderId] ?? checkoutDefaults();
    const outstanding = Math.max(0, Number(orderTotal) - paymentTotal(checkout.payments));
    updateCheckoutForm(orderId, {
      payments: [
        ...checkout.payments,
        { ...checkoutPaymentDefaults(), amount: outstanding ? outstanding.toFixed(2) : "" },
      ],
    });
  }
  async function settleOrder(orderId: string) {
    const order = findDiningOrder(orderId);
    if (!order) return;
    const checkout = checkoutForms[orderId] ?? checkoutDefaults();
    if (!checkout.revenueCategoryId)
      return setMessage("Cadastre uma categoria de receita ativa antes de concluir a comanda.");
    const hasPayments = checkout.payments.length > 0;
    const receivedTotal = paymentTotal(checkout.payments);
    if (hasPayments && !paymentsAreComplete(checkout.payments))
      return setMessage("Preencha valor, conta e forma de recebimento em cada pagamento.");
    if (hasPayments && hasDuplicatePaymentDestination(checkout.payments))
      return setMessage("Agrupe valores que usam a mesma forma de recebimento e conta financeira.");
    if (hasPayments && !paymentsMatchOrderTotal(order.total, checkout.payments))
      return setMessage(
        `Os pagamentos somam ${formatCurrency(String(receivedTotal))}, mas a comanda totaliza ${formatCurrency(order.total)}.`,
      );
    setMessage(null);
    setSettlingOrderId(order.id);
    const idempotencyKey = keyForPendingOperation(
      settlementIdempotencyKeysRef.current,
      order.id,
      crypto.randomUUID,
    );
    settlementIdempotencyKeysRef.current = {
      ...settlementIdempotencyKeysRef.current,
      [order.id]: idempotencyKey,
    };
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/settlement`,
        {
          body: JSON.stringify({
            dueDate: checkout.dueDate,
            expectedVersion: order.version,
            payments: hasPayments
              ? checkout.payments.map((payment) => ({
                  ...payment,
                  amount: payment.amount.replace(",", "."),
                }))
              : undefined,
            revenueCategoryId: checkout.revenueCategoryId,
          }),
          headers: { "content-type": "application/json", "idempotency-key": idempotencyKey },
          method: "POST",
        },
      );
      const result = (await response.json()) as {
        data?: { order?: unknown; sale?: unknown };
      } & ProblemDetails;
      if (!response.ok) return setMessage(result.detail ?? "Não foi possível concluir a comanda.");
      const settledOrder = foodServiceOrderViewSchema.parse(result.data?.order);
      const sale = completedSaleViewSchema.parse(result.data?.sale);
      const remainingTabs = (orders[settledOrder.tableSessionId ?? ""] ?? []).filter(
        (item) => item.id !== settledOrder.id,
      );
      removeDiningOrder(settledOrder.id);
      if (remainingTabs.length === 0)
        setSessions((value) =>
          value.filter((session) => session.id !== settledOrder.tableSessionId),
        );
      setCheckoutForms((value) => {
        const next = { ...value };
        delete next[order.id];
        return next;
      });
      delete settlementIdempotencyKeysRef.current[order.id];
      setMessage(
        sale.receivable.status === "SETTLED"
          ? remainingTabs.length === 0
            ? `Última conta liquidada na venda #${sale.number}. A mesa foi liberada.`
            : `Conta liquidada na venda #${sale.number}. A mesa continua com outras contas abertas.`
          : remainingTabs.length === 0
            ? `Última conta concluída na venda #${sale.number}, com recebimento a prazo. A mesa foi liberada.`
            : `Conta concluída na venda #${sale.number}, com recebimento a prazo. A mesa continua com outras contas abertas.`,
      );
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : "Não foi possível concluir a comanda.");
    } finally {
      setSettlingOrderId(null);
    }
  }
  async function settleCounterOrder(orderId: string) {
    const order = counterOrders.find((item) => item.id === orderId);
    if (!order) return;
    const checkout = checkoutForms[order.id] ?? checkoutDefaults();
    if (!checkout.revenueCategoryId)
      return setMessage("Cadastre uma categoria de receita ativa antes de concluir o pedido.");
    const hasPayments = checkout.payments.length > 0;
    const receivedTotal = paymentTotal(checkout.payments);
    if (hasPayments && !paymentsAreComplete(checkout.payments))
      return setMessage("Preencha valor, conta e forma de recebimento em cada pagamento.");
    if (hasPayments && hasDuplicatePaymentDestination(checkout.payments))
      return setMessage("Agrupe valores que usam a mesma forma de recebimento e conta financeira.");
    if (hasPayments && !paymentsMatchOrderTotal(order.total, checkout.payments))
      return setMessage(
        `Os pagamentos somam ${formatCurrency(String(receivedTotal))}, mas o pedido totaliza ${formatCurrency(order.total)}.`,
      );
    setMessage(null);
    setSettlingOrderId(order.id);
    const idempotencyKey = keyForPendingOperation(
      settlementIdempotencyKeysRef.current,
      order.id,
      crypto.randomUUID,
    );
    settlementIdempotencyKeysRef.current = {
      ...settlementIdempotencyKeysRef.current,
      [order.id]: idempotencyKey,
    };
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/food-service-orders/${order.id}/settlement`,
        {
          body: JSON.stringify({
            dueDate: checkout.dueDate,
            expectedVersion: order.version,
            payments: hasPayments
              ? checkout.payments.map((payment) => ({
                  ...payment,
                  amount: payment.amount.replace(",", "."),
                }))
              : undefined,
            revenueCategoryId: checkout.revenueCategoryId,
          }),
          headers: { "content-type": "application/json", "idempotency-key": idempotencyKey },
          method: "POST",
        },
      );
      const result = (await response.json()) as {
        data?: { order?: unknown; sale?: unknown };
      } & ProblemDetails;
      if (!response.ok) return setMessage(result.detail ?? "Não foi possível concluir o pedido.");
      const settledOrder = foodServiceOrderViewSchema.parse(result.data?.order);
      const sale = completedSaleViewSchema.parse(result.data?.sale);
      setCounterOrders((value) => value.filter((item) => item.id !== settledOrder.id));
      setCheckoutForms((value) => {
        const next = { ...value };
        delete next[order.id];
        return next;
      });
      delete settlementIdempotencyKeysRef.current[order.id];
      setMessage(
        sale.receivable.status === "SETTLED"
          ? `Pedido de balcão liquidado na venda #${sale.number}.`
          : `Pedido de balcão concluído na venda #${sale.number}, com recebimento a prazo.`,
      );
    } catch (cause) {
      setMessage(cause instanceof Error ? cause.message : "Não foi possível concluir o pedido.");
    } finally {
      setSettlingOrderId(null);
    }
  }
  if (loading) return <LoadingRows rows={5} />;
  return (
    <section className="grid gap-6">
      {message ? (
        <p
          className="rounded-xl border border-brand-100 bg-brand-50 p-4 text-sm text-brand-900"
          role="status"
        >
          {message}
        </p>
      ) : null}
      <FoodServiceSettingsForm onSubmit={saveSettings} settings={current} />
      <section className="grid gap-4 rounded-2xl border bg-white p-5">
        <FoodServiceDiningConfiguration
          areas={branchAreas}
          branches={branches}
          branchId={branchId}
          onAddArea={addArea}
          onAddTable={addTable}
          onBranchChange={setBranchId}
        />
        <FoodServiceTableSessionOpening
          branchId={branchId}
          onSubmit={(event) => void openTableSession(event)}
          sessions={sessions}
          tables={tables}
        />
        <section className="rounded-xl border bg-slate-50 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-semibold">Atendimento de balcão</h3>
            <button
              className="rounded-lg bg-brand-700 px-3 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
              disabled={!branchId || !current.acceptsCounter}
              onClick={() => void createCounterOrder()}
              type="button"
            >
              Novo pedido de balcão
            </button>
          </div>
          <p className="mt-1 text-sm text-slate-600">
            Pedidos sem mesa permanecem separados das comandas do salão.
          </p>
          <p className="mt-3 text-sm font-medium text-slate-700">
            {counterOrders.length} pedido(s) de balcão em andamento
          </p>
          <div className="mt-3 grid gap-3">
            {counterOrders.map((order) => (
              <article className="rounded-lg border bg-white p-3" key={order.id}>
                <p className="font-medium">Pedido de balcão</p>
                {order.status === "DRAFT" ? (
                  <form
                    className="mt-3 grid gap-2"
                    onSubmit={(event) => void addCounterOrderItem(event, order.id)}
                  >
                    <FoodServiceOrderItemAdder
                      organizationId={organizationId}
                      products={products}
                      resetKey={order.version}
                    />
                  </form>
                ) : null}
                {order.status === "DRAFT" || order.status === "ACCEPTED" ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <input
                      className="h-10 min-w-52 flex-1 rounded-lg border px-3 text-sm"
                      maxLength={240}
                      onChange={(event) =>
                        setOrderCancellationReasons((value) => ({
                          ...value,
                          [order.id]: event.target.value,
                        }))
                      }
                      placeholder="Motivo do cancelamento"
                      value={orderCancellationReasons[order.id] ?? ""}
                    />
                    <button
                      className="rounded-lg border border-red-200 px-3 py-2 text-sm font-medium text-red-700"
                      onClick={() => void cancelCounterOrder(order.id)}
                      type="button"
                    >
                      Cancelar pedido
                    </button>
                  </div>
                ) : null}
                <div className="mt-3 grid gap-1 text-sm">
                  {order.items.map((item) => (
                    <div className="rounded-lg bg-slate-50 px-2 py-1.5" key={item.id}>
                      <p>
                        {formatItemQuantity(item.quantity, item.unit)} · {item.description}
                        <span className="float-right font-medium">
                          {formatCurrency(item.total)}
                        </span>
                      </p>
                      {item.modifierNames.length > 0 ? (
                        <p className="mt-0.5 text-xs text-slate-600">
                          {item.modifierNames.join(" · ")}
                        </p>
                      ) : null}
                      {item.notes ? (
                        <p className="mt-0.5 text-xs text-slate-600">Observação: {item.notes}</p>
                      ) : null}
                      {order.status === "DRAFT" ? (
                        <Button
                          className="mt-2"
                          onClick={() => void removeOrderItem(item.id, order)}
                          type="button"
                          variant="outline"
                        >
                          Remover item
                        </Button>
                      ) : null}
                    </div>
                  ))}
                  <p className="border-t pt-2 font-semibold">
                    Total <span className="float-right">{formatCurrency(order.total)}</span>
                  </p>
                </div>
                {order.status === "DRAFT" ? (
                  <button
                    className="mt-3 rounded-lg bg-brand-700 px-3 py-2 text-sm font-medium text-white"
                    onClick={() => void acceptCounterOrder(order.id)}
                    type="button"
                  >
                    Enviar para cozinha
                  </button>
                ) : null}
                {order.status === "ACCEPTED" ? (
                  <button
                    className="mt-3 rounded-lg bg-brand-700 px-3 py-2 text-sm font-medium text-white"
                    onClick={() => void beginCounterOrderCheckout(order.id)}
                    type="button"
                  >
                    Ir para pagamento
                  </button>
                ) : null}
                {order.status === "CHECKOUT_PENDING" ? (
                  <div className="mt-3">
                    <FoodServiceOrderCheckout
                      checkout={checkoutForms[order.id] ?? checkoutDefaults()}
                      compatibleAccounts={compatibleAccounts}
                      context="counter"
                      onAddPayment={(orderTotal) => addCheckoutPayment(order.id, orderTotal)}
                      onRemovePayment={(index) =>
                        updateCheckoutForm(order.id, {
                          payments: (checkoutForms[order.id]?.payments ?? []).filter(
                            (_, paymentIndex) => paymentIndex !== index,
                          ),
                        })
                      }
                      onSettle={() => void settleCounterOrder(order.id)}
                      onUpdateCheckout={(changes) => updateCheckoutForm(order.id, changes)}
                      onUpdatePayment={(index, changes) =>
                        updateCheckoutPayment(order.id, index, changes)
                      }
                      order={order}
                      paymentMethods={paymentMethods}
                      revenueCategories={revenueCategories}
                      settling={settlingOrderId === order.id}
                    />
                  </div>
                ) : null}
              </article>
            ))}
          </div>
        </section>
        <FoodServiceTableSessionCards
          branchId={branchId}
          checkoutDefaults={checkoutDefaults}
          checkoutForms={checkoutForms}
          compatibleAccounts={compatibleAccounts}
          onAcceptOrder={(orderId) => void acceptOrder(orderId)}
          onAddCheckoutPayment={addCheckoutPayment}
          onAddOrderItem={(event, orderId) => void addOrderItem(event, orderId)}
          onBeginCheckout={(orderId) => void beginOrderCheckout(orderId)}
          onCancelOrder={(orderId, reason) => void cancelOrder(orderId, reason)}
          onCancelSession={(sessionId) => void cancelTableSession(sessionId)}
          onCreateOrder={(session, tabLabel) => void createOrder(session, tabLabel)}
          onMoveOrderItem={(itemId, sourceOrder, targetOrderId, quantity) =>
            void moveOrderItem(itemId, sourceOrder, targetOrderId, quantity)
          }
          onRemoveOrderItem={(itemId, order) => void removeOrderItem(itemId, order)}
          onMoveSession={(session, diningTableId) => void moveTableSession(session, diningTableId)}
          onRemovePayment={(orderId, index) =>
            updateCheckoutForm(orderId, {
              payments: (checkoutForms[orderId]?.payments ?? []).filter(
                (_, paymentIndex) => paymentIndex !== index,
              ),
            })
          }
          onSettle={(orderId) => void settleOrder(orderId)}
          onUpdateCheckout={updateCheckoutForm}
          onUpdatePayment={updateCheckoutPayment}
          organizationId={organizationId}
          orders={orders}
          paymentMethods={paymentMethods}
          products={products}
          revenueCategories={revenueCategories}
          sessions={sessions}
          settlingOrderId={settlingOrderId}
          tables={tables}
        />
        <FoodServiceKitchenStations
          branchId={branchId}
          onAdd={addKitchenStation}
          onSetDefault={(station) => void setDefaultKitchenStation(station)}
          stations={kitchenStations}
        />
        <FoodServiceKitchenRoutes
          branchId={branchId}
          onSave={(productId, kitchenStationId) =>
            void saveKitchenProductRoute(productId, kitchenStationId)
          }
          products={products}
          routes={kitchenProductRoutes}
          stations={kitchenStations}
        />
        <FoodServiceModifierConfiguration organizationId={organizationId} products={products} />
        <FoodServiceRecipes
          branchId={branchId}
          organizationId={organizationId}
          products={products}
        />
        <FoodServiceKitchenQueue
          branchId={branchId}
          cancellationReasons={ticketCancellationReasons}
          onCancellationReasonChange={(ticketId, reason) =>
            setTicketCancellationReasons((value) => ({ ...value, [ticketId]: reason }))
          }
          onStationFilterChange={setKitchenStationFilter}
          onStatusFilterChange={setKitchenStatusFilter}
          onRefresh={() =>
            void refreshKitchenTickets().catch((cause) =>
              setMessage(
                cause instanceof Error ? cause.message : "Não foi possível atualizar a fila.",
              ),
            )
          }
          onResolutionReasonChange={(ticketId, reason) =>
            setTicketResolutionReasons((value) => ({ ...value, [ticketId]: reason }))
          }
          onResolveIngredients={(ticket, resolution) =>
            void resolveTicketIngredients(ticket, resolution)
          }
          resolutionReasons={ticketResolutionReasons}
          onTransition={(ticket, status) => void transitionKitchenTicket(ticket, status)}
          stationFilter={kitchenStationFilter}
          statusFilter={kitchenStatusFilter}
          stations={kitchenStations}
          tickets={visibleKitchenTickets}
        />
        <FoodServiceDiningTableOverview areas={branchAreas} tables={tables} />
      </section>
    </section>
  );
}
