"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  catalogFileDownloadViewSchema,
  catalogFileListSchema,
  catalogFilePurposeSchema,
  type CatalogFilePurpose,
  type CatalogFileView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

export function CatalogFilesButton({
  allowImage,
  itemId,
  organizationId,
  segment,
}: {
  allowImage: boolean;
  itemId: string;
  organizationId: string;
  segment:
    | "customers"
    | "appointments"
    | "financial-obligations"
    | "organization"
    | "products"
    | "purchases"
    | "quotes"
    | "sales"
    | "services"
    | "suppliers"
    | "support-tickets";
}) {
  const [files, setFiles] = useState<readonly CatalogFileView[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [previews, setPreviews] = useState<Record<string, string>>({});
  const endpoint =
    segment === "organization"
      ? `/api/v1/organizations/${organizationId}/files`
      : `/api/v1/organizations/${organizationId}/${segment}/${itemId}/files`;
  const attachmentPurpose: CatalogFilePurpose = {
    customers: "CUSTOMER_ATTACHMENT",
    appointments: "APPOINTMENT_ATTACHMENT",
    "financial-obligations": "FINANCIAL_OBLIGATION_ATTACHMENT",
    organization: "ORGANIZATION_ATTACHMENT",
    products: "PRODUCT_ATTACHMENT",
    purchases: "PURCHASE_ATTACHMENT",
    quotes: "QUOTE_ATTACHMENT",
    sales: "SALE_ATTACHMENT",
    services: "SERVICE_ATTACHMENT",
    suppliers: "SUPPLIER_ATTACHMENT",
    "support-tickets": "SUPPORT_ATTACHMENT",
  }[segment] as CatalogFilePurpose;
  const uploadFormSchema = z.object({
    file: z.custom<FileList>(
      (value) => typeof FileList !== "undefined" && value instanceof FileList && value.length === 1,
      "Selecione um arquivo.",
    ),
    purpose: catalogFilePurposeSchema,
  });
  const {
    formState: { errors: formErrors },
    handleSubmit: handleUploadSubmit,
    register: registerUpload,
    reset: resetUpload,
  } = useForm<z.input<typeof uploadFormSchema>, undefined, z.output<typeof uploadFormSchema>>({
    defaultValues: { purpose: allowImage ? "PRODUCT_IMAGE" : attachmentPurpose },
    resolver: zodResolver(uploadFormSchema),
  });
  async function load() {
    if (files) return setFiles(null);
    const response = await fetch(endpoint);
    if (!response.ok) return setError(((await response.json()) as ProblemDetails).detail);
    const payload = (await response.json()) as { data: unknown };
    const parsed = catalogFileListSchema.parse(payload.data);
    setError(null);
    setFiles(parsed);
    await Promise.all(
      parsed
        .filter((file) => file.purpose === "PRODUCT_IMAGE" && file.status === "AVAILABLE")
        .map((file) => loadSignedUrl(file.id, true)),
    );
  }
  const upload = handleUploadSubmit(async (values) => {
    const selectedFile = values.file.item(0);
    if (!selectedFile) return setError("Selecione um arquivo.");
    setBusy(true);
    const form = new FormData();
    form.set("file", selectedFile);
    form.set("purpose", values.purpose);
    const response = await fetch(endpoint, {
      body: form,
      headers: { "idempotency-key": crypto.randomUUID() },
      method: "POST",
    });
    setBusy(false);
    if (!response.ok) return setError(((await response.json()) as ProblemDetails).detail);
    const payload = (await response.json()) as { data: unknown };
    const uploaded = catalogFileListSchema.element.parse(payload.data);
    setError(null);
    setFiles((current) => [
      uploaded,
      ...(current ?? []).filter(
        (file) => uploaded.purpose !== "PRODUCT_IMAGE" || file.purpose !== "PRODUCT_IMAGE",
      ),
    ]);
    resetUpload({ purpose: allowImage ? "PRODUCT_IMAGE" : attachmentPurpose });
    if (uploaded.purpose === "PRODUCT_IMAGE") await loadSignedUrl(uploaded.id, true);
  });
  async function loadSignedUrl(fileId: string, preview = false) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/catalog-files/${fileId}/download`,
    );
    if (!response.ok) return setError(((await response.json()) as ProblemDetails).detail);
    const payload = (await response.json()) as { data: unknown };
    const download = catalogFileDownloadViewSchema.parse(payload.data);
    if (preview) setPreviews((current) => ({ ...current, [fileId]: download.url }));
    else window.open(download.url, "_blank", "noopener,noreferrer");
  }
  async function remove(fileId: string) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/catalog-files/${fileId}`,
      { method: "DELETE" },
    );
    if (!response.ok) return setError(((await response.json()) as ProblemDetails).detail);
    setFiles((current) => current?.filter((file) => file.id !== fileId) ?? null);
    setPreviews((current) => {
      const next = { ...current };
      delete next[fileId];
      return next;
    });
  }
  return (
    <div className="relative">
      <Button onClick={() => void load()} type="button" variant="outline">
        Arquivos
      </Button>
      {files ? (
        <div className="absolute right-0 top-11 z-20 w-80 rounded-xl border bg-white p-3 text-left text-xs shadow-lg">
          <p className="mb-2 font-semibold">{allowImage ? "Fotos e anexos" : "Anexos"}</p>
          <form className="grid gap-2" onSubmit={upload}>
            <Input
              accept={
                allowImage ? ".jpg,.jpeg,.png,.webp,.pdf,.xml,.csv,.xlsx" : ".pdf,.xml,.csv,.xlsx"
              }
              type="file"
              {...registerUpload("file")}
            />
            {formErrors.file ? <p className="text-red-700">{formErrors.file.message}</p> : null}
            <select className="h-9 rounded-lg border bg-white px-2" {...registerUpload("purpose")}>
              {allowImage ? <option value="PRODUCT_IMAGE">Foto principal</option> : null}
              <option value={attachmentPurpose}>Anexo</option>
            </select>
            <Button disabled={busy} type="submit">
              {busy ? "Verificando..." : "Enviar"}
            </Button>
          </form>
          <div className="mt-3 grid gap-2">
            {files.map((file) => (
              <div className="rounded-lg border p-2" key={file.id}>
                {previews[file.id] ? (
                  <div
                    aria-label={file.originalName}
                    className="mb-2 h-24 w-full rounded bg-cover bg-center"
                    role="img"
                    style={{ backgroundImage: `url(${JSON.stringify(previews[file.id])})` }}
                  />
                ) : null}
                <p className="truncate font-medium">{file.originalName}</p>
                <p className="text-slate-500">
                  {file.status === "AVAILABLE"
                    ? "Disponível"
                    : file.status === "BLOCKED"
                      ? "Bloqueado"
                      : "Em verificação"}
                </p>
                <div className="mt-2 flex gap-2">
                  {file.status === "AVAILABLE" ? (
                    <Button
                      onClick={() => void loadSignedUrl(file.id)}
                      type="button"
                      variant="outline"
                    >
                      Abrir
                    </Button>
                  ) : null}
                  <Button onClick={() => void remove(file.id)} type="button" variant="outline">
                    Excluir
                  </Button>
                </div>
              </div>
            ))}
          </div>
          {error ? <p className="mt-2 text-red-700">{error}</p> : null}
        </div>
      ) : null}
    </div>
  );
}
