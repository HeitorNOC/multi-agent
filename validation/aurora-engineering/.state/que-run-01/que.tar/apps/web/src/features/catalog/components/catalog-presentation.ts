/**
 * Keeps quantity presentation consistent across public checkout and internal order views.
 * Stored quantities retain their database precision; people should only see useful digits.
 */
export function formatCatalogQuantity(value: number | string) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 3 }).format(Number(value));
}

export function formatCatalogItemCount(value: number) {
  return `${formatCatalogQuantity(value)} ${value === 1 ? "item" : "itens"}`;
}
