import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { ModuleGate } from "@/features/modules/components/module-gate";
import { ScheduleBoard } from "@/features/scheduling/components/schedule-board";

export const metadata: Metadata = { title: "Agenda | Gestor" };
type AgendaPageProps = { params: Promise<{ organizationId: string }> };
export default async function AgendaPage({ params }: AgendaPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Agenda Pro
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">Agenda</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Acompanhe os atendimentos por dia e filial e crie novos agendamentos nesta área.
        </p>
      </header>
      <ModuleGate moduleCode="scheduling" organizationId={organizationId}>
        <ScheduleBoard organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
