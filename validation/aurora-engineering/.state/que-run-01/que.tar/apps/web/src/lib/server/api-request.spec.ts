import { createHash } from "node:crypto";

import { beforeEach, describe, expect, it, vi } from "vitest";

import { BusinessRuleError } from "@gestor/kernel";

const { authenticate, requireCurrentLegalAcceptance } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  requireCurrentLegalAcceptance: vi.fn(),
}));

vi.mock("./container", () => ({
  services: { identityProvider: { authenticate } },
}));

import {
  handleApiRequest,
  readJsonBody,
  readLimitedTextBody,
  requireIdempotencyKey,
} from "./api-request";
import { MemoryRateLimiter } from "./rate-limit";

describe("readJsonBody", () => {
  it("returns a parsed JSON body", async () => {
    const request = new Request("http://localhost/api", {
      body: JSON.stringify({ name: "Empresa" }),
      headers: { "content-type": "application/json" },
      method: "POST",
    });

    await expect(readJsonBody(request)).resolves.toEqual({ name: "Empresa" });
  });

  it("maps malformed JSON to a validation error", async () => {
    const request = new Request("http://localhost/api", {
      body: "{invalid",
      headers: { "content-type": "application/json" },
      method: "POST",
    });

    await expect(readJsonBody(request)).rejects.toMatchObject({
      code: "INVALID_JSON_BODY",
      kind: "VALIDATION",
    });
  });
});

describe("readLimitedTextBody", () => {
  it("streams text and calculates the checksum of the original bytes", async () => {
    const bytes = new TextEncoder().encode("data;descrição;valor");
    const request = new Request("http://localhost/api", {
      body: bytes,
      method: "POST",
    });

    await expect(readLimitedTextBody(request, 1024)).resolves.toEqual({
      checksumSha256: createHash("sha256").update(bytes).digest("hex"),
      content: "data;descrição;valor",
      sizeBytes: bytes.byteLength,
    });
  });

  it("rejects a streamed body as soon as it exceeds the byte limit", async () => {
    const request = new Request("http://localhost/api", {
      body: "123456",
      method: "POST",
    });

    await expect(readLimitedTextBody(request, 5)).rejects.toMatchObject({
      code: "REQUEST_BODY_TOO_LARGE",
      kind: "PAYLOAD_TOO_LARGE",
    });
  });
});

describe("requireIdempotencyKey", () => {
  it("accepts an external key with up to 120 characters", () => {
    const key = "a".repeat(120);
    const request = new Request("http://localhost/api", {
      headers: { "idempotency-key": key },
    });

    expect(requireIdempotencyKey(request)).toBe(key);
  });

  it("rejects a key that would leave no room for the internal operation prefix", () => {
    const request = new Request("http://localhost/api", {
      headers: { "idempotency-key": "a".repeat(121) },
    });

    expect(() => requireIdempotencyKey(request)).toThrowError("entre 8 e 120 caracteres");
  });
});

describe("handleApiRequest", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: crypto.randomUUID() });
    requireCurrentLegalAcceptance.mockReset().mockResolvedValue(undefined);
  });

  it("authenticates private requests before entering the route handler", async () => {
    const handler = vi.fn().mockResolvedValue(Response.json({ data: true }));
    const request = new Request("http://localhost/api/v1/organizations");

    expect(
      (await handleApiRequest(request, handler, { legalAcceptance: false, rateLimit: false }))
        .status,
    ).toBe(200);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(handler).toHaveBeenCalledOnce();
  });

  it("rejects a cross-site mutation before authentication", async () => {
    const handler = vi.fn();
    const request = new Request("https://app.example.com/api/v1/organizations", {
      headers: { origin: "https://attacker.example", "sec-fetch-site": "cross-site" },
      method: "POST",
    });

    const response = await handleApiRequest(request, handler, {
      legalAcceptance: false,
      rateLimit: false,
    });

    expect(response.status).toBe(403);
    expect(authenticate).not.toHaveBeenCalled();
    expect(handler).not.toHaveBeenCalled();
  });

  it("returns structured business impact without leaking an internal stack", async () => {
    const response = await handleApiRequest(
      new Request("http://localhost/api/v1/platform/modules"),
      async () => {
        throw new BusinessRuleError(
          "MODULE_HAS_LIVE_OBLIGATIONS",
          "O módulo possui operações vivas.",
          {
            impact: {
              futureAppointments: 2,
            },
          },
        );
      },
      { authentication: "PUBLIC", rateLimit: false },
    );

    await expect(response.json()).resolves.toMatchObject({
      code: "MODULE_HAS_LIVE_OBLIGATIONS",
      meta: {
        impact: {
          futureAppointments: 2,
        },
      },
      status: 422,
    });
  });

  it("enforces an overridable policy before entering the route handler", async () => {
    const limiter = new MemoryRateLimiter();
    const policy = { limit: 1, namespace: "test.api", windowMs: 60_000 } as const;
    const handler = async () => Response.json({ data: true });
    const request = new Request("http://localhost/api/v1/test");
    const options = {
      authentication: "PUBLIC" as const,
      rateLimit: policy,
      rateLimiter: limiter,
      rateLimitSubject: "client-1",
    };

    expect((await handleApiRequest(request, handler, options)).status).toBe(200);
    const blocked = await handleApiRequest(request, handler, options);

    expect(blocked.status).toBe(429);
    expect(blocked.headers.get("ratelimit-remaining")).toBe("0");
    expect(blocked.headers.get("retry-after")).not.toBeNull();
    await expect(blocked.json()).resolves.toMatchObject({ code: "RATE_LIMIT_EXCEEDED" });
  });
});
