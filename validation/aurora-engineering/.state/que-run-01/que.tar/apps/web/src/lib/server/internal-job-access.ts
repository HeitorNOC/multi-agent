import { timingSafeEqual } from "node:crypto";

import { AuthenticationError } from "@gestor/kernel";

export function requireInternalJobAccess(request: Request, expectedToken: string): void {
  const authorization = request.headers.get("authorization");
  const suppliedToken = authorization?.startsWith("Bearer ")
    ? authorization.slice("Bearer ".length)
    : "";

  if (!safeEqual(suppliedToken, expectedToken)) {
    throw new AuthenticationError(
      "INTERNAL_JOB_AUTHENTICATION_REQUIRED",
      "Autenticação da tarefa interna inválida.",
    );
  }
}

function safeEqual(left: string, right: string): boolean {
  const leftBytes = Buffer.from(left);
  const rightBytes = Buffer.from(right);
  return leftBytes.length === rightBytes.length && timingSafeEqual(leftBytes, rightBytes);
}
