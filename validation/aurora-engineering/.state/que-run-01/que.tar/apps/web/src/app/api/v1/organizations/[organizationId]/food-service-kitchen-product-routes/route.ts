import {
  foodServiceListQuerySchema,
  organizationParamsSchema,
  setFoodServiceKitchenProductRouteBodySchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

async function actorFor(
  api: { correlationId: string; requestId: string },
  organizationId: string,
  request: Request,
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({
    correlationId: api.correlationId,
    organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
}

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = foodServiceListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams.entries()),
    );
    return Response.json({
      data: await services.listFoodServiceKitchenProductRoutes.execute(
        { ...params, ...(query.branchId ? { branchId: query.branchId } : {}) },
        await actorFor(api, params.organizationId, request),
      ),
    });
  });
}

export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = setFoodServiceKitchenProductRouteBodySchema.parse(await readJsonBody(request));
    const actor = await actorFor(api, params.organizationId, request);
    await services.setFoodServiceKitchenProductRoute.execute({ ...body, ...params }, actor);
    return Response.json({
      data: await services.listFoodServiceKitchenProductRoutes.execute(
        { ...params, branchId: body.branchId },
        actor,
      ),
    });
  });
}
