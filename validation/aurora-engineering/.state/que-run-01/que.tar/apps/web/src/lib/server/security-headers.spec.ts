import { describe, expect, it } from "vitest";

import { applicationSecurityHeaders } from "./security-headers";

describe("application security headers", () => {
  it("protects every page without enabling cross-origin API access", () => {
    const headers = Object.fromEntries(
      applicationSecurityHeaders.map(({ key, value }) => [key.toLowerCase(), value]),
    );

    expect(headers["content-security-policy"]).toContain("frame-ancestors 'none'");
    expect(headers["content-security-policy"]).toContain("object-src 'none'");
    expect(headers["strict-transport-security"]).toContain("max-age=31536000");
    expect(headers["x-content-type-options"]).toBe("nosniff");
    expect(headers).not.toHaveProperty("access-control-allow-origin");
  });
});
