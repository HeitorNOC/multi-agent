"use client";

import {
  helpArticleListSchema,
  type HelpArticleView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";

export function HelpCenter({ organizationId }: { organizationId: string }) {
  const [articles, setArticles] = useState<readonly HelpArticleView[]>([]);
  const [query, setQuery] = useState("");
  const [feedback, setFeedback] = useState("");
  async function search(signal?: AbortSignal) {
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/help-articles?query=${encodeURIComponent(query)}`,
      signal ? { signal } : undefined,
    );
    const payload = (await response.json()) as Partial<ProblemDetails>;
    if (!response.ok) throw new Error(payload.detail ?? "Não foi possível pesquisar a ajuda.");
    return helpArticleListSchema.parse(payload);
  }
  useEffect(() => {
    const controller = new AbortController();
    void search(controller.signal)
      .then(setArticles)
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Falha ao carregar a ajuda.");
      });
    return () => controller.abort(); /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [organizationId]);
  return (
    <section className="grid gap-4" aria-labelledby="help-title">
      <div>
        <h2 className="text-2xl font-semibold" id="help-title">
          Base de ajuda
        </h2>
        <p className="text-sm text-slate-600">Pesquise orientações organizadas por módulo.</p>
      </div>
      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          void search()
            .then(setArticles)
            .catch((error: unknown) =>
              setFeedback(error instanceof Error ? error.message : "Falha na pesquisa."),
            );
        }}
      >
        <Input
          aria-label="Pesquisar ajuda"
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Ex.: cancelar uma venda"
          value={query}
        />
        <Button type="submit">Pesquisar</Button>
      </form>
      {feedback ? (
        <p className="text-sm text-red-700" role="alert">
          {feedback}
        </p>
      ) : null}
      <div className="grid gap-3 md:grid-cols-2">
        {articles.map((article) => (
          <article className="rounded-2xl border bg-white p-5" key={article.id}>
            <p className="text-xs font-semibold uppercase text-slate-500">{article.category}</p>
            <h3 className="mt-1 font-semibold">{article.title}</h3>
            <p className="mt-2 text-sm text-slate-600">{article.summary}</p>
            <details className="mt-3 text-sm">
              <summary className="cursor-pointer font-medium">Ver orientação</summary>
              <p className="mt-2 whitespace-pre-wrap">{article.content}</p>
            </details>
          </article>
        ))}
        {articles.length === 0 ? (
          <p className="text-sm text-slate-600">Nenhum artigo encontrado.</p>
        ) : null}
      </div>
    </section>
  );
}
