import type { Metadata } from "next";
import { connection } from "next/server";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { ResetPasswordForm } from "@/features/auth/components/reset-password-form";

export const metadata: Metadata = {
  title: "Redefinir senha | Gestor",
};

type ResetPasswordPageProps = {
  searchParams: Promise<{
    error?: string;
    token?: string;
  }>;
};

export default async function ResetPasswordPage({ searchParams }: ResetPasswordPageProps) {
  await connection();
  const params = await searchParams;

  return (
    <AuthShell
      description="Crie uma nova senha para retomar o acesso com segurança."
      eyebrow="Nova credencial"
      title="Redefina sua senha"
    >
      <ResetPasswordForm error={params.error} token={params.token} />
    </AuthShell>
  );
}
