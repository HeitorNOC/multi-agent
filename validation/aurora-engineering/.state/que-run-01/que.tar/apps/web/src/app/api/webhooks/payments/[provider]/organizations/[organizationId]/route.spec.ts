import { expect, it, vi } from "vitest";

const { loggerError, processWebhook } = vi.hoisted(() => ({
  loggerError: vi.fn(),
  processWebhook: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({
    LOG_LEVEL: "silent",
    NODE_ENV: "test",
    RATE_LIMIT_HASH_SECRET: "test-secret",
    TRUST_PROXY_HEADERS: false,
  }),
}));
vi.mock("@/lib/server/container", () => ({
  services: { processTerminalPaymentWebhook: { execute: processWebhook } },
}));
vi.mock("@gestor/observability", () => ({
  getLogger: () => ({ error: loggerError }),
  metrics: { increment: vi.fn(), observe: vi.fn() },
}));

import { POST } from "./route";

it("forwards a signed Stripe event without a charge id in the URL", async () => {
  const rawBody = JSON.stringify({ id: "evt_001", type: "checkout.session.completed" });
  processWebhook.mockResolvedValue({ id: "charge", status: "CONFIRMED" });
  const params = {
    organizationId: "10000000-0000-4000-8000-000000000001",
    provider: "STRIPE",
  };
  const response = await POST(
    new Request("https://hml.example.com/api/webhooks/payments/STRIPE/organizations/id", {
      body: rawBody,
      headers: { "stripe-signature": "t=1700000000,v1=signature" },
      method: "POST",
    }),
    { params: Promise.resolve(params) },
  );
  const payload = await response.json();
  const logged = loggerError.mock.calls[0]?.[0] as { err?: Error } | undefined;
  expect(response.status, `${logged?.err?.message ?? "unknown"}: ${JSON.stringify(payload)}`).toBe(
    200,
  );
  expect(processWebhook).toHaveBeenCalledWith({
    ...params,
    rawBody,
    signature: "t=1700000000,v1=signature",
  });
});

it("passes Mercado Pago identifiers required by its signed manifest", async () => {
  const params = {
    organizationId: "10000000-0000-4000-8000-000000000001",
    provider: "MERCADO_PAGO",
  };
  const response = await POST(
    new Request(
      "https://hml.example.com/api/webhooks/payments/MERCADO_PAGO/organizations/id?data.id=ORD123",
      {
        body: "{}",
        headers: { "x-request-id": "request-123", "x-signature": "ts=1,v1=signature" },
        method: "POST",
      },
    ),
    { params: Promise.resolve(params) },
  );
  expect(response.status).toBe(200);
  expect(processWebhook).toHaveBeenLastCalledWith({
    ...params,
    dataId: "ORD123",
    rawBody: "{}",
    requestId: "request-123",
    signature: "ts=1,v1=signature",
  });
});

it("rejects the sandbox provider on the organization webhook route", async () => {
  const response = await POST(
    new Request("https://hml.example.com/api/webhooks/payments/SANDBOX/organizations/id", {
      body: "{}",
      headers: { "x-signature": "signature" },
      method: "POST",
    }),
    {
      params: Promise.resolve({
        organizationId: "10000000-0000-4000-8000-000000000001",
        provider: "SANDBOX",
      }),
    },
  );
  expect(response.status).toBe(401);
  expect(processWebhook).not.toHaveBeenCalledWith(expect.objectContaining({ provider: "SANDBOX" }));
});
