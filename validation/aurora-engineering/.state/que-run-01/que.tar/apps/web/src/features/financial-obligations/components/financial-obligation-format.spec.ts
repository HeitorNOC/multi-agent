import { describe, expect, it } from "vitest";

import { formatBrl, formatDate } from "./financial-obligation-format";

describe("financial obligation formatting", () => {
  it("formats canonical money and date values for pt-BR", () => {
    expect(formatBrl("1234.5000")).toBe("R$ 1.234,50");
    expect(formatBrl("0")).toBe("R$ 0,00");
    expect(formatDate("2026-08-11")).toBe("11/08/2026");
  });
});
