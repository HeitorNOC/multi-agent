export function keyForPendingOperation(
  keys: Readonly<Record<string, string>>,
  operationId: string,
  createKey: () => string,
) {
  return keys[operationId] ?? createKey();
}
