import { catalogFilePurposeSchema } from "@gestor/contracts";
import { BusinessRuleError, PayloadTooLargeError } from "@gestor/kernel";

import { MAX_CATALOG_FILE_BYTES } from "@gestor/catalog";

export async function readCatalogFileUpload(request: Request) {
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > MAX_CATALOG_FILE_BYTES + 512 * 1024)
    throw new PayloadTooLargeError("FILE_TOO_LARGE", "O arquivo excede o limite permitido.");
  const form = await request.formData();
  const value = form.get("file");
  if (!(value instanceof File))
    throw new BusinessRuleError("FILE_REQUIRED", "Selecione um arquivo para enviar.");
  const purpose = catalogFilePurposeSchema.parse(form.get("purpose"));
  const bytes = new Uint8Array(await value.arrayBuffer());
  if (bytes.byteLength > MAX_CATALOG_FILE_BYTES)
    throw new PayloadTooLargeError("FILE_TOO_LARGE", "O arquivo excede o limite permitido.");
  return { bytes, mimeType: value.type, originalName: value.name, purpose };
}
