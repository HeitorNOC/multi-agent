"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  provisionOrganizationBodySchema,
  provisionOrganizationResponseSchema,
  type BusinessSegment,
  type ProblemDetails,
  type ProvisionOrganizationBody,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";

const segmentOptions: readonly {
  description: string;
  label: string;
  value: BusinessSegment;
}[] = [
  { description: "Barbearias e estúdios masculinos", label: "Barbearia", value: "BARBERSHOP" },
  { description: "Salões, estética e beleza", label: "Salão e beleza", value: "BEAUTY_SALON" },
  { description: "Mercados, mercearias e conveniências", label: "Mercado", value: "MARKET" },
  { description: "Lojas e comércio em geral", label: "Varejo", value: "RETAIL" },
  {
    description: "Restaurantes, lanchonetes e alimentos",
    label: "Alimentação",
    value: "FOOD_SERVICE",
  },
  {
    description: "Clínicas, academias e bem-estar",
    label: "Saúde e bem-estar",
    value: "HEALTH_WELLNESS",
  },
  {
    description: "Consultorias, oficinas e outros serviços",
    label: "Serviços",
    value: "PROFESSIONAL_SERVICES",
  },
  { description: "Descreva a atividade da sua empresa", label: "Outro", value: "OTHER" },
] as const;

const inputClassName = "h-11 rounded-xl bg-white px-3";

export function OrganizationOnboardingForm() {
  const router = useRouter();
  const [idempotencyKey] = useState(() => crypto.randomUUID());
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
  } = useForm<ProvisionOrganizationBody>({
    defaultValues: {
      branchName: "Matriz",
      document: undefined,
      organizationName: "",
      segmentDescription: undefined,
    },
    resolver: zodResolver(provisionOrganizationBodySchema),
    shouldUnregister: true,
  });
  const selectedSegment = useWatch({ control, name: "businessSegment" });

  const submit = handleSubmit(async (values) => {
    try {
      const response = await fetch("/api/v1/organizations", {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": idempotencyKey,
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", {
          message: problem.detail,
          type: problem.code,
        });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const result = provisionOrganizationResponseSchema.parse(payload.data);
      router.replace(`/organizations/${result.organizationId}`);
      router.refresh();
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <form className="grid gap-8" noValidate onSubmit={submit}>
      <section className="grid gap-5" aria-labelledby="company-data-title">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Etapa 1</p>
          <h2 className="mt-2 text-lg font-semibold text-slate-950" id="company-data-title">
            Dados principais
          </h2>
        </div>

        <div className="grid gap-2">
          <Label className="text-slate-800" htmlFor="organization-name">
            Nome da empresa
          </Label>
          <Input
            aria-describedby={errors.organizationName ? "organization-name-error" : undefined}
            aria-invalid={Boolean(errors.organizationName)}
            autoComplete="organization"
            className={inputClassName}
            id="organization-name"
            placeholder="Ex.: Barbearia Central"
            {...register("organizationName")}
          />
          {errors.organizationName ? (
            <p className="text-sm text-red-700" id="organization-name-error" role="alert">
              {errors.organizationName.message}
            </p>
          ) : null}
        </div>

        <div className="grid gap-2">
          <Label className="text-slate-800" htmlFor="organization-document">
            CPF ou CNPJ <span className="font-normal text-slate-500">(opcional)</span>
          </Label>
          <Input
            aria-describedby={errors.document ? "organization-document-error" : undefined}
            aria-invalid={Boolean(errors.document)}
            autoComplete="off"
            className={inputClassName}
            id="organization-document"
            inputMode="numeric"
            placeholder="Somente números"
            {...register("document", {
              setValueAs: (value: string) => value.trim() || undefined,
            })}
          />
          <p className="text-xs leading-5 text-slate-500">
            Você poderá completar os dados fiscais depois.
          </p>
          {errors.document ? (
            <p className="text-sm text-red-700" id="organization-document-error" role="alert">
              {errors.document.message}
            </p>
          ) : null}
        </div>
      </section>

      <section className="grid gap-5" aria-labelledby="segment-title">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Etapa 2</p>
          <h2 className="mt-2 text-lg font-semibold text-slate-950" id="segment-title">
            Segmento principal
          </h2>
          <p className="mt-1 text-sm leading-6 text-slate-600">
            Isso ajusta apenas termos e sugestões iniciais. As funcionalidades continuam disponíveis
            conforme o plano.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {segmentOptions.map((option) => (
            <label
              className="has-[:checked]:border-brand-500 has-[:checked]:bg-brand-50 has-[:focus-visible]:ring-brand-200 cursor-pointer rounded-2xl border bg-white p-4 transition has-[:focus-visible]:ring-3"
              key={option.value}
            >
              <span className="flex items-start gap-3">
                <input
                  className="text-brand-600 mt-1 size-4 shrink-0"
                  type="radio"
                  value={option.value}
                  {...register("businessSegment")}
                />
                <span>
                  <span className="block text-sm font-semibold text-slate-900">{option.label}</span>
                  <span className="mt-1 block text-xs leading-5 text-slate-500">
                    {option.description}
                  </span>
                </span>
              </span>
            </label>
          ))}
        </div>
        {errors.businessSegment ? (
          <p className="text-sm text-red-700" role="alert">
            {errors.businessSegment.message}
          </p>
        ) : null}

        {selectedSegment === "OTHER" ? (
          <div className="grid gap-2">
            <Label className="text-slate-800" htmlFor="segment-description">
              Qual é o segmento?
            </Label>
            <Input
              aria-describedby={errors.segmentDescription ? "segment-description-error" : undefined}
              aria-invalid={Boolean(errors.segmentDescription)}
              className={inputClassName}
              id="segment-description"
              placeholder="Ex.: Escola de idiomas"
              {...register("segmentDescription", {
                setValueAs: (value: string) => value.trim() || undefined,
              })}
            />
            {errors.segmentDescription ? (
              <p className="text-sm text-red-700" id="segment-description-error" role="alert">
                {errors.segmentDescription.message}
              </p>
            ) : null}
          </div>
        ) : null}
      </section>

      <section className="grid gap-5" aria-labelledby="branch-data-title">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Etapa 3</p>
          <h2 className="mt-2 text-lg font-semibold text-slate-950" id="branch-data-title">
            Primeira filial
          </h2>
        </div>

        <div className="grid gap-2">
          <Label className="text-slate-800" htmlFor="first-branch-name">
            Nome da unidade
          </Label>
          <Input
            aria-describedby={errors.branchName ? "first-branch-name-error" : undefined}
            aria-invalid={Boolean(errors.branchName)}
            className={inputClassName}
            id="first-branch-name"
            placeholder="Ex.: Matriz"
            {...register("branchName")}
          />
          {errors.branchName ? (
            <p className="text-sm text-red-700" id="first-branch-name-error" role="alert">
              {errors.branchName.message}
            </p>
          ) : null}
        </div>
      </section>

      {errors.root?.message ? (
        <div
          className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
          role="alert"
        >
          {errors.root.message}
        </div>
      ) : null}

      <div className="border-t pt-6">
        <Button
          className="h-11 w-full rounded-xl sm:w-auto sm:px-6"
          disabled={isSubmitting}
          type="submit"
        >
          {isSubmitting ? "Preparando sua empresa..." : "Criar empresa e continuar"}
        </Button>
        <p className="mt-3 text-xs leading-5 text-slate-500">
          Você será o proprietário da conta e terá acesso a todas as filiais.
        </p>
      </div>
    </form>
  );
}
