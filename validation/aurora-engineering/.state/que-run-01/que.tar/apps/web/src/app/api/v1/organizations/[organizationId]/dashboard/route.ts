import { dashboardQuerySchema, organizationParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = dashboardQuerySchema.parse(Object.fromEntries(new URL(request.url).searchParams));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const dashboard = await services.getDashboard.execute({ ...query, ...params }, actor);
    return Response.json({ data: dashboard });
  });
}
