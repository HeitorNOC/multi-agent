import { NATIONAL_NFSE_OPERATION_INDICATORS } from "@gestor/contracts";
import type { UseFormRegisterReturn } from "react-hook-form";

export function NfseOperationIndicatorSelect({
  registration,
}: {
  registration: UseFormRegisterReturn;
}) {
  return (
    <select
      className="h-10 min-w-0 rounded-xl border bg-white px-3 text-sm"
      id="service-ibs-cbs-operation"
      {...registration}
    >
      <option value="">Selecione conforme o serviço</option>
      {NATIONAL_NFSE_OPERATION_INDICATORS.map(({ code, label }) => (
        <option key={code} value={code}>
          {code} — {label}
        </option>
      ))}
    </select>
  );
}
