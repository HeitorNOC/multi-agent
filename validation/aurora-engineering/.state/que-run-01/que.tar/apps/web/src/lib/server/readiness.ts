import { checkAuthDatabaseConnection } from "@gestor/auth";
import { Prisma, prisma } from "@gestor/database";

export type ReadinessCheck = {
  durationMs: number;
  status: "ok" | "unavailable";
};

export type ReadinessResult = {
  checks: Readonly<Record<string, ReadinessCheck>>;
  status: "ok" | "unavailable";
};

export type ReadinessProbe = () => Promise<void>;

export async function checkReadiness(
  probes: Readonly<Record<string, ReadinessProbe>>,
  timeoutMs = 2_000,
): Promise<ReadinessResult> {
  const entries = await Promise.all(
    Object.entries(probes).map(async ([name, probe]) => {
      const startedAt = performance.now();
      let status: ReadinessCheck["status"] = "ok";

      try {
        await withTimeout(probe(), timeoutMs);
      } catch {
        status = "unavailable";
      }

      return [
        name,
        { durationMs: Math.max(0, Math.round(performance.now() - startedAt)), status },
      ] as const;
    }),
  );
  const checks = Object.fromEntries(entries);

  return {
    checks,
    status: entries.every(([, check]) => check.status === "ok") ? "ok" : "unavailable",
  };
}

export const applicationReadinessProbes: Readonly<Record<string, ReadinessProbe>> = {
  authDatabase: checkAuthDatabaseConnection,
  database: async () => {
    await prisma.$queryRaw(Prisma.sql`SELECT 1`);
  },
};

async function withTimeout<Result>(operation: Promise<Result>, timeoutMs: number): Promise<Result> {
  let timeout: ReturnType<typeof setTimeout> | undefined;

  try {
    return await Promise.race([
      operation,
      new Promise<never>((_resolve, reject) => {
        timeout = setTimeout(() => reject(new Error("Readiness probe timed out.")), timeoutMs);
      }),
    ]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
