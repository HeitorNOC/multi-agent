"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  createFinancialObligationBodySchema,
  financialAccountListSchema,
  financialCategoryListSchema,
  financialObligationPageSchema,
  paymentMethodConfigurationListSchema,
  type BranchView,
  type CreateFinancialObligationBody,
  type FinancialAccountView,
  type FinancialCategoryView,
  type FinancialObligationView,
  type PaymentMethodConfigurationView,
  type ProblemDetails,
} from "@gestor/contracts";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { FinancialObligationForm } from "./financial-obligation-form";
import {
  cancelFinancialObligation,
  createFinancialObligation,
  loadMoreFinancialObligations,
  reverseFinancialObligation,
} from "./financial-obligation-api";
import {
  FinancialObligationList,
  type CancellationDraft,
  type ReversalDraft,
} from "./financial-obligation-list";

type FinancialObligationConfigurationsProps = {
  organizationId: string;
};

export function FinancialObligationConfigurations({
  organizationId,
}: FinancialObligationConfigurationsProps) {
  const today = useMemo(() => new Date().toLocaleDateString("en-CA"), []);
  const [obligations, setObligations] = useState<readonly FinancialObligationView[] | null>(null);
  const [branches, setBranches] = useState<readonly BranchView[] | null>(null);
  const [categories, setCategories] = useState<readonly FinancialCategoryView[] | null>(null);
  const [financialAccounts, setFinancialAccounts] = useState<
    readonly FinancialAccountView[] | null
  >(null);
  const [paymentMethods, setPaymentMethods] = useState<
    readonly PaymentMethodConfigurationView[] | null
  >(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [cancellation, setCancellation] = useState<CancellationDraft | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const [settlementId, setSettlementId] = useState<string | null>(null);
  const [reversal, setReversal] = useState<ReversalDraft | null>(null);
  const [isReversing, setIsReversing] = useState(false);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateFinancialObligationBody>({
    defaultValues: {
      branchId: "",
      categoryId: "",
      competencyDate: today,
      counterpartyName: "",
      description: "",
      dueDate: today,
      installmentNumber: null,
      installmentTotal: null,
      kind: "RECEIVABLE",
      origin: "MANUAL",
      originalAmount: "",
    },
    resolver: zodResolver(createFinancialObligationBodySchema),
  });
  const kind = useWatch({ control, name: "kind" });
  const availableCategories = useMemo(
    () =>
      categories?.filter(
        (category) =>
          category.status === "ACTIVE" &&
          (kind === "RECEIVABLE" ? category.type === "REVENUE" : category.type !== "REVENUE"),
      ) ?? [],
    [categories, kind],
  );
  const activeBranches = useMemo(
    () => branches?.filter((branch) => branch.status === "ACTIVE") ?? [],
    [branches],
  );
  const branchNames = useMemo(
    () => new Map(branches?.map((branch) => [branch.id, branch.name]) ?? []),
    [branches],
  );
  const categoryNames = useMemo(
    () => new Map(categories?.map((category) => [category.id, category.name]) ?? []),
    [categories],
  );

  useEffect(() => {
    setValue("categoryId", "");
  }, [kind, setValue]);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const [
          obligationsResponse,
          branchesResponse,
          categoriesResponse,
          financialAccountsResponse,
          paymentMethodsResponse,
        ] = await Promise.all([
          fetch(
            `/api/v1/organizations/${organizationId}/financial-obligations?kind=${kind}&limit=100`,
            { signal: controller.signal },
          ),
          fetch(`/api/v1/organizations/${organizationId}/branches`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-categories`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/payment-methods`, {
            signal: controller.signal,
          }),
        ]);

        for (const response of [
          obligationsResponse,
          branchesResponse,
          categoriesResponse,
          financialAccountsResponse,
          paymentMethodsResponse,
        ]) {
          if (!response.ok) {
            const problem = (await response.json()) as ProblemDetails;
            throw new Error(problem.detail);
          }
        }

        const obligationsPayload = financialObligationPageSchema.parse(
          await obligationsResponse.json(),
        );
        const branchesPayload = (await branchesResponse.json()) as { data: unknown };
        const categoriesPayload = (await categoriesResponse.json()) as { data: unknown };
        const financialAccountsPayload = (await financialAccountsResponse.json()) as {
          data: unknown;
        };
        const paymentMethodsPayload = (await paymentMethodsResponse.json()) as { data: unknown };
        setObligations(obligationsPayload.data);
        setNextCursor(obligationsPayload.page.nextCursor);
        setBranches(branchListSchema.parse(branchesPayload.data));
        setCategories(financialCategoryListSchema.parse(categoriesPayload.data));
        setFinancialAccounts(financialAccountListSchema.parse(financialAccountsPayload.data));
        setPaymentMethods(paymentMethodConfigurationListSchema.parse(paymentMethodsPayload.data));
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error ? error.message : "Não foi possível carregar as contas.",
          );
        }
      }
    }

    void load();
    return () => controller.abort();
  }, [kind, organizationId, reloadVersion]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const result = await createFinancialObligation(organizationId, values, idempotencyKey);
      if (result.problem) {
        setError("root", { message: result.problem.detail, type: result.problem.code });
        return;
      }
      const created = result.data;
      setObligations((current) => (current ? [...current, created] : [created]));
      setFeedback(
        created.kind === "RECEIVABLE"
          ? "Conta a receber registrada. Nenhum valor entrou no caixa."
          : "Conta a pagar registrada. Nenhum pagamento saiu do caixa.",
      );
      setIdempotencyKey(crypto.randomUUID());
      reset({
        ...values,
        counterpartyName: "",
        description: "",
        installmentNumber: null,
        installmentTotal: null,
        originalAmount: "",
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function confirmCancellation(obligation: FinancialObligationView) {
    if (!cancellation || cancellation.id !== obligation.id) {
      return;
    }

    if (cancellation.reason.trim().length < 3) {
      setFeedback("Informe um motivo com pelo menos 3 caracteres.");
      return;
    }

    setIsCancelling(true);
    setFeedback(null);

    try {
      const updated = await cancelFinancialObligation(organizationId, obligation, cancellation);
      setObligations(
        (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [],
      );
      setCancellation(null);
      setFeedback("Conta cancelada sem criar movimentação de caixa.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível cancelar a conta.");
    } finally {
      setIsCancelling(false);
    }
  }

  async function confirmReversal(obligation: FinancialObligationView) {
    if (!reversal || reversal.id !== obligation.id) return;
    if (reversal.reason.trim().length < 3) {
      setFeedback("Informe um motivo com pelo menos 3 caracteres.");
      return;
    }
    setIsReversing(true);
    setFeedback(null);
    try {
      const updated = await reverseFinancialObligation(organizationId, obligation, reversal);
      setObligations(
        (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [],
      );
      setReversal(null);
      setFeedback("Conta estornada com movimentos compensatórios. A dívida não foi reaberta.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível estornar a conta.");
    } finally {
      setIsReversing(false);
    }
  }

  async function loadMore() {
    if (!nextCursor) {
      return;
    }

    setIsLoadingMore(true);
    setFeedback(null);

    try {
      const payload = await loadMoreFinancialObligations(organizationId, kind, nextCursor);
      setObligations((current) => [...(current ?? []), ...payload.data]);
      setNextCursor(payload.page.nextCursor);
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível carregar mais contas.",
      );
    } finally {
      setIsLoadingMore(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
      <FinancialObligationForm
        activeBranches={activeBranches}
        availableCategories={availableCategories}
        branchesLoaded={Boolean(branches)}
        categoriesLoaded={Boolean(categories)}
        errors={errors}
        isSubmitting={isSubmitting}
        kind={kind}
        register={register}
        submit={submit}
      />

      <FinancialObligationList
        branchNames={branchNames}
        cancellation={cancellation}
        categoryNames={categoryNames}
        feedback={feedback}
        financialAccounts={financialAccounts}
        isCancelling={isCancelling}
        isLoadingMore={isLoadingMore}
        isReversing={isReversing}
        kind={kind}
        loadError={loadError}
        nextCursor={nextCursor}
        obligations={obligations}
        onConfirmCancellation={confirmCancellation}
        onLoadMore={loadMore}
        onConfirmReversal={confirmReversal}
        onRetry={() => {
          setLoadError(null);
          setReloadVersion((version) => version + 1);
        }}
        onSettled={(updated) => {
          setObligations(
            (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [],
          );
          setSettlementId(null);
          setFeedback(
            updated.kind === "RECEIVABLE"
              ? "Recebimento confirmado e saldo financeiro atualizado."
              : "Pagamento confirmado e saldo financeiro atualizado.",
          );
        }}
        organizationId={organizationId}
        paymentMethods={paymentMethods}
        referencesLoaded={Boolean(branches && categories)}
        reversal={reversal}
        setCancellation={setCancellation}
        setSettlementId={setSettlementId}
        setReversal={setReversal}
        settlementId={settlementId}
        today={today}
      />
    </div>
  );
}
