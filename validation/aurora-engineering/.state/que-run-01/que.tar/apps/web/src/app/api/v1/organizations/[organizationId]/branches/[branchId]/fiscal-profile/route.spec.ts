import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, resolveTenantActor, upsertFiscalProfile } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  resolveTenantActor: vi.fn(),
  upsertFiscalProfile: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
    upsertFiscalProfile: { execute: upsertFiscalProfile },
  },
}));

import { PUT } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
const branchId = "10000000-0000-4000-8000-000000000002";
it("requires idempotency and forwards a validated fiscal profile", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  upsertFiscalProfile.mockResolvedValue({ id: "profile" });
  const body = {
    activate: false,
    credentialReference: null,
    enabledDocumentTypes: ["NFCE"],
    expectedUpdatedAt: null,
    issuerData: {
      city: "São Paulo",
      cityCode: "3550308",
      district: "Centro",
      legalName: "Empresa",
      municipalRegistration: null,
      number: "1",
      postalCode: "01001000",
      state: "SP",
      stateRegistration: "123",
      street: "Rua A",
      taxId: "12345678000190",
    },
    provider: "SANDBOX",
    taxRegime: "Simples",
  };
  const response = await PUT(
    new Request(
      `http://localhost/api/v1/organizations/${organizationId}/branches/${branchId}/fiscal-profile`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "fiscal-key-001" },
        method: "PUT",
      },
    ),
    { params: Promise.resolve({ branchId, organizationId }) },
  );
  expect(response.status).toBe(200);
  expect(upsertFiscalProfile).toHaveBeenCalledWith(
    { ...body, branchId, idempotencyKey: "fiscal-key-001", organizationId },
    { role: "OWNER" },
  );
});
