"use client";

import {
  paymentChargeListSchema,
  paymentChargeViewSchema,
  registerTerminalDeviceBodySchema,
  terminalDeviceListSchema,
  terminalDeviceViewSchema,
  type PaymentChargeView,
  type ProblemDetails,
  type SaleDetailView,
  type TerminalDeviceView,
  type TerminalProvider,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";

export function PosPaymentPanel({
  organizationId,
  sale,
  setFeedback,
}: {
  organizationId: string;
  sale: Pick<SaleDetailView, "branchId" | "id" | "receivables" | "status">;
  setFeedback: (message: string) => void;
}) {
  const [terminals, setTerminals] = useState<readonly TerminalDeviceView[]>([]);
  const [charges, setCharges] = useState<readonly PaymentChargeView[]>([]);
  const [terminalName, setTerminalName] = useState("Terminal balcão");
  const [provider, setProvider] = useState<TerminalProvider>("SANDBOX");
  const [externalTerminalId, setExternalTerminalId] = useState("");
  const [terminalId, setTerminalId] = useState("");
  const [method, setMethod] = useState<"CARD" | "PAYMENT_LINK" | "PIX">("CARD");
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);
  const receivable = sale.receivables.find(
    ({ openAmount, status }) => ["PARTIAL", "PENDING"].includes(status) && openAmount !== "0.0000",
  );

  useEffect(() => {
    const controller = new AbortController();
    void Promise.all([
      fetch(`/api/v1/organizations/${organizationId}/branches/${sale.branchId}/terminals`, {
        signal: controller.signal,
      }).then(readData),
      fetch(`/api/v1/organizations/${organizationId}/sales/${sale.id}/payment-charges`, {
        signal: controller.signal,
      }).then(readData),
    ])
      .then(([terminalData, chargeData]) => {
        const loadedTerminals = terminalDeviceListSchema.parse(terminalData);
        setTerminals(loadedTerminals);
        setTerminalId(loadedTerminals.find(({ status }) => status === "AVAILABLE")?.id ?? "");
        setCharges(paymentChargeListSchema.parse(chargeData));
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Não foi possível carregar o PDV.");
      });
    return () => controller.abort();
  }, [organizationId, sale.branchId, sale.id, setFeedback]);

  async function registerTerminal() {
    const providerTerminalId =
      provider === "SANDBOX"
        ? `sandbox-${crypto.randomUUID()}`
        : provider === "STRIPE"
          ? `stripe-checkout-${sale.branchId}`
          : externalTerminalId.trim();
    const body = registerTerminalDeviceBodySchema.safeParse({
      cashRegisterId: null,
      externalTerminalId: providerTerminalId,
      name: terminalName,
      provider,
    });
    if (!body.success) return setFeedback(body.error.issues[0]?.message ?? "Terminal inválido.");
    setBusy(true);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/branches/${sale.branchId}/terminals`,
        {
          body: JSON.stringify(body.data),
          headers: {
            "content-type": "application/json",
            "idempotency-key": crypto.randomUUID(),
          },
          method: "POST",
        },
      );
      const created = terminalDeviceViewSchema.parse(await responseData(response));
      setTerminals((current) => [...current, created]);
      setTerminalId(created.id);
      setFeedback(`${providerLabel(provider)} cadastrado para cobrança.`);
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível cadastrar o terminal.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function startPayment() {
    if (!receivable || !terminalId) return;
    setBusy(true);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/payment-charges`,
        {
          body: JSON.stringify({
            amount: amount || receivable.openAmount,
            method,
            receivableId: receivable.id,
            terminalDeviceId: terminalId,
          }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const charge = paymentChargeViewSchema.parse(await responseData(response));
      setCharges((current) => [charge, ...current.filter(({ id }) => id !== charge.id)]);
      setTerminals((current) =>
        current.map((terminal) =>
          terminal.id === terminalId ? { ...terminal, status: "PROCESSING" } : terminal,
        ),
      );
      setFeedback("Cobrança enviada. A confirmação definitiva virá pelo provedor.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível iniciar a cobrança.");
    } finally {
      setBusy(false);
    }
  }

  async function refundPayment(charge: PaymentChargeView) {
    setBusy(true);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/sales/${sale.id}/payment-charges/${charge.id}/refund`,
        {
          body: JSON.stringify({ reason: "Estorno solicitado no detalhe da venda" }),
          headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
          method: "POST",
        },
      );
      const refunded = paymentChargeViewSchema.parse(await responseData(response));
      setCharges((current) =>
        current.map((currentCharge) =>
          currentCharge.id === refunded.id ? refunded : currentCharge,
        ),
      );
      setFeedback("Pagamento estornado e saldo financeiro reaberto.");
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível estornar a cobrança.");
    } finally {
      setBusy(false);
    }
  }

  if (sale.status !== "COMPLETED") return null;
  return (
    <div className="grid gap-3 border-t pt-5">
      <div>
        <h4 className="font-semibold">PDV e terminal</h4>
        <p className="text-sm text-slate-600">
          O retorno visual inicia a cobrança; somente a confirmação do provedor liquida a venda.
        </p>
      </div>
      <div className="flex flex-wrap items-end gap-2">
        <label className="grid min-w-56 flex-1 gap-1 text-sm font-medium">
          Nome do meio de cobrança
          <Input onChange={(event) => setTerminalName(event.target.value)} value={terminalName} />
        </label>
        <label className="grid gap-1 text-sm font-medium">
          Provedor
          <select
            className="h-10 rounded-md border border-slate-300 bg-white px-3 text-sm"
            onChange={(event) => setProvider(event.target.value as TerminalProvider)}
            value={provider}
          >
            <option value="SANDBOX">Ambiente de testes</option>
            <option value="MERCADO_PAGO">Mercado Pago Point</option>
            <option value="STRIPE">Stripe Checkout online</option>
          </select>
        </label>
        {provider === "MERCADO_PAGO" ? (
          <label className="grid min-w-48 gap-1 text-sm font-medium">
            Identificador do terminal Point
            <Input
              onChange={(event) => setExternalTerminalId(event.target.value)}
              value={externalTerminalId}
            />
          </label>
        ) : null}
        <Button
          disabled={busy}
          onClick={() => void registerTerminal()}
          type="button"
          variant="outline"
        >
          Cadastrar terminal
        </Button>
      </div>
      {provider === "STRIPE" ? (
        <p className="text-sm text-slate-600">
          Stripe aceita cobrança online. Pix está disponível somente para contas habilitadas por
          convite; o terminal físico Stripe não está disponível no Brasil.
        </p>
      ) : null}
      {receivable && terminals.length > 0 ? (
        <div className="flex flex-wrap items-end gap-2">
          <label className="grid gap-1 text-sm font-medium">
            Terminal
            <select
              className="h-10 rounded-md border border-slate-300 bg-white px-3 text-sm"
              onChange={(event) => setTerminalId(event.target.value)}
              value={terminalId}
            >
              <option value="">Selecione</option>
              {terminals.map((terminal) => (
                <option
                  disabled={terminal.status !== "AVAILABLE"}
                  key={terminal.id}
                  value={terminal.id}
                >
                  {terminal.name} · {terminal.status}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-1 text-sm font-medium">
            Forma de pagamento
            <select
              className="h-10 rounded-md border border-slate-300 bg-white px-3 text-sm"
              onChange={(event) => setMethod(event.target.value as typeof method)}
              value={method}
            >
              <option value="CARD">Cartão</option>
              <option value="PIX">Pix</option>
              {terminals.find(({ id }) => id === terminalId)?.provider === "STRIPE" ? (
                <option value="PAYMENT_LINK">Link de pagamento</option>
              ) : null}
            </select>
          </label>
          <label className="grid gap-1 text-sm font-medium">
            Valor
            <Input
              inputMode="decimal"
              onChange={(event) => setAmount(event.target.value)}
              placeholder={receivable.openAmount}
              value={amount}
            />
          </label>
          <Button disabled={busy || !terminalId} onClick={() => void startPayment()} type="button">
            Enviar cobrança
          </Button>
        </div>
      ) : null}
      {charges.map((charge) => (
        <div
          className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm ${["DISPUTED", "CHARGEBACK"].includes(charge.status) ? "border border-red-200 bg-red-50 text-red-900" : ""}`}
          key={charge.id}
        >
          <span>
            {providerLabel(charge.provider)} · {charge.method} · R$ {charge.amount} ·{" "}
            <strong>{charge.status}</strong>
          </span>
          {charge.checkoutUrl && charge.status === "PENDING" ? (
            <a
              className="underline"
              href={charge.checkoutUrl}
              rel="noopener noreferrer"
              target="_blank"
            >
              Abrir pagamento
            </a>
          ) : null}
          {charge.status === "CONFIRMED" ? (
            <Button
              disabled={busy}
              onClick={() => void refundPayment(charge)}
              size="sm"
              type="button"
              variant="outline"
            >
              Estornar
            </Button>
          ) : null}
          {["DISPUTED", "CHARGEBACK"].includes(charge.status) ? (
            <strong className="ml-auto">Ação financeira necessária</strong>
          ) : null}
        </div>
      ))}
    </div>
  );
}

function providerLabel(provider: TerminalProvider) {
  if (provider === "MERCADO_PAGO") return "Mercado Pago";
  if (provider === "STRIPE") return "Stripe";
  return "Ambiente de testes";
}

async function readData(response: Response) {
  return responseData(response);
}

async function responseData(response: Response) {
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "A operação de PDV falhou.");
  return payload.data;
}
