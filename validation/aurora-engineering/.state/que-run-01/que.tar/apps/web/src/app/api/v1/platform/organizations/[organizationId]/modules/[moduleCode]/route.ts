import {
  changeOrganizationModuleBodySchema,
  organizationModuleParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForPlatformRole } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{
    moduleCode: string;
    organizationId: string;
  }>;
};

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationModuleParamsSchema.parse(await route.params);
    const body = changeOrganizationModuleBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolvePlatformActor.execute({
      correlationId: api.correlationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForPlatformRole(identity, actor.role);
    const organizationModule = await services.changeOrganizationModule.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        moduleCode: params.moduleCode,
        organizationId: params.organizationId,
      },
      actor,
    );

    return Response.json({ data: organizationModule });
  });
}
