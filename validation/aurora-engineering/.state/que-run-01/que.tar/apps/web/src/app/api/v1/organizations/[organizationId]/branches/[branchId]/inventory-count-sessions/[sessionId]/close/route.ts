import { inventoryBranchParamsSchema } from "@gestor/contracts";
import { z } from "zod";
import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type P={params:Promise<{branchId:string;organizationId:string;sessionId:string}>};
export async function POST(request:Request, route:P){return handleApiRequest(request,async api=>{const params=inventoryBranchParamsSchema.extend({sessionId:z.uuid()}).parse(await route.params);const identity=await authenticateApiRequest(request);const actor=await services.resolveTenantActor.execute({correlationId:api.correlationId,organizationId:params.organizationId,requestId:api.requestId,userId:identity.userId});return Response.json({data:await services.closeInventoryCountSession.execute(params,actor)});});}
