import type { BankAccountView, BankTransactionView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

import { formatBrl, formatDate } from "./bank-statement-format";

type BankStatementListProps = {
  accountNames: ReadonlyMap<string, string>;
  bankAccountId: string;
  bankAccounts: readonly BankAccountView[] | null;
  feedback: string | null;
  hasMore: boolean;
  loadError: string | null;
  loadingMore: boolean;
  onLoadMore: () => void;
  onRetry: () => void;
  transactions: readonly BankTransactionView[] | null;
};

export function BankStatementList({
  accountNames,
  bankAccountId,
  bankAccounts,
  feedback,
  hasMore,
  loadError,
  loadingMore,
  onLoadMore,
  onRetry,
  transactions,
}: BankStatementListProps) {
  return (
    <section className="grid content-start gap-4">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Lançamentos</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Transações importadas</h2>
        {bankAccountId ? (
          <p className="mt-1 text-sm text-slate-500">
            {accountNames.get(bankAccountId) ?? "Conta selecionada"}
          </p>
        ) : null}
      </div>

      {feedback ? (
        <div className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700" role="status">
          {feedback}
        </div>
      ) : null}

      {!bankAccounts || transactions === null ? (
        <div className="grid gap-3 rounded-2xl border bg-white p-5">
          <p className="text-sm text-slate-600">
            {loadError ?? "Carregando transações bancárias..."}
          </p>
          {loadError ? (
            <div>
              <Button onClick={onRetry} size="sm" variant="outline">
                Tentar novamente
              </Button>
            </div>
          ) : null}
        </div>
      ) : transactions.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
          Nenhuma transação importada para esta conta.
        </div>
      ) : (
        <>
          <ul className="grid gap-3">
            {transactions.map((transaction) => (
              <li className="rounded-2xl border bg-white p-5" key={transaction.id}>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-950">
                      {transaction.descriptionRaw}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      {formatDate(transaction.occurredAt)} ·{" "}
                      {transaction.sourceFormat ?? "Integração"}
                    </p>
                  </div>
                  <p
                    className={`text-sm font-semibold ${
                      transaction.amount.startsWith("-") ? "text-red-700" : "text-emerald-700"
                    }`}
                  >
                    {formatBrl(transaction.amount)}
                  </p>
                </div>
                <p className="mt-4 text-xs font-medium text-slate-500">Aguardando conciliação</p>
              </li>
            ))}
          </ul>
          {hasMore ? (
            <div>
              <Button disabled={loadingMore} onClick={onLoadMore} size="sm" variant="outline">
                {loadingMore ? "Carregando..." : "Carregar mais"}
              </Button>
            </div>
          ) : null}
        </>
      )}
    </section>
  );
}
