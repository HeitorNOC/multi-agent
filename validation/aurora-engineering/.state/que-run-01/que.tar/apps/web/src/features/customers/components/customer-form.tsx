"use client";

import type { CreateCustomerBody, CustomerView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import type { FormEventHandler } from "react";
import type { FieldErrors, UseFormRegister } from "react-hook-form";

import { CustomerField } from "./customer-field";

type CustomerFormProps = {
  editingCustomer: CustomerView | null;
  errors: FieldErrors<CreateCustomerBody>;
  isSubmitting: boolean;
  onCancel: () => void;
  register: UseFormRegister<CreateCustomerBody>;
  submit: FormEventHandler<HTMLFormElement>;
};

export function CustomerForm({
  editingCustomer,
  errors,
  isSubmitting,
  onCancel,
  register,
  submit,
}: CustomerFormProps) {
  return (
    <section className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7">
      <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
        {editingCustomer ? "Editar cliente" : "Novo cliente"}
      </p>
      <h2 className="mt-2 text-xl font-semibold text-slate-950">Dados essenciais</h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">
        Informe telefone ou e-mail. Documento, nascimento e observações são opcionais.
      </p>
      <form className="mt-6 grid gap-4" noValidate onSubmit={submit}>
        <CustomerField error={errors.name?.message} id="customer-name" label="Nome">
          <Input id="customer-name" className="h-11 rounded-xl px-3" {...register("name")} />
        </CustomerField>
        <div className="grid gap-4 sm:grid-cols-2">
          <CustomerField error={errors.phone?.message} id="customer-phone" label="Telefone">
            <Input
              id="customer-phone"
              className="h-11 rounded-xl px-3"
              inputMode="tel"
              {...register("phone")}
            />
          </CustomerField>
          <CustomerField error={errors.email?.message} id="customer-email" label="E-mail">
            <Input
              id="customer-email"
              className="h-11 rounded-xl px-3"
              type="email"
              {...register("email")}
            />
          </CustomerField>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <CustomerField
            error={errors.document?.message}
            id="customer-document"
            label="CPF ou CNPJ"
          >
            <Input
              id="customer-document"
              className="h-11 rounded-xl px-3"
              {...register("document")}
            />
          </CustomerField>
          <CustomerField
            error={errors.birthDate?.message}
            id="customer-birth-date"
            label="Nascimento"
          >
            <Input
              id="customer-birth-date"
              className="h-11 rounded-xl px-3"
              type="date"
              {...register("birthDate")}
            />
          </CustomerField>
        </div>
        <CustomerField error={errors.notes?.message} id="customer-notes" label="Observações">
          <textarea
            className="focus-visible:border-ring focus-visible:ring-ring/50 min-h-24 rounded-xl border bg-white px-3 py-2 text-sm outline-none focus-visible:ring-3"
            id="customer-notes"
            {...register("notes")}
          />
        </CustomerField>
        {errors.root?.message ? (
          <div
            className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
            role="alert"
          >
            {errors.root.message}
          </div>
        ) : null}
        <div className="flex gap-2">
          <Button disabled={isSubmitting} type="submit">
            {isSubmitting
              ? "Salvando..."
              : editingCustomer
                ? "Salvar alterações"
                : "Cadastrar cliente"}
          </Button>
          {editingCustomer ? (
            <Button onClick={onCancel} type="button" variant="outline">
              Cancelar
            </Button>
          ) : null}
        </div>
      </form>
    </section>
  );
}
