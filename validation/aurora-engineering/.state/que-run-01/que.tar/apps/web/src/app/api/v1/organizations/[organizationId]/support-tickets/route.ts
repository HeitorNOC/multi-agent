import { createSupportTicketBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ organizationId: string }> };
export async function GET(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await tenantActor(api, params.organizationId, identity.userId);
    return Response.json(await services.customerCare.listTickets(params, actor));
  });
}
export async function POST(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createSupportTicketBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await tenantActor(api, params.organizationId, identity.userId);
    return Response.json(
      {
        data: await services.customerCare.createTicket(
          { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
          actor,
        ),
      },
      { status: 201 },
    );
  });
}
function tenantActor(
  api: { correlationId: string; requestId: string },
  organizationId: string,
  userId: string,
) {
  return services.resolveTenantActor.execute({
    correlationId: api.correlationId,
    organizationId,
    requestId: api.requestId,
    userId,
  });
}
