import { beforeEach, describe, expect, it, vi } from "vitest";

const { checkReadiness } = vi.hoisted(() => ({ checkReadiness: vi.fn() }));

vi.mock("@/lib/server/readiness", () => ({
  applicationReadinessProbes: { database: vi.fn() },
  checkReadiness,
}));

import { GET } from "./route";

describe("GET /api/v1/health/ready", () => {
  beforeEach(() => checkReadiness.mockReset());

  it.each([
    ["ok", 200],
    ["unavailable", 503],
  ] as const)("maps readiness status %s to HTTP %s", async (status, expectedStatus) => {
    checkReadiness.mockResolvedValue({ checks: {}, status });

    const response = await GET();

    expect(response.status).toBe(expectedStatus);
    expect(response.headers.get("cache-control")).toBe("no-store");
    await expect(response.json()).resolves.toEqual({ checks: {}, status });
  });
});
