"use client";

import {
  branchListSchema,
  organizationAccessConfigurationSchema,
  organizationInvitationListSchema,
  organizationMemberListSchema,
  type BranchView,
  type OrganizationMemberView,
  type OrganizationInvitationView,
  type OrganizationRoleView,
  type PermissionView,
} from "@gestor/contracts";
import { useCallback, useEffect, useState } from "react";

import { fetchData } from "../../sales/components/direct-sale-data";
import { MemberForm } from "./member-form";
import { InvitationList } from "./invitation-list";
import { MemberList } from "./member-list";
import { RoleForm } from "./role-form";

export function OrganizationUserManagement({ organizationId }: { organizationId: string }) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [members, setMembers] = useState<readonly OrganizationMemberView[]>([]);
  const [invitations, setInvitations] = useState<readonly OrganizationInvitationView[]>([]);
  const [permissions, setPermissions] = useState<readonly PermissionView[]>([]);
  const [roles, setRoles] = useState<readonly OrganizationRoleView[]>([]);
  const [revision, setRevision] = useState(0);
  const [feedback, setFeedback] = useState("Carregando acessos...");
  const refresh = useCallback(() => setRevision((value) => value + 1), []);

  useEffect(() => {
    const controller = new AbortController();
    const base = `/api/v1/organizations/${organizationId}`;
    void Promise.all([
      fetchData(`${base}/branches`, branchListSchema, controller.signal),
      fetchData(`${base}/users`, organizationMemberListSchema, controller.signal),
      fetchData(`${base}/invitations`, organizationInvitationListSchema, controller.signal),
      fetchData(`${base}/roles`, organizationAccessConfigurationSchema, controller.signal),
    ])
      .then(([branchData, memberData, invitationData, access]) => {
        setBranches(branchData.filter(({ status }) => status === "ACTIVE"));
        setMembers(memberData);
        setInvitations(invitationData);
        setPermissions(access.permissions);
        setRoles(access.roles);
        setFeedback("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar acessos.",
          );
      });
    return () => controller.abort();
  }, [organizationId, revision]);

  return (
    <section className="grid gap-8">
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <div className="grid gap-6 lg:grid-cols-2">
        <MemberForm
          branches={branches}
          onCompleted={refresh}
          organizationId={organizationId}
          roles={roles}
        />
        <RoleForm onCompleted={refresh} organizationId={organizationId} permissions={permissions} />
      </div>
      <InvitationList
        invitations={invitations}
        onCompleted={refresh}
        organizationId={organizationId}
      />
      <MemberList
        branches={branches}
        members={members}
        onCompleted={refresh}
        organizationId={organizationId}
        roles={roles}
      />
    </section>
  );
}
