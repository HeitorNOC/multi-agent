import {
  createFinancialTransferBodySchema,
  financialTransferListQuerySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForFinancialMutation } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
  }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = financialTransferListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const result = await services.listFinancialTransfers.execute(
      { ...query, organizationId: params.organizationId },
      actor,
    );

    return Response.json(result);
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createFinancialTransferBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForFinancialMutation(identity, actor, "financial_transfer.manage");
    const transfer = await services.createFinancialTransfer.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );

    return Response.json(
      { data: transfer },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/financial-transfers/${transfer.id}`,
        },
        status: 201,
      },
    );
  });
}
