import { adjustStockBodySchema, inventoryBranchParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ branchId: string; organizationId: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = inventoryBranchParamsSchema.parse(await route.params);
    const body = adjustStockBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.adjustStock.execute(
        { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}
