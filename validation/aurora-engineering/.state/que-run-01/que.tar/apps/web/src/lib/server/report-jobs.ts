import { randomUUID } from "node:crypto";

import { getReportStorageEnv, getSupabaseJobsEnv } from "@gestor/config";
import { createPrismaClient } from "@gestor/database";
import { ExpireReports, NotifyGeneratedReport, PublishReportOutbox } from "@gestor/reporting";
import { ResendGeneratedReportEmailSender } from "@gestor/reporting/email";
import { ReportGeneratedMessageHandler } from "@gestor/reporting/messaging";
import {
  PrismaGeneratedReportNotificationRepository,
  PrismaReportExpirationRepository,
  PrismaReportOutboxRepository,
} from "@gestor/reporting/prisma";
import {
  createReportRequestedMessageHandler,
  InProcessReportEventPublisher,
} from "@gestor/reporting/runtime";
import { SupabaseReportArtifactStorage } from "@gestor/reporting/storage";

export type ReportJobsResult = {
  expiration: { expired: number; failed: number };
  outbox: { failed: number; published: number; rounds: number };
};

type ReportJobsRuntime = {
  expiration: Pick<ExpireReports, "execute">;
  maxRounds: number;
  outbox: Pick<PublishReportOutbox, "execute">;
};

let runtime: ReportJobsRuntime | undefined;

export async function runReportJobs(): Promise<ReportJobsResult> {
  const jobs = runtime ?? (runtime = createRuntime());
  const outbox = { failed: 0, published: 0, rounds: 0 };

  for (let round = 0; round < jobs.maxRounds; round += 1) {
    const result = await jobs.outbox.execute();
    outbox.rounds += 1;
    outbox.failed += result.failed;
    outbox.published += result.published;
    if (result.failed === 0 && result.published === 0) break;
  }

  return { expiration: await jobs.expiration.execute(), outbox };
}

function createRuntime(): ReportJobsRuntime {
  const environment = getSupabaseJobsEnv();
  const prisma = createPrismaClient(environment.WORKER_DATABASE_URL);
  const storageConfiguration = () => {
    const storage = getReportStorageEnv();
    return {
      bucket: storage.SUPABASE_STORAGE_BUCKET,
      secretKey: storage.SUPABASE_STORAGE_SECRET_KEY,
      url: storage.SUPABASE_STORAGE_URL,
    };
  };
  const requested = createReportRequestedMessageHandler({
    generatorVersion: "reporting@0.1.0-supabase-cron",
    prisma,
    storage: storageConfiguration,
  });
  const generated = new ReportGeneratedMessageHandler(
    new NotifyGeneratedReport(
      new PrismaGeneratedReportNotificationRepository(prisma),
      new ResendGeneratedReportEmailSender(),
      environment.REPORTS_APP_URL,
    ),
  );
  const publisher = new InProcessReportEventPublisher(requested, generated);

  return {
    expiration: new ExpireReports(
      new PrismaReportExpirationRepository(prisma),
      new SupabaseReportArtifactStorage(storageConfiguration),
      { now: () => new Date() },
      { create: randomUUID },
      environment.REPORT_EXPIRATION_BATCH_SIZE,
    ),
    maxRounds: environment.SUPABASE_JOBS_MAX_ROUNDS,
    outbox: new PublishReportOutbox(
      new PrismaReportOutboxRepository(prisma),
      publisher,
      { now: () => new Date() },
      { create: randomUUID },
      {
        batchSize: environment.SUPABASE_JOBS_BATCH_SIZE,
        maxAttempts: environment.SUPABASE_JOBS_MAX_ATTEMPTS,
      },
    ),
  };
}
