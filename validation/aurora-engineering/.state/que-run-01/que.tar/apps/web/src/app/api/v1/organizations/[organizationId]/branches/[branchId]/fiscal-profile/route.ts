import { fiscalProfileParamsSchema, upsertFiscalProfileBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ branchId: string; organizationId: string }> };

export async function PUT(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = fiscalProfileParamsSchema.parse(await route.params);
    const body = upsertFiscalProfileBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.upsertFiscalProfile.execute(
        { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}
