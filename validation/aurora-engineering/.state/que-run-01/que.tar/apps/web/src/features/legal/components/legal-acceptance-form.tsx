"use client";

import { Button } from "@gestor/ui/components/button";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

import { safeReturnTo } from "@/features/auth/return-to";

type AcceptanceStatus = {
  accepted: boolean;
  documents: { termsOfUse: { version: string }; privacyPolicy: { version: string } };
};

export function LegalAcceptanceForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnTo = safeReturnTo(searchParams.get("returnTo") ?? undefined);
  const [status, setStatus] = useState<AcceptanceStatus>();
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const continueAfterAcceptance = useCallback(async (): Promise<void> => {
    if (returnTo) {
      router.replace(returnTo);
      return;
    }

    try {
      const response = await fetch("/api/v1/auth/post-login-destination");
      if (!response.ok) throw new Error();
      const payload = (await response.json()) as { data?: { destination?: unknown } };
      const destination = payload.data?.destination;
      router.replace(typeof destination === "string" ? destination : "/onboarding");
    } catch {
      router.replace("/onboarding");
    }
  }, [returnTo, router]);

  useEffect(() => {
    void fetch("/api/v1/legal/acceptance")
      .then(async (response) => {
        const payload = (await response.json().catch(() => null)) as
          | { data?: AcceptanceStatus; detail?: string }
          | null;
        if (!response.ok) {
          if (response.status === 401) throw new Error("Sua sessão expirou. Entre novamente para continuar.");
          throw new Error(payload?.detail ?? "Não foi possível carregar os documentos. Atualize a página e tente novamente.");
        }
        if (!payload?.data) throw new Error("Não foi possível carregar os documentos. Atualize a página e tente novamente.");
        return { data: payload.data };
      })
      .then(({ data }) => {
        if (data.accepted) {
          void continueAfterAcceptance();
          return;
        }
        setStatus(data);
      })
      .catch((cause: unknown) =>
        setError(cause instanceof Error ? cause.message : "Não foi possível carregar os documentos. Atualize a página e tente novamente."),
      );
  }, [continueAfterAcceptance]);

  async function submit(): Promise<void> {
    if (!agreed) return;
    setError("");
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/v1/legal/acceptance", { method: "POST" });
      if (!response.ok) throw new Error();
      await continueAfterAcceptance();
      router.refresh();
    } catch {
      setError("Não foi possível registrar seu aceite. Tente novamente.");
      setIsSubmitting(false);
    }
  }

  if (!status && !error) return <p className="text-sm text-slate-600">Carregando documentos…</p>;

  return (
    <div className="grid gap-5">
      <p className="text-sm leading-6 text-slate-600">
        Para usar o Gestor, confirme que leu e aceita os documentos abaixo. Guardamos a data e a
        versão aceita para fins de registro.
      </p>
      <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-4 text-sm text-slate-700">
        <input
          checked={agreed}
          className="mt-0.5 size-4"
          onChange={(event) => setAgreed(event.target.checked)}
          type="checkbox"
        />
        <span>
          Li e aceito os{" "}
          <Link className="text-brand-600 font-semibold" href="/termos-de-uso" target="_blank">
            Termos de Uso
          </Link>{" "}
          (versão {status?.documents.termsOfUse.version}) e a{" "}
          <Link
            className="text-brand-600 font-semibold"
            href="/politica-de-privacidade"
            target="_blank"
          >
            Política de Privacidade
          </Link>{" "}
          (versão {status?.documents.privacyPolicy.version}).
        </span>
      </label>
      {error ? (
        <p className="text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
      <Button
        className="h-11 rounded-xl"
        disabled={!agreed || isSubmitting}
        onClick={() => void submit()}
        type="button"
      >
        {isSubmitting ? "Registrando aceite..." : "Aceitar e continuar"}
      </Button>
    </div>
  );
}
