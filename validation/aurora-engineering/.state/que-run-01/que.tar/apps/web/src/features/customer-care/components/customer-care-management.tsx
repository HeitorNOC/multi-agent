"use client";

import { HelpCenter } from "./help-center";
import { PrivacyRequests } from "./privacy-requests";
import { SupportTickets } from "./support-tickets";

export function CustomerCareManagement({ organizationId }: { organizationId: string }) {
  return (
    <div className="grid gap-12">
      <HelpCenter organizationId={organizationId} />
      <SupportTickets organizationId={organizationId} />
      <PrivacyRequests organizationId={organizationId} />
    </div>
  );
}
