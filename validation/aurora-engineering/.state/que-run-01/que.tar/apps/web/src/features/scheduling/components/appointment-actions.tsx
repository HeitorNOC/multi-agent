"use client";

import {
  appointmentViewSchema,
  type AppointmentStatus,
  type AppointmentView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useState } from "react";

type AppointmentActionsProps = {
  appointment: AppointmentView;
  onUpdated: (appointment: AppointmentView) => void;
  organizationId: string;
};

const actions: Readonly<
  Record<AppointmentStatus, readonly { label: string; status: AppointmentStatus }[]>
> = {
  SCHEDULED: [
    { label: "Confirmar", status: "CONFIRMED" },
    { label: "Iniciar atendimento", status: "IN_SERVICE" },
    { label: "Registrar falta", status: "NO_SHOW" },
    { label: "Cancelar", status: "CANCELLED" },
  ],
  CONFIRMED: [
    { label: "Iniciar atendimento", status: "IN_SERVICE" },
    { label: "Registrar falta", status: "NO_SHOW" },
    { label: "Cancelar", status: "CANCELLED" },
  ],
  IN_SERVICE: [
    { label: "Concluir", status: "COMPLETED" },
    { label: "Cancelar", status: "CANCELLED" },
  ],
  COMPLETED: [],
  CANCELLED: [],
  NO_SHOW: [],
};

export function AppointmentActions({
  appointment,
  onUpdated,
  organizationId,
}: AppointmentActionsProps) {
  const [cancelling, setCancelling] = useState(false);
  const [cancellationReason, setCancellationReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pendingStatus, setPendingStatus] = useState<AppointmentStatus | null>(null);

  async function changeStatus(status: AppointmentStatus) {
    if (status === "CANCELLED" && cancellationReason.trim().length < 2) {
      setError("Informe o motivo do cancelamento.");
      return;
    }
    setError(null);
    setPendingStatus(status);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/appointments/${appointment.id}/status`,
        {
          body: JSON.stringify({
            cancellationReason: status === "CANCELLED" ? cancellationReason.trim() : undefined,
            expectedUpdatedAt: appointment.updatedAt,
            status,
          }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError(problem.detail);
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      onUpdated(appointmentViewSchema.parse(payload.data));
      setCancelling(false);
      setCancellationReason("");
    } catch {
      setError("Não foi possível conectar ao servidor. Tente novamente.");
    } finally {
      setPendingStatus(null);
    }
  }

  const availableActions = actions[appointment.status];
  if (availableActions.length === 0) return null;

  return (
    <div className="mt-4 border-t pt-4">
      <p className="text-xs font-semibold tracking-[0.12em] text-slate-500 uppercase">
        Atualizar atendimento
      </p>
      {error ? (
        <p
          className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
          role="alert"
        >
          {error}
        </p>
      ) : null}
      {cancelling ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_auto_auto] sm:items-end">
          <label
            className="grid gap-1.5 text-sm font-medium text-slate-700"
            htmlFor={`cancellation-reason-${appointment.id}`}
          >
            Motivo do cancelamento
            <Input
              id={`cancellation-reason-${appointment.id}`}
              minLength={2}
              onChange={(event) => setCancellationReason(event.target.value)}
              value={cancellationReason}
            />
          </label>
          <Button
            disabled={pendingStatus !== null}
            onClick={() => void changeStatus("CANCELLED")}
            type="button"
          >
            {pendingStatus === "CANCELLED" ? "Cancelando..." : "Confirmar cancelamento"}
          </Button>
          <Button
            disabled={pendingStatus !== null}
            onClick={() => {
              setCancelling(false);
              setError(null);
            }}
            type="button"
            variant="outline"
          >
            Voltar
          </Button>
        </div>
      ) : (
        <div className="mt-3 flex flex-wrap gap-2">
          {availableActions.map((action) =>
            action.status === "CANCELLED" ? (
              <Button
                disabled={pendingStatus !== null}
                key={action.status}
                onClick={() => setCancelling(true)}
                type="button"
                variant="outline"
              >
                Cancelar
              </Button>
            ) : (
              <Button
                disabled={pendingStatus !== null}
                key={action.status}
                onClick={() => void changeStatus(action.status)}
                type="button"
                variant={action.status === "NO_SHOW" ? "outline" : "default"}
              >
                {pendingStatus === action.status ? "Atualizando..." : action.label}
              </Button>
            ),
          )}
        </div>
      )}
    </div>
  );
}
