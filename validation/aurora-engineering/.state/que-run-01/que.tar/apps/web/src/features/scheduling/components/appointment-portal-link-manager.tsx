"use client";

import {
  appointmentPortalLinkListSchema,
  type AppointmentPortalLinkView,
  type BranchView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

type AppointmentPortalLinkManagerProps = {
  branches: readonly BranchView[];
  organizationId: string;
};

type CreatedLink = { link: AppointmentPortalLinkView; token: string };

export function AppointmentPortalLinkManager({
  branches,
  organizationId,
}: AppointmentPortalLinkManagerProps) {
  const [links, setLinks] = useState<readonly AppointmentPortalLinkView[] | null>(null);
  const [title, setTitle] = useState("");
  const [branchId, setBranchId] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [createdUrl, setCreatedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const activeBranches = useMemo(
    () => branches.filter((branch) => branch.status === "ACTIVE"),
    [branches],
  );

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const response = await fetch(
          `/api/v1/organizations/${organizationId}/appointment-portal-links`,
          { signal: controller.signal },
        );
        if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
        const payload = (await response.json()) as { data: unknown };
        setLinks(appointmentPortalLinkListSchema.parse(payload.data));
      } catch (cause) {
        if (!controller.signal.aborted)
          setError(cause instanceof Error ? cause.message : "Não foi possível carregar os links.");
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId]);

  async function createLink(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError(null);
    setNotice(null);
    setCreatedUrl(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/appointment-portal-links`,
        {
          body: JSON.stringify({
            ...(branchId ? { branchId } : {}),
            ...(expiresAt ? { expiresAt: new Date(expiresAt).toISOString() } : {}),
            ...(title.trim() ? { title: title.trim() } : {}),
          }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: CreatedLink };
      const created = payload.data;
      setLinks((current) => [created.link, ...(current ?? [])]);
      setCreatedUrl(`${window.location.origin}/p/${created.token}`);
      setTitle("");
      setBranchId("");
      setExpiresAt("");
      setNotice("Link criado. Copie-o agora: por segurança ele não será exibido novamente.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível criar o link.");
    } finally {
      setSaving(false);
    }
  }

  async function revoke(link: AppointmentPortalLinkView) {
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/appointment-portal-links/${link.id}`,
        { method: "DELETE" },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: AppointmentPortalLinkView };
      setLinks(
        (current) =>
          current?.map((item) => (item.id === payload.data.id ? payload.data : item)) ?? [],
      );
      setNotice("Link revogado. Ele não pode mais ser usado.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível revogar o link.");
    } finally {
      setSaving(false);
    }
  }

  async function copyCreatedLink() {
    if (!createdUrl) return;
    try {
      await navigator.clipboard.writeText(createdUrl);
      setNotice("Link copiado.");
    } catch {
      setError("Não foi possível copiar automaticamente. Selecione e copie o endereço abaixo.");
    }
  }

  return (
    <section
      className="grid gap-5 rounded-2xl border bg-white p-5"
      aria-labelledby="portal-links-title"
    >
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Portal do cliente
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="portal-links-title">
          Links de agendamento
        </h2>
        <p className="mt-1 max-w-2xl text-sm text-slate-600">
          Crie um endereço público para novos agendamentos. O cliente não recebe acesso à operação
          da empresa.
        </p>
      </div>
      {error ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
          role="alert"
        >
          {error}
        </p>
      ) : null}
      {notice ? (
        <p
          className="border-brand-100 bg-brand-50 text-brand-700 rounded-xl border p-3 text-sm"
          role="status"
        >
          {notice}
        </p>
      ) : null}
      {createdUrl ? (
        <div className="grid gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3">
          <Label htmlFor="new-appointment-link">Copie o link agora</Label>
          <input
            className="h-10 rounded-lg border bg-white px-3 text-sm"
            id="new-appointment-link"
            readOnly
            value={createdUrl}
          />
          <div>
            <Button onClick={() => void copyCreatedLink()} type="button" variant="outline">
              Copiar link
            </Button>
          </div>
        </div>
      ) : null}
      <form className="grid gap-3 sm:grid-cols-3" onSubmit={createLink}>
        <div className="grid gap-1.5">
          <Label htmlFor="appointment-link-title">Identificação</Label>
          <input
            className="h-10 rounded-xl border px-3 text-sm"
            id="appointment-link-title"
            maxLength={160}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Ex.: Agenda da matriz"
            value={title}
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="appointment-link-branch">Filial</Label>
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="appointment-link-branch"
            onChange={(event) => setBranchId(event.target.value)}
            value={branchId}
          >
            <option value="">Todas as filiais permitidas</option>
            {activeBranches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="appointment-link-expiration">Expira em</Label>
          <input
            className="h-10 rounded-xl border px-3 text-sm"
            id="appointment-link-expiration"
            max={oneYearFromNow()}
            min={toDateTimeLocal(new Date())}
            onChange={(event) => setExpiresAt(event.target.value)}
            type="datetime-local"
            value={expiresAt}
          />
        </div>
        <div className="sm:col-span-3">
          <Button disabled={saving} type="submit">
            {saving ? "Criando..." : "Criar link de agendamento"}
          </Button>
        </div>
      </form>
      {links === null ? <LoadingRows rows={2} /> : null}
      {links?.length === 0 ? (
        <p className="rounded-xl border border-dashed p-4 text-sm text-slate-600">
          Nenhum link de agendamento criado.
        </p>
      ) : null}
      <div className="grid gap-2">
        {links?.map((link) => (
          <article
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3"
            key={link.id}
          >
            <div>
              <p className="font-medium text-slate-950">{link.title ?? "Link sem identificação"}</p>
              <p className="text-sm text-slate-600">
                {link.revokedAt
                  ? "Revogado"
                  : link.expiresAt
                    ? `Expira em ${formatDate(link.expiresAt)}`
                    : "Sem expiração"}
              </p>
            </div>
            {link.revokedAt ? null : (
              <Button
                disabled={saving}
                onClick={() => void revoke(link)}
                type="button"
                variant="outline"
              >
                Revogar
              </Button>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}
function toDateTimeLocal(value: Date) {
  return new Date(value.getTime() - value.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}
function oneYearFromNow() {
  const value = new Date();
  value.setFullYear(value.getFullYear() + 1);
  return toDateTimeLocal(value);
}
function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(
    new Date(value),
  );
}
