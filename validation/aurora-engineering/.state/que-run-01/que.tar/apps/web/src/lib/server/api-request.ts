import { createHash } from "node:crypto";

import type { ProblemDetails } from "@gestor/contracts";
import type { AuthenticatedIdentity } from "@gestor/auth";
import {
  AppError,
  PayloadTooLargeError,
  RateLimitError,
  type RateLimitConsumption,
  type RateLimiter,
  type RateLimitPolicy,
} from "@gestor/kernel";
import { getLogger, metrics } from "@gestor/observability";
import { ZodError } from "zod";

import { apiRateLimiter, apiRateLimitPolicies, createRateLimitSubject } from "./rate-limit";

export type ApiRequestContext = {
  correlationId: string;
  requestId: string;
};

export type ApiRequestOptions = {
  /** Private by default. Public endpoints must opt out explicitly. */
  authentication?: "PUBLIC" | "REQUIRED";
  /** Required for authenticated application access; legal endpoints opt out. */
  legalAcceptance?: boolean;
  rateLimit?: false | RateLimitPolicy;
  /** Infrastructure seam for deterministic tests; routes should use `rateLimit` only. */
  rateLimiter?: RateLimiter;
  /** Infrastructure seam for deterministic tests; never pass raw personal data. */
  rateLimitSubject?: string;
};

const requestIdentities = new WeakMap<Request, Promise<AuthenticatedIdentity>>();

export async function handleApiRequest(
  request: Request,
  handler: (context: ApiRequestContext) => Promise<Response>,
  options: ApiRequestOptions = {},
): Promise<Response> {
  const context = createApiRequestContext(request);
  const startedAt = performance.now();
  let rateLimitConsumption: RateLimitConsumption | undefined;

  try {
    if (options.rateLimit !== false) {
      const policy = options.rateLimit ?? apiRateLimitPolicies.default;
      rateLimitConsumption = await (options.rateLimiter ?? apiRateLimiter).consume({
        key: options.rateLimitSubject ?? createRateLimitSubject(request),
        now: new Date(),
        policy,
      });

      if (!rateLimitConsumption.allowed) {
        const retryAfterSeconds = Math.max(
          1,
          Math.ceil((rateLimitConsumption.resetAt.getTime() - Date.now()) / 1_000),
        );
        throw new RateLimitError(
          "RATE_LIMIT_EXCEEDED",
          "Muitas solicitações foram realizadas. Aguarde antes de tentar novamente.",
          {
            limit: rateLimitConsumption.limit,
            resetAt: rateLimitConsumption.resetAt.toISOString(),
            retryAfterSeconds,
          },
        );
      }
    }

    if ((options.authentication ?? "REQUIRED") === "REQUIRED") {
      requireTrustedMutationOrigin(request);
      const identity = await authenticateApiRequest(request);
      if (options.legalAcceptance !== false) {
        const { requireCurrentLegalAcceptance } = await import("./legal-acceptance");
        await requireCurrentLegalAcceptance(identity.userId);
      }
    }

    const response = await handler(context);
    applyResponseHeaders(response, context, rateLimitConsumption);
    recordHttpMetrics(request, response, startedAt);
    return response;
  } catch (error) {
    const response = mapErrorToResponse(error, request, context);
    applyResponseHeaders(response, context, rateLimitConsumption);

    if (error instanceof RateLimitError) {
      const retryAfterSeconds = error.details?.retryAfterSeconds;
      if (typeof retryAfterSeconds === "number") {
        response.headers.set("retry-after", String(retryAfterSeconds));
      }
      metrics.increment("http_rate_limit_rejections_total", {
        route: normalizedMetricRoute(request),
      });
    }

    recordHttpMetrics(request, response, startedAt);
    return response;
  }
}

export function authenticateApiRequest(request: Request): Promise<AuthenticatedIdentity> {
  const existing = requestIdentities.get(request);
  if (existing) return existing;

  const authentication = import("./container").then(({ services }) =>
    services.identityProvider.authenticate(request),
  );
  requestIdentities.set(request, authentication);
  return authentication;
}

function requireTrustedMutationOrigin(request: Request): void {
  if (["GET", "HEAD", "OPTIONS"].includes(request.method.toUpperCase())) return;

  const fetchSite = request.headers.get("sec-fetch-site")?.toLowerCase();
  const suppliedOrigin = request.headers.get("origin");
  const allowedOrigins = new Set([
    new URL(process.env.BETTER_AUTH_URL ?? request.url).origin,
    ...(process.env.AUTH_TRUSTED_ORIGINS ?? "")
      .split(",")
      .map((origin) => origin.trim())
      .filter(Boolean)
      .map((origin) => new URL(origin).origin),
  ]);

  if (fetchSite === "cross-site" || (suppliedOrigin && !allowedOrigins.has(suppliedOrigin))) {
    throw new AppError({
      code: "UNTRUSTED_REQUEST_ORIGIN",
      kind: "AUTHORIZATION",
      message: "A origem da requisição não é permitida.",
    });
  }
}

function recordHttpMetrics(request: Request, response: Response, startedAt: number): void {
  const labels = {
    method: request.method,
    route: normalizedMetricRoute(request),
    status: String(response.status),
  };
  metrics.increment("http_requests_total", labels);
  metrics.observe("http_request_duration_ms", Math.max(0, performance.now() - startedAt), labels);
}

function normalizedMetricRoute(request: Request): string {
  const pathname = new URL(request.url).pathname;
  if (/^\/api\/public\/appointment-links\/[^/]+(?:\/(?:access|appointments|options|slots))?$/.test(pathname))
    return "/api/public/appointment-links/:token";
  return pathname
    .replaceAll(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/gi, ":id")
    .replaceAll(/\/\d+(?=\/|$)/g, "/:id");
}

function applyResponseHeaders(
  response: Response,
  context: ApiRequestContext,
  rateLimit?: RateLimitConsumption,
): void {
  response.headers.set("x-correlation-id", context.correlationId);
  response.headers.set("x-request-id", context.requestId);

  if (rateLimit) {
    response.headers.set("ratelimit-limit", String(rateLimit.limit));
    response.headers.set("ratelimit-remaining", String(rateLimit.remaining));
    response.headers.set("ratelimit-reset", String(Math.ceil(rateLimit.resetAt.getTime() / 1_000)));
  }
}

export function requireIdempotencyKey(request: Request): string {
  const value = request.headers.get("idempotency-key")?.trim();

  if (!value || value.length < 8 || value.length > 120) {
    throw new AppError({
      code: "INVALID_IDEMPOTENCY_KEY",
      kind: "VALIDATION",
      message: "O header Idempotency-Key deve possuir entre 8 e 120 caracteres.",
    });
  }

  return value;
}

export async function readJsonBody(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch (error) {
    throw new AppError({
      cause: error,
      code: "INVALID_JSON_BODY",
      kind: "VALIDATION",
      message: "O corpo da requisição deve conter um JSON válido.",
    });
  }
}

export async function readLimitedTextBody(
  request: Request,
  maxBytes: number,
): Promise<{ checksumSha256: string; content: string; sizeBytes: number }> {
  const declaredLength = request.headers.get("content-length");

  if (declaredLength && Number(declaredLength) > maxBytes) {
    throw new PayloadTooLargeError(
      "REQUEST_BODY_TOO_LARGE",
      `O arquivo deve possuir no máximo ${formatBytes(maxBytes)}.`,
    );
  }

  if (!request.body) {
    throw new AppError({
      code: "REQUEST_BODY_REQUIRED",
      kind: "VALIDATION",
      message: "Envie o conteúdo do arquivo no corpo da requisição.",
    });
  }

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let sizeBytes = 0;

  while (true) {
    const result = await reader.read();

    if (result.done) {
      break;
    }

    sizeBytes += result.value.byteLength;

    if (sizeBytes > maxBytes) {
      await reader.cancel();
      throw new PayloadTooLargeError(
        "REQUEST_BODY_TOO_LARGE",
        `O arquivo deve possuir no máximo ${formatBytes(maxBytes)}.`,
      );
    }

    chunks.push(result.value);
  }

  if (sizeBytes === 0) {
    throw new AppError({
      code: "REQUEST_BODY_REQUIRED",
      kind: "VALIDATION",
      message: "O arquivo enviado está vazio.",
    });
  }

  const bytes = new Uint8Array(sizeBytes);
  let offset = 0;

  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }

  let content: string;

  try {
    content = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    content = new TextDecoder("windows-1252").decode(bytes);
  }

  return {
    checksumSha256: createHash("sha256").update(bytes).digest("hex"),
    content,
    sizeBytes,
  };
}

function createApiRequestContext(request: Request): ApiRequestContext {
  const incomingCorrelationId = request.headers.get("x-correlation-id")?.trim();

  return {
    correlationId:
      incomingCorrelationId && incomingCorrelationId.length <= 160
        ? incomingCorrelationId
        : crypto.randomUUID(),
    requestId: crypto.randomUUID(),
  };
}

function mapErrorToResponse(
  error: unknown,
  request: Request,
  context: ApiRequestContext,
): Response {
  if (error instanceof ZodError) {
    const fieldErrors: Record<string, string[]> = {};

    for (const issue of error.issues) {
      const field = issue.path.length > 0 ? issue.path.join(".") : "_root";
      (fieldErrors[field] ??= []).push(issue.message);
    }

    return problemResponse(
      {
        code: "VALIDATION_ERROR",
        correlationId: context.correlationId,
        detail: "Um ou mais campos são inválidos.",
        errors: fieldErrors,
        instance: normalizedMetricRoute(request),
        status: 400,
        title: "Dados inválidos",
        type: "https://api.gestor.local/problems/validation-error",
      },
      400,
    );
  }

  if (error instanceof AppError) {
    const status = statusByKind[error.kind];
    return problemResponse(
      {
        code: error.code,
        correlationId: context.correlationId,
        detail: error.message,
        instance: normalizedMetricRoute(request),
        ...(error.details ? { meta: error.details } : {}),
        status,
        title: titleByStatus[status] ?? "Erro na solicitação",
        type: `https://api.gestor.local/problems/${toKebabCase(error.code)}`,
      },
      status,
    );
  }

  getLogger().error(
    {
      correlationId: context.correlationId,
      err: error,
      operation: `${request.method} ${normalizedMetricRoute(request)}`,
      requestId: context.requestId,
    },
    "Unhandled API error",
  );

  return problemResponse(
    {
      code: "INTERNAL_ERROR",
      correlationId: context.correlationId,
      detail: "Não foi possível concluir a solicitação.",
      instance: normalizedMetricRoute(request),
      status: 500,
      title: "Erro interno",
      type: "https://api.gestor.local/problems/internal-error",
    },
    500,
  );
}

function problemResponse(problem: ProblemDetails, status: number): Response {
  return Response.json(problem, {
    headers: {
      "content-type": "application/problem+json",
    },
    status,
  });
}

function toKebabCase(value: string): string {
  return value.toLowerCase().replaceAll("_", "-");
}

const statusByKind = {
  AUTHENTICATION: 401,
  AUTHORIZATION: 403,
  BUSINESS_RULE: 422,
  CONFLICT: 409,
  DEPENDENCY: 503,
  NOT_FOUND: 404,
  PAYLOAD_TOO_LARGE: 413,
  RATE_LIMIT: 429,
  VALIDATION: 400,
} as const;

const titleByStatus: Readonly<Record<number, string>> = {
  400: "Requisição inválida",
  401: "Autenticação necessária",
  403: "Acesso negado",
  404: "Recurso não encontrado",
  409: "Conflito",
  413: "Conteúdo muito grande",
  422: "Regra de negócio",
  429: "Limite excedido",
  500: "Erro interno",
  503: "Serviço temporariamente indisponível",
};

function formatBytes(value: number): string {
  return value % (1024 * 1024) === 0
    ? `${value / (1024 * 1024)} MiB`
    : `${value.toLocaleString("pt-BR")} bytes`;
}
