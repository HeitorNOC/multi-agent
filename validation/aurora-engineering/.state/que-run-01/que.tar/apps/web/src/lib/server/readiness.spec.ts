import { describe, expect, it } from "vitest";

import { checkReadiness } from "./readiness";

describe("checkReadiness", () => {
  it("is ready only when every dependency responds", async () => {
    await expect(
      checkReadiness({ database: async () => undefined, outbox: async () => undefined }),
    ).resolves.toMatchObject({
      checks: { database: { status: "ok" }, outbox: { status: "ok" } },
      status: "ok",
    });
  });

  it("reports an unavailable dependency without leaking its error", async () => {
    const result = await checkReadiness({
      database: async () => {
        throw new Error("postgresql://user:secret@private-host/database");
      },
    });

    expect(result).toMatchObject({ checks: { database: { status: "unavailable" } } });
    expect(JSON.stringify(result)).not.toContain("secret");
  });

  it("expires a probe that exceeds the readiness budget", async () => {
    const result = await checkReadiness({ database: async () => new Promise(() => undefined) }, 5);

    expect(result.status).toBe("unavailable");
  });
});
