import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createInvitation, listInvitations, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createInvitation: vi.fn(),
  listInvitations: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    createOrganizationInvitation: { execute: createInvitation },
    identityProvider: { authenticate },
    listOrganizationInvitations: { execute: listInvitations },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const roleId = "20000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ organizationId }) };

describe("organization invitations route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    listInvitations.mockReset().mockResolvedValue([]);
    createInvitation.mockReset().mockResolvedValue({ id: crypto.randomUUID() });
  });

  it("lists invitations through the tenant actor", async () => {
    const response = await GET(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/invitations`),
      route,
    );
    expect(response.status).toBe(200);
    expect(listInvitations).toHaveBeenCalledWith(organizationId, { role: "OWNER" });
  });

  it("creates an invitation with idempotency", async () => {
    const body = { branchIds: [], branchScope: "ALL", email: "user@example.com", roleId };
    const response = await POST(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/invitations`, {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "invite-key" },
        method: "POST",
      }),
      route,
    );
    expect(response.status).toBe(201);
    expect(createInvitation).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "invite-key", organizationId },
      { role: "OWNER" },
    );
  });
});
