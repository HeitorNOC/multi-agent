"use client";

import type { QuoteView, SalesOrderView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useMemo, useState } from "react";

import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

export function CommercialDocumentLists({
  onCompleteOrder,
  orders,
  organizationId,
  quotes,
  request,
}: {
  onCompleteOrder: (order: SalesOrderView) => void;
  orders: readonly SalesOrderView[];
  organizationId: string;
  quotes: readonly QuoteView[];
  request: (path: string, method: string, body: object) => Promise<void>;
}) {
  const [quoteStatus, setQuoteStatus] = useState<QuoteView["status"] | "ALL">("ALL");
  const [orderStatus, setOrderStatus] = useState<SalesOrderView["status"] | "ALL">("ALL");
  const visibleQuotes = useMemo(
    () => (quoteStatus === "ALL" ? quotes : quotes.filter((quote) => quote.status === quoteStatus)),
    [quoteStatus, quotes],
  );
  const visibleOrders = useMemo(
    () => (orderStatus === "ALL" ? orders : orders.filter((order) => order.status === orderStatus)),
    [orderStatus, orders],
  );

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <div>
        <div className="flex items-center justify-between gap-3">
          <h3 className="font-semibold">Orçamentos</h3>
          <label className="text-sm text-slate-600">
            <span className="sr-only">Filtrar orçamentos por status</span>
            <select
              className="rounded-md border bg-white px-2 py-1 text-sm"
              onChange={(event) =>
                setQuoteStatus(event.target.value as QuoteView["status"] | "ALL")
              }
              value={quoteStatus}
            >
              <option value="ALL">Todos</option>
              <option value="DRAFT">Rascunhos</option>
              <option value="APPROVED">Aprovados</option>
              <option value="REJECTED">Recusados</option>
              <option value="EXPIRED">Expirados</option>
              <option value="CONVERTED">Convertidos</option>
              <option value="CANCELLED">Cancelados</option>
            </select>
          </label>
        </div>
        {visibleQuotes.map((q) => (
          <article className="mt-2 rounded-xl border p-3 text-sm" key={q.id}>
            <div className="flex justify-between">
              <strong>
                #{q.number} · {q.customerName}
              </strong>
              <span>{q.status}</span>
            </div>
            <p>
              R$ {q.total} · {q.items.length} item(ns)
            </p>
            <div className="mt-2 flex gap-2">
              <CatalogFilesButton
                allowImage={false}
                itemId={q.id}
                organizationId={organizationId}
                segment="quotes"
              />
              {q.status === "DRAFT" ? (
                <>
                  <Button
                    size="sm"
                    onClick={() =>
                      request(`/api/v1/organizations/${organizationId}/quotes/${q.id}`, "PATCH", {
                        expectedUpdatedAt: q.updatedAt,
                        status: "APPROVED",
                      })
                    }
                  >
                    Aprovar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      request(`/api/v1/organizations/${organizationId}/quotes/${q.id}`, "PATCH", {
                        expectedUpdatedAt: q.updatedAt,
                        status: "REJECTED",
                      })
                    }
                  >
                    Recusar
                  </Button>
                </>
              ) : null}
              {q.status === "APPROVED" ? (
                <Button
                  size="sm"
                  onClick={() =>
                    request(
                      `/api/v1/organizations/${organizationId}/quotes/${q.id}/convert`,
                      "POST",
                      { expectedUpdatedAt: q.updatedAt },
                    )
                  }
                >
                  Gerar pedido
                </Button>
              ) : null}
            </div>
          </article>
        ))}
        {visibleQuotes.length === 0 ? (
          <p className="mt-3 text-sm text-slate-600">Nenhum orçamento neste status.</p>
        ) : null}
      </div>
      <div>
        <div className="flex items-center justify-between gap-3">
          <h3 className="font-semibold">Pedidos</h3>
          <label className="text-sm text-slate-600">
            <span className="sr-only">Filtrar pedidos por status</span>
            <select
              className="rounded-md border bg-white px-2 py-1 text-sm"
              onChange={(event) =>
                setOrderStatus(event.target.value as SalesOrderView["status"] | "ALL")
              }
              value={orderStatus}
            >
              <option value="ALL">Todos</option>
              <option value="OPEN">Abertos</option>
              <option value="IN_PROGRESS">Em andamento</option>
              <option value="COMPLETED">Concluídos</option>
              <option value="CANCELLED">Cancelados</option>
            </select>
          </label>
        </div>
        {visibleOrders.map((o) => (
          <article className="mt-2 rounded-xl border p-3 text-sm" key={o.id}>
            <div className="flex justify-between">
              <strong>
                #{o.number} · {o.customerName}
              </strong>
              <span>{o.status}</span>
            </div>
            <p>
              R$ {o.total} · {o.items.length} item(ns)
            </p>
            <div className="mt-2 flex gap-2">
              {o.status === "OPEN" ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    request(
                      `/api/v1/organizations/${organizationId}/sales-orders/${o.id}`,
                      "PATCH",
                      { expectedUpdatedAt: o.updatedAt, status: "IN_PROGRESS" },
                    )
                  }
                >
                  Iniciar
                </Button>
              ) : null}
              {["OPEN", "IN_PROGRESS"].includes(o.status) ? (
                <>
                  <Button size="sm" onClick={() => onCompleteOrder(o)}>
                    Concluir venda
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      request(
                        `/api/v1/organizations/${organizationId}/sales-orders/${o.id}`,
                        "PATCH",
                        { expectedUpdatedAt: o.updatedAt, status: "CANCELLED" },
                      )
                    }
                  >
                    Cancelar
                  </Button>
                </>
              ) : null}
            </div>
          </article>
        ))}
        {visibleOrders.length === 0 ? (
          <p className="mt-3 text-sm text-slate-600">Nenhum pedido neste status.</p>
        ) : null}
      </div>
    </div>
  );
}
