import { getPaymentEnv } from "@gestor/config";
import { prisma } from "@gestor/database";
import {
  DefaultTerminalProviderRegistry,
  ListPaymentCharges,
  ListTerminalDevices,
  MercadoPagoTerminalProvider,
  ProcessTerminalPaymentWebhook,
  RefundTerminalPayment,
  RegisterTerminalDevice,
  SandboxTerminalProvider,
  StartTerminalPayment,
  StripeTerminalProvider,
} from "@gestor/sales";
import { PrismaPosUnitOfWork } from "@gestor/sales/prisma";

import { mercadoPagoCredentials, stripeCredentials } from "./payment-provider-credentials";

const unitOfWork = new PrismaPosUnitOfWork(prisma);
const providers = new DefaultTerminalProviderRegistry(
  new SandboxTerminalProvider(() => getPaymentEnv().PAYMENT_WEBHOOK_SECRET),
  new MercadoPagoTerminalProvider(mercadoPagoCredentials),
  new StripeTerminalProvider(stripeCredentials),
);

export const posServices = {
  listPaymentCharges: new ListPaymentCharges(unitOfWork),
  listTerminalDevices: new ListTerminalDevices(unitOfWork),
  processTerminalPaymentWebhook: new ProcessTerminalPaymentWebhook(unitOfWork, providers),
  refundTerminalPayment: new RefundTerminalPayment(unitOfWork, providers),
  registerTerminalDevice: new RegisterTerminalDevice(unitOfWork),
  startTerminalPayment: new StartTerminalPayment(unitOfWork, providers),
};
