import type { Metadata } from "next";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { AcceptInvitationPanel } from "@/features/organization-users/components/accept-invitation-panel";

export const metadata: Metadata = { title: "Aceitar convite | Gestor" };

export default function AcceptInvitationPage() {
  return (
    <AuthShell
      description="O acesso será ativado somente para o e-mail que recebeu o convite."
      eyebrow="Acesso à empresa"
      title="Aceitar convite"
    >
      <AcceptInvitationPanel />
    </AuthShell>
  );
}
