type FormFeedbackProps = {
  children: string;
  kind: "error" | "success";
};

export function FormFeedback({ children, kind }: FormFeedbackProps) {
  if (kind === "success") {
    return (
      <div
        className="border-brand-100 bg-brand-50 text-brand-700 rounded-xl border px-4 py-3 text-sm leading-5"
        role="status"
      >
        {children}
      </div>
    );
  }

  return (
    <div
      className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-5 text-red-800"
      role="alert"
    >
      {children}
    </div>
  );
}
