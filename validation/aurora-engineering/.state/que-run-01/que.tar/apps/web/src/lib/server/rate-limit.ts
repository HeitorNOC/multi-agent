import { createHash, createHmac } from "node:crypto";

import { getServerEnv } from "@gestor/config";
import { Prisma, prisma, type PrismaClient } from "@gestor/database";
import {
  defineRateLimitPolicy,
  type ConsumeRateLimitInput,
  type RateLimitConsumption,
  type RateLimiter,
} from "@gestor/kernel";

type RateLimitRow = {
  count: number;
  windowStartedAt: bigint;
};

export const apiRateLimitPolicies = Object.freeze({
  default: defineRateLimitPolicy({ limit: 120, namespace: "api.default", windowMs: 60_000 }),
  fileImport: defineRateLimitPolicy({
    limit: 12,
    namespace: "api.file-import",
    windowMs: 5 * 60_000,
  }),
  fileUpload: defineRateLimitPolicy({
    limit: 20,
    namespace: "api.file-upload",
    windowMs: 60_000,
  }),
  publicPortalLink: defineRateLimitPolicy({
    limit: 30,
    namespace: "api.public-portal-link",
    windowMs: 60_000,
  }),
  reportRequest: defineRateLimitPolicy({
    limit: 5,
    namespace: "api.report-request",
    windowMs: 10 * 60_000,
  }),
});

export class PrismaRateLimiter implements RateLimiter {
  constructor(private readonly client: PrismaClient) {}

  async consume(input: ConsumeRateLimitInput): Promise<RateLimitConsumption> {
    const nowMs = BigInt(input.now.getTime());
    const resetBeforeMs = nowMs - BigInt(input.policy.windowMs);
    const keyHash = createHash("sha256")
      .update(`${input.policy.namespace}:${input.key}`)
      .digest("hex");

    const rows = await this.client.$queryRaw<RateLimitRow[]>(Prisma.sql`
      INSERT INTO "request_rate_limit_buckets" (
        "id", "key_hash", "count", "window_started_at", "updated_at"
      )
      VALUES (
        gen_random_uuid(), ${keyHash}, 1, ${nowMs}, ${input.now}
      )
      ON CONFLICT ("key_hash") DO UPDATE
      SET
        "count" = CASE
          WHEN "request_rate_limit_buckets"."window_started_at" <= ${resetBeforeMs} THEN 1
          ELSE "request_rate_limit_buckets"."count" + 1
        END,
        "window_started_at" = CASE
          WHEN "request_rate_limit_buckets"."window_started_at" <= ${resetBeforeMs} THEN ${nowMs}
          ELSE "request_rate_limit_buckets"."window_started_at"
        END,
        "updated_at" = ${input.now}
      RETURNING
        "count",
        "window_started_at" AS "windowStartedAt"
    `);
    const row = rows[0];

    if (!row) {
      throw new Error("Rate limit counter did not return a value.");
    }

    const resetAt = new Date(Number(row.windowStartedAt) + input.policy.windowMs);
    return {
      allowed: row.count <= input.policy.limit,
      limit: input.policy.limit,
      remaining: Math.max(0, input.policy.limit - row.count),
      resetAt,
    };
  }
}

export class MemoryRateLimiter implements RateLimiter {
  private readonly buckets = new Map<string, { count: number; windowStartedAt: number }>();

  async consume(input: ConsumeRateLimitInput): Promise<RateLimitConsumption> {
    const bucketKey = `${input.policy.namespace}:${input.key}`;
    const nowMs = input.now.getTime();
    const current = this.buckets.get(bucketKey);
    const bucket =
      !current || current.windowStartedAt + input.policy.windowMs <= nowMs
        ? { count: 1, windowStartedAt: nowMs }
        : { count: current.count + 1, windowStartedAt: current.windowStartedAt };
    this.buckets.set(bucketKey, bucket);

    return {
      allowed: bucket.count <= input.policy.limit,
      limit: input.policy.limit,
      remaining: Math.max(0, input.policy.limit - bucket.count),
      resetAt: new Date(bucket.windowStartedAt + input.policy.windowMs),
    };
  }
}

export function createRateLimitSubject(request: Request): string {
  const environment = getServerEnv();
  const address = environment.TRUST_PROXY_HEADERS ? getForwardedAddress(request) : null;
  const rawSubject = address
    ? `ip:${address}`
    : `untrusted:${request.headers.get("user-agent") ?? "unknown"}:${
        request.headers.get("accept-language") ?? "unknown"
      }`;
  const secret =
    environment.RATE_LIMIT_HASH_SECRET ?? "local-rate-limit-secret-must-not-be-used-in-production";

  return createHmac("sha256", secret).update(rawSubject).digest("hex");
}

function getForwardedAddress(request: Request): string | null {
  const cloudflareAddress = request.headers.get("cf-connecting-ip")?.trim();
  if (cloudflareAddress) return cloudflareAddress;

  const realAddress = request.headers.get("x-real-ip")?.trim();
  if (realAddress) return realAddress;

  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || null;
}

const memoryRateLimiter = new MemoryRateLimiter();

export const apiRateLimiter: RateLimiter =
  process.env.NODE_ENV === "test" ? memoryRateLimiter : new PrismaRateLimiter(prisma);
