export function formatDate(value: string): string {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short" }).format(new Date(value));
}

export function formatBrl(value: string): string {
  return new Intl.NumberFormat("pt-BR", { currency: "BRL", style: "currency" }).format(
    Number(value),
  );
}
