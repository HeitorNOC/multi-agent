import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, list, register, resolve } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  list: vi.fn(),
  register: vi.fn(),
  resolve: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listTerminalDevices: { execute: list },
    registerTerminalDevice: { execute: register },
    resolveTenantActor: { execute: resolve },
  },
}));

import { POST } from "./route";

it("registers a validated terminal with idempotency", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolve.mockResolvedValue({ role: "OWNER" });
  register.mockResolvedValue({ id: "terminal" });
  const params = {
    branchId: "10000000-0000-4000-8000-000000000002",
    organizationId: "10000000-0000-4000-8000-000000000001",
  };
  const body = {
    cashRegisterId: null,
    externalTerminalId: "sandbox-terminal",
    name: "Balcão",
    provider: "SANDBOX",
  };
  const response = await POST(
    new Request("http://localhost/terminals", {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": "register-key" },
      method: "POST",
    }),
    { params: Promise.resolve(params) },
  );
  expect(response.status).toBe(201);
  expect(register).toHaveBeenCalledWith(
    { ...body, ...params, idempotencyKey: "register-key" },
    { role: "OWNER" },
  );
});
