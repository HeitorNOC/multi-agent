"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  cancelSaleBodySchema,
  returnSaleBodySchema,
  saleDetailViewSchema,
  saleReturnViewSchema,
  type CancelSaleBody,
  type ProblemDetails,
  type ReturnSaleBody,
  type SaleDetailView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect } from "react";
import { useFieldArray, useForm } from "react-hook-form";

import { remainingQuantity, statusLabel } from "./sale-format";
import { FiscalDocumentsPanel } from "./fiscal-documents-panel";
import { PosPaymentPanel } from "./pos-payment-panel";
import { SaleReceiptPanel } from "./sale-receipt-panel";
import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

export function SaleDetail({
  onCancelled,
  onClose,
  onReturned,
  organizationId,
  sale,
  setFeedback,
}: {
  onCancelled: (sale: SaleDetailView) => void;
  onClose: () => void;
  onReturned: () => Promise<void>;
  organizationId: string;
  sale: SaleDetailView;
  setFeedback: (message: string) => void;
}) {
  const cancelForm = useForm<CancelSaleBody>({
    defaultValues: { expectedUpdatedAt: sale.updatedAt, reason: "" },
    resolver: zodResolver(cancelSaleBodySchema),
  });
  const returnForm = useForm<ReturnSaleBody>({
    defaultValues: { expectedUpdatedAt: sale.updatedAt, items: [], reason: "" },
    resolver: zodResolver(returnSaleBodySchema),
  });
  const returnItems = useFieldArray({ control: returnForm.control, name: "items" });
  useEffect(() => {
    cancelForm.reset({ expectedUpdatedAt: sale.updatedAt, reason: "" });
    returnForm.reset({ expectedUpdatedAt: sale.updatedAt, items: [], reason: "" });
  }, [cancelForm, returnForm, sale.updatedAt]);
  async function cancel(body: CancelSaleBody) {
    if (
      !window.confirm(
        `Confirma o cancelamento da venda #${sale.number} e todos os estornos aplicáveis?`,
      )
    )
      return;
    setFeedback("");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/sales/${sale.id}/cancel`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      },
    );
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) {
      setFeedback(payload.detail ?? "Não foi possível cancelar a venda.");
      return;
    }
    const current = saleDetailViewSchema.parse(payload.data);
    setFeedback(`Venda #${current.number} cancelada e efeitos revertidos.`);
    onCancelled(current);
  }
  async function returnSale(body: ReturnSaleBody) {
    if (!window.confirm(`Confirma a devolução selecionada da venda #${sale.number}?`)) return;
    setFeedback("");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/sales/${sale.id}/return`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      },
    );
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) {
      setFeedback(payload.detail ?? "Não foi possível registrar a devolução.");
      return;
    }
    const returned = saleReturnViewSchema.parse(payload.data);
    setFeedback(
      `Devolução registrada: R$ ${returned.creditedAmount} em crédito e R$ ${returned.refundedAmount} em reembolso.`,
    );
    await onReturned();
  }
  return (
    <div className="grid gap-5 rounded-2xl border bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold">Venda #{sale.number}</h3>
          <p className="text-sm text-slate-600">
            {sale.branchName} · {sale.customerName} · {statusLabel(sale.status)}
          </p>
        </div>
        <Button onClick={onClose} type="button" variant="outline">
          Fechar
        </Button>
      </div>
      <div className="grid gap-2 text-sm sm:grid-cols-3">
        <p>
          Total: <strong>R$ {sale.total}</strong>
        </p>
        <p>Desconto: R$ {sale.discountAmount}</p>
        <p>Realizada em: {new Date(sale.occurredAt).toLocaleString("pt-BR")}</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead>
            <tr className="border-b">
              <th className="py-2">Item</th>
              <th>Quantidade</th>
              <th>Unitário</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {sale.items.map((item) => (
              <tr className="border-b" key={item.id}>
                <td className="py-2">{item.description}</td>
                <td>
                  {item.quantity}
                  {item.returnedQuantity !== "0.0000" ? (
                    <span className="block text-xs text-slate-500">
                      Devolvido: {item.returnedQuantity}
                    </span>
                  ) : null}
                </td>
                <td>R$ {item.unitPrice}</td>
                <td>R$ {item.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="grid gap-2 text-sm">
        <h4 className="font-semibold">Contas a receber</h4>
        {sale.receivables.map((receivable) => (
          <p key={receivable.id}>
            {receivable.status} · Original R$ {receivable.originalAmount} · Em aberto R${" "}
            {receivable.openAmount} · Vence {receivable.dueDate}
          </p>
        ))}
      </div>
      <SaleReceiptPanel organizationId={organizationId} sale={sale} setFeedback={setFeedback} />
      <div>
        <CatalogFilesButton
          allowImage={false}
          itemId={sale.id}
          organizationId={organizationId}
          segment="sales"
        />
      </div>
      <FiscalDocumentsPanel organizationId={organizationId} sale={sale} setFeedback={setFeedback} />
      <PosPaymentPanel organizationId={organizationId} sale={sale} setFeedback={setFeedback} />
      {["COMPLETED", "PARTIALLY_RETURNED"].includes(sale.status) ? (
        <form className="grid gap-4 border-t pt-5" onSubmit={returnForm.handleSubmit(returnSale)}>
          <input type="hidden" {...returnForm.register("expectedUpdatedAt")} />
          <div>
            <h4 className="font-semibold">Devolver itens</h4>
            <p className="text-sm text-slate-600">
              Selecione somente os itens que o cliente está devolvendo agora.
            </p>
          </div>
          <div className="grid gap-2">
            {sale.items.map((item) => {
              const remaining = remainingQuantity(item.quantity, item.returnedQuantity);
              const selectedIndex = returnItems.fields.findIndex(
                (field) => field.saleItemId === item.id,
              );
              return (
                <div className="flex flex-wrap items-end gap-3 rounded-xl border p-3" key={item.id}>
                  <div className="min-w-48 flex-1 text-sm">
                    <strong>{item.description}</strong>
                    <span className="block text-slate-600">Disponível: {remaining}</span>
                  </div>
                  {selectedIndex >= 0 ? (
                    <>
                      <label className="grid gap-1 text-sm font-medium">
                        Quantidade
                        <Input
                          className="w-36"
                          inputMode="decimal"
                          {...returnForm.register(`items.${selectedIndex}.quantity`)}
                        />
                      </label>
                      <Button
                        onClick={() => returnItems.remove(selectedIndex)}
                        type="button"
                        variant="outline"
                      >
                        Remover
                      </Button>
                    </>
                  ) : remaining !== "0.0000" ? (
                    <Button
                      onClick={() =>
                        returnItems.append({ quantity: remaining, saleItemId: item.id })
                      }
                      type="button"
                      variant="outline"
                    >
                      Selecionar
                    </Button>
                  ) : (
                    <span className="text-sm text-slate-500">Totalmente devolvido</span>
                  )}
                </div>
              );
            })}
            {returnForm.formState.errors.items?.message ? (
              <span className="text-xs text-red-700">
                {returnForm.formState.errors.items.message}
              </span>
            ) : null}
          </div>
          <label className="grid gap-1 text-sm font-medium">
            Motivo da devolução
            <Input
              aria-invalid={Boolean(returnForm.formState.errors.reason)}
              {...returnForm.register("reason")}
            />
            {returnForm.formState.errors.reason?.message ? (
              <span className="text-xs text-red-700">
                {returnForm.formState.errors.reason.message}
              </span>
            ) : null}
          </label>
          <div>
            <Button disabled={returnForm.formState.isSubmitting} type="submit">
              Registrar devolução
            </Button>
          </div>
        </form>
      ) : null}
      {sale.status === "COMPLETED" ? (
        <form
          className="grid gap-3 border-t pt-5 sm:grid-cols-[1fr_auto]"
          onSubmit={cancelForm.handleSubmit(cancel)}
        >
          <input type="hidden" {...cancelForm.register("expectedUpdatedAt")} />
          <label className="grid gap-1 text-sm font-medium">
            Motivo do cancelamento
            <Input
              aria-invalid={Boolean(cancelForm.formState.errors.reason)}
              {...cancelForm.register("reason")}
            />
            {cancelForm.formState.errors.reason?.message ? (
              <span className="text-xs text-red-700">
                {cancelForm.formState.errors.reason.message}
              </span>
            ) : null}
          </label>
          <div className="flex items-end">
            <Button
              disabled={cancelForm.formState.isSubmitting}
              type="submit"
              variant="destructive"
            >
              Cancelar venda
            </Button>
          </div>
        </form>
      ) : null}
      {sale.cancellationReason ? (
        <p className="text-sm text-red-700">Motivo: {sale.cancellationReason}</p>
      ) : null}
    </div>
  );
}
