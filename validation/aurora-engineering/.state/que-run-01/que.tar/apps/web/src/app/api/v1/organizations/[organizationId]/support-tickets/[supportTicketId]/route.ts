import { changeSupportTicketStatusBodySchema, supportTicketParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ organizationId: string; supportTicketId: string }> };
export async function PATCH(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = supportTicketParamsSchema.parse(await route.params);
    const body = changeSupportTicketStatusBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.customerCare.changeTicketStatus(
        { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}
