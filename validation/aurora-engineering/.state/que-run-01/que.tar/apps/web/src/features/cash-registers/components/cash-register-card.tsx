"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  cashOperationResultSchema,
  cashRegisterViewSchema,
  closeCashRegisterBodySchema,
  createCashOperationBodySchema,
  type CashRegisterView,
  type CloseCashRegisterBody,
  type CreateCashOperationBody,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import { formatBrl, formatDateTime, formatSignedBrl } from "./cash-register-money";
import { ErrorBox, Field, StatusBadge } from "./cash-register-ui";

export function CashRegisterCard({
  accountName,
  branchName,
  cashRegister,
  onUpdated,
  organizationId,
}: {
  accountName: string;
  branchName: string;
  cashRegister: CashRegisterView;
  onUpdated: (register: CashRegisterView, message: string) => void;
  organizationId: string;
}) {
  const [actionError, setActionError] = useState<string | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [operationKey, setOperationKey] = useState(() => crypto.randomUUID());
  const [reconcileKey, setReconcileKey] = useState(() => crypto.randomUUID());
  const [resumeKey, setResumeKey] = useState(() => crypto.randomUUID());
  const [closeKey, setCloseKey] = useState(() => crypto.randomUUID());
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateCashOperationBody>({
    defaultValues: {
      amount: "",
      expectedVersion: cashRegister.version,
      reason: "",
      type: "SUPPLY",
    },
    resolver: zodResolver(createCashOperationBodySchema),
  });
  const closeForm = useForm<CloseCashRegisterBody>({
    defaultValues: {
      countedAmount: cashRegister.expectedAmount ?? cashRegister.currentExpectedAmount,
      differenceReason: null,
      expectedVersion: cashRegister.version,
    },
    resolver: zodResolver(closeCashRegisterBodySchema),
  });
  const setCloseValue = closeForm.setValue;

  useEffect(() => {
    setValue("expectedVersion", cashRegister.version);
    setCloseValue("expectedVersion", cashRegister.version);
    if (cashRegister.status === "RECONCILING" && cashRegister.expectedAmount) {
      setCloseValue("countedAmount", cashRegister.expectedAmount);
    }
  }, [cashRegister, setCloseValue, setValue]);

  async function transition(action: "reconcile" | "resume") {
    setIsTransitioning(true);
    setActionError(null);

    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/cash-registers/${cashRegister.id}/${action}`,
        {
          body: JSON.stringify({ expectedVersion: cashRegister.version }),
          headers: {
            "content-type": "application/json",
            "idempotency-key": action === "reconcile" ? reconcileKey : resumeKey,
          },
          method: "POST",
        },
      );
      const updated = await readRegisterResponse(response);
      onUpdated(
        updated,
        action === "reconcile"
          ? "Conferência iniciada. Movimentações estão bloqueadas."
          : "Conferência cancelada. O caixa voltou a aceitar movimentações.",
      );
      if (action === "reconcile") {
        setReconcileKey(crypto.randomUUID());
      } else {
        setResumeKey(crypto.randomUUID());
      }
    } catch (error) {
      setActionError(
        error instanceof Error ? error.message : "Não foi possível atualizar o caixa.",
      );
    } finally {
      setIsTransitioning(false);
    }
  }

  const submitOperation = handleSubmit(async (values) => {
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/cash-registers/${cashRegister.id}/operations`,
        {
          body: JSON.stringify(values),
          headers: {
            "content-type": "application/json",
            "idempotency-key": operationKey,
          },
          method: "POST",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const result = cashOperationResultSchema.parse(payload.data);
      onUpdated(result.cashRegister, "Movimentação registrada no caixa e no saldo financeiro.");
      setOperationKey(crypto.randomUUID());
      reset({
        amount: "",
        expectedVersion: result.cashRegister.version,
        reason: "",
        type: values.type,
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  const submitClose = closeForm.handleSubmit(async (values) => {
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/cash-registers/${cashRegister.id}/close`,
        {
          body: JSON.stringify(values),
          headers: {
            "content-type": "application/json",
            "idempotency-key": closeKey,
          },
          method: "POST",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        closeForm.setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const closed = cashRegisterViewSchema.parse(payload.data);
      onUpdated(closed, "Caixa conferido e fechado.");
      setCloseKey(crypto.randomUUID());
    } catch {
      closeForm.setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <li className="rounded-2xl border bg-white p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-950">{accountName}</h3>
            <StatusBadge status={cashRegister.status} />
          </div>
          <p className="mt-1 text-xs text-slate-500">
            {branchName} · aberto em {formatDateTime(cashRegister.openedAt)}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-500">
            {cashRegister.status === "CLOSED" ? "Contado no fechamento" : "Esperado agora"}
          </p>
          <p className="mt-1 text-xl font-semibold text-slate-950">
            {formatBrl(cashRegister.currentExpectedAmount)}
          </p>
        </div>
      </div>

      {cashRegister.status === "OPEN" ? (
        <div className="mt-5 grid gap-5 border-t pt-5">
          <form className="grid gap-4" noValidate onSubmit={submitOperation}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                error={errors.type?.message}
                htmlFor={`cash-type-${cashRegister.id}`}
                label="Operação"
              >
                <select
                  className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
                  id={`cash-type-${cashRegister.id}`}
                  {...register("type")}
                >
                  <option value="SUPPLY">Suprimento</option>
                  <option value="BLEED">Sangria</option>
                  <option value="WITHDRAWAL">Retirada</option>
                </select>
              </Field>
              <Field
                error={errors.amount?.message}
                htmlFor={`cash-amount-${cashRegister.id}`}
                label="Valor"
              >
                <Input
                  className="h-11"
                  id={`cash-amount-${cashRegister.id}`}
                  inputMode="decimal"
                  {...register("amount")}
                />
              </Field>
            </div>
            <Field
              error={errors.reason?.message}
              htmlFor={`cash-reason-${cashRegister.id}`}
              label="Motivo"
            >
              <Input
                className="h-11"
                id={`cash-reason-${cashRegister.id}`}
                placeholder="Ex.: Troco adicional"
                {...register("reason")}
              />
            </Field>
            {errors.root?.message ? <ErrorBox>{errors.root.message}</ErrorBox> : null}
            <div className="flex flex-wrap gap-2">
              <Button className="min-h-11" disabled={isSubmitting} size="sm" type="submit">
                {isSubmitting ? "Registrando..." : "Registrar movimento"}
              </Button>
              <Button
                disabled={isTransitioning}
                className="min-h-11"
                onClick={() => void transition("reconcile")}
                size="sm"
                type="button"
                variant="outline"
              >
                {isTransitioning ? "Preparando..." : "Conferir e fechar"}
              </Button>
            </div>
          </form>
        </div>
      ) : null}

      {cashRegister.status === "RECONCILING" ? (
        <form className="mt-5 grid gap-4 border-t pt-5" noValidate onSubmit={submitClose}>
          <p className="text-xs leading-5 text-slate-600">
            Movimentações bloqueadas. Esperado na conferência:{" "}
            <strong>{formatBrl(cashRegister.expectedAmount ?? "0")}</strong>.
          </p>
          <Field
            error={closeForm.formState.errors.countedAmount?.message}
            htmlFor={`cash-counted-${cashRegister.id}`}
            label="Valor contado"
          >
            <Input
              className="h-11"
              id={`cash-counted-${cashRegister.id}`}
              inputMode="decimal"
              {...closeForm.register("countedAmount")}
            />
          </Field>
          <Field
            error={closeForm.formState.errors.differenceReason?.message}
            htmlFor={`cash-difference-${cashRegister.id}`}
            label="Motivo da diferença, se houver"
          >
            <Input
              className="h-11"
              id={`cash-difference-${cashRegister.id}`}
              placeholder="Ex.: Falta conferida"
              {...closeForm.register("differenceReason")}
            />
          </Field>
          {closeForm.formState.errors.root?.message ? (
            <ErrorBox>{closeForm.formState.errors.root.message}</ErrorBox>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <Button
              className="min-h-11"
              disabled={closeForm.formState.isSubmitting}
              size="sm"
              type="submit"
            >
              {closeForm.formState.isSubmitting ? "Fechando..." : "Confirmar fechamento"}
            </Button>
            <Button
              disabled={isTransitioning}
              className="min-h-11"
              onClick={() => void transition("resume")}
              size="sm"
              type="button"
              variant="outline"
            >
              Voltar a movimentar
            </Button>
          </div>
        </form>
      ) : null}

      {cashRegister.status === "CLOSED" ? (
        <div className="mt-5 grid gap-2 border-t pt-5 text-xs text-slate-600">
          <p>Esperado: {formatBrl(cashRegister.expectedAmount ?? "0")}</p>
          <p>Diferença: {formatSignedBrl(cashRegister.differenceAmount ?? "0")}</p>
          {cashRegister.differenceReason ? <p>Motivo: {cashRegister.differenceReason}</p> : null}
          <p>Fechado em {cashRegister.closedAt ? formatDateTime(cashRegister.closedAt) : "—"}</p>
        </div>
      ) : null}
      {actionError ? (
        <div className="mt-4">
          <ErrorBox>{actionError}</ErrorBox>
        </div>
      ) : null}
    </li>
  );
}

export async function readRegisterResponse(response: Response): Promise<CashRegisterView> {
  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }
  const payload = (await response.json()) as { data: unknown };
  return cashRegisterViewSchema.parse(payload.data);
}
