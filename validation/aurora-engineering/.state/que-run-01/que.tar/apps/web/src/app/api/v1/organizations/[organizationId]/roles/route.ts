import { createOrganizationRoleBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

async function context(
  request: Request,
  organizationId: string,
  api: { correlationId: string; requestId: string },
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({ ...api, organizationId, userId: identity.userId });
}

export async function GET(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    const actor = await context(request, organizationId, api);
    const [permissions, roles] = await Promise.all([
      services.manageOrganizationUsers.listPermissions(organizationId, actor),
      services.manageOrganizationUsers.listRoles(organizationId, actor),
    ]);
    return Response.json({ permissions, roles });
  });
}

export async function POST(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const { organizationId } = organizationParamsSchema.parse(await route.params);
    const body = createOrganizationRoleBodySchema.parse(await readJsonBody(request));
    const role = await services.manageOrganizationUsers.createRole(
      { ...body, idempotencyKey: requireIdempotencyKey(request), organizationId },
      await context(request, organizationId, api),
    );
    return Response.json({ data: role }, { status: 201 });
  });
}
