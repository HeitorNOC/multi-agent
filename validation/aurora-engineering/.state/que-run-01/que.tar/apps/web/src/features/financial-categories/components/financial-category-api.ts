import {
  financialCategoryListSchema,
  financialCategoryViewSchema,
  type CreateFinancialCategoryBody,
  type FinancialCategoryView,
  type ProblemDetails,
} from "@gestor/contracts";

export async function loadFinancialCategories(organizationId: string, signal: AbortSignal) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/financial-categories`, {
    signal,
  });
  if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
  const payload = (await response.json()) as { data: unknown };
  return financialCategoryListSchema.parse(payload.data);
}

export async function createFinancialCategory(
  organizationId: string,
  values: CreateFinancialCategoryBody,
  idempotencyKey: string,
) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/financial-categories`, {
    body: JSON.stringify(values),
    headers: { "content-type": "application/json", "idempotency-key": idempotencyKey },
    method: "POST",
  });
  if (!response.ok) {
    return { data: null, problem: (await response.json()) as ProblemDetails } as const;
  }
  const payload = (await response.json()) as { data: unknown };
  return { data: financialCategoryViewSchema.parse(payload.data), problem: null } as const;
}

export async function toggleFinancialCategoryStatus(
  organizationId: string,
  category: FinancialCategoryView,
) {
  const status = category.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/financial-categories/${category.id}`,
    {
      body: JSON.stringify({ status }),
      headers: { "content-type": "application/json" },
      method: "PATCH",
    },
  );
  if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
  const payload = (await response.json()) as { data: unknown };
  return { status, updated: financialCategoryViewSchema.parse(payload.data) };
}
