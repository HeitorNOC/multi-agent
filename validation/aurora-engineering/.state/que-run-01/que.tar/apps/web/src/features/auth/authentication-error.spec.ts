import { describe, expect, it } from "vitest";

import { getAuthenticationErrorMessage } from "./authentication-error";

describe("getAuthenticationErrorMessage", () => {
  it("translates safe known errors", () => {
    expect(
      getAuthenticationErrorMessage({ code: "INVALID_EMAIL_OR_PASSWORD", status: 401 }, "fallback"),
    ).toBe("E-mail ou senha incorretos.");
  });

  it("does not expose unknown server messages", () => {
    expect(
      getAuthenticationErrorMessage(
        { code: "DATABASE_ERROR", message: "connection details", status: 500 },
        "Não foi possível entrar.",
      ),
    ).toBe("Não foi possível entrar.");
  });

  it("gives a clear rate-limit instruction", () => {
    expect(getAuthenticationErrorMessage({ status: 429 }, "fallback")).toContain(
      "Aguarde um minuto",
    );
  });
});
