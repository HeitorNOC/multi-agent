"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createPaymentMethodConfigurationBodySchema,
  paymentMethodConfigurationListSchema,
  paymentMethodConfigurationViewSchema,
  type CreatePaymentMethodConfigurationBody,
  type PaymentMethodConfigurationView,
  type PaymentMethodType,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

const methodLabels: Record<PaymentMethodType, string> = {
  BANK_TRANSFER: "Transferência bancária",
  BOLETO: "Boleto",
  CARD: "Cartão",
  CASH: "Dinheiro",
  OTHER: "Outro",
  PAYMENT_LINK: "Link de pagamento",
  PIX: "Pix",
};

const methodOptions = Object.entries(methodLabels) as [PaymentMethodType, string][];

type PaymentMethodConfigurationsProps = {
  organizationId: string;
};

export function PaymentMethodConfigurations({ organizationId }: PaymentMethodConfigurationsProps) {
  const [configurations, setConfigurations] = useState<
    readonly PaymentMethodConfigurationView[] | null
  >(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyConfiguration, setBusyConfiguration] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreatePaymentMethodConfigurationBody>({
    defaultValues: {
      allowsPayments: true,
      allowsReceipts: true,
      method: "PIX",
      name: "",
    },
    resolver: zodResolver(createPaymentMethodConfigurationBodySchema),
  });

  useEffect(() => {
    const controller = new AbortController();

    async function loadConfigurations() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/payment-methods`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const payload = (await response.json()) as { data: unknown };
        setConfigurations(paymentMethodConfigurationListSchema.parse(payload.data));
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar as formas de pagamento.",
          );
        }
      }
    }

    void loadConfigurations();

    return () => controller.abort();
  }, [organizationId, reloadVersion]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/payment-methods`, {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": idempotencyKey,
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const created = paymentMethodConfigurationViewSchema.parse(payload.data);
      setConfigurations((current) =>
        current
          ? [...current, created].sort((left, right) => left.name.localeCompare(right.name))
          : [created],
      );
      setIdempotencyKey(crypto.randomUUID());
      setFeedback("Forma de pagamento criada. A etapa do onboarding foi atualizada.");
      reset({
        allowsPayments: true,
        allowsReceipts: true,
        method: "PIX",
        name: "",
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function changeStatus(configuration: PaymentMethodConfigurationView) {
    setBusyConfiguration(configuration.id);
    setFeedback(null);

    try {
      const nextStatus = configuration.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/payment-methods/${configuration.id}`,
        {
          body: JSON.stringify({ status: nextStatus }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        throw new Error(problem.detail);
      }

      const payload = (await response.json()) as { data: unknown };
      const updated = paymentMethodConfigurationViewSchema.parse(payload.data);
      setConfigurations(
        (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [updated],
      );
      setFeedback(
        nextStatus === "ACTIVE" ? "Forma de pagamento ativada." : "Forma de pagamento desativada.",
      );
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível alterar a forma de pagamento.",
      );
    } finally {
      setBusyConfiguration(null);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section
        aria-labelledby="new-payment-method-title"
        className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7"
      >
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Nova configuração
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="new-payment-method-title">
          Adicionar forma de pagamento
        </h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          Isso define uma opção operacional. Nenhum valor entra ou sai do caixa nesta tela.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="payment-method-name">Nome exibido</Label>
            <Input
              aria-describedby={errors.name ? "payment-method-name-error" : undefined}
              aria-invalid={Boolean(errors.name)}
              id="payment-method-name"
              placeholder="Ex.: Cartão de débito"
              {...register("name")}
            />
            {errors.name ? (
              <p className="text-sm text-red-700" id="payment-method-name-error" role="alert">
                {errors.name.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="payment-method-type">Tipo</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="payment-method-type"
              {...register("method")}
            >
              {methodOptions.map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <fieldset className="grid gap-3">
            <legend className="text-sm font-medium text-slate-800">Disponível para</legend>
            <label className="flex items-center gap-3 text-sm text-slate-700">
              <input
                className="text-brand-600 size-4 rounded border-slate-300"
                type="checkbox"
                {...register("allowsReceipts")}
              />
              Recebimentos de clientes
            </label>
            <label className="flex items-center gap-3 text-sm text-slate-700">
              <input
                className="text-brand-600 size-4 rounded border-slate-300"
                type="checkbox"
                {...register("allowsPayments")}
              />
              Pagamentos a fornecedores e despesas
            </label>
            {errors.allowsReceipts ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.allowsReceipts.message}
              </p>
            ) : null}
          </fieldset>

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button disabled={isSubmitting} type="submit">
            {isSubmitting ? "Salvando..." : "Adicionar forma"}
          </Button>
        </form>
      </section>

      <section aria-labelledby="payment-method-list-title" className="grid content-start gap-4">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
            Configuradas
          </p>
          <h2 className="mt-2 text-xl font-semibold text-slate-950" id="payment-method-list-title">
            Formas de pagamento
          </h2>
        </div>

        {feedback ? (
          <div
            className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700"
            role="status"
          >
            {feedback}
          </div>
        ) : null}

        {!configurations ? (
          <div className="grid gap-3 rounded-2xl border bg-white p-5">
            <p className="text-sm text-slate-600">
              {loadError ?? "Carregando formas de pagamento..."}
            </p>
            {loadError ? (
              <div>
                <Button
                  onClick={() => {
                    setLoadError(null);
                    setReloadVersion((version) => version + 1);
                  }}
                  size="sm"
                  variant="outline"
                >
                  Tentar novamente
                </Button>
              </div>
            ) : null}
          </div>
        ) : configurations.length === 0 ? (
          <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
            Nenhuma forma configurada. Adicione a primeira para concluir esta etapa essencial.
          </div>
        ) : (
          <ul className="grid gap-3">
            {configurations.map((configuration) => (
              <li className="rounded-2xl border bg-white p-5" key={configuration.id}>
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-semibold text-slate-950">{configuration.name}</h3>
                      <span
                        className={
                          configuration.status === "ACTIVE"
                            ? "rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-semibold text-emerald-800"
                            : "rounded-full bg-slate-200 px-2 py-0.5 text-xs font-semibold text-slate-700"
                        }
                      >
                        {configuration.status === "ACTIVE" ? "Ativa" : "Inativa"}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      {methodLabels[configuration.method]} ·{" "}
                      {configuration.allowsReceipts && configuration.allowsPayments
                        ? "Recebimentos e pagamentos"
                        : configuration.allowsReceipts
                          ? "Somente recebimentos"
                          : "Somente pagamentos"}
                    </p>
                  </div>
                  <Button
                    disabled={busyConfiguration === configuration.id}
                    onClick={() => void changeStatus(configuration)}
                    size="sm"
                    variant="outline"
                  >
                    {busyConfiguration === configuration.id
                      ? "Salvando..."
                      : configuration.status === "ACTIVE"
                        ? "Desativar"
                        : "Ativar"}
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
