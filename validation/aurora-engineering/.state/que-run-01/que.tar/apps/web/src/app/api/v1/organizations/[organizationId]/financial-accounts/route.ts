import { createFinancialAccountBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForFinancialMutation } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
  }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const accounts = await services.listFinancialAccounts.execute(params, actor);

    return Response.json({ data: accounts });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createFinancialAccountBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForFinancialMutation(identity, actor, "financial_account.manage");
    const account = await services.createFinancialAccount.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );

    return Response.json(
      { data: account },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/financial-accounts/${account.id}`,
        },
        status: 201,
      },
    );
  });
}
