import { foodServiceSettingsBodySchema, organizationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };
async function actorFor(
  request: Request,
  route: RouteParameters,
  correlationId: string,
  requestId: string,
) {
  const params = organizationParamsSchema.parse(await route.params);
  const identity = await authenticateApiRequest(request);
  return {
    actor: await services.resolveTenantActor.execute({
      correlationId,
      organizationId: params.organizationId,
      requestId,
      userId: identity.userId,
    }),
    params,
  };
}
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { actor, params } = await actorFor(request, route, api.correlationId, api.requestId);
    return Response.json({ data: await services.getFoodServiceSettings.execute(params, actor) });
  });
}
export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { actor, params } = await actorFor(request, route, api.correlationId, api.requestId);
    const body = foodServiceSettingsBodySchema.parse(await readJsonBody(request));
    requireIdempotencyKey(request);
    return Response.json({
      data: await services.updateFoodServiceSettings.execute({ ...body, ...params }, actor),
    });
  });
}
