import { customerParamsSchema, updateCustomerTagsBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ customerId: string; organizationId: string }>;
};

export async function PUT(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = customerParamsSchema.parse(await route.params);
    const body = updateCustomerTagsBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const customer = await services.updateCustomerTags.execute(
      {
        ...body,
        customerId: params.customerId,
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json({ data: customer });
  });
}
