import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, countInventory, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  countInventory: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    countInventory: { execute: countInventory },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const branchId = "30000000-0000-4000-8000-000000000002";
const productId = "30000000-0000-4000-8000-000000000003";
const route = { params: Promise.resolve({ branchId, organizationId }) };

describe("inventory count route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "MANAGER" });
    countInventory.mockReset().mockResolvedValue({ balance: {}, movement: {} });
  });

  it("forwards the counted quantity and expected version", async () => {
    const body = {
      countedQuantity: "8.5",
      expectedVersion: 4,
      productId,
      reason: "Contagem mensal",
    };
    const request = new Request("http://localhost/inventory", {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": "count-key" },
      method: "POST",
    });
    const response = await POST(request, route);

    expect(response.status).toBe(200);
    expect(countInventory).toHaveBeenCalledWith(
      { ...body, branchId, idempotencyKey: "count-key", organizationId },
      { role: "MANAGER" },
    );
  });
});
