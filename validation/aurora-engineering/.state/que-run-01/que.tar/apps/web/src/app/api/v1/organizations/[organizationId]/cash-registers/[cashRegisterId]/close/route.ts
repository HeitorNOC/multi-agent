import { cashRegisterParamsSchema, closeCashRegisterBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForFinancialMutation } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{ cashRegisterId: string; organizationId: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = cashRegisterParamsSchema.parse(await route.params);
    const body = closeCashRegisterBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForFinancialMutation(identity, actor, "cash_register.manage");
    const register = await services.closeCashRegister.execute(
      {
        ...body,
        cashRegisterId: params.cashRegisterId,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json({ data: register });
  });
}
