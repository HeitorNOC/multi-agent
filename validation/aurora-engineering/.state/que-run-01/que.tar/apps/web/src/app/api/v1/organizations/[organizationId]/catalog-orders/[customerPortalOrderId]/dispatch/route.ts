import { dispatchCustomerPortalOrderBodySchema, organizationParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ customerPortalOrderId: string; organizationId: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const routeParams = await route.params;
    const params = organizationParamsSchema.parse(routeParams);
    const body = dispatchCustomerPortalOrderBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.dispatchCustomerPortalOrder.execute(
        {
          ...body,
          orderId: routeParams.customerPortalOrderId,
          organizationId: params.organizationId,
        },
        actor,
      ),
    });
  });
}
