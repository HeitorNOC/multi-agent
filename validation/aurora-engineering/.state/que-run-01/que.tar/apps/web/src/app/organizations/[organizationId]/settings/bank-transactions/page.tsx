import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { BankStatementManager } from "@/features/bank-transactions/components/bank-statement-manager";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Extratos bancários | Gestor",
};

type BankTransactionsPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function BankTransactionsPage({ params }: BankTransactionsPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">Bancos</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Importar extrato bancário
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Importe CSV ou OFX para preparar a conciliação. Os lançamentos importados não alteram
          caixa, saldo financeiro, receitas ou despesas.
        </p>
      </header>

      <ModuleGate moduleCode="banking" organizationId={organizationId}>
        <BankStatementManager organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
