import type { FinancialAccountView, PaymentMethodConfigurationView } from "@gestor/contracts";

/**
 * Mirrors the financial invariant enforced by direct-sale-payment: the UI must
 * only offer destinations that the server can accept for a payment method.
 */
export function accountTypeForPayment(
  method: PaymentMethodConfigurationView["method"],
): FinancialAccountView["type"] {
  if (method === "CASH") return "CASH";
  if (method === "CARD" || method === "PAYMENT_LINK") return "ACQUIRER";
  return "BANK";
}

export function compatiblePaymentAccounts({
  branchId,
  financialAccounts,
  paymentMethodConfigurationId,
  paymentMethods,
}: {
  branchId: string;
  financialAccounts: readonly FinancialAccountView[];
  paymentMethodConfigurationId: string;
  paymentMethods: readonly PaymentMethodConfigurationView[];
}) {
  const paymentMethod = paymentMethods.find(({ id }) => id === paymentMethodConfigurationId);
  if (!paymentMethod) return [];
  const requiredType = accountTypeForPayment(paymentMethod.method);
  return financialAccounts.filter(
    (account) =>
      account.type === requiredType && (!account.branchId || account.branchId === branchId),
  );
}
