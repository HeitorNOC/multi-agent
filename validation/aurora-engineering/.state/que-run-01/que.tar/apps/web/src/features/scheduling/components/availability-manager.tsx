"use client";

import {
  appointmentResourceViewSchema,
  availabilityRuleViewSchema,
  schedulingProfessionalListSchema,
  type AppointmentResourceView,
  type AvailabilityRuleView,
  type BranchView,
  type ProblemDetails,
  type SchedulingProfessionalView,
} from "@gestor/contracts";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";

import { AvailabilityForms, AvailabilityRuleList } from "./availability-manager-parts";
type AvailabilityManagerProps = { branches: readonly BranchView[]; organizationId: string };

export function AvailabilityManager({ branches, organizationId }: AvailabilityManagerProps) {
  const [rules, setRules] = useState<readonly AvailabilityRuleView[] | null>(null);
  const [resources, setResources] = useState<readonly AppointmentResourceView[]>([]);
  const [professionals, setProfessionals] = useState<readonly SchedulingProfessionalView[]>([]);
  const [branchId, setBranchId] = useState("");
  const [targetType, setTargetType] = useState<"professional" | "resource">("professional");
  const [targetId, setTargetId] = useState("");
  const [dayOfWeek, setDayOfWeek] = useState("1");
  const [startsAt, setStartsAt] = useState("09:00");
  const [endsAt, setEndsAt] = useState("18:00");
  const [resourceName, setResourceName] = useState("");
  const [editingRule, setEditingRule] = useState<AvailabilityRuleView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const activeBranches = useMemo(
    () => branches.filter((branch) => branch.status === "ACTIVE"),
    [branches],
  );
  const selectedBranchId = branchId || activeBranches[0]?.id || "";

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const query = selectedBranchId ? `?branchId=${encodeURIComponent(selectedBranchId)}` : "";
        const [rulesResponse, resourcesResponse, professionalsResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/availability-rules${query}`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/appointment-resources${query}`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/scheduling-professionals`, {
            signal: controller.signal,
          }),
        ]);
        const failed = [rulesResponse, resourcesResponse, professionalsResponse].find(
          (response) => !response.ok,
        );
        if (failed) throw new Error(((await failed.json()) as ProblemDetails).detail);
        const [rulesPayload, resourcesPayload, professionalsPayload] = await Promise.all([
          rulesResponse.json(),
          resourcesResponse.json(),
          professionalsResponse.json(),
        ]);
        setRules(parseList((rulesPayload as { data: unknown }).data, availabilityRuleViewSchema));
        setResources(
          parseList((resourcesPayload as { data: unknown }).data, appointmentResourceViewSchema),
        );
        setProfessionals(
          schedulingProfessionalListSchema.parse((professionalsPayload as { data: unknown }).data),
        );
        setError(null);
      } catch (cause) {
        if (!controller.signal.aborted)
          setError(
            cause instanceof Error
              ? cause.message
              : "Não foi possível carregar as configurações da agenda.",
          );
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId, selectedBranchId]);

  async function createResource(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedBranchId) {
      setError("Selecione uma filial para cadastrar o recurso.");
      return;
    }
    const name = resourceName.trim();
    if (name.length < 2) {
      setError("Informe o nome do recurso com pelo menos 2 caracteres.");
      return;
    }
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/appointment-resources`,
        {
          body: JSON.stringify({ branchId: selectedBranchId, name }),
          headers: { "content-type": "application/json" },
          method: "POST",
        },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      setResources((current) =>
        [...current, appointmentResourceViewSchema.parse(payload.data)].sort((a, b) =>
          a.name.localeCompare(b.name, "pt-BR"),
        ),
      );
      setResourceName("");
      setNotice("Recurso criado com sucesso.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Não foi possível criar o recurso.");
    } finally {
      setSaving(false);
    }
  }

  async function createRule(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedBranchId || !targetId) {
      setError("Selecione a filial e o profissional ou recurso.");
      return;
    }
    const startsAtMinute = timeToMinutes(startsAt);
    const endsAtMinute = timeToMinutes(endsAt);
    if (endsAtMinute <= startsAtMinute) {
      setError("O fim deve ser posterior ao início.");
      return;
    }
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const body = {
        branchId: selectedBranchId,
        dayOfWeek: Number(dayOfWeek),
        endsAtMinute,
        startsAtMinute,
        ...(targetType === "professional"
          ? { professionalUserId: targetId }
          : { resourceId: targetId }),
      };
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/availability-rules${editingRule ? `/${editingRule.id}` : ""}`,
        {
          body: JSON.stringify(
            editingRule ? { ...body, expectedUpdatedAt: editingRule.updatedAt } : body,
          ),
          headers: { "content-type": "application/json" },
          method: editingRule ? "PATCH" : "POST",
        },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      const saved = availabilityRuleViewSchema.parse(payload.data);
      setRules((current) =>
        editingRule
          ? (current ?? []).map((item) => (item.id === saved.id ? saved : item))
          : [...(current ?? []), saved],
      );
      setEditingRule(null);
      setNotice(
        editingRule
          ? "Horário de disponibilidade atualizado."
          : "Horário de disponibilidade salvo.",
      );
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Não foi possível salvar a disponibilidade.",
      );
    } finally {
      setSaving(false);
    }
  }

  async function removeRule(rule: AvailabilityRuleView) {
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/availability-rules/${rule.id}`,
        { method: "DELETE" },
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      setRules((current) => current?.filter((item) => item.id !== rule.id) ?? []);
      setNotice("Horário removido.");
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Não foi possível remover a disponibilidade.",
      );
    } finally {
      setSaving(false);
    }
  }

  const targetOptions = targetType === "professional" ? professionals : resources;
  return (
    <section
      aria-labelledby="availability-title"
      className="grid gap-5 rounded-2xl border bg-white p-5"
    >
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Configuração</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="availability-title">
          Disponibilidade e recursos
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Cadastre salas, equipamentos e horários de atendimento por filial.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1.5">
          <Label htmlFor="availability-branch">Filial</Label>
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="availability-branch"
            onChange={(event) => {
              setBranchId(event.target.value);
              setTargetId("");
            }}
            value={selectedBranchId}
          >
            <option value="">Selecione uma filial</option>
            {activeBranches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {error ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"
          role="alert"
        >
          {error}
        </p>
      ) : null}
      {notice ? (
        <p
          className="border-brand-100 bg-brand-50 text-brand-700 rounded-xl border p-3 text-sm"
          role="status"
        >
          {notice}
        </p>
      ) : null}
      <AvailabilityForms
        branchId={selectedBranchId}
        dayOfWeek={dayOfWeek}
        editingRule={editingRule}
        endsAt={endsAt}
        onCancelEdit={() => setEditingRule(null)}
        onCreateResource={createResource}
        onCreateRule={createRule}
        onResourceNameChange={setResourceName}
        onTargetIdChange={setTargetId}
        onTargetTypeChange={(value) => {
          setTargetType(value);
          setTargetId("");
        }}
        onDayOfWeekChange={setDayOfWeek}
        onStartsAtChange={setStartsAt}
        onEndsAtChange={setEndsAt}
        resourceName={resourceName}
        resources={resources}
        saving={saving}
        startsAt={startsAt}
        targetId={targetId}
        targetOptions={targetOptions}
        targetType={targetType}
      />
      <AvailabilityRuleList
        onEdit={(rule) => {
          setEditingRule(rule);
          setTargetType(rule.professionalUserId ? "professional" : "resource");
          setTargetId(rule.professionalUserId ?? rule.resourceId ?? "");
          setDayOfWeek(String(rule.dayOfWeek));
          setStartsAt(minutesToTime(rule.startsAtMinute));
          setEndsAt(minutesToTime(rule.endsAtMinute));
        }}
        onRemove={removeRule}
        rules={rules}
        saving={saving}
      />
    </section>
  );
}
function parseList<T>(value: unknown, schema: { parse(value: unknown): T }): readonly T[] {
  if (!Array.isArray(value)) throw new Error("A resposta da agenda é inválida.");
  return value.map((item) => schema.parse(item));
}
function timeToMinutes(value: string): number {
  const [hours = 0, minutes = 0] = value.split(":").map(Number);
  return hours * 60 + minutes;
}
function minutesToTime(value: number): string {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}
