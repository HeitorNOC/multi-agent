import { reportParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ organizationId: string; reportId: string }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = reportParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.createReportDownload.execute(params, actor),
    });
  });
}
