import { safeReturnTo } from "./return-to";

export function getGoogleAuthNavigation(
  origin: string,
  errorPath: "/cadastro" | "/login",
  returnTo?: string,
) {
  const destination = safeReturnTo(returnTo);
  const errorCallback = new URL(errorPath, origin);
  errorCallback.searchParams.set("oauthError", "1");
  if (destination) errorCallback.searchParams.set("returnTo", destination);

  return {
    callbackURL: destination ?? "/",
    errorCallbackURL: errorCallback.toString(),
    newUserCallbackURL: destination ?? "/onboarding",
  };
}
