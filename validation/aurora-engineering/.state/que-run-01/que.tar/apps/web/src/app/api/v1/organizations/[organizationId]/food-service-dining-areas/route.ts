import {
  createFoodServiceDiningAreaBodySchema,
  foodServiceListQuerySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type RouteParameters = { params: Promise<{ organizationId: string }> };
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = foodServiceListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams.entries()),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.listFoodServiceDiningAreas.execute(
        { ...params, ...(query.branchId ? { branchId: query.branchId } : {}) },
        actor,
      ),
    });
  });
}
export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createFoodServiceDiningAreaBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json(
      { data: await services.createFoodServiceDiningArea.execute({ ...body, ...params }, actor) },
      { status: 201 },
    );
  });
}
