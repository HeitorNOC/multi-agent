import { inventoryBranchParamsSchema } from "@gestor/contracts";
import { z } from "zod";
import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type RouteParameters={params:Promise<{branchId:string;organizationId:string}>};
export async function GET(request:Request,route:RouteParameters):Promise<Response>{return handleApiRequest(request,async(api)=>{const params=inventoryBranchParamsSchema.parse(await route.params);const limit=z.coerce.number().int().min(1).max(100).default(30).parse(new URL(request.url).searchParams.get("limit")??undefined);const identity=await authenticateApiRequest(request);const actor=await services.resolveTenantActor.execute({correlationId:api.correlationId,organizationId:params.organizationId,requestId:api.requestId,userId:identity.userId});return Response.json({data:await services.listStockMovements.execute({...params,limit},actor)});});}
