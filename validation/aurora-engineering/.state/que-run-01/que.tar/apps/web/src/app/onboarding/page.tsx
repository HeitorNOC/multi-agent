import type { Metadata } from "next";
import Link from "next/link";

import { OrganizationOnboardingForm } from "@/features/onboarding/components/organization-onboarding-form";

export const metadata: Metadata = {
  title: "Configurar empresa | Gestor",
};

export default function OnboardingPage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <header className="border-b bg-white">
        <div className="mx-auto flex w-full max-w-5xl items-center justify-between px-5 py-4 sm:px-8">
          <Link className="inline-flex items-center gap-3" href="/">
            <span className="bg-brand-600 grid size-9 place-items-center rounded-xl text-sm font-black text-white">
              G
            </span>
            <span className="font-semibold text-slate-950">Gestor</span>
          </Link>
          <p className="text-xs font-medium text-slate-500">Configuração inicial</p>
        </div>
      </header>

      <div className="mx-auto grid w-full max-w-5xl gap-8 px-5 py-10 sm:px-8 sm:py-14 lg:grid-cols-[16rem_minmax(0,1fr)]">
        <aside className="h-fit rounded-2xl border bg-white p-5 lg:sticky lg:top-8">
          <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
            Primeiro acesso
          </p>
          <h1 className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">
            Conte sobre sua empresa
          </h1>
          <p className="mt-3 text-sm leading-6 text-slate-600">
            São apenas os dados necessários para criar seu espaço de trabalho com segurança.
          </p>
          <ol className="mt-6 grid gap-3 text-sm text-slate-600">
            <li className="flex gap-3">
              <span className="bg-brand-100 text-brand-700 grid size-6 shrink-0 place-items-center rounded-full text-xs font-bold">
                1
              </span>
              Empresa
            </li>
            <li className="flex gap-3">
              <span className="bg-brand-100 text-brand-700 grid size-6 shrink-0 place-items-center rounded-full text-xs font-bold">
                2
              </span>
              Segmento
            </li>
            <li className="flex gap-3">
              <span className="bg-brand-100 text-brand-700 grid size-6 shrink-0 place-items-center rounded-full text-xs font-bold">
                3
              </span>
              Primeira filial
            </li>
          </ol>
        </aside>

        <section className="rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-9">
          <OrganizationOnboardingForm />
        </section>
      </div>
    </main>
  );
}
