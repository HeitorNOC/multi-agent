import { describe, expect, it } from "vitest";

import { formatCatalogItemCount, formatCatalogQuantity } from "./catalog-presentation";

describe("catalog presentation", () => {
  it("removes database-only trailing decimal places from quantities", () => {
    expect(formatCatalogQuantity("1.0000")).toBe("1");
    expect(formatCatalogQuantity("1.2500")).toBe("1,25");
  });

  it("limits displayed fractional quantities to useful precision", () => {
    expect(formatCatalogQuantity("1.2345")).toBe("1,235");
  });

  it("uses the correct singular and plural item labels", () => {
    expect(formatCatalogItemCount(1)).toBe("1 item");
    expect(formatCatalogItemCount(2)).toBe("2 itens");
  });
});
