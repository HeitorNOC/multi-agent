import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, getReport, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  getReport: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));

vi.mock("@/lib/server/container", () => ({
  services: {
    getReport: { execute: getReport },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const reportId = "30000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ organizationId, reportId }) };

describe("get report route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    getReport.mockReset().mockResolvedValue({ id: reportId, status: "PENDING" });
  });

  it("returns the authorized report job", async () => {
    const response = await GET(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/reports/${reportId}`),
      route,
    );

    expect(response.status).toBe(200);
    expect(await response.json()).toEqual({ data: { id: reportId, status: "PENDING" } });
    expect(getReport).toHaveBeenCalledWith({ organizationId, reportId }, { role: "OWNER" });
  });
});
