import {
  catalogCustomFieldDefinitionListSchema,
  catalogCustomFieldDefinitionViewSchema,
  catalogCustomFieldValueListSchema,
  customerCustomFieldDefinitionListSchema,
  customerCustomFieldDefinitionViewSchema,
  customerCustomFieldValueListSchema,
  customerListSchema,
  customerViewSchema,
  productListSchema,
  productViewSchema,
  serviceListSchema,
  serviceViewSchema,
  supplierCustomFieldDefinitionListSchema,
  supplierCustomFieldDefinitionViewSchema,
  supplierCustomFieldValueListSchema,
  supplierListSchema,
  supplierViewSchema,
  type CustomerCustomFieldDefinitionView,
  type CustomerView,
} from "@gestor/contracts";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import type { UseFormRegister } from "react-hook-form";

export type CustomFieldEntity = "CUSTOMER" | "SUPPLIER" | "PRODUCT" | "SERVICE";
export type CustomFieldEntityView = Pick<CustomerView, "id" | "name" | "updatedAt">;
export type CustomFieldValueForm = { fields: Record<string, boolean | number | string> };

export const customFieldEntityConfig = {
  CUSTOMER: { label: "cliente", labelPlural: "clientes", segment: "customers" },
  PRODUCT: { label: "produto", labelPlural: "produtos", segment: "products" },
  SERVICE: { label: "serviço", labelPlural: "serviços", segment: "services" },
  SUPPLIER: { label: "fornecedor", labelPlural: "fornecedores", segment: "suppliers" },
} as const;

export function parseEntityList(
  entity: CustomFieldEntity,
  value: unknown,
): readonly CustomFieldEntityView[] {
  if (entity === "CUSTOMER") return customerListSchema.parse(value);
  if (entity === "SUPPLIER") return supplierListSchema.parse(value);
  if (entity === "PRODUCT") return productListSchema.parse(value);
  return serviceListSchema.parse(value);
}

export function parseEntity(entity: CustomFieldEntity, value: unknown): CustomFieldEntityView {
  if (entity === "CUSTOMER") return customerViewSchema.parse(value);
  if (entity === "SUPPLIER") return supplierViewSchema.parse(value);
  if (entity === "PRODUCT") return productViewSchema.parse(value);
  return serviceViewSchema.parse(value);
}

export function parseDefinitionList(entity: CustomFieldEntity, value: unknown) {
  if (entity === "CUSTOMER") return customerCustomFieldDefinitionListSchema.parse(value);
  if (entity === "SUPPLIER") return supplierCustomFieldDefinitionListSchema.parse(value);
  return catalogCustomFieldDefinitionListSchema.parse(value);
}

export function parseDefinition(entity: CustomFieldEntity, value: unknown) {
  if (entity === "CUSTOMER") return customerCustomFieldDefinitionViewSchema.parse(value);
  if (entity === "SUPPLIER") return supplierCustomFieldDefinitionViewSchema.parse(value);
  return catalogCustomFieldDefinitionViewSchema.parse(value);
}

export function parseValues(entity: CustomFieldEntity, value: unknown) {
  if (entity === "CUSTOMER") return customerCustomFieldValueListSchema.parse(value);
  if (entity === "SUPPLIER") return supplierCustomFieldValueListSchema.parse(value);
  return catalogCustomFieldValueListSchema.parse(value);
}

export function CustomValueInput({
  definition,
  register,
}: {
  definition: CustomerCustomFieldDefinitionView;
  register: UseFormRegister<CustomFieldValueForm>;
}) {
  const name = `fields.${definition.id}` as const;
  return (
    <FormField
      id={`custom-value-${definition.id}`}
      label={`${definition.label}${definition.required ? " *" : ""}`}
    >
      {definition.fieldType === "BOOLEAN" ? (
        <select
          className="h-10 rounded-xl border bg-white px-3 text-sm"
          id={`custom-value-${definition.id}`}
          {...register(name)}
        >
          <option value="">Selecione</option>
          <option value="true">Sim</option>
          <option value="false">Não</option>
        </select>
      ) : definition.fieldType === "SELECT" ? (
        <select
          className="h-10 rounded-xl border bg-white px-3 text-sm"
          id={`custom-value-${definition.id}`}
          {...register(name)}
        >
          <option value="">Selecione</option>
          {definition.options?.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      ) : (
        <Input
          id={`custom-value-${definition.id}`}
          type={
            definition.fieldType === "NUMBER"
              ? "number"
              : definition.fieldType === "DATE"
                ? "date"
                : "text"
          }
          {...register(name)}
        />
      )}
    </FormField>
  );
}

export function FormField({
  children,
  error,
  id,
  label,
}: {
  children: React.ReactNode;
  error?: string | undefined;
  id: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? <p className="text-sm text-red-700">{error}</p> : null}
    </div>
  );
}
