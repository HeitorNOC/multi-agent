import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, cancelFiscalDocument, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  cancelFiscalDocument: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    cancelFiscalDocument: { execute: cancelFiscalDocument },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { POST } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
const saleId = "10000000-0000-4000-8000-000000000002";
const documentId = "10000000-0000-4000-8000-000000000003";

it("requires idempotency and forwards a validated fiscal cancellation", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  cancelFiscalDocument.mockResolvedValue({ id: documentId });
  const reason = "Cancelamento solicitado pelo cliente.";
  const response = await POST(
    new Request(
      `http://localhost/api/v1/organizations/${organizationId}/sales/${saleId}/fiscal-documents/${documentId}/cancel`,
      {
        body: JSON.stringify({ reason }),
        headers: { "content-type": "application/json", "idempotency-key": "cancel-key-001" },
        method: "POST",
      },
    ),
    { params: Promise.resolve({ documentId, organizationId, saleId }) },
  );
  expect(response.status).toBe(200);
  expect(cancelFiscalDocument).toHaveBeenCalledWith(
    { documentId, idempotencyKey: "cancel-key-001", organizationId, reason, saleId },
    { role: "OWNER" },
  );
});
