"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createFinancialTransferBodySchema,
  financialAccountListSchema,
  financialTransferPageSchema,
  financialTransferViewSchema,
  type CreateFinancialTransferBody,
  type FinancialAccountView,
  type FinancialTransferView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { formatBrl } from "./financial-transfer-format";
import { FinancialTransferList } from "./financial-transfer-list";

type FinancialTransferManagerProps = {
  organizationId: string;
};

export function FinancialTransferManager({ organizationId }: FinancialTransferManagerProps) {
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[] | null>(null);
  const [transfers, setTransfers] = useState<readonly FinancialTransferView[] | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateFinancialTransferBody>({
    defaultValues: {
      amount: "",
      sourceAccountId: "",
      targetAccountId: "",
    },
    resolver: zodResolver(createFinancialTransferBodySchema),
  });
  const sourceAccountId = useWatch({ control, name: "sourceAccountId" });
  const targetAccountId = useWatch({ control, name: "targetAccountId" });
  const activeAccounts = useMemo(
    () => accounts?.filter(({ status }) => status === "ACTIVE") ?? [],
    [accounts],
  );
  const accountById = useMemo(
    () => new Map(accounts?.map((account) => [account.id, account]) ?? []),
    [accounts],
  );
  const selectedSource = accountById.get(sourceAccountId);
  const selectedTarget = accountById.get(targetAccountId);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const [accountsResponse, transfersResponse] = await Promise.all([
          fetch(`/api/v1/organizations/${organizationId}/financial-accounts`, {
            signal: controller.signal,
          }),
          fetch(`/api/v1/organizations/${organizationId}/financial-transfers?limit=20`, {
            signal: controller.signal,
          }),
        ]);

        if (!accountsResponse.ok || !transfersResponse.ok) {
          const response = !accountsResponse.ok ? accountsResponse : transfersResponse;
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const accountPayload = (await accountsResponse.json()) as { data: unknown };
        const transferPayload = await transfersResponse.json();
        const nextAccounts = financialAccountListSchema.parse(accountPayload.data);
        const nextTransfers = financialTransferPageSchema.parse(transferPayload);
        setAccounts(nextAccounts);
        setTransfers(nextTransfers.data);
        setHasMore(nextTransfers.page.hasMore);
        setNextCursor(nextTransfers.page.nextCursor);
        setLoadError(null);

        const firstSource = nextAccounts.find(({ status }) => status === "ACTIVE");
        const firstTarget = nextAccounts.find(
          ({ id, status }) => status === "ACTIVE" && id !== firstSource?.id,
        );

        if (firstSource && !sourceAccountId) {
          setValue("sourceAccountId", firstSource.id);
        }

        if (firstTarget && !targetAccountId) {
          setValue("targetAccountId", firstTarget.id);
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error ? error.message : "Não foi possível carregar as transferências.",
          );
        }
      }
    }

    void load();
    return () => controller.abort();
  }, [organizationId, reloadVersion, setValue, sourceAccountId, targetAccountId]);

  useEffect(() => {
    if (sourceAccountId && targetAccountId === sourceAccountId) {
      const alternative = activeAccounts.find(({ id }) => id !== sourceAccountId);
      setValue("targetAccountId", alternative?.id ?? "", { shouldValidate: true });
    }
  }, [activeAccounts, setValue, sourceAccountId, targetAccountId]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/financial-transfers`, {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": idempotencyKey,
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }

      const payload = (await response.json()) as { data: unknown };
      const created = financialTransferViewSchema.parse(payload.data);
      setTransfers((current) => [created, ...(current ?? [])]);
      setIdempotencyKey(crypto.randomUUID());
      setFeedback("Transferência concluída e registrada nos dois livros financeiros.");
      reset({
        amount: "",
        sourceAccountId: values.sourceAccountId,
        targetAccountId: values.targetAccountId,
      });
      const accountsResponse = await fetch(
        `/api/v1/organizations/${organizationId}/financial-accounts`,
      );

      if (accountsResponse.ok) {
        const accountPayload = (await accountsResponse.json()) as { data: unknown };
        setAccounts(financialAccountListSchema.parse(accountPayload.data));
      }
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function loadMore() {
    if (!nextCursor) {
      return;
    }

    setLoadingMore(true);

    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/financial-transfers?limit=20&cursor=${encodeURIComponent(nextCursor)}`,
      );

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        throw new Error(problem.detail);
      }

      const page = financialTransferPageSchema.parse(await response.json());
      setTransfers((current) => [...(current ?? []), ...page.data]);
      setHasMore(page.page.hasMore);
      setNextCursor(page.page.nextCursor);
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível carregar mais itens.");
    } finally {
      setLoadingMore(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
      <section className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7">
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Nova transferência
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950">Movimentar entre contas</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          O valor sai da origem e entra no destino na mesma transação. Não será classificado como
          receita, despesa, recebimento ou pagamento.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="transfer-source-account">Conta de origem</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="transfer-source-account"
              {...register("sourceAccountId")}
            >
              <option value="">Selecione a origem</option>
              {activeAccounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name} — {formatBrl(account.currentBalance)}
                </option>
              ))}
            </select>
            {errors.sourceAccountId ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.sourceAccountId.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="transfer-target-account">Conta de destino</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="transfer-target-account"
              {...register("targetAccountId")}
            >
              <option value="">Selecione o destino</option>
              {activeAccounts
                .filter(({ id }) => id !== sourceAccountId)
                .map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name} — {formatBrl(account.currentBalance)}
                  </option>
                ))}
            </select>
            {errors.targetAccountId ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.targetAccountId.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="transfer-amount">Valor</Label>
            <Input
              id="transfer-amount"
              inputMode="decimal"
              placeholder="0,00"
              {...register("amount")}
            />
            {errors.amount ? (
              <p className="text-sm text-red-700" role="alert">
                {errors.amount.message}
              </p>
            ) : null}
          </div>

          {selectedSource?.type === "CASH" || selectedTarget?.type === "CASH" ? (
            <p className="rounded-xl bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">
              O operador precisa manter aberto cada caixa físico envolvido. Transferências são
              bloqueadas durante a conferência.
            </p>
          ) : null}

          {activeAccounts.length < 2 ? (
            <p className="rounded-xl border border-dashed px-4 py-3 text-sm text-slate-600">
              Cadastre e ative ao menos duas contas financeiras para realizar uma transferência.
            </p>
          ) : null}

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button disabled={isSubmitting || activeAccounts.length < 2} type="submit">
            {isSubmitting ? "Transferindo..." : "Concluir transferência"}
          </Button>
        </form>
      </section>

      <FinancialTransferList
        accountById={accountById}
        accounts={accounts}
        feedback={feedback}
        hasMore={hasMore}
        loadError={loadError}
        loadingMore={loadingMore}
        onLoadMore={() => void loadMore()}
        onRetry={() => {
          setLoadError(null);
          setReloadVersion((version) => version + 1);
        }}
        transfers={transfers}
      />
    </div>
  );
}
