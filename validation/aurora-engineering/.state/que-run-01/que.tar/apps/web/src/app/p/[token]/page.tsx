import type { Metadata } from "next";

import { PublicAppointmentLink } from "@/features/scheduling/components/public-appointment-link";

export const metadata: Metadata = { title: "Agendamento | Gestor" };

type PublicAppointmentPageProps = { params: Promise<{ token: string }> };

export default async function PublicAppointmentPage({ params }: PublicAppointmentPageProps) {
  const { token } = await params;
  return <PublicAppointmentLink token={token} />;
}
