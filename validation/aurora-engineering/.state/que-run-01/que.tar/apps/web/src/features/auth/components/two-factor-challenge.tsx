"use client";

import { useState } from "react";

import { authClient } from "@gestor/auth/client";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import Link from "next/link";
import { useRouter } from "next/navigation";

import { safeReturnTo } from "../return-to";
import { FormFeedback } from "./form-feedback";

type VerificationMethod = "backup" | "totp";

type TwoFactorChallengeProps = {
  returnTo?: string;
};

export function TwoFactorChallenge({ returnTo }: TwoFactorChallengeProps) {
  const router = useRouter();
  const destination = safeReturnTo(returnTo);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string>();
  const [method, setMethod] = useState<VerificationMethod>("totp");
  const [submitting, setSubmitting] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(undefined);

    const normalizedCode = method === "totp" ? code.replace(/\D/g, "") : code.trim();
    if ((method === "totp" && normalizedCode.length !== 6) || !normalizedCode) {
      setError(
        method === "totp"
          ? "Digite os seis números exibidos no aplicativo autenticador."
          : "Digite um código de recuperação.",
      );
      return;
    }

    setSubmitting(true);
    const result =
      method === "totp"
        ? await authClient.twoFactor.verifyTotp({ code: normalizedCode })
        : await authClient.twoFactor.verifyBackupCode({ code: normalizedCode });
    setSubmitting(false);

    if (result.error) {
      setError(
        "Não foi possível confirmar o código. Confira-o e tente novamente. Para sua segurança, novos erros podem bloquear tentativas temporariamente.",
      );
      return;
    }

    const session = await authClient.getSession();
    if (!session.data?.session || !session.data.user) {
      setError("Não foi possível confirmar sua sessão. Volte ao login e tente novamente.");
      return;
    }

    const acceptance = new URL("/aceite", window.location.origin);
    if (destination) acceptance.searchParams.set("returnTo", destination);
    router.replace(`${acceptance.pathname}${acceptance.search}`);
    router.refresh();
  }

  function switchMethod(nextMethod: VerificationMethod) {
    setMethod(nextMethod);
    setCode("");
    setError(undefined);
  }

  return (
    <div className="grid gap-5">
      <p className="text-sm leading-6 text-slate-600">
        Confirme a segunda etapa antes de acessar sua conta. Essa proteção impede o acesso mesmo
        quando alguém descobre sua senha.
      </p>

      <div className="flex flex-wrap gap-2" role="tablist" aria-label="Forma de confirmação">
        <Button
          aria-selected={method === "totp"}
          aria-controls="two-factor-challenge-panel"
          id="two-factor-totp-tab"
          onClick={() => switchMethod("totp")}
          role="tab"
          size="sm"
          tabIndex={method === "totp" ? 0 : -1}
          type="button"
          variant={method === "totp" ? "default" : "outline"}
        >
          Aplicativo autenticador
        </Button>
        <Button
          aria-selected={method === "backup"}
          aria-controls="two-factor-challenge-panel"
          id="two-factor-backup-tab"
          onClick={() => switchMethod("backup")}
          role="tab"
          size="sm"
          tabIndex={method === "backup" ? 0 : -1}
          type="button"
          variant={method === "backup" ? "default" : "outline"}
        >
          Código de recuperação
        </Button>
      </div>

      <form
        aria-labelledby={`two-factor-${method}-tab`}
        className="grid gap-5"
        id="two-factor-challenge-panel"
        noValidate
        onSubmit={submit}
        role="tabpanel"
      >
        <div className="grid gap-2">
          <Label htmlFor="two-factor-code">
            {method === "totp" ? "Código de seis dígitos" : "Código de recuperação"}
          </Label>
          <Input
            aria-describedby={error ? "two-factor-error" : undefined}
            aria-invalid={Boolean(error)}
            autoComplete="one-time-code"
            className="h-11 rounded-xl bg-white px-3"
            id="two-factor-code"
            inputMode={method === "totp" ? "numeric" : "text"}
            maxLength={method === "totp" ? 6 : 64}
            onChange={(event) =>
              setCode(method === "totp" ? event.target.value.replace(/\D/g, "") : event.target.value)
            }
            placeholder={method === "totp" ? "000000" : "Ex.: ABCD-EFGH"}
            required
            value={code}
          />
          <p className="text-xs leading-5 text-slate-500">
            {method === "totp"
              ? "Abra o aplicativo autenticador e informe o código atual."
              : "Use um dos códigos guardados quando a autenticação em duas etapas foi ativada."}
          </p>
        </div>

        {error ? <FormFeedback kind="error">{error}</FormFeedback> : null}

        <Button className="h-11 rounded-xl" disabled={submitting} type="submit">
          {submitting ? "Confirmando..." : "Confirmar e entrar"}
        </Button>
      </form>

      <Link className="text-center text-sm font-semibold text-brand-600 hover:text-brand-700" href="/login">
        Voltar para entrar com outra conta
      </Link>
    </div>
  );
}
