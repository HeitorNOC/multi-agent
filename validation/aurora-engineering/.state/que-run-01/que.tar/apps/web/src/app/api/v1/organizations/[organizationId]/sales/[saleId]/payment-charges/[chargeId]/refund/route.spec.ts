import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, loggerError, refundPayment, resolveActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  loggerError: vi.fn(),
  refundPayment: vi.fn(),
  resolveActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({
    LOG_LEVEL: "silent",
    NODE_ENV: "test",
    RATE_LIMIT_HASH_SECRET: "test-secret",
    TRUST_PROXY_HEADERS: false,
  }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    refundTerminalPayment: { execute: refundPayment },
    resolveTenantActor: { execute: resolveActor },
  },
}));
vi.mock("@gestor/observability", () => ({
  getLogger: () => ({ error: loggerError }),
  metrics: { increment: vi.fn(), observe: vi.fn() },
}));

import { POST } from "./route";

it("forwards an authenticated idempotent terminal refund", async () => {
  const params = {
    chargeId: "10000000-0000-4000-8000-000000000003",
    organizationId: "10000000-0000-4000-8000-000000000001",
    saleId: "10000000-0000-4000-8000-000000000002",
  };
  const actor = { organizationId: params.organizationId };
  authenticate.mockResolvedValue({ userId: "user" });
  resolveActor.mockResolvedValue(actor);
  refundPayment.mockResolvedValue({ id: params.chargeId, status: "REFUNDED" });
  const response = await POST(
    new Request("http://localhost/api/v1/payment-refund", {
      body: JSON.stringify({ reason: "Solicitado pelo cliente" }),
      headers: { "content-type": "application/json", "idempotency-key": "refund-key" },
      method: "POST",
    }),
    { params: Promise.resolve(params) },
  );
  const payload = await response.json();
  const logged = loggerError.mock.calls[0]?.[0] as { err?: Error } | undefined;
  expect(response.status, `${logged?.err?.message ?? "unknown"}: ${JSON.stringify(payload)}`).toBe(
    200,
  );
  expect(refundPayment).toHaveBeenCalledWith(
    { ...params, idempotencyKey: "refund-key", reason: "Solicitado pelo cliente" },
    actor,
  );
});
