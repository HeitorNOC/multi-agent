import { afterEach, describe, expect, it, vi } from "vitest";

import {
  cancelFinancialObligation,
  createFinancialObligation,
  loadMoreFinancialObligations,
} from "./financial-obligation-api";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("financial obligation API", () => {
  it("preserves the idempotency key and returns structured creation problems", async () => {
    const problem = { code: "INVALID_OBLIGATION", detail: "Conta inválida." };
    const fetchMock = vi.fn().mockResolvedValue(Response.json(problem, { status: 422 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      createFinancialObligation("org-1", { kind: "PAYABLE" } as never, "key-1"),
    ).resolves.toEqual({ data: null, problem });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/org-1/financial-obligations",
      expect.objectContaining({
        headers: { "content-type": "application/json", "idempotency-key": "key-1" },
        method: "POST",
      }),
    );
  });

  it("sends version, kind and reason when cancelling", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(Response.json({ detail: "Conflito." }, { status: 409 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      cancelFinancialObligation(
        "org-1",
        { id: "obligation-1", kind: "RECEIVABLE", version: 3 } as never,
        { idempotencyKey: "key-2", reason: "Duplicada" },
      ),
    ).rejects.toThrow("Conflito.");
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/org-1/financial-obligations/obligation-1/cancel",
      expect.objectContaining({
        body: JSON.stringify({ expectedVersion: 3, kind: "RECEIVABLE", reason: "Duplicada" }),
        headers: { "content-type": "application/json", "idempotency-key": "key-2" },
      }),
    );
  });

  it("encodes the cursor when loading another page", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(Response.json({ detail: "Página indisponível." }, { status: 503 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(loadMoreFinancialObligations("org-1", "PAYABLE", "cursor+/=")).rejects.toThrow(
      "Página indisponível.",
    );
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/organizations/org-1/financial-obligations?kind=PAYABLE&limit=100&cursor=cursor%2B%2F%3D",
    );
  });
});
