import type {
  FinancialAccountView,
  FinancialCategoryView,
  PaymentMethodConfigurationView,
} from "@gestor/contracts";
import { Input } from "@gestor/ui/components/input";
import type { UseFormRegister } from "react-hook-form";

import { SelectField } from "../../sales/components/direct-sale-support";
import type { PurchaseFormValues } from "./purchase-form";

export function PurchaseFinancialFields({
  accounts,
  categories,
  payNow,
  paymentMethods,
  register,
}: {
  accounts: readonly FinancialAccountView[];
  categories: readonly FinancialCategoryView[];
  payNow: boolean;
  paymentMethods: readonly PaymentMethodConfigurationView[];
  register: UseFormRegister<PurchaseFormValues>;
}) {
  return (
    <>
      <SelectField label="Categoria de despesa">
        <select className="rounded-md border px-3 py-2 text-sm" {...register("expenseCategoryId")}>
          <option value="">Selecione</option>
          {categories.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </select>
      </SelectField>
      <SelectField label="Vencimento">
        <Input type="date" {...register("dueDate")} />
      </SelectField>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" {...register("payNow")} /> Registrar pagamento à vista
      </label>
      {payNow ? (
        <>
          <SelectField label="Forma de pagamento">
            <select
              className="rounded-md border px-3 py-2 text-sm"
              {...register("paymentMethodConfigurationId")}
            >
              <option value="">Selecione</option>
              {paymentMethods.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </SelectField>
          <SelectField label="Conta financeira">
            <select
              className="rounded-md border px-3 py-2 text-sm"
              {...register("financialAccountId")}
            >
              <option value="">Selecione</option>
              {accounts.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </SelectField>
        </>
      ) : null}
    </>
  );
}
