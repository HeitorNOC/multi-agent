import { beforeEach, describe, expect, it, vi } from "vitest";
import { BusinessRuleError } from "@gestor/kernel";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createFinancialAccount, listFinancialAccounts, resolveTenantActor } =
  vi.hoisted(() => ({
    authenticate: vi.fn(),
    createFinancialAccount: vi.fn(),
    listFinancialAccounts: vi.fn(),
    resolveTenantActor: vi.fn(),
  }));

vi.mock("@/lib/server/container", () => ({
  services: {
    createFinancialAccount: { execute: createFinancialAccount },
    identityProvider: { authenticate },
    listFinancialAccounts: { execute: listFinancialAccounts },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));

import { GET, POST } from "./route";

const organizationId = "00000000-0000-4000-8000-000000000001";
const branchId = "00000000-0000-4000-8000-000000000002";
const account = {
  branchId,
  createdAt: "2026-08-12T12:00:00.000Z",
  currentBalance: "100.0000",
  id: "00000000-0000-4000-8000-000000000003",
  initialBalance: "100.0000",
  initialBalanceDate: "2026-08-12",
  name: "Caixa principal",
  status: "ACTIVE",
  type: "CASH",
  updatedAt: "2026-08-12T12:00:00.000Z",
} as const;
const route = { params: Promise.resolve({ organizationId }) };

describe("financial account routes", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    createFinancialAccount.mockReset().mockResolvedValue(account);
    listFinancialAccounts.mockReset().mockResolvedValue([account]);
  });

  it("lists accounts within the authenticated tenant", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-accounts`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ data: [account] });
    expect(resolveTenantActor).toHaveBeenCalledWith(
      expect.objectContaining({ organizationId, userId: "user-1" }),
    );
    expect(listFinancialAccounts).toHaveBeenCalledWith({ organizationId }, { role: "OWNER" });
  });

  it("returns a treatable problem when an account lacks its opening balance", async () => {
    listFinancialAccounts.mockRejectedValueOnce(
      new BusinessRuleError(
        "FINANCIAL_ACCOUNT_OPENING_BALANCE_MISSING",
        "A conta financeira precisa de um saldo inicial antes de poder ser consultada.",
      ),
    );
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-accounts`,
    );

    const response = await GET(request, route);

    expect(response.status).toBe(422);
    await expect(response.json()).resolves.toMatchObject({
      code: "FINANCIAL_ACCOUNT_OPENING_BALANCE_MISSING",
    });
  });

  it("creates an account with the external idempotency key", async () => {
    const body = {
      branchId,
      initialBalance: "100",
      initialBalanceDate: "2026-08-12",
      name: "Caixa principal",
      type: "CASH",
    };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-accounts`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "account-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(response.headers.get("location")).toBe(
      `/api/v1/organizations/${organizationId}/financial-accounts/${account.id}`,
    );
    expect(createFinancialAccount).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "account-key", organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects an invalid body after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-accounts`,
      {
        body: JSON.stringify({ name: "x" }),
        headers: { "content-type": "application/json", "idempotency-key": "account-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(createFinancialAccount).not.toHaveBeenCalled();
  });
});
