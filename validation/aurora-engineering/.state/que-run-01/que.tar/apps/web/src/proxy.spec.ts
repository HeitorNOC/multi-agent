import { NextRequest } from "next/server";
import { afterEach, describe, expect, it } from "vitest";

import { proxy } from "./proxy";

const originalEnvironment = { ...process.env };

afterEach(() => {
  process.env = { ...originalEnvironment };
});

describe("proxy", () => {
  it("rejects a private API request without a session credential", async () => {
    const response = proxy(new NextRequest("https://app.example.com/api/v1/organizations"));

    expect(response.status).toBe(401);
    await expect(response.json()).resolves.toMatchObject({ code: "AUTHENTICATION_REQUIRED" });
  });

  it("redirects a private page and preserves its intended destination", () => {
    const response = proxy(
      new NextRequest("https://app.example.com/organizations/org-1/settings/users?tab=active"),
    );

    expect(response.status).toBe(307);
    expect(response.headers.get("location")).toContain("returnTo=");
  });

  it("allows a session cookie through to authoritative server authentication", () => {
    const response = proxy(
      new NextRequest("https://app.example.com/api/v1/organizations", {
        headers: { cookie: "gestor.session_token=opaque" },
      }),
    );

    expect(response.status).toBe(200);
    expect(response.headers.get("x-frame-options")).toBe("DENY");
  });
});
