import { reschedulePublicAppointmentBodySchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ appointmentId: string; token: string }> };

export async function PATCH(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { appointmentId, token } = await route.params;
    const identity = await authenticateApiRequest(request);
    const link = await services.resolvePublicAppointmentPortalLink.execute(token);
    const actor = await services.resolveCustomerPortalActor.execute({ correlationId: api.correlationId, organizationId: link.organizationId, requestId: api.requestId, userId: identity.userId });
    const body = reschedulePublicAppointmentBodySchema.parse(await readJsonBody(request));
    return Response.json({ data: await services.reschedulePublicAppointment.execute({ ...body, appointmentId }, actor) });
  }, { rateLimit: apiRateLimitPolicies.publicPortalLink });
}
