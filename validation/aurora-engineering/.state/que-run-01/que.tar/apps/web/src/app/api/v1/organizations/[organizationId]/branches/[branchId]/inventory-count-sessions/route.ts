import { inventoryBranchParamsSchema, openInventoryCountSessionBodySchema } from "@gestor/contracts";
import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
type P={params:Promise<{branchId:string;organizationId:string}>};
async function actor(request:Request, api:any, params:any){const identity=await authenticateApiRequest(request);return services.resolveTenantActor.execute({correlationId:api.correlationId,organizationId:params.organizationId,requestId:api.requestId,userId:identity.userId});}
export async function GET(request:Request, route:P){return handleApiRequest(request,async api=>{const params=inventoryBranchParamsSchema.parse(await route.params); return Response.json({data:await services.listInventoryCountSessions.execute(params,await actor(request,api,params))});});}
export async function POST(request:Request, route:P){return handleApiRequest(request,async api=>{const params=inventoryBranchParamsSchema.parse(await route.params);const body=openInventoryCountSessionBodySchema.parse(await readJsonBody(request));return Response.json({data:await services.openInventoryCountSession.execute({...params,...body},await actor(request,api,params))});});}
