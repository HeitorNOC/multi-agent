/**
 * Better Auth returns an otpauth URI. Authenticator applications accept that
 * URI through a QR code, while their manual setup expects only its Base32
 * `secret` parameter.
 */
export function parseTotpEnrollmentUri(totpUri: string): { manualKey: string; totpUri: string } {
  const uri = new URL(totpUri);
  const manualKey = uri.searchParams.get("secret")?.replace(/\s/g, "").toUpperCase();

  if (uri.protocol !== "otpauth:" || uri.hostname !== "totp" || !manualKey) {
    throw new Error("TOTP enrollment URI is invalid.");
  }

  return { manualKey, totpUri };
}
