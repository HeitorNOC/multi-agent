type AuthenticationError = {
  code?: string | undefined;
  message?: string | undefined;
  status?: number;
};

const errorMessages: Record<string, string> = {
  EMAIL_NOT_VERIFIED: "Confirme seu e-mail antes de entrar.",
  INVALID_EMAIL_OR_PASSWORD: "E-mail ou senha incorretos.",
  INVALID_TOKEN: "Este link é inválido ou expirou. Solicite um novo.",
  PASSWORD_TOO_LONG: "A senha deve ter no máximo 128 caracteres.",
  PASSWORD_TOO_SHORT: "A senha deve ter pelo menos 10 caracteres.",
  USER_ALREADY_EXISTS: "Já existe uma conta com este e-mail.",
  USER_ALREADY_EXISTS_USE_ANOTHER_EMAIL: "Já existe uma conta com este e-mail.",
};

export function getAuthenticationErrorMessage(
  error: AuthenticationError | null,
  fallback: string,
): string {
  if (!error) {
    return fallback;
  }

  if (error.status === 429) {
    return "Muitas tentativas em pouco tempo. Aguarde um minuto e tente novamente.";
  }

  const translatedMessage = error.code ? errorMessages[error.code] : undefined;
  if (translatedMessage) {
    return translatedMessage;
  }

  return fallback;
}
