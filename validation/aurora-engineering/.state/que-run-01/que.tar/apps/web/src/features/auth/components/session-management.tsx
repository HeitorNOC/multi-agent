"use client";

import { useCallback, useEffect, useState } from "react";

import { authClient } from "@gestor/auth/client";

type Session = {
  createdAt: Date | string;
  expiresAt: Date | string;
  ipAddress?: string | null | undefined;
  token: string;
  userAgent?: string | null | undefined;
};

function formatDate(value: Date | string): string {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(
    new Date(value),
  );
}

export function SessionManagement() {
  const [sessions, setSessions] = useState<readonly Session[]>([]);
  const [message, setMessage] = useState<string>();
  const [status, setStatus] = useState<"LOADING" | "READY" | "ERROR">("LOADING");

  const load = useCallback(async () => {
    setStatus("LOADING");
    const result = await authClient.listSessions();
    if (result.error) {
      setMessage("Não foi possível carregar suas sessões. Tente novamente.");
      setStatus("ERROR");
      return;
    }
    setSessions(result.data ?? []);
    setStatus("READY");
  }, []);

  useEffect(() => {
    let active = true;
    void authClient.listSessions().then((result) => {
      if (!active) return;
      if (result.error) {
        setMessage("Não foi possível carregar suas sessões. Tente novamente.");
        setStatus("ERROR");
        return;
      }
      setSessions(result.data ?? []);
      setStatus("READY");
    });
    return () => {
      active = false;
    };
  }, []);

  async function revoke(token: string) {
    setMessage(undefined);
    const result = await authClient.revokeSession({ token });
    if (result.error) {
      setMessage("Não foi possível encerrar esta sessão.");
      return;
    }
    setMessage("Sessão encerrada.");
    await load();
  }

  return (
    <section className="grid gap-5" aria-labelledby="sessions-title">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.18em] uppercase">Segurança</p>
        <h1
          className="mt-2 text-3xl font-semibold tracking-tight text-slate-950"
          id="sessions-title"
        >
          Sessões ativas
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Revise os dispositivos conectados à sua conta e encerre aqueles que não reconhecer.
        </p>
      </div>
      {message ? (
        <p className="text-sm text-slate-700" role="status">
          {message}
        </p>
      ) : null}
      {status === "LOADING" ? (
        <p className="text-sm text-slate-600">Carregando sessões...</p>
      ) : null}
      {status === "ERROR" ? (
        <button
          className="w-fit rounded-lg border px-3 py-2 text-sm font-semibold"
          onClick={() => void load()}
          type="button"
        >
          Tentar novamente
        </button>
      ) : null}
      {status === "READY" && sessions.length === 0 ? (
        <p className="rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-600">
          Nenhuma sessão ativa foi encontrada.
        </p>
      ) : null}
      {status === "READY" ? (
        <ul className="grid gap-3" aria-label="Sessões ativas">
          {sessions.map((session) => (
            <li
              className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm"
              key={session.token}
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="font-medium text-slate-900">
                    {session.userAgent || "Dispositivo não identificado"}
                  </p>
                  <p className="mt-1 text-sm text-slate-600">
                    {session.ipAddress || "Origem não informada"} · iniciada em{" "}
                    {formatDate(session.createdAt)}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Expira em {formatDate(session.expiresAt)}
                  </p>
                </div>
                <button
                  className="rounded-lg border border-red-200 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-50"
                  onClick={() => void revoke(session.token)}
                  type="button"
                >
                  Encerrar sessão
                </button>
              </div>
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}
