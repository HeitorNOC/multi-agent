import type { CatalogMalwareScanner, CatalogObjectStorage } from "@gestor/catalog";
import { getFileStorageEnv, type FileStorageEnv } from "@gestor/config";
import { DependencyUnavailableError } from "@gestor/kernel";

type Fetch = typeof fetch;

export class SupabaseCatalogObjectStorage implements CatalogObjectStorage {
  constructor(
    private readonly environment: () => FileStorageEnv = getFileStorageEnv,
    private readonly request: Fetch = fetch,
  ) {}
  async put(input: { bytes: Uint8Array; mimeType: string; storageKey: string }): Promise<void> {
    const env = resolveEnvironment(this.environment);
    const response = await this.request(this.objectUrl(env, input.storageKey), {
      body: binaryBody(input.bytes),
      headers: this.headers(env, { "content-type": input.mimeType, "x-upsert": "true" }),
      method: "POST",
    }).catch((cause) => {
      throw unavailable(cause);
    });
    if (!response.ok) throw unavailable(await safeError(response));
  }
  async remove(storageKey: string): Promise<void> {
    const env = resolveEnvironment(this.environment);
    const response = await this.request(
      `${baseUrl(env)}/storage/v1/object/${env.SUPABASE_STORAGE_BUCKET}`,
      {
        body: JSON.stringify({ prefixes: [storageKey] }),
        headers: this.headers(env, { "content-type": "application/json" }),
        method: "DELETE",
      },
    ).catch((cause) => {
      throw unavailable(cause);
    });
    if (!response.ok && response.status !== 404) throw unavailable(await safeError(response));
  }
  async createSignedDownloadUrl(storageKey: string, expiresInSeconds: number): Promise<string> {
    const env = resolveEnvironment(this.environment);
    const response = await this.request(
      `${baseUrl(env)}/storage/v1/object/sign/${env.SUPABASE_STORAGE_BUCKET}/${encodeKey(storageKey)}`,
      {
        body: JSON.stringify({ expiresIn: expiresInSeconds }),
        headers: this.headers(env, { "content-type": "application/json" }),
        method: "POST",
      },
    ).catch((cause) => {
      throw unavailable(cause);
    });
    if (!response.ok) throw unavailable(await safeError(response));
    const payload = (await response.json()) as { signedURL?: string; signedUrl?: string };
    const signedUrl = payload.signedURL ?? payload.signedUrl;
    if (!signedUrl) throw unavailable("Resposta sem URL assinada.");
    return signedUrl.startsWith("http") ? signedUrl : `${baseUrl(env)}/storage/v1${signedUrl}`;
  }
  private headers(env: FileStorageEnv, extra: Record<string, string>) {
    return {
      ...extra,
      apikey: env.SUPABASE_STORAGE_SECRET_KEY,
      authorization: `Bearer ${env.SUPABASE_STORAGE_SECRET_KEY}`,
    };
  }
  private objectUrl(env: FileStorageEnv, storageKey: string) {
    return `${baseUrl(env)}/storage/v1/object/${env.SUPABASE_STORAGE_BUCKET}/${encodeKey(storageKey)}`;
  }
}

export class HttpCatalogMalwareScanner implements CatalogMalwareScanner {
  constructor(
    private readonly environment: () => FileStorageEnv = getFileStorageEnv,
    private readonly request: Fetch = fetch,
  ) {}
  async scan(input: {
    bytes: Uint8Array;
    checksumSha256: string;
    mimeType: string;
    originalName: string;
  }): Promise<{ clean: boolean; details: Record<string, unknown> }> {
    const env = resolveEnvironment(this.environment);
    const response = await this.request(env.MALWARE_SCAN_URL, {
      body: binaryBody(input.bytes),
      headers: {
        authorization: `Bearer ${env.MALWARE_SCAN_TOKEN}`,
        "content-type": input.mimeType,
        "x-file-checksum-sha256": input.checksumSha256,
        "x-file-name": encodeURIComponent(input.originalName),
      },
      method: "POST",
    }).catch((cause) => {
      throw unavailable(cause);
    });
    if (!response.ok) throw unavailable(await safeError(response));
    const payload = (await response.json()) as Record<string, unknown>;
    if (typeof payload.clean !== "boolean") throw unavailable("Resposta inválida do antivírus.");
    const { clean, ...details } = payload;
    return { clean, details };
  }
}

function baseUrl(env: FileStorageEnv) {
  return env.SUPABASE_STORAGE_URL.replace(/\/$/, "");
}
function encodeKey(key: string) {
  return key.split("/").map(encodeURIComponent).join("/");
}
function binaryBody(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}
async function safeError(response: Response) {
  return { body: (await response.text()).slice(0, 500), status: response.status };
}
function unavailable(cause: unknown): DependencyUnavailableError {
  return new DependencyUnavailableError(
    "CATALOG_FILE_DEPENDENCY_UNAVAILABLE",
    "O serviço seguro de arquivos está temporariamente indisponível.",
    cause,
  );
}

function resolveEnvironment(environment: () => FileStorageEnv): FileStorageEnv {
  try {
    return environment();
  } catch (cause) {
    throw unavailable(cause);
  }
}
