"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { authClient } from "@gestor/auth/client";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";

import { getAuthenticationErrorMessage } from "../authentication-error";
import { safeReturnTo } from "../return-to";
import { signUpSchema, type SignUpInput, type SignUpValues } from "../schemas";
import { FormFeedback } from "./form-feedback";
import { GoogleSignInButton } from "./google-sign-in-button";
import { PasswordInput } from "./password-input";

const inputClassName = "h-11 rounded-xl bg-white px-3";

export function SignUpForm({
  googleEnabled,
  returnTo,
}: {
  googleEnabled: boolean;
  returnTo?: string;
}) {
  const router = useRouter();
  const destination = safeReturnTo(returnTo);
  const loginHref = destination ? `/login?returnTo=${encodeURIComponent(destination)}` : "/login";
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setError,
  } = useForm<SignUpInput, undefined, SignUpValues>({
    defaultValues: {
      confirmPassword: "",
      email: "",
      name: "",
      password: "",
    },
    resolver: zodResolver(signUpSchema),
  });

  const submit = handleSubmit(async (values) => {
    try {
      const callback = new URL("/login", window.location.origin);
      callback.searchParams.set("emailVerified", "1");
      if (destination) callback.searchParams.set("returnTo", destination);
      const result = await authClient.signUp.email({
        callbackURL: callback.toString(),
        email: values.email,
        name: values.name,
        password: values.password,
      });

      if (result.error) {
        setError("root", {
          message: getAuthenticationErrorMessage(
            result.error,
            "Não foi possível criar a conta. Tente novamente.",
          ),
          type: result.error.code ?? "server",
        });
        return;
      }

      window.sessionStorage.setItem("gestor.pendingVerificationEmail", values.email);
      router.push("/verificar-email");
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <form className="grid gap-5" noValidate onSubmit={submit}>
      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="sign-up-name">
          Seu nome
        </Label>
        <Input
          aria-describedby={errors.name ? "sign-up-name-error" : undefined}
          aria-invalid={Boolean(errors.name)}
          autoComplete="name"
          className={inputClassName}
          id="sign-up-name"
          placeholder="Como você quer ser chamado"
          {...register("name")}
        />
        {errors.name ? (
          <p className="text-sm text-red-700" id="sign-up-name-error" role="alert">
            {errors.name.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="sign-up-email">
          E-mail
        </Label>
        <Input
          aria-describedby={errors.email ? "sign-up-email-error" : undefined}
          aria-invalid={Boolean(errors.email)}
          autoComplete="email"
          className={inputClassName}
          id="sign-up-email"
          inputMode="email"
          placeholder="voce@empresa.com.br"
          type="email"
          {...register("email")}
        />
        {errors.email ? (
          <p className="text-sm text-red-700" id="sign-up-email-error" role="alert">
            {errors.email.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="sign-up-password">
          Senha
        </Label>
        <PasswordInput
          aria-describedby={
            errors.password
              ? "sign-up-password-help sign-up-password-error"
              : "sign-up-password-help"
          }
          aria-invalid={Boolean(errors.password)}
          autoComplete="new-password"
          className={inputClassName}
          id="sign-up-password"
          {...register("password")}
        />
        <p className="text-xs text-slate-500" id="sign-up-password-help">
          Use de 10 a 128 caracteres.
        </p>
        {errors.password ? (
          <p className="text-sm text-red-700" id="sign-up-password-error" role="alert">
            {errors.password.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="sign-up-confirm-password">
          Confirme a senha
        </Label>
        <PasswordInput
          aria-describedby={errors.confirmPassword ? "sign-up-confirm-password-error" : undefined}
          aria-invalid={Boolean(errors.confirmPassword)}
          autoComplete="new-password"
          className={inputClassName}
          id="sign-up-confirm-password"
          {...register("confirmPassword")}
        />
        {errors.confirmPassword ? (
          <p className="text-sm text-red-700" id="sign-up-confirm-password-error" role="alert">
            {errors.confirmPassword.message}
          </p>
        ) : null}
      </div>

      {errors.root?.message ? (
        <FormFeedback kind="error">{errors.root.message}</FormFeedback>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSubmitting} type="submit">
        {isSubmitting ? "Criando conta..." : "Criar minha conta"}
      </Button>

      {googleEnabled ? (
        <GoogleSignInButton
          errorPath="/cadastro"
          {...(destination ? { returnTo: destination } : {})}
        />
      ) : null}

      <p className="text-center text-sm text-slate-600">
        Já tem uma conta?{" "}
        <Link className="text-brand-600 hover:text-brand-700 font-semibold" href={loginHref}>
          Entrar
        </Link>
      </p>
    </form>
  );
}
