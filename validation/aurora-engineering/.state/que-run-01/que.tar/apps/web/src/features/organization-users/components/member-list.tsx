"use client";

import {
  updateOrganizationMemberBodySchema,
  type BranchView,
  type OrganizationMemberView,
  type OrganizationRoleView,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useState } from "react";

export function MemberList({
  branches,
  members,
  onCompleted,
  organizationId,
  roles,
}: {
  branches: readonly BranchView[];
  members: readonly OrganizationMemberView[];
  onCompleted: () => void;
  organizationId: string;
  roles: readonly OrganizationRoleView[];
}) {
  return (
    <div className="grid gap-4">
      <h2 className="text-xl font-semibold">Usuários e acessos</h2>
      {members.map((member) => (
        <MemberCard
          branches={branches}
          key={member.id}
          member={member}
          onCompleted={onCompleted}
          organizationId={organizationId}
          roles={roles}
        />
      ))}
      {members.length === 0 ? (
        <p className="text-sm text-slate-600">Nenhum usuário encontrado.</p>
      ) : null}
    </div>
  );
}

function MemberCard({
  branches,
  member,
  onCompleted,
  organizationId,
  roles,
}: {
  branches: readonly BranchView[];
  member: OrganizationMemberView;
  onCompleted: () => void;
  organizationId: string;
  roles: readonly OrganizationRoleView[];
}) {
  const [roleId, setRoleId] = useState(member.roleId);
  const [branchScope, setBranchScope] = useState(member.branchScope);
  const [branchIds, setBranchIds] = useState<readonly string[]>(member.branchIds);
  const [status, setStatus] = useState<"ACTIVE" | "REVOKED" | "SUSPENDED">(
    member.status === "INVITED" ? "SUSPENDED" : member.status,
  );
  const [feedback, setFeedback] = useState("");
  async function save() {
    setFeedback("");
    const body = updateOrganizationMemberBodySchema.parse({
      branchIds: branchScope === "ALL" ? [] : branchIds,
      branchScope,
      roleId,
      status,
    });
    const response = await fetch(`/api/v1/organizations/${organizationId}/users/${member.id}`, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json" },
      method: "PATCH",
    });
    const payload = (await response.json()) as Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível atualizar o acesso.");
    setFeedback("Acesso atualizado.");
    onCompleted();
  }
  return (
    <article className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm">
      <div>
        <h3 className="font-semibold">
          {member.name}
          {member.isOwner ? " · Proprietário" : ""}
        </h3>
        <p className="text-sm text-slate-600">{member.email}</p>
      </div>
      {member.isOwner ? (
        <p className="text-sm text-slate-600">Acesso integral protegido.</p>
      ) : (
        <>
          <div className="grid gap-3 md:grid-cols-3">
            <select
              aria-label="Papel"
              className="rounded-md border px-3 py-2 text-sm"
              onChange={(event) => setRoleId(event.target.value)}
              value={roleId}
            >
              {roles
                .filter(({ isSystem }) => !isSystem)
                .map((role) => (
                  <option key={role.id} value={role.id}>
                    {role.name}
                  </option>
                ))}
            </select>
            <select
              aria-label="Filiais"
              className="rounded-md border px-3 py-2 text-sm"
              onChange={(event) => setBranchScope(event.target.value as "ALL" | "SELECTED")}
              value={branchScope}
            >
              <option value="ALL">Todas as filiais</option>
              <option value="SELECTED">Selecionadas</option>
            </select>
            <select
              aria-label="Status"
              className="rounded-md border px-3 py-2 text-sm"
              onChange={(event) => setStatus(event.target.value as typeof status)}
              value={status}
            >
              <option value="ACTIVE">Ativo</option>
              <option value="SUSPENDED">Suspenso</option>
              <option value="REVOKED">Revogado</option>
            </select>
          </div>
          {branchScope === "SELECTED" ? (
            <div className="flex flex-wrap gap-4">
              {branches.map((branch) => (
                <label className="flex gap-2 text-sm" key={branch.id}>
                  <input
                    checked={branchIds.includes(branch.id)}
                    onChange={(event) =>
                      setBranchIds(
                        event.target.checked
                          ? [...branchIds, branch.id]
                          : branchIds.filter((id) => id !== branch.id),
                      )
                    }
                    type="checkbox"
                  />
                  {branch.name}
                </label>
              ))}
            </div>
          ) : null}
          <div className="flex items-center justify-between gap-4">
            {feedback ? (
              <p className="text-sm" role="status">
                {feedback}
              </p>
            ) : (
              <span />
            )}
            <Button onClick={save} type="button">
              Salvar acesso
            </Button>
          </div>
        </>
      )}
    </article>
  );
}
