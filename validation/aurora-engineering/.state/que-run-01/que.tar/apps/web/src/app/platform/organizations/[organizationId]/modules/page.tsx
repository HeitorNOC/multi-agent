import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";

import { OrganizationModules } from "@/features/platform-organization-modules/components/organization-modules";

export const metadata: Metadata = {
  title: "Módulos da empresa | Administração Gestor",
};

type PlatformOrganizationModulesPageProps = {
  params: Promise<{ organizationId: string }>;
};

export default async function PlatformOrganizationModulesPage({
  params,
}: PlatformOrganizationModulesPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <p className="text-brand-600 text-xs font-bold tracking-[0.16em] uppercase">
          Administração da plataforma
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Módulos da empresa
        </h1>
        <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
          Habilite, restrinja ou desabilite módulos desta organização. Dependências, plano,
          vigência, auditoria e concorrência continuam validados pelo backend.
        </p>
      </header>

      <OrganizationModules organizationId={organizationId} />
    </main>
  );
}
