"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  branchListSchema,
  completeDirectSaleBodySchema,
  completedSaleViewSchema,
  customerListSchema,
  financialAccountListSchema,
  financialCategoryListSchema,
  paymentMethodConfigurationListSchema,
  productListSchema,
  serviceListSchema,
  type BranchView,
  type CompletedSaleView,
  type CustomerView,
  type FinancialAccountView,
  type FinancialCategoryView,
  type PaymentMethodConfigurationView,
  type ProblemDetails,
  type ProductView,
  type ServiceView,
  type SalesOrderView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useMemo, useState } from "react";
import { useFieldArray, useForm, useWatch } from "react-hook-form";

import { DirectSaleFeedback } from "./direct-sale-feedback";
import { fetchData, saleFormSchema, type CatalogEntry, type SaleForm } from "./direct-sale-data";
import { DirectSalePayments } from "./direct-sale-payments";
import { SelectField } from "./direct-sale-support";

export function DirectSaleForm({
  onCompleted,
  organizationId,
  salesOrder,
}: {
  onCompleted?: () => void;
  organizationId: string;
  salesOrder: SalesOrderView | null;
}) {
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [customers, setCustomers] = useState<readonly CustomerView[]>([]);
  const [categories, setCategories] = useState<readonly FinancialCategoryView[]>([]);
  const [financialAccounts, setFinancialAccounts] = useState<readonly FinancialAccountView[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<readonly PaymentMethodConfigurationView[]>(
    [],
  );
  const [products, setProducts] = useState<readonly ProductView[]>([]);
  const [services, setServices] = useState<readonly ServiceView[]>([]);
  const [feedback, setFeedback] = useState("Carregando dados da venda...");
  const [completed, setCompleted] = useState<CompletedSaleView | null>(null);
  const form = useForm<SaleForm>({
    defaultValues: {
      branchId: "",
      customerId: "",
      discountAmount: "0",
      dueDate: "",
      items: [{ catalogEntry: "", quantity: "1" }],
      payments: [],
      revenueCategoryId: "",
      salesOrderId: null,
      salesOrderUpdatedAt: null,
    },
    resolver: zodResolver(saleFormSchema),
  });
  const itemFields = useFieldArray({ control: form.control, name: "items" });
  const paymentFields = useFieldArray({ control: form.control, name: "payments" });
  const selectedBranchId = useWatch({ control: form.control, name: "branchId" });
  const catalog = useMemo<readonly CatalogEntry[]>(
    () => [
      ...products
        .filter(({ status }) => status === "ACTIVE")
        .map(({ defaultPrice, id, name, sku }) => ({
          id,
          kind: "PRODUCT" as const,
          label: `${name} (${sku})`,
          price: defaultPrice,
        })),
      ...services
        .filter(({ status }) => status === "ACTIVE")
        .map(({ code, defaultPrice, id, name }) => ({
          id,
          kind: "SERVICE" as const,
          label: `${name} (${code})`,
          price: defaultPrice,
        })),
    ],
    [products, services],
  );

  useEffect(() => {
    if (!salesOrder || catalog.length === 0) return;
    form.setValue("branchId", salesOrder.branchId);
    form.setValue("customerId", salesOrder.customerId);
    form.setValue("discountAmount", salesOrder.discountAmount);
    form.setValue(
      "items",
      salesOrder.items.map((item) => ({
        catalogEntry: item.productId ? `PRODUCT:${item.productId}` : `SERVICE:${item.serviceId}`,
        quantity: item.quantity,
      })),
    );
    form.setValue("salesOrderId", salesOrder.id);
    form.setValue("salesOrderUpdatedAt", salesOrder.updatedAt);
  }, [catalog, form, salesOrder]);

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const base = `/api/v1/organizations/${organizationId}`;
        const [
          branchData,
          productData,
          serviceData,
          categoryData,
          financialAccountData,
          paymentMethodData,
        ] = await Promise.all([
          fetchData(`${base}/branches`, branchListSchema, controller.signal),
          fetchData(
            `${base}/products?limit=100&status=ACTIVE`,
            productListSchema,
            controller.signal,
          ),
          fetchData(
            `${base}/services?limit=100&status=ACTIVE`,
            serviceListSchema,
            controller.signal,
          ),
          fetchData(`${base}/financial-categories`, financialCategoryListSchema, controller.signal),
          fetchData(`${base}/financial-accounts`, financialAccountListSchema, controller.signal),
          fetchData(
            `${base}/payment-methods`,
            paymentMethodConfigurationListSchema,
            controller.signal,
          ),
        ]);
        setBranches(branchData.filter(({ status }) => status === "ACTIVE"));
        setProducts(productData);
        setServices(serviceData);
        setCategories(
          categoryData.filter(({ status, type }) => status === "ACTIVE" && type === "REVENUE"),
        );
        setFinancialAccounts(financialAccountData.filter(({ status }) => status === "ACTIVE"));
        setPaymentMethods(
          paymentMethodData.filter(
            ({ allowsReceipts, status }) => allowsReceipts && status === "ACTIVE",
          ),
        );
        form.setValue("branchId", branchData.find(({ status }) => status === "ACTIVE")?.id ?? "");
        form.setValue(
          "revenueCategoryId",
          categoryData.find(({ status, type }) => status === "ACTIVE" && type === "REVENUE")?.id ??
            "",
        );
        try {
          setCustomers(
            await fetchData(
              `${base}/customers?limit=100&status=ACTIVE`,
              customerListSchema,
              controller.signal,
            ),
          );
        } catch {
          setCustomers([]);
        }
        setFeedback("");
      } catch (error) {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível preparar a venda.",
          );
      }
    }
    void load();
    return () => controller.abort();
  }, [form, organizationId]);

  async function submit(values: SaleForm) {
    setCompleted(null);
    setFeedback("");
    const body = completeDirectSaleBodySchema.parse({
      branchId: values.branchId,
      customerId: values.customerId || null,
      discountAmount: values.discountAmount,
      dueDate: values.dueDate,
      items: values.items.map(({ catalogEntry, quantity }) => {
        const [kind, id] = catalogEntry.split(":");
        return {
          productId: kind === "PRODUCT" ? id : null,
          quantity,
          serviceId: kind === "SERVICE" ? id : null,
        };
      }),
      payments: values.payments,
      revenueCategoryId: values.revenueCategoryId,
      salesOrderId: values.salesOrderId,
      salesOrderUpdatedAt: values.salesOrderUpdatedAt,
    });
    const response = await fetch(`/api/v1/organizations/${organizationId}/sales`, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
      method: "POST",
    });
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) {
      setFeedback(payload.detail ?? "Não foi possível concluir a venda.");
      return;
    }
    const sale = completedSaleViewSchema.parse(payload.data);
    setCompleted(sale);
    onCompleted?.();
    setFeedback(
      sale.receivable.status === "SETTLED"
        ? `Venda #${sale.number} concluída e recebida integralmente.`
        : `Venda #${sale.number} concluída a prazo, sem movimentar caixa ou banco.`,
    );
    form.reset({
      ...values,
      discountAmount: "0",
      items: [{ catalogEntry: "", quantity: "1" }],
      payments: [],
    });
  }

  const cannotSell = branches.length === 0 || catalog.length === 0 || categories.length === 0;
  return (
    <section className="grid gap-6">
      <DirectSaleFeedback completed={completed} feedback={feedback} />
      <form className="grid gap-6" onSubmit={form.handleSubmit(submit)}>
        <DirectSalePayments
          branchId={selectedBranchId}
          financialAccounts={financialAccounts}
          form={form}
          paymentFields={paymentFields}
          paymentMethods={paymentMethods}
        />
        <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm sm:grid-cols-2">
          <SelectField error={form.formState.errors.branchId?.message} label="Filial">
            <select className="rounded-md border px-3 py-2 text-sm" {...form.register("branchId")}>
              <option value="">Selecione</option>
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </SelectField>
          <SelectField error={form.formState.errors.customerId?.message} label="Cliente (opcional)">
            <select
              className="rounded-md border px-3 py-2 text-sm"
              {...form.register("customerId")}
            >
              <option value="">Consumidor final</option>
              {customers.map((customer) => (
                <option key={customer.id} value={customer.id}>
                  {customer.name}
                </option>
              ))}
            </select>
          </SelectField>
          <SelectField
            error={form.formState.errors.revenueCategoryId?.message}
            label="Categoria de receita"
          >
            <select
              className="rounded-md border px-3 py-2 text-sm"
              {...form.register("revenueCategoryId")}
            >
              <option value="">Selecione</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </SelectField>
          <SelectField error={form.formState.errors.dueDate?.message} label="Vencimento">
            <Input type="date" {...form.register("dueDate")} />
          </SelectField>
        </div>

        <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-lg font-semibold">Itens</h2>
            <Button
              onClick={() => itemFields.append({ catalogEntry: "", quantity: "1" })}
              type="button"
              variant="outline"
            >
              Adicionar item
            </Button>
          </div>
          {itemFields.fields.map((field, index) => (
            <div className="grid gap-3 border-t pt-4 sm:grid-cols-[1fr_10rem_auto]" key={field.id}>
              <SelectField
                error={form.formState.errors.items?.[index]?.catalogEntry?.message}
                label="Produto ou serviço"
              >
                <select
                  className="rounded-md border px-3 py-2 text-sm"
                  {...form.register(`items.${index}.catalogEntry`)}
                >
                  <option value="">Selecione</option>
                  {catalog.map((entry) => (
                    <option key={`${entry.kind}:${entry.id}`} value={`${entry.kind}:${entry.id}`}>
                      {entry.label} — R$ {entry.price}
                    </option>
                  ))}
                </select>
              </SelectField>
              <SelectField
                error={form.formState.errors.items?.[index]?.quantity?.message}
                label="Quantidade"
              >
                <Input inputMode="decimal" {...form.register(`items.${index}.quantity`)} />
              </SelectField>
              <div className="flex items-end">
                <Button
                  disabled={itemFields.fields.length === 1}
                  onClick={() => itemFields.remove(index)}
                  type="button"
                  variant="outline"
                >
                  Remover
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-end justify-between gap-4 rounded-2xl border bg-white p-5 shadow-sm">
          <SelectField error={form.formState.errors.discountAmount?.message} label="Desconto total">
            <Input className="w-48" inputMode="decimal" {...form.register("discountAmount")} />
          </SelectField>
          <Button disabled={cannotSell || form.formState.isSubmitting} type="submit">
            Concluir venda
          </Button>
        </div>
      </form>
    </section>
  );
}
