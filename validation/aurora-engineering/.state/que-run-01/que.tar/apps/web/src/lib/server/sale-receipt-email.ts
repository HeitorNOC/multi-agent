import { getAuthEmailEnv } from "@gestor/config";
import type { SaleReceiptEmailSender } from "@gestor/sales";

export class ResendSaleReceiptEmailSender implements SaleReceiptEmailSender {
  async send(input: Parameters<SaleReceiptEmailSender["send"]>[0]): Promise<void> {
    const environment = getAuthEmailEnv();
    const response = await fetch("https://api.resend.com/emails", {
      body: JSON.stringify({
        from: environment.AUTH_EMAIL_FROM,
        html: input.receipt.html,
        reply_to: environment.AUTH_EMAIL_REPLY_TO,
        subject: input.receipt.subject,
        text: input.receipt.text,
        to: [input.recipientEmail],
      }),
      headers: {
        authorization: `Bearer ${environment.RESEND_API_KEY}`,
        "content-type": "application/json",
        "idempotency-key": input.idempotencyKey,
      },
      method: "POST",
    });
    if (!response.ok) throw new Error(`SALE_RECEIPT_EMAIL_DELIVERY_FAILED:${response.status}`);
  }
}
