import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, listPurchases, receivePurchase, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  listPurchases: vi.fn(),
  receivePurchase: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listPurchases: { execute: listPurchases },
    receivePurchase: { execute: receivePurchase },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const route = { params: Promise.resolve({ organizationId }) };
const body = {
  branchId: "20000000-0000-4000-8000-000000000002",
  discountAmount: "0",
  dueDate: "2026-08-20",
  expenseCategoryId: "20000000-0000-4000-8000-000000000003",
  freightAmount: "0",
  items: [
    {
      productId: "20000000-0000-4000-8000-000000000004",
      quantity: "2",
      taxAmount: "0",
      unitCost: "8",
    },
  ],
  supplierDocumentNumber: null,
  supplierId: "20000000-0000-4000-8000-000000000005",
};

describe("purchase receipt route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    receivePurchase.mockReset().mockResolvedValue({ id: "20000000-0000-4000-8000-000000000006" });
    listPurchases
      .mockReset()
      .mockResolvedValue({ data: [], page: { hasMore: false, nextCursor: null } });
  });

  it("lists tenant purchases with validated filters", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/purchases?limit=10&status=RECEIVED`,
    );
    expect((await GET(request, route)).status).toBe(200);
    expect(listPurchases).toHaveBeenCalledWith(
      { limit: 10, organizationId, status: "RECEIVED" },
      { role: "OWNER" },
    );
  });

  it("receives a purchase with external idempotency", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/purchases`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "purchase-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);
    expect(response.status).toBe(201);
    expect(receivePurchase).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "purchase-key", organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects duplicate products after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/purchases`,
      {
        body: JSON.stringify({ ...body, items: [body.items[0], body.items[0]] }),
        headers: { "content-type": "application/json", "idempotency-key": "purchase-key" },
        method: "POST",
      },
    );
    expect((await POST(request, route)).status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
  });
});
