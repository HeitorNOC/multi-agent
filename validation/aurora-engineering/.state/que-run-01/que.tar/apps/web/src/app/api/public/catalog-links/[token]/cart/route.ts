import { authenticateApiRequest, handleApiRequest, readJsonBody } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
async function context(
  request: Request,
  token: string,
  api: { correlationId: string; requestId: string },
) {
  const link = await services.resolvePublicCatalogPortalLink.execute(token);
  const identity = await authenticateApiRequest(request);
  const actor = await services.resolveCustomerPortalActor.execute({
    correlationId: api.correlationId,
    organizationId: link.organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
  return { actor, link };
}
export async function GET(request: Request, { params }: { params: Promise<{ token: string }> }) {
  return handleApiRequest(request, async (api) => {
    const { actor, link } = await context(request, (await params).token, api);
    return Response.json({
      data: await services.getPublicCart.execute(
        { branchId: link.branchId, linkId: link.id },
        actor,
      ),
    });
  });
}
