import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ token: string; orderId: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const { token, orderId } = await route.params;
    const identity = await authenticateApiRequest(request);
    const link = await services.resolvePublicCatalogPortalLink.execute(token);
    const actor = await services.resolveCustomerPortalActor.execute({
      correlationId: api.correlationId, organizationId: link.organizationId,
      requestId: api.requestId, userId: identity.userId,
    });
    return Response.json({ data: await services.confirmCustomerPortalOrderReceipt.execute(orderId, actor) });
  });
}
