"use client";

import type { ProblemDetails, SaleDetailView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useState } from "react";

export function SaleReceiptPanel({
  organizationId,
  sale,
  setFeedback,
}: {
  organizationId: string;
  sale: Pick<SaleDetailView, "id" | "number">;
  setFeedback: (message: string) => void;
}) {
  const [recipientEmail, setRecipientEmail] = useState("");
  const [sending, setSending] = useState(false);
  const receiptUrl = `/api/v1/organizations/${organizationId}/sales/${sale.id}/receipt`;

  async function sendReceipt(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSending(true);
    setFeedback("");
    try {
      const response = await fetch(receiptUrl, {
        body: JSON.stringify({ recipientEmail }),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      });
      const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
      if (!response.ok) {
        setFeedback(payload.detail ?? "Não foi possível enviar o comprovante.");
        return;
      }
      setFeedback(`Comprovante da venda #${sale.number} enviado para ${recipientEmail}.`);
    } finally {
      setSending(false);
    }
  }

  return (
    <section className="grid gap-3 border-t pt-5">
      <div>
        <h4 className="font-semibold">Comprovante digital</h4>
        <p className="text-sm text-slate-600">
          Abra a versão imprimível ou envie uma cópia por e-mail.
        </p>
      </div>
      <div>
        <Button
          onClick={() => window.open(receiptUrl, "_blank", "noopener,noreferrer")}
          type="button"
          variant="outline"
        >
          Abrir comprovante
        </Button>
      </div>
      <form className="flex flex-col gap-3 sm:flex-row sm:items-end" onSubmit={sendReceipt}>
        <label className="grid flex-1 gap-1 text-sm font-medium">
          E-mail do destinatário
          <Input
            autoComplete="email"
            maxLength={320}
            onChange={(event) => setRecipientEmail(event.target.value)}
            placeholder="cliente@exemplo.com"
            required
            type="email"
            value={recipientEmail}
          />
        </label>
        <Button disabled={sending} type="submit">
          {sending ? "Enviando..." : "Enviar comprovante"}
        </Button>
      </form>
    </section>
  );
}
