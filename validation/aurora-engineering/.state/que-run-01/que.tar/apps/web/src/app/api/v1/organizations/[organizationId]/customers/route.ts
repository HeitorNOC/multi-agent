import {
  createCustomerBodySchema,
  customerListQuerySchema,
  organizationParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = customerListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams.entries()),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const customers = await services.listCustomers.execute(
      { ...query, organizationId: params.organizationId },
      actor,
    );
    return Response.json({ data: customers });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const body = createCustomerBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const customer = await services.createCustomer.execute(
      {
        ...body,
        idempotencyKey: requireIdempotencyKey(request),
        organizationId: params.organizationId,
      },
      actor,
    );
    return Response.json(
      { data: customer },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/customers/${customer.id}`,
        },
        status: 201,
      },
    );
  });
}
