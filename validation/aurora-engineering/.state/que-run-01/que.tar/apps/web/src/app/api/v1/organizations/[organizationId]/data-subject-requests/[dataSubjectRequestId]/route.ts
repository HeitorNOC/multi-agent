import {
  changeDataSubjectRequestStatusBodySchema,
  dataSubjectRequestParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type Parameters = { params: Promise<{ dataSubjectRequestId: string; organizationId: string }> };
export async function PATCH(request: Request, route: Parameters) {
  return handleApiRequest(request, async (api) => {
    const params = dataSubjectRequestParamsSchema.parse(await route.params);
    const body = changeDataSubjectRequestStatusBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.customerCare.changeDataRequestStatus(
        { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}
