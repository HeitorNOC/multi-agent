import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { InventoryManagement } from "@/features/inventory/components/inventory-management";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = { title: "Estoque | Gestor" };

export default async function InventoryPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Operação
        </p>
        <h1 className="mt-2 text-3xl font-semibold">Estoque</h1>
        <p className="mt-2 text-sm text-slate-600">
          Consulte saldos por filial, defina o estoque inicial uma única vez e registre ajustes
          auditáveis.
        </p>
      </header>
      <ModuleGate moduleCode="inventory" organizationId={organizationId}>
        <InventoryManagement organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
