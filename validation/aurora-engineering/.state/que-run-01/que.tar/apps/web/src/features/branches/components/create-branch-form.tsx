"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createBranchBodySchema,
  type CreateBranchBody,
  type ProblemDetails,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useState } from "react";
import { useForm } from "react-hook-form";

type CreateBranchFormProps = {
  organizationId: string;
};

export function CreateBranchForm({ organizationId }: CreateBranchFormProps) {
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateBranchBody>({
    defaultValues: {
      document: "",
      name: "",
    },
    resolver: zodResolver(createBranchBodySchema),
  });

  const submit = handleSubmit(async (values) => {
    setSuccessMessage(null);

    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/branches`, {
        body: JSON.stringify(values),
        headers: {
          "content-type": "application/json",
          "idempotency-key": crypto.randomUUID(),
        },
        method: "POST",
      });

      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", {
          message: problem.detail,
          type: problem.code,
        });
        return;
      }

      reset();
      setSuccessMessage("Filial cadastrada com sucesso.");
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  return (
    <form className="grid gap-5" noValidate onSubmit={submit}>
      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="branch-name">
          Nome da filial
        </Label>
        <Input
          aria-describedby={errors.name ? "branch-name-error" : undefined}
          aria-invalid={Boolean(errors.name)}
          autoComplete="organization"
          className="h-11 rounded-xl bg-white px-3"
          id="branch-name"
          placeholder="Ex.: Unidade Centro"
          {...register("name")}
        />
        {errors.name ? (
          <p className="text-sm text-red-700" id="branch-name-error" role="alert">
            {errors.name.message}
          </p>
        ) : null}
      </div>

      <div className="grid gap-2">
        <Label className="text-slate-800" htmlFor="branch-document">
          CPF ou CNPJ <span className="font-normal text-slate-500">(opcional)</span>
        </Label>
        <Input
          aria-describedby={errors.document ? "branch-document-error" : undefined}
          aria-invalid={Boolean(errors.document)}
          autoComplete="off"
          className="h-11 rounded-xl bg-white px-3"
          id="branch-document"
          inputMode="numeric"
          placeholder="Somente números"
          {...register("document", {
            setValueAs: (value: string) => value.trim() || undefined,
          })}
        />
        {errors.document ? (
          <p className="text-sm text-red-700" id="branch-document-error" role="alert">
            {errors.document.message}
          </p>
        ) : null}
      </div>

      {errors.root ? (
        <div
          className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
          role="alert"
        >
          {errors.root.message}
        </div>
      ) : null}

      {successMessage ? (
        <div
          className="border-brand-100 bg-brand-50 text-brand-700 rounded-xl border px-4 py-3 text-sm"
          role="status"
        >
          {successMessage}
        </div>
      ) : null}

      <Button className="h-11 rounded-xl" disabled={isSubmitting} type="submit">
        {isSubmitting ? "Cadastrando..." : "Cadastrar filial"}
      </Button>
    </form>
  );
}
