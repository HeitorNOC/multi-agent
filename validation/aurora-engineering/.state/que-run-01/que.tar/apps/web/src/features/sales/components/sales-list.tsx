"use client";

import {
  saleDetailViewSchema,
  saleListPageSchema,
  type ProblemDetails,
  type SaleDetailView,
  type SaleSummaryView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useEffect, useState } from "react";

import { SaleDetail } from "./sale-detail";
import { statusLabel } from "./sale-format";

export function SalesList({
  onChanged,
  organizationId,
  revision,
}: {
  onChanged: () => void;
  organizationId: string;
  revision: number;
}) {
  const [sales, setSales] = useState<readonly SaleSummaryView[]>([]);
  const [selected, setSelected] = useState<SaleDetailView | null>(null);
  const [feedback, setFeedback] = useState("Carregando vendas...");
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    void requestSalesPage(organizationId, controller.signal)
      .then((page) => {
        setSales(page.data);
        setNextCursor(page.page.nextCursor);
        setFeedback("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar as vendas.",
          );
      });
    return () => controller.abort();
  }, [organizationId, revision]);

  async function loadMore(cursor: string) {
    const page = await requestSalesPage(organizationId, undefined, cursor);
    setSales((current) => [...current, ...page.data]);
    setNextCursor(page.page.nextCursor);
    setFeedback("");
  }

  async function openSale(saleId: string) {
    setFeedback("Carregando detalhes...");
    const response = await fetch(`/api/v1/organizations/${organizationId}/sales/${saleId}`);
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) {
      setFeedback(payload.detail ?? "Não foi possível carregar a venda.");
      return;
    }
    setSelected(saleDetailViewSchema.parse(payload.data));
    setFeedback("");
  }

  return (
    <section className="grid gap-5" aria-labelledby="sales-history-title">
      <div>
        <h2 className="text-2xl font-semibold" id="sales-history-title">
          Histórico de vendas
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Consulte os efeitos financeiros e cancele com estornos rastreáveis.
        </p>
      </div>
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      {selected ? (
        <SaleDetail
          onCancelled={(sale) => {
            setSelected(sale);
            onChanged();
          }}
          onReturned={async () => {
            await openSale(selected.id);
            onChanged();
          }}
          onClose={() => setSelected(null)}
          organizationId={organizationId}
          sale={selected}
          setFeedback={setFeedback}
        />
      ) : null}
      <div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b bg-slate-50 text-slate-600">
            <tr>
              <th className="px-4 py-3">Venda</th>
              <th className="px-4 py-3">Filial</th>
              <th className="px-4 py-3">Cliente</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Em aberto</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Ação</th>
            </tr>
          </thead>
          <tbody>
            {sales.map((sale) => (
              <tr className="border-b last:border-0" key={sale.id}>
                <td className="px-4 py-3 font-medium">#{sale.number}</td>
                <td className="px-4 py-3">{sale.branchName}</td>
                <td className="px-4 py-3">{sale.customerName}</td>
                <td className="px-4 py-3">R$ {sale.total}</td>
                <td className="px-4 py-3">R$ {sale.openAmount}</td>
                <td className="px-4 py-3">{statusLabel(sale.status)}</td>
                <td className="px-4 py-3">
                  <Button
                    onClick={() => void openSale(sale.id)}
                    size="sm"
                    type="button"
                    variant="outline"
                  >
                    Detalhes
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {sales.length === 0 && !feedback ? (
          <p className="p-5 text-sm text-slate-600">Nenhuma venda registrada.</p>
        ) : null}
      </div>
      {nextCursor ? (
        <div className="flex justify-center">
          <Button
            onClick={() =>
              void loadMore(nextCursor).catch((error: unknown) =>
                setFeedback(
                  error instanceof Error ? error.message : "Não foi possível carregar mais vendas.",
                ),
              )
            }
            type="button"
            variant="outline"
          >
            Carregar mais
          </Button>
        </div>
      ) : null}
    </section>
  );
}

async function requestSalesPage(organizationId: string, signal?: AbortSignal, cursor?: string) {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/sales?limit=25${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
    signal ? { signal } : undefined,
  );
  const payload = (await response.json()) as Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar as vendas.");
  return saleListPageSchema.parse(payload);
}
