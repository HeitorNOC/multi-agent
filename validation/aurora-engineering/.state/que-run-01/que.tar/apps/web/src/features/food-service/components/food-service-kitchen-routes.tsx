import type {
  FoodServiceKitchenProductRouteView,
  FoodServiceKitchenStationView,
  ProductView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

export function FoodServiceKitchenRoutes({
  branchId,
  onSave,
  products,
  routes,
  stations,
}: {
  branchId: string;
  onSave: (productId: string, kitchenStationId: string | null) => void;
  products: readonly ProductView[];
  routes: readonly FoodServiceKitchenProductRouteView[];
  stations: readonly FoodServiceKitchenStationView[];
}) {
  const activeStations = stations.filter(
    (station) => station.branchId === branchId && station.status === "ACTIVE",
  );
  const branchRoutes = routes.filter((route) => route.branchId === branchId);
  return (
    <section className="grid gap-4 rounded-xl border bg-white p-4">
      <div>
        <h2 className="font-semibold">Encaminhamento por produto</h2>
        <p className="mt-1 text-sm text-slate-600">
          Direcione produtos para uma estação específica. Sem rota, o produto usa a estação padrão
          da filial.
        </p>
      </div>
      <form
        className="grid gap-2 sm:grid-cols-3"
        onSubmit={(event) => {
          event.preventDefault();
          const form = new FormData(event.currentTarget);
          const productId = String(form.get("productId") ?? "");
          const kitchenStationId = String(form.get("kitchenStationId") ?? "");
          if (productId) onSave(productId, kitchenStationId || null);
        }}
      >
        <select className="h-10 rounded-xl border px-3" name="productId" required>
          <option value="">Selecione um produto</option>
          {products.map((product) => (
            <option key={product.id} value={product.id}>
              {product.name}
            </option>
          ))}
        </select>
        <select className="h-10 rounded-xl border px-3" name="kitchenStationId">
          <option value="">Usar estação padrão</option>
          {activeStations.map((station) => (
            <option key={station.id} value={station.id}>
              {station.name}
            </option>
          ))}
        </select>
        <Button disabled={!branchId} type="submit">
          Salvar rota
        </Button>
      </form>
      <div className="grid gap-2 sm:grid-cols-2">
        {branchRoutes.length === 0 ? (
          <p className="text-sm text-slate-600">
            Nenhum produto possui rota específica nesta filial.
          </p>
        ) : (
          branchRoutes.map((route) => {
            const product = products.find((item) => item.id === route.productId);
            const station = stations.find((item) => item.id === route.kitchenStationId);
            return (
              <div
                className="flex items-center justify-between gap-3 rounded-lg bg-slate-50 px-3 py-2 text-sm"
                key={route.productId}
              >
                <div>
                  <p className="font-semibold">{product?.name ?? "Produto"}</p>
                  <p className="text-slate-600">{station?.name ?? "Estação"}</p>
                </div>
                <Button
                  onClick={() => onSave(route.productId, null)}
                  size="sm"
                  type="button"
                  variant="outline"
                >
                  Usar padrão
                </Button>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
