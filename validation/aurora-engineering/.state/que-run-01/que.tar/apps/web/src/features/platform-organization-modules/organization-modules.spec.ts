import { describe, expect, it } from "vitest";

import { organizationModuleConfigurationSchema } from "./organization-modules";

describe("organizationModuleConfigurationSchema", () => {
  it("requires a reason for restricted access", () => {
    const result = organizationModuleConfigurationSchema.safeParse({
      expiresAt: "",
      reason: "",
      source: "ADD_ON",
      status: "READ_ONLY",
    });

    expect(result.success).toBe(false);
  });

  it("requires an expiration for temporary administrative grants", () => {
    const result = organizationModuleConfigurationSchema.safeParse({
      expiresAt: "",
      reason: "Exceção comercial aprovada",
      source: "ADMIN_GRANT",
      status: "ENABLED",
    });

    expect(result.success).toBe(false);
  });
});
