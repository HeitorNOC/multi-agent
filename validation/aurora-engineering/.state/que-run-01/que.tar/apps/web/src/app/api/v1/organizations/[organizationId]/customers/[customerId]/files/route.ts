import { customerParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { readCatalogFileUpload } from "@/lib/server/catalog-file-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ organizationId: string; customerId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = customerParamsSchema.parse(await route.params);
    const actor = await resolveActor(request, api, params.organizationId);
    return Response.json({
      data: await services.listCatalogFiles.execute(
        {
          entityId: params.customerId,
          entityType: "CUSTOMER",
          organizationId: params.organizationId,
        },
        actor,
      ),
    });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const params = customerParamsSchema.parse(await route.params);
      const upload = await readCatalogFileUpload(request);
      const actor = await resolveActor(request, api, params.organizationId);
      const file = await services.uploadCatalogFile.execute(
        {
          ...upload,
          entityId: params.customerId,
          entityType: "CUSTOMER",
          idempotencyKey: requireIdempotencyKey(request),
          organizationId: params.organizationId,
        },
        actor,
      );
      return Response.json({ data: file }, { status: 201 });
    },
    { rateLimit: apiRateLimitPolicies.fileUpload },
  );
}

async function resolveActor(
  request: Request,
  api: { correlationId: string; requestId: string },
  organizationId: string,
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({ ...api, organizationId, userId: identity.userId });
}
