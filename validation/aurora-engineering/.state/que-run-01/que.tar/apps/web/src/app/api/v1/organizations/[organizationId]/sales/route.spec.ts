import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, completeSale, listSales, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  completeSale: vi.fn(),
  listSales: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    completeSale: { execute: completeSale },
    identityProvider: { authenticate },
    listSales: { execute: listSales },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const branchId = "20000000-0000-4000-8000-000000000002";
const productId = "20000000-0000-4000-8000-000000000003";
const revenueCategoryId = "20000000-0000-4000-8000-000000000004";
const sale = { id: "20000000-0000-4000-8000-000000000005", number: 42 };
const route = { params: Promise.resolve({ organizationId }) };

describe("sales collection routes", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    completeSale.mockReset().mockResolvedValue(sale);
    listSales.mockReset().mockResolvedValue({ data: [sale], page: { nextCursor: null } });
  });

  it("applies query filters to tenant-scoped sales", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/sales?limit=10&status=COMPLETED`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(200);
    expect(listSales).toHaveBeenCalledWith(
      { limit: 10, organizationId, status: "COMPLETED" },
      { role: "OWNER" },
    );
  });

  it("completes a direct sale with the external idempotency key", async () => {
    const body = {
      branchId,
      customerId: null,
      discountAmount: "0",
      dueDate: "2026-08-12",
      items: [{ productId, quantity: "2" }],
      revenueCategoryId,
    };
    const request = new Request(`http://localhost/api/v1/organizations/${organizationId}/sales`, {
      body: JSON.stringify(body),
      headers: { "content-type": "application/json", "idempotency-key": "sale-key" },
      method: "POST",
    });
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(response.headers.get("location")).toContain(sale.id);
    expect(completeSale).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "sale-key", organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects a sale without items after centralized authentication", async () => {
    const request = new Request(`http://localhost/api/v1/organizations/${organizationId}/sales`, {
      body: JSON.stringify({
        branchId,
        customerId: null,
        discountAmount: "0",
        dueDate: "2026-08-12",
        items: [],
        revenueCategoryId,
      }),
      headers: { "content-type": "application/json", "idempotency-key": "sale-key" },
      method: "POST",
    });
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(completeSale).not.toHaveBeenCalled();
  });
});
