import type { CreateServiceBody } from "@gestor/contracts";

export const serviceDefaults: CreateServiceBody = {
  categoryId: null,
  code: "",
  defaultPrice: "0",
  durationMinutes: 30,
  name: "",
  nationalNfse: null,
  professionalUserIds: [],
};

export function nullableServiceValue(value: unknown) {
  return String(value ?? "").trim() || null;
}
