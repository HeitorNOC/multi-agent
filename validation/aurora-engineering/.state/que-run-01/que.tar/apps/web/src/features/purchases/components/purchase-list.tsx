"use client";

import {
  purchaseDetailViewSchema,
  purchaseListPageSchema,
  type ProblemDetails,
  type PurchaseDetailView,
  type PurchaseSummaryView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useEffect, useState } from "react";

import { PurchaseWorkflowActions } from "./purchase-workflow-actions";
import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

const labels = {
  CANCELLED: "Cancelada",
  DRAFT: "Rascunho",
  ORDERED: "Pedida",
  PARTIALLY_RECEIVED: "Recebida parcialmente",
  RECEIVED: "Recebida",
} as const;

export function PurchaseList({
  onChanged,
  organizationId,
  revision,
}: {
  onChanged: () => void;
  organizationId: string;
  revision: number;
}) {
  const [purchases, setPurchases] = useState<readonly PurchaseSummaryView[]>([]);
  const [selected, setSelected] = useState<PurchaseDetailView | null>(null);
  const [reason, setReason] = useState("");
  const [feedback, setFeedback] = useState("Carregando compras...");
  const [nextCursor, setNextCursor] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    void requestPage(organizationId, controller.signal)
      .then((page) => {
        setPurchases(page.data);
        setNextCursor(page.page.nextCursor);
        setFeedback("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar as compras.",
          );
      });
    return () => controller.abort();
  }, [organizationId, revision]);

  async function open(purchaseId: string) {
    const response = await fetch(`/api/v1/organizations/${organizationId}/purchases/${purchaseId}`);
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível carregar a compra.");
    setSelected(purchaseDetailViewSchema.parse(payload.data));
    setReason("");
    setFeedback("");
  }

  async function cancel() {
    if (!selected || reason.trim().length < 3)
      return setFeedback("Informe um motivo com pelo menos 3 caracteres.");
    const response = await fetch(
      `/api/v1/organizations/${organizationId}/purchases/${selected.id}/cancel`,
      {
        body: JSON.stringify({ expectedUpdatedAt: selected.updatedAt, reason }),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      },
    );
    const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
    if (!response.ok) return setFeedback(payload.detail ?? "Não foi possível cancelar a compra.");
    setSelected(purchaseDetailViewSchema.parse(payload.data));
    setFeedback("Compra cancelada com compensações de estoque e financeiro.");
    onChanged();
  }

  return (
    <section className="grid gap-5" aria-labelledby="purchase-history-title">
      <div>
        <h2 className="text-2xl font-semibold" id="purchase-history-title">
          Histórico de compras
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Consulte estoque, conta a pagar e cancelamentos compensatórios.
        </p>
      </div>
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      {selected ? (
        <div className="grid gap-4 rounded-2xl border bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold">Compra #{selected.number}</h3>
              <p className="text-sm text-slate-600">
                {selected.supplierName} · {selected.branchName}
              </p>
            </div>
            <div className="flex gap-2">
              <CatalogFilesButton
                allowImage={false}
                itemId={selected.id}
                organizationId={organizationId}
                segment="purchases"
              />
              <Button onClick={() => setSelected(null)} type="button" variant="outline">
                Fechar
              </Button>
            </div>
          </div>
          <dl className="grid gap-3 text-sm sm:grid-cols-3">
            <div>
              <dt className="text-slate-500">Total</dt>
              <dd>R$ {selected.total}</dd>
            </div>
            <div>
              <dt className="text-slate-500">Em aberto</dt>
              <dd>
                R${" "}
                {selected.payables
                  .reduce((sum, item) => sum + Number(item.openAmount), 0)
                  .toFixed(2)}
              </dd>
            </div>
            <div>
              <dt className="text-slate-500">Status</dt>
              <dd>{labels[selected.status]}</dd>
            </div>
          </dl>
          <ul className="grid gap-2 text-sm">
            {selected.items.map((item) => (
              <li className="rounded-lg bg-slate-50 p-3" key={item.id}>
                {item.description}: {item.quantityReceived} × R$ {item.unitCost}
              </li>
            ))}
          </ul>
          <PurchaseWorkflowActions
            onChanged={(purchase, message) => {
              setSelected(purchase);
              setFeedback(message);
              onChanged();
            }}
            organizationId={organizationId}
            purchase={selected}
          />
          {selected.status !== "CANCELLED" ? (
            <div className="flex flex-col gap-3 border-t pt-4 sm:flex-row">
              <Input
                aria-label="Motivo do cancelamento"
                onChange={(event) => setReason(event.target.value)}
                placeholder="Motivo do cancelamento"
                value={reason}
              />
              <Button onClick={() => void cancel()} type="button" variant="destructive">
                Cancelar compra
              </Button>
            </div>
          ) : null}
        </div>
      ) : null}
      <div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b bg-slate-50 text-slate-600">
            <tr>
              <th className="px-4 py-3">Compra</th>
              <th className="px-4 py-3">Fornecedor</th>
              <th className="px-4 py-3">Filial</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Em aberto</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Ação</th>
            </tr>
          </thead>
          <tbody>
            {purchases.map((purchase) => (
              <tr className="border-b last:border-0" key={purchase.id}>
                <td className="px-4 py-3 font-medium">#{purchase.number}</td>
                <td className="px-4 py-3">{purchase.supplierName}</td>
                <td className="px-4 py-3">{purchase.branchName}</td>
                <td className="px-4 py-3">R$ {purchase.total}</td>
                <td className="px-4 py-3">R$ {purchase.openAmount}</td>
                <td className="px-4 py-3">{labels[purchase.status]}</td>
                <td className="px-4 py-3">
                  <Button
                    onClick={() => void open(purchase.id)}
                    size="sm"
                    type="button"
                    variant="outline"
                  >
                    Detalhes
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {purchases.length === 0 && !feedback ? (
          <p className="p-5 text-sm text-slate-600">Nenhuma compra registrada.</p>
        ) : null}
      </div>
      {nextCursor ? (
        <div className="flex justify-center">
          <Button
            onClick={() =>
              void requestPage(organizationId, undefined, nextCursor).then((page) => {
                setPurchases((current) => [...current, ...page.data]);
                setNextCursor(page.page.nextCursor);
              })
            }
            type="button"
            variant="outline"
          >
            Carregar mais
          </Button>
        </div>
      ) : null}
    </section>
  );
}

async function requestPage(organizationId: string, signal?: AbortSignal, cursor?: string) {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/purchases?limit=25${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
    signal ? { signal } : undefined,
  );
  const payload = (await response.json()) as Partial<ProblemDetails>;
  if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar as compras.");
  return purchaseListPageSchema.parse(payload);
}
