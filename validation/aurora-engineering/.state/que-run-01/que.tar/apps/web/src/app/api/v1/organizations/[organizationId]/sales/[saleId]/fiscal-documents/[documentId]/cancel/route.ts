import {
  cancelFiscalDocumentBodySchema,
  fiscalDocumentResourceParamsSchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ documentId: string; organizationId: string; saleId: string }>;
};

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = fiscalDocumentResourceParamsSchema.parse(await route.params);
    const body = cancelFiscalDocumentBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.cancelFiscalDocument.execute(
        { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
        actor,
      ),
    });
  });
}
