import { describe, expect, it, vi } from "vitest";
import { z } from "zod";

import { fetchData } from "./direct-sale-data";

describe("fetchData", () => {
  it("uses the operational fallback when an unavailable route returns HTML", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response("<!doctype html><title>Not found</title>", { status: 404 })),
    );

    await expect(
      fetchData("/missing", z.array(z.string()), new AbortController().signal),
    ).rejects.toThrow("Não foi possível carregar os dados.");
  });
});
