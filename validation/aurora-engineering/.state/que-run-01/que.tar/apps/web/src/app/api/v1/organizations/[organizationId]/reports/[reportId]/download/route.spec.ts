import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createReportDownload, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createReportDownload: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    createReportDownload: { execute: createReportDownload },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const reportId = "30000000-0000-4000-8000-000000000002";

describe("report download route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    createReportDownload.mockReset().mockResolvedValue({
      expiresAt: "2026-08-13T20:01:00.000Z",
      url: "https://signed.example",
    });
  });

  it("returns only a short-lived signed URL", async () => {
    const response = await GET(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/reports/${reportId}/download`,
      ),
      { params: Promise.resolve({ organizationId, reportId }) },
    );

    expect(response.status).toBe(200);
    expect(createReportDownload).toHaveBeenCalledWith(
      { organizationId, reportId },
      { role: "OWNER" },
    );
  });
});
