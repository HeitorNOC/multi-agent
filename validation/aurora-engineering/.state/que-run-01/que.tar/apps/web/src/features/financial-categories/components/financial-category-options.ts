import type { FinancialCategoryType } from "@gestor/contracts";

export const financialCategoryTypeLabels: Record<FinancialCategoryType, string> = {
  COST: "Custo",
  EXPENSE: "Despesa",
  OTHER: "Outra",
  REVENUE: "Receita",
  TAX: "Imposto",
};

export const financialCategoryTypeDescriptions: Record<FinancialCategoryType, string> = {
  COST: "Gasto diretamente ligado ao que a empresa vende.",
  EXPENSE: "Gasto necessário para manter a empresa funcionando.",
  OTHER: "Classificação excepcional que não se encaixa nos demais tipos.",
  REVENUE: "Entrada gerada pelas atividades da empresa.",
  TAX: "Tributo ou encargo fiscal.",
};

export const financialCategoryTypeOptions: readonly [FinancialCategoryType, string][] = [
  ["REVENUE", financialCategoryTypeLabels.REVENUE],
  ["COST", financialCategoryTypeLabels.COST],
  ["EXPENSE", financialCategoryTypeLabels.EXPENSE],
  ["TAX", financialCategoryTypeLabels.TAX],
  ["OTHER", financialCategoryTypeLabels.OTHER],
];

export const financialOutflowCategoryTypes = new Set<FinancialCategoryType>([
  "COST",
  "EXPENSE",
  "TAX",
]);
