import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { CatalogConfigurations } from "@/features/catalog/components/catalog-configurations";
import { CustomFieldConfigurations } from "@/features/custom-fields/components/custom-field-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = { title: "Catálogo | Gestor" };
export default async function CatalogPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 text-sm font-semibold"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Operação
        </p>
        <h1 className="mt-2 text-3xl font-semibold">Catálogo</h1>
        <p className="mt-2 text-sm text-slate-600">
          Cadastre categorias, produtos e serviços usados nas próximas vendas, compras e
          movimentações.
        </p>
      </header>
      <ModuleGate moduleCode="catalog" organizationId={organizationId}>
        <div>
          <CatalogConfigurations organizationId={organizationId} />
          <CustomFieldConfigurations entity="PRODUCT" organizationId={organizationId} />
          <CustomFieldConfigurations entity="SERVICE" organizationId={organizationId} />
        </div>
      </ModuleGate>
    </main>
  );
}
