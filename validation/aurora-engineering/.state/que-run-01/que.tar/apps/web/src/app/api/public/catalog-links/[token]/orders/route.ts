import { createPublicOrderBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ token: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { token } = await route.params;
      const identity = await authenticateApiRequest(request);
      const link = await services.resolvePublicCatalogPortalLink.execute(token);
      const actor = await services.resolveCustomerPortalActor.execute({
        correlationId: api.correlationId,
        organizationId: link.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });
      return Response.json({ data: await services.listPublicOrders.execute(actor) });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { token } = await route.params;
      const body = createPublicOrderBodySchema.parse(await readJsonBody(request));
      const idempotencyKey = requireIdempotencyKey(request);
      const identity = await authenticateApiRequest(request);
      const link = await services.resolvePublicCatalogPortalLink.execute(token);
      const actor = await services.resolveCustomerPortalActor.execute({
        correlationId: api.correlationId,
        organizationId: link.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });

      const order = await services.createPublicOrder.execute(
        { ...body, branchId: link.branchId, idempotencyKey, linkId: link.id },
        actor,
      );
      return Response.json({ data: order }, { status: 201 });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}
