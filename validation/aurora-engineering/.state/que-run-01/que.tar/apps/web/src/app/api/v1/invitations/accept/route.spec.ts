import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { acceptInvitation, authenticate } = vi.hoisted(() => ({
  acceptInvitation: vi.fn(),
  authenticate: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    acceptOrganizationInvitation: { execute: acceptInvitation },
    identityProvider: { authenticate },
  },
}));

import { POST } from "./route";

describe("accept organization invitation route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    acceptInvitation.mockReset().mockResolvedValue({
      membershipId: crypto.randomUUID(),
      organizationId: "20000000-0000-4000-8000-000000000001",
    });
  });

  it("passes the opaque token only to the acceptance use case", async () => {
    const body = {
      organizationId: "20000000-0000-4000-8000-000000000001",
      token: "a".repeat(43),
    };
    const response = await POST(
      new Request("http://localhost/api/v1/invitations/accept", {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json" },
        method: "POST",
      }),
    );
    expect(response.status).toBe(200);
    expect(acceptInvitation).toHaveBeenCalledWith(
      body,
      expect.objectContaining({ userId: "user-1" }),
    );
    expect(authenticate).toHaveBeenCalledOnce();
  });
});
