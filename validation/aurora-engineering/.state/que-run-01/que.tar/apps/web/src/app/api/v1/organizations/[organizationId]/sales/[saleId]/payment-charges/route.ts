import { salePaymentChargeParamsSchema, startTerminalPaymentBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string; saleId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = salePaymentChargeParamsSchema.parse(await route.params);
    const actor = await tenantActor(request, api, params.organizationId);
    return Response.json({ data: await services.listPaymentCharges.execute(params, actor) });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = salePaymentChargeParamsSchema.parse(await route.params);
    const body = startTerminalPaymentBodySchema.parse(await readJsonBody(request));
    const actor = await tenantActor(request, api, params.organizationId);
    return Response.json(
      {
        data: await services.startTerminalPayment.execute(
          { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
          actor,
        ),
      },
      { status: 201 },
    );
  });
}

async function tenantActor(
  request: Request,
  api: { correlationId: string; requestId: string },
  organizationId: string,
) {
  const identity = await authenticateApiRequest(request);
  return services.resolveTenantActor.execute({
    correlationId: api.correlationId,
    organizationId,
    requestId: api.requestId,
    userId: identity.userId,
  });
}
