type LoadingSkeletonProps = {
  className?: string;
};

export function LoadingSkeleton({ className = "" }: LoadingSkeletonProps) {
  return (
    <div aria-hidden="true" className={`animate-pulse rounded-lg bg-slate-200 ${className}`} />
  );
}

export function LoadingRows({ rows = 3 }: { rows?: number }) {
  return (
    <div aria-label="Carregando conteúdo" aria-live="polite" className="grid gap-3" role="status">
      {Array.from({ length: rows }, (_, index) => (
        <div className="rounded-2xl border bg-white p-4" key={index}>
          <LoadingSkeleton className="h-4 w-2/5" />
          <LoadingSkeleton className="mt-3 h-3 w-3/5" />
        </div>
      ))}
    </div>
  );
}
