"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createProductBodySchema,
  productViewSchema,
  supplierListSchema,
  type CreateProductBody,
  type ProductView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { CatalogSection, ErrorText, Field, ItemList } from "./catalog-layout";
import {
  active,
  mergeSupplierChoices,
  money,
  patch,
  post,
  setProblem,
  toggle,
} from "./catalog-helpers";
import type { CatalogSectionProps } from "./catalog-types";

export function ProductSection({
  organizationId,
  setFeedback,
  setState,
  state,
}: CatalogSectionProps) {
  const [editing, setEditing] = useState<ProductView | null>(null);
  const [supplierChoices, setSupplierChoices] = useState<readonly { id: string; name: string }[]>(
    [],
  );
  const defaults: CreateProductBody = {
    categoryId: null,
    defaultPrice: "0",
    kind: "STOCKABLE",
    minimumStock: "0",
    name: "",
    sku: "",
    suppliers: [],
    unit: "UN",
  };
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateProductBody>({
    defaultValues: defaults,
    resolver: zodResolver(createProductBodySchema),
  });
  const selectedSuppliers = useWatch({ control, name: "suppliers" });
  const submit = handleSubmit(async (values) => {
    const response = editing
      ? await patch(`/api/v1/organizations/${organizationId}/products/${editing.id}`, {
          ...values,
          expectedUpdatedAt: editing.updatedAt,
        })
      : await post(`/api/v1/organizations/${organizationId}/products`, values);
    if (!response.ok) return setProblem(response, setError);
    const product = productViewSchema.parse(((await response.json()) as { data: unknown }).data);
    setState((current) =>
      current
        ? {
            ...current,
            products: editing
              ? current.products.map((item) => (item.id === product.id ? product : item))
              : [...current.products, product],
          }
        : current,
    );
    setEditing(null);
    reset(defaults);
    setFeedback(editing ? "Produto atualizado." : "Produto cadastrado.");
  });
  function beginEditing(product: ProductView) {
    setEditing(product);
    setSupplierChoices((current) =>
      mergeSupplierChoices(
        current,
        product.suppliers.map((item) => ({ id: item.supplierId, name: item.supplierName })),
      ),
    );
    reset({
      barcode: product.barcode ?? "",
      categoryId: product.categoryId,
      defaultPrice: product.defaultPrice,
      description: product.description ?? "",
      kind: product.kind,
      minimumStock: product.minimumStock,
      name: product.name,
      sku: product.sku,
      suppliers: product.suppliers.map(({ isPrimary, supplierId, supplierSku }) => ({
        isPrimary,
        supplierId,
        supplierSku: supplierSku ?? "",
      })),
      unit: product.unit,
    });
  }
  async function loadSuppliers() {
    const response = await fetch(`/api/v1/organizations/${organizationId}/suppliers`);
    if (!response.ok)
      return setFeedback(
        "Fornecedores indisponíveis. Verifique se o módulo CRM está habilitado e se você possui permissão.",
      );
    const payload = (await response.json()) as { data: unknown };
    setSupplierChoices(
      supplierListSchema.parse(payload.data).map(({ id, name }) => ({ id, name })),
    );
  }
  function toggleSupplier(supplierId: string) {
    const current = selectedSuppliers ?? [];
    const exists = current.some((item) => item.supplierId === supplierId);
    setValue(
      "suppliers",
      exists
        ? current.filter((item) => item.supplierId !== supplierId)
        : [...current, { isPrimary: false, supplierId, supplierSku: "" }],
      { shouldDirty: true, shouldValidate: true },
    );
  }
  function choosePrimarySupplier(supplierId: string) {
    setValue(
      "suppliers",
      (selectedSuppliers ?? []).map((item) => ({
        ...item,
        isPrimary: item.supplierId === supplierId,
      })),
      { shouldDirty: true, shouldValidate: true },
    );
  }
  return (
    <CatalogSection
      title="Produtos"
      description="O custo não é digitado aqui: ele será calculado por produto e filial no estoque."
    >
      <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" onSubmit={submit}>
        <Field error={errors.name?.message} id="product-name" label="Nome">
          <Input id="product-name" {...register("name")} />
        </Field>
        <Field error={errors.sku?.message} id="product-sku" label="SKU">
          <Input id="product-sku" {...register("sku")} />
        </Field>
        <Field error={errors.barcode?.message} id="product-barcode" label="Código de barras">
          <Input id="product-barcode" {...register("barcode")} />
        </Field>
        <Field id="product-category" label="Categoria">
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="product-category"
            {...register("categoryId", { setValueAs: (value) => value || null })}
          >
            <option value="">Sem categoria</option>
            {state.categories.filter(active).map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </Field>
        <Field error={errors.defaultPrice?.message} id="product-price" label="Preço padrão">
          <Input id="product-price" inputMode="decimal" {...register("defaultPrice")} />
        </Field>
        <Field error={errors.minimumStock?.message} id="product-minimum" label="Estoque mínimo">
          <Input id="product-minimum" inputMode="decimal" {...register("minimumStock")} />
        </Field>
        <Field error={errors.unit?.message} id="product-unit" label="Unidade">
          <Input id="product-unit" {...register("unit")} />
        </Field>
        <Field id="product-kind" label="Controle">
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="product-kind"
            {...register("kind")}
          >
            <option value="STOCKABLE">Controlar estoque</option>
            <option value="NON_STOCKABLE">Sem estoque</option>
          </select>
        </Field>
        <Field error={errors.description?.message} id="product-description" label="Descrição">
          <textarea
            className="min-h-20 rounded-xl border px-3 py-2 text-sm"
            id="product-description"
            {...register("description")}
          />
        </Field>
        <div className="grid gap-3 sm:col-span-2 lg:col-span-3">
          <div className="flex items-center justify-between">
            <Label>Fornecedores</Label>
            <Button onClick={() => void loadSuppliers()} type="button" variant="outline">
              Carregar fornecedores
            </Button>
          </div>
          {supplierChoices.length ? (
            <div className="flex flex-wrap gap-3">
              {supplierChoices.map((supplier) => (
                <label className="flex items-center gap-2 text-sm" key={supplier.id}>
                  <input
                    checked={(selectedSuppliers ?? []).some(
                      (item) => item.supplierId === supplier.id,
                    )}
                    onChange={() => toggleSupplier(supplier.id)}
                    type="checkbox"
                  />
                  {supplier.name}
                </label>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500">
              O catálogo funciona sem CRM; carregue fornecedores somente quando precisar
              vinculá-los.
            </p>
          )}
          {(selectedSuppliers ?? []).length ? (
            <label className="grid max-w-sm gap-2 text-sm">
              Fornecedor principal
              <select
                className="h-10 rounded-xl border bg-white px-3"
                onChange={(event) => choosePrimarySupplier(event.target.value)}
                value={
                  (selectedSuppliers ?? []).find((supplier) => supplier.isPrimary)?.supplierId ?? ""
                }
              >
                <option value="">Nenhum</option>
                {supplierChoices
                  .filter((supplier) =>
                    (selectedSuppliers ?? []).some(
                      (selected) => selected.supplierId === supplier.id,
                    ),
                  )
                  .map((supplier) => (
                    <option key={supplier.id} value={supplier.id}>
                      {supplier.name}
                    </option>
                  ))}
              </select>
            </label>
          ) : null}
        </div>
        <div className="sm:col-span-2 lg:col-span-4">
          <div className="flex gap-2">
            <Button disabled={isSubmitting} type="submit">
              {editing ? "Salvar produto" : "Cadastrar produto"}
            </Button>
            {editing ? (
              <Button
                onClick={() => {
                  setEditing(null);
                  reset(defaults);
                }}
                type="button"
                variant="outline"
              >
                Cancelar
              </Button>
            ) : null}
          </div>
          {errors.root ? <ErrorText>{errors.root.message}</ErrorText> : null}
        </div>
      </form>
      <ItemList
        items={state.products}
        onEdit={beginEditing}
        onToggle={(product) =>
          void toggle(
            "products",
            product,
            organizationId,
            productViewSchema,
            (updated) =>
              setState((current) =>
                current
                  ? {
                      ...current,
                      products: current.products.map((item) =>
                        item.id === updated.id ? updated : item,
                      ),
                    }
                  : current,
              ),
            setFeedback,
          )
        }
        secondary={(product) =>
          `${product.sku} · R$ ${money(product.defaultPrice)} · ${product.unit}`
        }
        priceHistory={{ organizationId, segment: "products" }}
        files={{ allowImage: true, organizationId, segment: "products" }}
      />
    </CatalogSection>
  );
}
