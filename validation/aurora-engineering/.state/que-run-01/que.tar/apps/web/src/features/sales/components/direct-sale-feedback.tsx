import type { CompletedSaleView } from "@gestor/contracts";

export function DirectSaleFeedback({
  completed,
  feedback,
}: {
  completed: CompletedSaleView | null;
  feedback: string;
}) {
  return (
    <>
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      {completed ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-sm">
          <p className="font-semibold">Total: R$ {completed.total}</p>
          <p>Em aberto: R$ {completed.receivable.openAmount}</p>
          <p>Vencimento: {completed.receivable.dueDate}</p>
        </div>
      ) : null}
    </>
  );
}
