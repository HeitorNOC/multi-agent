import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createTransfer, listTransfers, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createTransfer: vi.fn(),
  listTransfers: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    createFinancialTransfer: { execute: createTransfer },
    identityProvider: { authenticate },
    listFinancialTransfers: { execute: listTransfers },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
const sourceAccountId = "10000000-0000-4000-8000-000000000002";
const targetAccountId = "10000000-0000-4000-8000-000000000003";
const transfer = { id: "10000000-0000-4000-8000-000000000004" };
const route = { params: Promise.resolve({ organizationId }) };

describe("financial transfer routes", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    createTransfer.mockReset().mockResolvedValue(transfer);
    listTransfers.mockReset().mockResolvedValue({ data: [transfer], page: { nextCursor: null } });
  });

  it("parses pagination and lists transfers inside the tenant", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-transfers?limit=20`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(200);
    expect(listTransfers).toHaveBeenCalledWith({ limit: 20, organizationId }, { role: "OWNER" });
    await expect(response.json()).resolves.toEqual({
      data: [transfer],
      page: { nextCursor: null },
    });
  });

  it("creates an atomic transfer with idempotency", async () => {
    const body = { amount: "125,50", sourceAccountId, targetAccountId };
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-transfers`,
      {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "transfer-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(201);
    expect(response.headers.get("location")).toContain(transfer.id);
    expect(createTransfer).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "transfer-key", organizationId },
      { role: "OWNER" },
    );
  });

  it("rejects equal source and target accounts after centralized authentication", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/financial-transfers`,
      {
        body: JSON.stringify({
          amount: "10",
          sourceAccountId,
          targetAccountId: sourceAccountId,
        }),
        headers: { "content-type": "application/json", "idempotency-key": "transfer-key" },
        method: "POST",
      },
    );
    const response = await POST(request, route);

    expect(response.status).toBe(400);
    expect(authenticate).toHaveBeenCalledOnce();
    expect(createTransfer).not.toHaveBeenCalled();
  });
});
