"use client";

import Link from "next/link";

import { resolveModuleAccessPresentation } from "../module-access";
import { useOrganizationModules } from "../use-organization-modules";

type OrganizationNavigationProps = {
  organizationId: string;
};

const moduleLinks = [
  { href: "users", label: "Usuários", moduleCode: "core" },
  { href: "customers", label: "Clientes", moduleCode: "crm" },
  { href: "agenda", label: "Agenda", moduleCode: "scheduling" },
  { href: "food-service", label: "Alimentação", moduleCode: "food_service" },
  { href: "suppliers", label: "Fornecedores", moduleCode: "crm" },
  { href: "catalog", label: "Catálogo", moduleCode: "catalog" },
  { href: "inventory", label: "Estoque", moduleCode: "inventory" },
  { href: "sales", label: "Vendas", moduleCode: "sales" },
  { href: "purchases", label: "Compras", moduleCode: "purchases" },
  { href: "cash-registers", label: "Operar caixa", moduleCode: "financial" },
  { href: "bank-accounts", label: "Identificar bancos", moduleCode: "banking" },
  { href: "bank-transactions", label: "Importar extrato", moduleCode: "banking" },
  { href: "financial-transfers", label: "Transferir entre contas", moduleCode: "financial" },
  { href: "reports", label: "Relatórios", moduleCode: "reporting" },
  { href: "fiscal", label: "Fiscal", moduleCode: "fiscal" },
  { href: "help-support", label: "Ajuda e suporte", moduleCode: "core" },
] as const;

export function OrganizationNavigation({ organizationId }: OrganizationNavigationProps) {
  const state = useOrganizationModules(organizationId);

  if (state.status === "LOADING") {
    return <p className="text-sm text-slate-500">Carregando atalhos...</p>;
  }

  if (state.status === "ERROR") {
    return (
      <p className="text-sm text-red-700" role="alert">
        {state.message}
      </p>
    );
  }

  const availableLinks = moduleLinks.filter(
    ({ moduleCode }) =>
      resolveModuleAccessPresentation(state.modules, moduleCode).mode !== "DISABLED",
  );

  return (
    <nav aria-label="Atalhos da empresa" className="flex flex-wrap gap-4">
      <Link
        className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
        href={`/organizations/${organizationId}`}
      >
        Visão geral
      </Link>
      {availableLinks.map(({ href, label }) => (
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}/settings/${href}`}
          key={href}
        >
          {label}
        </Link>
      ))}
      <Link
        className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
        href="/"
      >
        Voltar ao início
      </Link>{" "}
      <Link
        className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
        href="/seguranca"
      >
        Segurança da conta
      </Link>
    </nav>
  );
}
