"use client";

import {
  branchListSchema,
  purchaseSuggestionListSchema,
  stockBalanceListSchema,
  stockMovementListSchema,
  type BranchView,
  type ProblemDetails,
  type PurchaseSuggestionView,
  type StockBalanceView,
  type StockMovementView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Label } from "@gestor/ui/components/label";
import { useCallback, useEffect, useState } from "react";

import { AdjustmentForm, InitialStockForm } from "./adjust-stock";
import { InventoryCountForm } from "./count-inventory";
import { DailyInventoryCount } from "./daily-inventory-count";
import { StockTransferForm } from "./transfer-stock";

function formatQuantity(value: string, unit: string): string {
  const quantity = Number(value);
  const formatted = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(quantity);

  if (unit === "UN") return `${formatted} ${Math.abs(quantity) === 1 ? "unidade" : "unidades"}`;
  return `${formatted} ${unit.toLocaleLowerCase("pt-BR")}`;
}

function movementLabel(type: StockMovementView["type"]): string {
  const labels: Partial<Record<StockMovementView["type"], string>> = {
    ADJUSTMENT: "Ajuste de estoque",
    CUSTOMER_RETURN: "Devolução de cliente",
    FOOD_SERVICE_CONSUMPTION: "Consumo na cozinha",
    FOOD_SERVICE_CONSUMPTION_REVERSAL: "Devolução da cozinha",
    IMPLEMENTATION: "Saldo inicial",
    INVENTORY: "Conferência de estoque",
    LOSS: "Perda",
    PURCHASE_RECEIPT: "Recebimento de compra",
    SALE_ISSUE: "Saída por venda",
    SUPPLIER_RETURN: "Devolução ao fornecedor",
    TRANSFER_IN: "Transferência recebida",
    TRANSFER_OUT: "Transferência enviada",
  };
  return labels[type] ?? type;
}

export function InventoryManagement({ organizationId }: { organizationId: string }) {
  const [balances, setBalances] = useState<readonly StockBalanceView[]>([]);
  const [movements, setMovements] = useState<readonly StockMovementView[]>([]);
  const [suggestions, setSuggestions] = useState<readonly PurchaseSuggestionView[]>([]);
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [branchId, setBranchId] = useState("");
  const [query, setQuery] = useState("");
  const [feedback, setFeedback] = useState("Carregando estoque...");
  const [selected, setSelected] = useState<StockBalanceView | null>(null);
  const [operation, setOperation] = useState<"ADJUST" | "COUNT" | "TRANSFER">("ADJUST");

  const loadBalances = useCallback(
    async (selectedBranchId: string, search = "", signal?: AbortSignal) => {
      const options = signal ? { signal } : undefined;
      const base = `/api/v1/organizations/${organizationId}/branches/${selectedBranchId}`;
      const queryString = new URLSearchParams({ limit: "100" });
      if (search.trim()) queryString.set("q", search.trim());
      const [balanceResponse, movementResponse, suggestionResponse] = await Promise.all([
        fetch(`${base}/stock-balances?${queryString}`, options),
        fetch(`${base}/stock-movements?limit=30`, options),
        fetch(`${base}/purchase-suggestions?${queryString}`, options),
      ]);
      const [balancePayload, movementPayload, suggestionPayload] = (await Promise.all([
        balanceResponse.json(),
        movementResponse.json(),
        suggestionResponse.json(),
      ])) as [
        { data?: unknown } & Partial<ProblemDetails>,
        { data?: unknown } & Partial<ProblemDetails>,
        { data?: unknown } & Partial<ProblemDetails>,
      ];
      if (!balanceResponse.ok)
        throw new Error(balancePayload.detail ?? "Não foi possível carregar o estoque.");
      if (!movementResponse.ok)
        throw new Error(
          (movementPayload as Partial<ProblemDetails>).detail ??
            "Não foi possível carregar o histórico.",
        );
      if (!suggestionResponse.ok)
        throw new Error(suggestionPayload.detail ?? "Não foi possível carregar as sugestões.");
      setBalances(stockBalanceListSchema.parse(balancePayload.data));
      setMovements(stockMovementListSchema.parse(movementPayload.data));
      setSuggestions(purchaseSuggestionListSchema.parse(suggestionPayload.data));
      setFeedback("");
    },
    [organizationId],
  );

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/branches`, {
          signal: controller.signal,
        });
        const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
        if (!response.ok)
          throw new Error(payload.detail ?? "Não foi possível carregar as filiais.");
        const available = branchListSchema
          .parse(payload.data)
          .filter(({ status }) => status === "ACTIVE");
        setBranches(available);
        const first = available[0];
        if (!first) {
          setFeedback("Cadastre uma filial ativa antes de controlar o estoque.");
          return;
        }
        setBranchId(first.id);
        await loadBalances(first.id, "", controller.signal);
      } catch (error) {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar o estoque.",
          );
      }
    }
    void load();
    return () => controller.abort();
  }, [loadBalances, organizationId]);

  async function changeBranch(nextBranchId: string) {
    setBranchId(nextBranchId);
    setSelected(null);
    setFeedback("Carregando estoque...");
    try {
      await loadBalances(nextBranchId, query);
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Não foi possível carregar o estoque.");
    }
  }

  function acceptChangedBalance(changed: StockBalanceView) {
    setBalances((current) =>
      current.map((balance) => (balance.productId === changed.productId ? changed : balance)),
    );
    setSelected(null);
    setFeedback("Estoque atualizado com segurança.");
  }

  return (
    <section className="grid gap-6">
      <div className="rounded-2xl border bg-white p-5 shadow-sm">
        <Label htmlFor="inventory-branch">Filial</Label>
        <select
          className="mt-2 w-full rounded-md border px-3 py-2 text-sm sm:max-w-sm"
          id="inventory-branch"
          onChange={(event) => void changeBranch(event.target.value)}
          value={branchId}
        >
          {branches.map((branch) => (
            <option key={branch.id} value={branch.id}>
              {branch.name}
            </option>
          ))}
        </select>
      </div>

      <form
        className="rounded-2xl border bg-white p-5 shadow-sm"
        onSubmit={(event) => {
          event.preventDefault();
          if (!branchId) return;
          setSelected(null);
          setFeedback("Filtrando estoque...");
          void loadBalances(branchId, query).catch((error: unknown) =>
            setFeedback(
              error instanceof Error ? error.message : "Não foi possível filtrar o estoque.",
            ),
          );
        }}
      >
        <Label htmlFor="inventory-filter">Filtrar produtos</Label>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row">
          <input
            className="min-w-0 flex-1 rounded-md border px-3 py-2 text-sm"
            id="inventory-filter"
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Nome, SKU ou código de barras"
            value={query}
          />
          <Button type="submit" variant="outline">
            Aplicar filtro
          </Button>
          {query ? (
            <Button
              onClick={() => {
                setQuery("");
                setSelected(null);
                setFeedback("Carregando estoque...");
                void loadBalances(branchId);
              }}
              type="button"
              variant="ghost"
            >
              Limpar
            </Button>
          ) : null}
        </div>
        <p className="mt-2 text-xs text-slate-600">
          A busca é aplicada ao saldo e às sugestões desta filial.
        </p>
      </form>

      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}

      <DailyInventoryCount
        branchId={branchId}
        onCompleted={async () => {
          await loadBalances(branchId, query);
          setFeedback("Estoque atualizado após a conferência.");
        }}
        organizationId={organizationId}
      />

      {selected ? (
        selected.version === 0 && selected.updatedAt === null ? (
          <InitialStockForm
            balance={selected}
            branchId={branchId}
            onChanged={acceptChangedBalance}
            organizationId={organizationId}
            setFeedback={setFeedback}
          />
        ) : operation === "COUNT" ? (
          <InventoryCountForm
            balance={selected}
            branchId={branchId}
            onChanged={acceptChangedBalance}
            organizationId={organizationId}
            setFeedback={setFeedback}
          />
        ) : operation === "TRANSFER" ? (
          <StockTransferForm
            balance={selected}
            branches={branches}
            onChanged={async () => {
              setSelected(null);
              await loadBalances(branchId, query);
              setFeedback("Transferência concluída nas duas filiais.");
            }}
            organizationId={organizationId}
            setFeedback={setFeedback}
          />
        ) : (
          <AdjustmentForm
            balance={selected}
            branchId={branchId}
            onChanged={acceptChangedBalance}
            organizationId={organizationId}
            setFeedback={setFeedback}
          />
        )
      ) : null}

      <section className="rounded-2xl border bg-white shadow-sm">
        <div className="border-b px-5 py-4">
          <h2 className="font-semibold">Histórico operacional</h2>
          <p className="text-sm text-slate-600">
            Consumos da cozinha, perdas, devoluções e demais movimentos recentes desta filial.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead>
              <tr>
                <th className="px-4 py-3">Quando</th>
                <th className="px-4 py-3">Produto</th>
                <th className="px-4 py-3">Movimento</th>
                <th className="px-4 py-3">Quantidade</th>
                <th className="px-4 py-3">Motivo</th>
              </tr>
            </thead>
            <tbody>
              {movements.length ? (
                movements.map((movement) => {
                  const product = balances.find(
                    (balance) => balance.productId === movement.productId,
                  );
                  return (
                    <tr className="border-t" key={movement.id}>
                      <td className="px-4 py-3">
                        {new Intl.DateTimeFormat("pt-BR", {
                          dateStyle: "short",
                          timeStyle: "short",
                        }).format(new Date(movement.occurredAt))}
                      </td>
                      <td className="px-4 py-3">{product?.productName ?? "Produto"}</td>
                      <td className="px-4 py-3">{movementLabel(movement.type)}</td>
                      <td className="px-4 py-3 font-medium">
                        {formatQuantity(movement.quantity, product?.unit ?? "UN")}
                      </td>
                      <td className="px-4 py-3">{movement.reason ?? "—"}</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td className="px-4 py-4 text-slate-600" colSpan={5}>
                    Ainda não há movimentações nesta filial.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {suggestions.length > 0 ? (
        <div className="overflow-x-auto rounded-2xl border border-amber-200 bg-amber-50 shadow-sm">
          <div className="border-b border-amber-200 px-5 py-4">
            <h2 className="font-semibold">Sugestões de compra</h2>
            <p className="text-sm text-slate-600">
              Calculadas pelo estoque mínimo. Nenhum pedido é criado automaticamente.
            </p>
          </div>
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead>
              <tr>
                <th className="px-4 py-3">Produto</th>
                <th className="px-4 py-3">Saldo / mínimo</th>
                <th className="px-4 py-3">Comprar</th>
                <th className="px-4 py-3">Fornecedor sugerido</th>
              </tr>
            </thead>
            <tbody>
              {suggestions.map((suggestion) => (
                <tr className="border-t border-amber-200" key={suggestion.productId}>
                  <td className="px-4 py-3 font-medium">
                    {suggestion.productName} · {suggestion.sku}
                  </td>
                  <td className="px-4 py-3">
                    {formatQuantity(suggestion.currentQuantity, suggestion.unit)} disponíveis
                    <br />
                    <span className="text-slate-600">
                      mínimo: {formatQuantity(suggestion.minimumStock, suggestion.unit)}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-semibold text-amber-800">
                    {formatQuantity(suggestion.suggestedQuantity, suggestion.unit)}
                  </td>
                  <td className="px-4 py-3">
                    {suggestion.supplierName ?? "Sem fornecedor vinculado"}
                    {suggestion.supplierSku ? ` · ${suggestion.supplierSku}` : ""}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      <div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">
        <table className="w-full min-w-[760px] text-left text-sm">
          <caption className="px-4 pt-4 text-left text-sm text-slate-600">
            Saldo físico é o que existe na filial. Reservado está comprometido com pedidos;
            disponível é o que ainda pode ser vendido.
          </caption>
          <thead className="border-b bg-slate-50 text-slate-600">
            <tr>
              <th className="px-4 py-3">Produto</th>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3">
                <span className="block">Disponível para venda</span>
                <span className="text-xs font-normal">Saldo físico menos reservas</span>
              </th>
              <th className="px-4 py-3">Reservado</th>
              <th className="px-4 py-3">
                <span className="block">Estoque mínimo</span>
                <span className="text-xs font-normal">Alerta de reposição</span>
              </th>
              <th className="px-4 py-3">
                <span className="block">Custo por unidade</span>
                <span className="text-xs font-normal">Média das entradas</span>
              </th>
              <th className="px-4 py-3">Ação</th>
            </tr>
          </thead>
          <tbody>
            {balances.map((balance) => (
              <tr className="border-b last:border-0" key={balance.productId}>
                <td className="px-4 py-3 font-medium">{balance.productName}</td>
                <td className="px-4 py-3">{balance.sku}</td>
                <td
                  className={
                    balance.belowMinimum ? "px-4 py-3 font-semibold text-amber-700" : "px-4 py-3"
                  }
                >
                  <span className="block">
                    {formatQuantity(balance.quantityAvailable, balance.unit)}
                  </span>
                  <span className="text-xs font-normal text-slate-600">disponíveis</span>
                </td>
                <td className="px-4 py-3">
                  {formatQuantity(balance.quantityReserved, balance.unit)}
                </td>
                <td className="px-4 py-3">
                  <span className="block">
                    {formatQuantity(balance.minimumStock, balance.unit)}
                  </span>
                  <span className="text-xs text-slate-600">alerta abaixo deste nível</span>
                </td>
                <td className="px-4 py-3">
                  <span className="block">
                    R${" "}
                    {new Intl.NumberFormat("pt-BR", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 4,
                    }).format(Number(balance.weightedAverageCost))}
                  </span>
                  <span className="text-xs text-slate-600">
                    por{" "}
                    {balance.unit === "UN" ? "unidade" : balance.unit.toLocaleLowerCase("pt-BR")}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setOperation("ADJUST");
                        setSelected(balance);
                      }}
                      size="sm"
                      type="button"
                      variant="outline"
                    >
                      {balance.version === 0 && balance.updatedAt === null
                        ? "Definir inicial"
                        : "Ajustar"}
                    </Button>
                    {balance.updatedAt ? (
                      <>
                        <Button
                          onClick={() => {
                            setOperation("COUNT");
                            setSelected(balance);
                          }}
                          size="sm"
                          type="button"
                          variant="outline"
                        >
                          Contar
                        </Button>
                        <Button
                          disabled={branches.length < 2 || Number(balance.quantityOnHand) <= 0}
                          onClick={() => {
                            setOperation("TRANSFER");
                            setSelected(balance);
                          }}
                          size="sm"
                          type="button"
                          variant="outline"
                        >
                          Transferir
                        </Button>
                      </>
                    ) : null}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {balances.length === 0 ? (
          <p className="p-5 text-sm text-slate-600">Nenhum produto ativo controla estoque.</p>
        ) : null}
      </div>
    </section>
  );
}
