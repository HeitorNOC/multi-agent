import { expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, listFiscalProfiles, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  listFiscalProfiles: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listFiscalProfiles: { execute: listFiscalProfiles },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "10000000-0000-4000-8000-000000000001";
it("lists fiscal profiles through the resolved tenant actor", async () => {
  authenticate.mockResolvedValue({ userId: "user" });
  resolveTenantActor.mockResolvedValue({ role: "OWNER" });
  listFiscalProfiles.mockResolvedValue([]);
  const response = await GET(
    new Request(`http://localhost/api/v1/organizations/${organizationId}/fiscal-profiles`),
    { params: Promise.resolve({ organizationId }) },
  );
  expect(response.status).toBe(200);
  expect(listFiscalProfiles).toHaveBeenCalledWith({ organizationId }, { role: "OWNER" });
});
