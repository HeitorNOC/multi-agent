import { returnSaleBodySchema, saleParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ organizationId: string; saleId: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = saleParamsSchema.parse(await route.params);
    const body = returnSaleBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const saleReturn = await services.returnSale.execute(
      { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
      actor,
    );
    return Response.json(
      { data: saleReturn },
      {
        headers: {
          location: `/api/v1/organizations/${params.organizationId}/sales/${params.saleId}`,
        },
        status: 201,
      },
    );
  });
}
