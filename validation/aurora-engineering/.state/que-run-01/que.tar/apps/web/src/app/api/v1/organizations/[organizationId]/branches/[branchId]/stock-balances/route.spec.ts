import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, listStockBalances, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  listStockBalances: vi.fn(),
  resolveTenantActor: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listStockBalances: { execute: listStockBalances },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const branchId = "30000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ branchId, organizationId }) };

describe("stock balance route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "MANAGER" });
    listStockBalances.mockReset().mockResolvedValue([{ quantity: "10.0000" }]);
  });

  it("normalizes search and pagination inside the selected branch", async () => {
    const request = new Request(
      `http://localhost/api/v1/organizations/${organizationId}/branches/${branchId}/stock-balances?limit=20&q=%20tesoura%20`,
    );
    const response = await GET(request, route);

    expect(response.status).toBe(200);
    expect(listStockBalances).toHaveBeenCalledWith(
      { branchId, limit: 20, organizationId, q: "tesoura" },
      { role: "MANAGER" },
    );
    await expect(response.json()).resolves.toEqual({ data: [{ quantity: "10.0000" }] });
  });
});
