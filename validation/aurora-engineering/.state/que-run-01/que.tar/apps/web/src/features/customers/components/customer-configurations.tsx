"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createCustomerBodySchema,
  createCustomerTagBodySchema,
  customerListSchema,
  customerTagListSchema,
  customerTagViewSchema,
  customerViewSchema,
  type CreateCustomerBody,
  type CreateCustomerTagBody,
  type CustomerTagView,
  type CustomerView,
  type ProblemDetails,
} from "@gestor/contracts";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import { CustomerForm } from "./customer-form";
import { CustomerList } from "./customer-list";

type CustomerConfigurationsProps = { organizationId: string };

const defaults: CreateCustomerBody = {
  birthDate: "",
  document: "",
  email: "",
  name: "",
  notes: "",
  phone: "",
};

const tagDefaults: CreateCustomerTagBody = { color: "#2563EB", name: "" };

export function CustomerConfigurations({ organizationId }: CustomerConfigurationsProps) {
  const [customers, setCustomers] = useState<readonly CustomerView[] | null>(null);
  const [tags, setTags] = useState<readonly CustomerTagView[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [editingCustomer, setEditingCustomer] = useState<CustomerView | null>(null);
  const [updatingCustomerId, setUpdatingCustomerId] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateCustomerBody>({
    defaultValues: defaults,
    resolver: zodResolver(createCustomerBodySchema),
  });
  const {
    formState: { errors: tagErrors, isSubmitting: isSubmittingTag },
    handleSubmit: handleTagSubmit,
    register: registerTag,
    reset: resetTag,
    setError: setTagError,
  } = useForm<CreateCustomerTagBody>({
    defaultValues: tagDefaults,
    resolver: zodResolver(createCustomerTagBodySchema),
  });

  const loadCustomers = useCallback(
    async (search: string, signal?: AbortSignal) => {
      const params = new URLSearchParams({ limit: "100" });
      if (search.trim()) params.set("q", search.trim());
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/customers?${params}`,
        signal ? { signal } : undefined,
      );
      if (!response.ok) throw new Error(((await response.json()) as ProblemDetails).detail);
      const payload = (await response.json()) as { data: unknown };
      setCustomers(customerListSchema.parse(payload.data));
    },
    [organizationId],
  );

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const tagResponse = await fetch(`/api/v1/organizations/${organizationId}/customers/tags`, {
          signal: controller.signal,
        });
        if (!tagResponse.ok) throw new Error(((await tagResponse.json()) as ProblemDetails).detail);
        const tagPayload = (await tagResponse.json()) as { data: unknown };
        setTags(customerTagListSchema.parse(tagPayload.data));
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error ? error.message : "Não foi possível carregar os clientes.",
          );
        }
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId]);

  useEffect(() => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => {
      void loadCustomers(query, controller.signal)
        .then(() => setLoadError(null))
        .catch((error: unknown) => {
          if (!controller.signal.aborted)
            setLoadError(
              error instanceof Error ? error.message : "Não foi possível carregar os clientes.",
            );
        });
    }, 250);
    return () => {
      window.clearTimeout(timeout);
      controller.abort();
    };
  }, [loadCustomers, query]);

  const visibleCustomers = customers ?? [];

  const submit = handleSubmit(async (values) => {
    setFeedback(null);
    try {
      const response = await fetch(
        editingCustomer
          ? `/api/v1/organizations/${organizationId}/customers/${editingCustomer.id}`
          : `/api/v1/organizations/${organizationId}/customers`,
        {
          body: JSON.stringify(
            editingCustomer ? { ...values, expectedUpdatedAt: editingCustomer.updatedAt } : values,
          ),
          headers: editingCustomer
            ? { "content-type": "application/json" }
            : { "content-type": "application/json", "idempotency-key": idempotencyKey },
          method: editingCustomer ? "PATCH" : "POST",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setError("root", { message: problem.detail, type: problem.code });
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const customer = customerViewSchema.parse(payload.data);
      setCustomers((current) =>
        editingCustomer
          ? (current ?? []).map((item) => (item.id === customer.id ? customer : item))
          : [...(current ?? []), customer],
      );
      if (!editingCustomer) setIdempotencyKey(crypto.randomUUID());
      setFeedback(
        editingCustomer ? "Cliente atualizado com segurança." : "Cliente cadastrado com segurança.",
      );
      setEditingCustomer(null);
      reset(defaults);
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  function beginEditing(customer: CustomerView) {
    setEditingCustomer(customer);
    setFeedback(null);
    reset({
      birthDate: customer.birthDate ?? "",
      document: customer.document ?? "",
      email: customer.email ?? "",
      name: customer.name,
      notes: customer.notes ?? "",
      phone: customer.phone ?? "",
    });
  }

  async function toggleStatus(customer: CustomerView) {
    setUpdatingCustomerId(customer.id);
    setFeedback(null);
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/customers/${customer.id}`,
        {
          body: JSON.stringify({
            expectedUpdatedAt: customer.updatedAt,
            status: customer.status === "ACTIVE" ? "INACTIVE" : "ACTIVE",
          }),
          headers: { "content-type": "application/json" },
          method: "PATCH",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setFeedback(problem.detail);
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const updated = customerViewSchema.parse(payload.data);
      setCustomers((current) =>
        (current ?? []).map((item) => (item.id === updated.id ? updated : item)),
      );
      setFeedback(updated.status === "ACTIVE" ? "Cliente reativado." : "Cliente inativado.");
    } catch {
      setFeedback("Não foi possível conectar ao servidor. Tente novamente.");
    } finally {
      setUpdatingCustomerId(null);
    }
  }

  const submitTag = handleTagSubmit(async (values) => {
    try {
      const response = await fetch(`/api/v1/organizations/${organizationId}/customers/tags`, {
        body: JSON.stringify(values),
        headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
        method: "POST",
      });
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setTagError("root", { message: problem.detail, type: problem.code });
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const tag = customerTagViewSchema.parse(payload.data);
      setTags((current) => [...(current ?? []), tag].sort((a, b) => a.name.localeCompare(b.name)));
      resetTag(tagDefaults);
      setFeedback("Etiqueta criada.");
    } catch {
      setTagError("root", { message: "Não foi possível criar a etiqueta.", type: "network" });
    }
  });

  async function toggleTag(customer: CustomerView, tagId: string) {
    setUpdatingCustomerId(customer.id);
    setFeedback(null);
    const tagIds = customer.tagIds.includes(tagId)
      ? customer.tagIds.filter((id) => id !== tagId)
      : [...customer.tagIds, tagId];
    try {
      const response = await fetch(
        `/api/v1/organizations/${organizationId}/customers/${customer.id}/tags`,
        {
          body: JSON.stringify({ expectedUpdatedAt: customer.updatedAt, tagIds }),
          headers: { "content-type": "application/json" },
          method: "PUT",
        },
      );
      if (!response.ok) {
        const problem = (await response.json()) as ProblemDetails;
        setFeedback(problem.detail);
        return;
      }
      const payload = (await response.json()) as { data: unknown };
      const updated = customerViewSchema.parse(payload.data);
      setCustomers((current) =>
        (current ?? []).map((item) => (item.id === updated.id ? updated : item)),
      );
      setFeedback("Etiquetas do cliente atualizadas.");
    } catch {
      setFeedback("Não foi possível atualizar as etiquetas.");
    } finally {
      setUpdatingCustomerId(null);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
      <CustomerForm
        editingCustomer={editingCustomer}
        errors={errors}
        isSubmitting={isSubmitting}
        onCancel={() => {
          setEditingCustomer(null);
          reset(defaults);
        }}
        register={register}
        submit={submit}
      />

      <CustomerList
        customersLoaded={Boolean(customers)}
        feedback={feedback}
        isSubmittingTag={isSubmittingTag}
        loadError={loadError}
        onBeginEditing={beginEditing}
        onQueryChange={setQuery}
        onToggleStatus={toggleStatus}
        onToggleTag={toggleTag}
        organizationId={organizationId}
        query={query}
        registerTag={registerTag}
        submitTag={submitTag}
        tagErrors={tagErrors}
        tags={tags}
        updatingCustomerId={updatingCustomerId}
        visibleCustomers={visibleCustomers}
      />
    </div>
  );
}
