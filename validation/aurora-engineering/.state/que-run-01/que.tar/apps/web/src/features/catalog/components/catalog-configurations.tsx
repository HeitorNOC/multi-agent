"use client";

import {
  catalogCategoryListSchema,
  productListSchema,
  serviceListSchema,
  type ProblemDetails,
} from "@gestor/contracts";
import { useEffect, useState } from "react";

import { LoadingRows } from "@/components/loading-skeleton";

import { CategorySection } from "./category-section";
import { CatalogCommercialPolicySettings } from "./catalog-commercial-policy-settings";
import { CatalogOrderManager } from "./catalog-order-manager";
import { CatalogPortalLinkManager } from "./catalog-portal-link-manager";
import type { CatalogState } from "./catalog-types";
import { PriceListSection } from "./price-list-section";
import { ProductSection } from "./product-section";
import { ServiceSection } from "./service-section";

export function CatalogConfigurations({ organizationId }: { organizationId: string }) {
  const [state, setState] = useState<CatalogState | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const paths = ["catalog-categories", "products", "services"];
        const responses = await Promise.all(
          paths.map((path) =>
            fetch(`/api/v1/organizations/${organizationId}/${path}`, {
              signal: controller.signal,
            }),
          ),
        );
        const failed = responses.find((response) => !response.ok);
        if (failed) throw new Error(((await failed.json()) as ProblemDetails).detail);
        const payloads = await Promise.all(
          responses.map((response) => response.json() as Promise<{ data: unknown }>),
        );
        setState({
          categories: catalogCategoryListSchema.parse(payloads[0]?.data),
          products: productListSchema.parse(payloads[1]?.data),
          services: serviceListSchema.parse(payloads[2]?.data),
        });
      } catch (error) {
        if (!controller.signal.aborted)
          setFeedback(
            error instanceof Error ? error.message : "Não foi possível carregar o catálogo.",
          );
      }
    }
    void load();
    return () => controller.abort();
  }, [organizationId]);

  if (!state)
    return feedback ? (
      <p className="rounded-2xl border bg-white p-5 text-sm" role="alert">
        {feedback}
      </p>
    ) : (
      <LoadingRows rows={3} />
    );

  return (
    <div className="grid gap-8">
      {feedback ? (
        <p className="rounded-xl border px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      <CatalogCommercialPolicySettings organizationId={organizationId} />
      <CatalogPortalLinkManager organizationId={organizationId} />
      <CatalogOrderManager organizationId={organizationId} />
      <CategorySection
        organizationId={organizationId}
        setFeedback={setFeedback}
        setState={setState}
        state={state}
      />
      <ProductSection
        organizationId={organizationId}
        setFeedback={setFeedback}
        setState={setState}
        state={state}
      />
      <ServiceSection
        organizationId={organizationId}
        setFeedback={setFeedback}
        setState={setState}
        state={state}
      />
      <PriceListSection
        organizationId={organizationId}
        products={state.products}
        services={state.services}
        setFeedback={setFeedback}
      />
    </div>
  );
}
