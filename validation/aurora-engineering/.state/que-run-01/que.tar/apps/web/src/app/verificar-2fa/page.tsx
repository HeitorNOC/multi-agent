import type { Metadata } from "next";
import { connection } from "next/server";

import { AuthShell } from "@/features/auth/components/auth-shell";
import { TwoFactorChallenge } from "@/features/auth/components/two-factor-challenge";
import { safeReturnTo } from "@/features/auth/return-to";

export const metadata: Metadata = {
  title: "Confirme sua identidade | Gestor",
};

type TwoFactorPageProps = {
  searchParams: Promise<{ returnTo?: string }>;
};

export default async function TwoFactorPage({ searchParams }: TwoFactorPageProps) {
  await connection();
  const params = await searchParams;

  return (
    <AuthShell
      description="Use o aplicativo autenticador ou um código de recuperação para continuar."
      eyebrow="Proteção da conta"
      title="Confirme sua identidade"
    >
      <TwoFactorChallenge
        {...(safeReturnTo(params.returnTo) ? { returnTo: params.returnTo } : {})}
      />
    </AuthShell>
  );
}
