import type {
  FinancialAccountView,
  FinancialObligationView,
  PaymentMethodConfigurationView,
} from "@gestor/contracts";

export function availableSettlementMethods(
  paymentMethods: readonly PaymentMethodConfigurationView[],
  kind: FinancialObligationView["kind"],
): readonly PaymentMethodConfigurationView[] {
  return paymentMethods.filter(
    (configuration) =>
      configuration.status === "ACTIVE" &&
      (kind === "RECEIVABLE"
        ? configuration.allowsReceipts
        : configuration.allowsPayments && configuration.method !== "CARD"),
  );
}

export function availableSettlementAccounts(
  financialAccounts: readonly FinancialAccountView[],
  branchId: string,
  selectedMethod: PaymentMethodConfigurationView["method"] | undefined,
): readonly FinancialAccountView[] {
  return financialAccounts.filter((account) => {
    if (
      account.status !== "ACTIVE" ||
      (account.branchId !== null && account.branchId !== branchId)
    ) {
      return false;
    }

    if (selectedMethod === "CASH") {
      return account.type === "CASH" && account.branchId === branchId;
    }

    if (selectedMethod === "CARD") {
      return account.type === "ACQUIRER";
    }

    return selectedMethod ? account.type === "BANK" : false;
  });
}
