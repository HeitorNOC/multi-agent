import { provisionOrganizationBodySchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

export async function POST(request: Request): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const body = provisionOrganizationBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    let result;

    try {
      result = await services.provisionOrganization.execute(
        {
          branchName: body.branchName,
          businessSegment: body.businessSegment,
          ...(body.document ? { document: body.document } : {}),
          organizationName: body.organizationName,
          ...(body.segmentDescription ? { segmentDescription: body.segmentDescription } : {}),
        },
        {
          correlationId: api.correlationId,
          idempotencyKey: requireIdempotencyKey(request),
          requestId: api.requestId,
          userId: identity.userId,
        },
      );
    } catch (error) {
      console.error("Organization provisioning failed", {
        correlationId: api.correlationId,
        error,
        requestId: api.requestId,
      });
      throw error;
    }

    return Response.json(
      { data: result },
      {
        headers: {
          location: `/organizations/${result.organizationId}`,
        },
        status: 201,
      },
    );
  });
}
