"use client";

import {
  organizationModuleListSchema,
  type OrganizationModuleView,
  type ProblemDetails,
} from "@gestor/contracts";
import { useEffect, useState } from "react";

type OrganizationModulesState =
  | { organizationId: string; status: "LOADING" }
  | { message: string; organizationId: string; status: "ERROR" }
  | { modules: readonly OrganizationModuleView[]; organizationId: string; status: "SUCCESS" };

export function useOrganizationModules(organizationId: string): OrganizationModulesState {
  const [state, setState] = useState<OrganizationModulesState>({
    organizationId,
    status: "LOADING",
  });

  useEffect(() => {
    const controller = new AbortController();

    async function loadOrganizationModules() {
      try {
        const response = await fetch(`/api/v1/organizations/${organizationId}/modules`, {
          signal: controller.signal,
        });

        if (!response.ok) {
          const problem = (await response.json()) as ProblemDetails;
          throw new Error(problem.detail);
        }

        const payload = (await response.json()) as { data: unknown };
        const modules = organizationModuleListSchema.parse(payload.data);

        if (!controller.signal.aborted) {
          setState({ modules, organizationId, status: "SUCCESS" });
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          setState({
            message:
              error instanceof Error
                ? error.message
                : "Não foi possível verificar os módulos desta empresa.",
            organizationId,
            status: "ERROR",
          });
        }
      }
    }

    void loadOrganizationModules();
    return () => controller.abort();
  }, [organizationId]);

  return state.organizationId === organizationId ? state : { organizationId, status: "LOADING" };
}
