import { parsePaymentProviderCredentials } from "@gestor/config";

function organizationCredentials(organizationId: string) {
  const serialized = process.env.PAYMENT_PROVIDER_CREDENTIALS_JSON;
  if (!serialized) return null;
  const parsed = parsePaymentProviderCredentials(JSON.parse(serialized));
  return parsed[organizationId] ?? null;
}

export async function mercadoPagoCredentials(organizationId: string) {
  return organizationCredentials(organizationId)?.mercadoPago ?? null;
}

export async function stripeCredentials(organizationId: string) {
  const stripe = organizationCredentials(organizationId)?.stripe;
  if (!stripe) throw new Error("STRIPE_NOT_CONFIGURED");
  const appUrl = process.env.BETTER_AUTH_URL;
  if (!appUrl) throw new Error("STRIPE_APP_URL_NOT_CONFIGURED");
  return { ...stripe, appUrl };
}
