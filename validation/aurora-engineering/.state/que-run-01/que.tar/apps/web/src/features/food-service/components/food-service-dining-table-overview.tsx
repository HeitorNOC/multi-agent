import type { FoodServiceDiningAreaView, FoodServiceDiningTableView } from "@gestor/contracts";

export function FoodServiceDiningTableOverview({
  areas,
  tables,
}: {
  areas: readonly FoodServiceDiningAreaView[];
  tables: readonly FoodServiceDiningTableView[];
}) {
  return (
    <div className="grid gap-2">
      {areas.length === 0 ? (
        <p className="text-sm text-slate-600">Cadastre a primeira área para criar mesas.</p>
      ) : (
        areas.map((area) => {
          const areaTables = tables.filter((table) => table.areaId === area.id);
          return (
            <article className="rounded-xl border p-4" key={area.id}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-semibold">{area.name}</p>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                  {areaTables.length} mesa(s)
                </span>
              </div>
              <p className="mt-1 text-sm text-slate-600">
                Confira os lugares cadastrados antes de abrir a primeira comanda.
              </p>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {areaTables.length === 0 ? (
                  <li className="text-sm text-slate-500">Nenhuma mesa cadastrada nesta área.</li>
                ) : (
                  areaTables.map((table) => (
                    <li
                      className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm"
                      key={table.id}
                    >
                      <span className="font-semibold text-slate-900">{table.code}</span>
                      <span className="text-slate-600">
                        {table.capacity} {table.capacity === 1 ? "lugar" : "lugares"}
                      </span>
                    </li>
                  ))
                )}
              </ul>
            </article>
          );
        })
      )}
    </div>
  );
}
