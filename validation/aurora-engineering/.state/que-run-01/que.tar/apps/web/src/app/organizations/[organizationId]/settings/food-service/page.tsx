import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { ModuleGate } from "@/features/modules/components/module-gate";
import { FoodServiceSetup } from "@/features/food-service/components/food-service-setup";

export const metadata: Metadata = { title: "Alimentação | Gestor" };
export default async function FoodServicePage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao painel
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Operação
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">Alimentação</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Configure como a empresa atende no salão, balcão, retirada e entrega. Depois cadastre as
          áreas e mesas da filial.
        </p>
      </header>
      <ModuleGate moduleCode="food_service" organizationId={organizationId}>
        <FoodServiceSetup organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
