import {
  foodServiceModifierGroupListSchema,
  replaceFoodServiceProductModifierGroupsBodySchema,
  type FoodServiceModifierGroupView,
  type ProductView,
} from "@gestor/contracts";
import { useEffect, useState } from "react";

type DraftOption = { id: string; kitchenName: string; name: string; priceDelta: string };
type DraftGroup = {
  id: string;
  maximumSelections: number;
  minimumSelections: number;
  name: string;
  options: DraftOption[];
};
const newOption = (): DraftOption => ({ id: crypto.randomUUID(), kitchenName: "", name: "", priceDelta: "0" });
const newGroup = (): DraftGroup => ({
  id: crypto.randomUUID(),
  maximumSelections: 1,
  minimumSelections: 0,
  name: "",
  options: [newOption()],
});
function toDraft(group: FoodServiceModifierGroupView): DraftGroup {
  return {
    id: group.id,
    maximumSelections: group.maximumSelections,
    minimumSelections: group.minimumSelections,
    name: group.name,
    options: group.options.map((option) => ({
      id: option.id,
      kitchenName: option.kitchenName ?? "",
      name: option.name,
      priceDelta: option.priceDelta,
    })),
  };
}

export function FoodServiceModifierConfiguration({
  organizationId,
  products,
}: {
  organizationId: string;
  products: readonly ProductView[];
}) {
  const [productId, setProductId] = useState("");
  const [groups, setGroups] = useState<DraftGroup[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!productId) return setGroups([]);
    const controller = new AbortController();
    setLoading(true);
    setMessage(null);
    fetch(`/api/v1/organizations/${organizationId}/food-service-product-modifiers?productId=${productId}`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const payload = (await response.json()) as { data?: unknown; detail?: string };
        if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar a configuração.");
        setGroups(foodServiceModifierGroupListSchema.parse(payload.data).map(toDraft));
      })
      .catch((cause: unknown) => {
        if (cause instanceof DOMException && cause.name === "AbortError") return;
        setMessage(cause instanceof Error ? cause.message : "Não foi possível carregar a configuração.");
      })
      .finally(() => !controller.signal.aborted && setLoading(false));
    return () => controller.abort();
  }, [organizationId, productId]);

  function updateGroup(groupId: string, changes: Partial<DraftGroup>) {
    setGroups((current) => current.map((group) => (group.id === groupId ? { ...group, ...changes } : group)));
  }
  function updateOption(groupId: string, optionId: string, changes: Partial<DraftOption>) {
    setGroups((current) => current.map((group) => group.id !== groupId ? group : {
      ...group,
      options: group.options.map((option) => option.id === optionId ? { ...option, ...changes } : option),
    }));
  }
  async function save() {
    if (!productId) return;
    setMessage(null);
    const candidate = {
      productId,
      groups: groups.map((group) => ({
        maximumSelections: Number(group.maximumSelections),
        minimumSelections: Number(group.minimumSelections),
        name: group.name.trim(),
        options: group.options.map((option) => ({
          kitchenName: option.kitchenName.trim() || null,
          name: option.name.trim(),
          priceDelta: option.priceDelta.replace(",", "."),
        })),
      })),
    };
    const validation = replaceFoodServiceProductModifierGroupsBodySchema.safeParse(candidate);
    if (!validation.success) return setMessage(validation.error.issues[0]?.message ?? "Revise os complementos antes de salvar.");
    setSaving(true);
    const response = await fetch(`/api/v1/organizations/${organizationId}/food-service-product-modifiers`, {
      body: JSON.stringify(validation.data),
      headers: { "content-type": "application/json" },
      method: "PUT",
    });
    const payload = (await response.json()) as { data?: unknown; detail?: string };
    setSaving(false);
    if (!response.ok) return setMessage(payload.detail ?? "Não foi possível salvar os complementos.");
    setGroups(foodServiceModifierGroupListSchema.parse(payload.data).map(toDraft));
    setMessage("Complementos salvos. Novos pedidos já usarão esta configuração.");
  }

  return (
    <section className="grid gap-4 rounded-2xl border bg-white p-5">
      <div>
        <h2 className="font-semibold">Complementos do cardápio</h2>
        <p className="mt-1 text-sm text-slate-600">
          Configure escolhas por produto. O atendimento verá somente o que precisa perguntar ao cliente.
        </p>
      </div>
      <label className="grid gap-1 text-sm font-medium">
        Produto
        <select className="h-11 rounded-xl border px-3" onChange={(event) => setProductId(event.target.value)} value={productId}>
          <option value="">Selecione um produto</option>
          {products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}
        </select>
      </label>
      {loading ? <p className="text-sm text-slate-600">Carregando configuração…</p> : null}
      {productId ? (
        <div className="grid gap-3">
          {groups.map((group) => (
            <article className="grid gap-3 rounded-xl border bg-slate-50 p-4" key={group.id}>
              <div className="flex items-center justify-between gap-3">
                <strong className="text-sm">Grupo de escolha</strong>
                <button className="text-sm font-medium text-red-700" onClick={() => setGroups((items) => items.filter((item) => item.id !== group.id))} type="button">Remover grupo</button>
              </div>
              <label className="grid gap-1 text-sm">Nome do grupo<input className="h-11 rounded-xl border px-3" onChange={(event) => updateGroup(group.id, { name: event.target.value })} placeholder="Ex.: Ponto da carne" value={group.name} /></label>
              <div className="grid grid-cols-2 gap-3">
                <label className="grid gap-1 text-sm">Mínimo<input className="h-11 rounded-xl border px-3" min="0" onChange={(event) => updateGroup(group.id, { minimumSelections: Number(event.target.value) })} type="number" value={group.minimumSelections} /></label>
                <label className="grid gap-1 text-sm">Máximo<input className="h-11 rounded-xl border px-3" min="1" onChange={(event) => updateGroup(group.id, { maximumSelections: Number(event.target.value) })} type="number" value={group.maximumSelections} /></label>
              </div>
              <div className="grid gap-2">
                {group.options.map((option) => (
                  <div className="grid gap-2 rounded-lg border bg-white p-3" key={option.id}>
                    <label className="grid gap-1 text-sm">Opção exibida no atendimento<input className="h-11 rounded-xl border px-3" onChange={(event) => updateOption(group.id, option.id, { name: event.target.value })} placeholder="Ex.: Ao ponto" value={option.name} /></label>
                    <label className="grid gap-1 text-sm">Nome para a cozinha <span className="font-normal text-slate-500">(opcional)</span><input className="h-11 rounded-xl border px-3" onChange={(event) => updateOption(group.id, option.id, { kitchenName: event.target.value })} placeholder="Ex.: AO PONTO" value={option.kitchenName} /></label>
                    <div className="flex gap-2"><label className="grid flex-1 gap-1 text-sm">Acréscimo ou desconto<input className="h-11 rounded-xl border px-3" inputMode="decimal" onChange={(event) => updateOption(group.id, option.id, { priceDelta: event.target.value })} placeholder="Ex.: 3,50" value={option.priceDelta} /></label><button className="mt-6 rounded-lg px-3 text-sm text-red-700" onClick={() => updateGroup(group.id, { options: group.options.filter((item) => item.id !== option.id) })} type="button">Remover</button></div>
                  </div>
                ))}
                <button className="min-h-11 rounded-xl border px-3 text-sm font-medium" onClick={() => updateGroup(group.id, { options: [...group.options, newOption()] })} type="button">Adicionar opção</button>
              </div>
            </article>
          ))}
          <button className="min-h-11 rounded-xl border px-3 text-sm font-medium" onClick={() => setGroups((items) => [...items, newGroup()])} type="button">Adicionar grupo de escolhas</button>
          <button className="min-h-11 rounded-xl bg-brand-700 px-4 text-base font-semibold text-white disabled:opacity-50" disabled={saving} onClick={() => void save()} type="button">{saving ? "Salvando…" : "Salvar complementos"}</button>
        </div>
      ) : null}
      {message ? <p aria-live="polite" className="text-sm text-slate-700">{message}</p> : null}
    </section>
  );
}
