"use client";

import type { CreateCustomerTagBody, CustomerTagView, CustomerView } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import type { FormEventHandler } from "react";
import type { FieldErrors, UseFormRegister } from "react-hook-form";

import { LoadingRows } from "@/components/loading-skeleton";

import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";
import { CustomerField } from "./customer-field";

type CustomerListProps = {
  customersLoaded: boolean;
  feedback: string | null;
  isSubmittingTag: boolean;
  loadError: string | null;
  onBeginEditing: (customer: CustomerView) => void;
  onQueryChange: (query: string) => void;
  onToggleStatus: (customer: CustomerView) => Promise<void>;
  onToggleTag: (customer: CustomerView, tagId: string) => Promise<void>;
  organizationId: string;
  query: string;
  registerTag: UseFormRegister<CreateCustomerTagBody>;
  submitTag: FormEventHandler<HTMLFormElement>;
  tagErrors: FieldErrors<CreateCustomerTagBody>;
  tags: readonly CustomerTagView[] | null;
  updatingCustomerId: string | null;
  visibleCustomers: readonly CustomerView[];
};

export function CustomerList({
  customersLoaded,
  feedback,
  isSubmittingTag,
  loadError,
  onBeginEditing,
  onQueryChange,
  onToggleStatus,
  onToggleTag,
  organizationId,
  query,
  registerTag,
  submitTag,
  tagErrors,
  tags,
  updatingCustomerId,
  visibleCustomers,
}: CustomerListProps) {
  return (
    <section className="grid content-start gap-4" aria-labelledby="customer-list-title">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Relacionamento
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="customer-list-title">
          Clientes cadastrados
        </h2>
      </div>
      <form
        className="grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-[minmax(0,1fr)_7rem_auto]"
        noValidate
        onSubmit={submitTag}
      >
        <CustomerField error={tagErrors.name?.message} id="customer-tag-name" label="Nova etiqueta">
          <Input
            className="h-10 rounded-xl px-3"
            id="customer-tag-name"
            placeholder="Ex.: Cliente VIP"
            {...registerTag("name")}
          />
        </CustomerField>
        <CustomerField error={tagErrors.color?.message} id="customer-tag-color" label="Cor">
          <Input
            className="h-10 rounded-xl p-1"
            id="customer-tag-color"
            type="color"
            {...registerTag("color")}
          />
        </CustomerField>
        <div className="flex items-end">
          <Button className="h-10 w-full" disabled={isSubmittingTag} type="submit">
            {isSubmittingTag ? "Criando..." : "Criar"}
          </Button>
        </div>
        {tagErrors.root?.message ? (
          <p className="text-sm text-red-700 sm:col-span-3" role="alert">
            {tagErrors.root.message}
          </p>
        ) : null}
      </form>
      <Label className="sr-only" htmlFor="customer-search">
        Buscar cliente
      </Label>
      <Input
        className="h-11 rounded-xl bg-white px-3"
        id="customer-search"
        onChange={(event) => onQueryChange(event.target.value)}
        placeholder="Buscar por nome, contato ou documento"
        value={query}
      />
      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700" role="status">
          {feedback}
        </p>
      ) : null}
      {loadError ? (
        <p
          className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
          role="alert"
        >
          {loadError}
        </p>
      ) : null}
      {!customersLoaded && !loadError ? <LoadingRows rows={3} /> : null}
      {customersLoaded && visibleCustomers.length === 0 ? (
        <p className="rounded-2xl border border-dashed bg-white p-6 text-sm text-slate-600">
          {query ? "Nenhum cliente corresponde à busca." : "Nenhum cliente cadastrado ainda."}
        </p>
      ) : null}
      <div className="grid gap-3">
        {visibleCustomers.map((customer) => (
          <article className="rounded-2xl border bg-white p-5" key={customer.id}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="font-semibold text-slate-950">{customer.name}</h3>
                <p className="mt-1 text-sm text-slate-600">{customer.phone ?? customer.email}</p>
              </div>
              <span
                className={
                  customer.status === "ACTIVE"
                    ? "rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700"
                    : "rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600"
                }
              >
                {customer.status === "ACTIVE" ? "Ativo" : "Inativo"}
              </span>
            </div>
            {customer.phone && customer.email ? (
              <p className="mt-2 text-xs text-slate-500">{customer.email}</p>
            ) : null}
            {tags && tags.length > 0 ? (
              <div className="mt-4 flex flex-wrap gap-2" aria-label="Etiquetas do cliente">
                {tags.map((tag) => {
                  const selected = customer.tagIds.includes(tag.id);
                  return (
                    <button
                      aria-pressed={selected}
                      className={
                        selected
                          ? "rounded-full border border-slate-300 bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-800"
                          : "rounded-full border border-dashed border-slate-300 px-2.5 py-1 text-xs text-slate-500"
                      }
                      disabled={updatingCustomerId === customer.id}
                      key={tag.id}
                      onClick={() => void onToggleTag(customer, tag.id)}
                      style={selected && tag.color ? { borderColor: tag.color } : undefined}
                      type="button"
                    >
                      {tag.name}
                    </button>
                  );
                })}
              </div>
            ) : null}
            <div className="mt-4 flex flex-wrap gap-2">
              <CatalogFilesButton
                allowImage={false}
                itemId={customer.id}
                organizationId={organizationId}
                segment="customers"
              />
              <Button
                onClick={() => onBeginEditing(customer)}
                size="sm"
                type="button"
                variant="outline"
              >
                Editar
              </Button>
              <Button
                disabled={updatingCustomerId === customer.id}
                onClick={() => void onToggleStatus(customer)}
                size="sm"
                type="button"
                variant="outline"
              >
                {updatingCustomerId === customer.id
                  ? "Salvando..."
                  : customer.status === "ACTIVE"
                    ? "Inativar"
                    : "Reativar"}
              </Button>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
