import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createSaleReceipt, resolveTenantActor, sendSaleReceipt } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createSaleReceipt: vi.fn(),
  resolveTenantActor: vi.fn(),
  sendSaleReceipt: vi.fn(),
}));

vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    createSaleReceipt: { execute: createSaleReceipt },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
    sendSaleReceipt: { execute: sendSaleReceipt },
  },
}));

import { GET, POST } from "./route";

const params = {
  organizationId: "10000000-0000-4000-8000-000000000001",
  saleId: "10000000-0000-4000-8000-000000000002",
};

describe("sale receipt route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    createSaleReceipt.mockReset().mockResolvedValue({
      fileName: "comprovante-venda-1.html",
      html: "<!doctype html><title>Comprovante</title>",
    });
    sendSaleReceipt.mockReset().mockResolvedValue({
      recipientEmail: "cliente@example.com",
      saleId: params.saleId,
      status: "SENT",
    });
  });

  it("returns an authenticated printable document with restrictive headers", async () => {
    const response = await GET(new Request("http://localhost/receipt"), {
      params: Promise.resolve(params),
    });
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("text/html; charset=utf-8");
    expect(response.headers.get("cache-control")).toBe("private, no-store");
    expect(response.headers.get("content-security-policy")).toContain("default-src 'none'");
    expect(createSaleReceipt).toHaveBeenCalledWith(params, { role: "OWNER" });
  });

  it("validates and forwards an idempotent email delivery", async () => {
    const response = await POST(
      new Request("http://localhost/receipt", {
        body: JSON.stringify({ recipientEmail: "CLIENTE@example.com" }),
        headers: { "content-type": "application/json", "idempotency-key": "receipt-1" },
        method: "POST",
      }),
      { params: Promise.resolve(params) },
    );
    expect(response.status).toBe(200);
    expect(sendSaleReceipt).toHaveBeenCalledWith(
      { ...params, idempotencyKey: "receipt-1", recipientEmail: "cliente@example.com" },
      { role: "OWNER" },
    );
  });
});
