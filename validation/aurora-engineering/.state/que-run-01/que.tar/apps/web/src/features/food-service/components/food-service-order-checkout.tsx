import type {
  FinancialAccountView,
  FinancialCategoryView,
  FoodServiceOrderView,
  PaymentMethodConfigurationView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

export type FoodServiceCheckoutPayment = {
  amount: string;
  financialAccountId: string;
  paymentMethodConfigurationId: string;
};
export type FoodServiceCheckoutForm = {
  dueDate: string;
  payments: FoodServiceCheckoutPayment[];
  revenueCategoryId: string;
};

function formatCurrency(value: string) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    Number(value),
  );
}
function paymentTotal(payments: readonly FoodServiceCheckoutPayment[]) {
  return payments.reduce(
    (total, payment) => total + (Number(payment.amount.replace(",", ".")) || 0),
    0,
  );
}
function paymentsAreComplete(payments: readonly FoodServiceCheckoutPayment[]) {
  return payments.every(
    (payment) =>
      Number(payment.amount.replace(",", ".")) > 0 &&
      Boolean(payment.financialAccountId) &&
      Boolean(payment.paymentMethodConfigurationId),
  );
}
function paymentsMatchOrderTotal(
  orderTotal: string,
  payments: readonly FoodServiceCheckoutPayment[],
) {
  return Math.abs(paymentTotal(payments) - Number(orderTotal)) <= 0.005;
}
function hasDuplicatePaymentDestination(payments: readonly FoodServiceCheckoutPayment[]) {
  const destinations = new Set<string>();
  return payments.some((payment) => {
    if (!payment.financialAccountId || !payment.paymentMethodConfigurationId) return false;
    const destination = `${payment.paymentMethodConfigurationId}:${payment.financialAccountId}`;
    if (destinations.has(destination)) return true;
    destinations.add(destination);
    return false;
  });
}

export function FoodServiceOrderCheckout({
  checkout,
  compatibleAccounts,
  context = "table",
  onAddPayment,
  onRemovePayment,
  onSettle,
  onUpdateCheckout,
  onUpdatePayment,
  order,
  paymentMethods,
  revenueCategories,
  settling,
}: {
  checkout: FoodServiceCheckoutForm;
  compatibleAccounts: (paymentMethodConfigurationId: string) => readonly FinancialAccountView[];
  context?: "counter" | "table";
  onAddPayment: (orderTotal: string) => void;
  onRemovePayment: (index: number) => void;
  onSettle: () => void;
  onUpdateCheckout: (changes: Partial<FoodServiceCheckoutForm>) => void;
  onUpdatePayment: (index: number, changes: Partial<FoodServiceCheckoutPayment>) => void;
  order: FoodServiceOrderView;
  paymentMethods: readonly PaymentMethodConfigurationView[];
  revenueCategories: readonly FinancialCategoryView[];
  settling: boolean;
}) {
  const payments = checkout.payments;
  const isPaymentInvalid =
    payments.length > 0 &&
    (!paymentsAreComplete(payments) ||
      hasDuplicatePaymentDestination(payments) ||
      !paymentsMatchOrderTotal(order.total, payments));
  const isCounter = context === "counter";

  return (
    <section className="grid gap-3 rounded-xl border border-brand-100 bg-brand-50 p-4">
      <div>
        <h4 className="font-semibold text-brand-950">
          {isCounter ? "Finalizar pedido de balcão" : "Finalizar comanda"}
        </h4>
        <p className="mt-1 text-sm text-brand-900">
          Registre o recebimento agora ou conclua a venda a prazo. A venda só será concluída após
          esta confirmação.
        </p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="grid gap-1.5 text-sm font-medium text-slate-800">
          Categoria de receita
          <select
            className="h-10 rounded-xl border bg-white px-3 font-normal"
            onChange={(event) => onUpdateCheckout({ revenueCategoryId: event.target.value })}
            value={checkout.revenueCategoryId}
          >
            <option value="">Selecione uma categoria</option>
            {revenueCategories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1.5 text-sm font-medium text-slate-800">
          Vencimento
          <input
            className="h-10 rounded-xl border bg-white px-3 font-normal"
            onChange={(event) => onUpdateCheckout({ dueDate: event.target.value })}
            type="date"
            value={checkout.dueDate}
          />
        </label>
      </div>
      <div className="rounded-lg bg-white p-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-slate-800">Recebimento no ato</p>
            <p className="mt-1 text-xs text-slate-600">
              Você pode combinar formas de pagamento. Sem itens, a venda fica a prazo.
            </p>
          </div>
          <Button
            disabled={payments.length >= 10}
            onClick={() => onAddPayment(order.total)}
            type="button"
            variant="outline"
          >
            Adicionar pagamento
          </Button>
        </div>
        {payments.map((payment, index) => (
          <div
            className="mt-3 grid gap-3 border-t pt-3 sm:grid-cols-[1fr_1fr_8rem_auto]"
            key={`${order.id}-${index}`}
          >
            <label className="grid gap-1.5 text-sm font-medium text-slate-800">
              Forma
              <select
                className="h-10 rounded-xl border bg-white px-3 font-normal"
                onChange={(event) =>
                  onUpdatePayment(index, {
                    financialAccountId: compatibleAccounts(event.target.value)[0]?.id ?? "",
                    paymentMethodConfigurationId: event.target.value,
                  })
                }
                value={payment.paymentMethodConfigurationId}
              >
                <option value="">Selecione uma forma</option>
                {paymentMethods.map((method) => (
                  <option key={method.id} value={method.id}>
                    {method.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-slate-800">
              Conta de destino
              <select
                className="h-10 rounded-xl border bg-white px-3 font-normal"
                onChange={(event) =>
                  onUpdatePayment(index, { financialAccountId: event.target.value })
                }
                value={payment.financialAccountId}
              >
                <option value="">Selecione uma conta</option>
                {compatibleAccounts(payment.paymentMethodConfigurationId).map((account) => (
                  <option key={account.id} value={account.id}>
                    {account.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-1.5 text-sm font-medium text-slate-800">
              Valor
              <input
                className="h-10 rounded-xl border bg-white px-3 font-normal"
                inputMode="decimal"
                min="0.01"
                onChange={(event) => onUpdatePayment(index, { amount: event.target.value })}
                step="0.01"
                type="number"
                value={payment.amount}
              />
            </label>
            <div className="flex items-end">
              <Button onClick={() => onRemovePayment(index)} type="button" variant="outline">
                Remover
              </Button>
            </div>
          </div>
        ))}
        {payments.length > 0 ? (
          <div className="mt-3 grid gap-1">
            <p className="text-sm font-medium text-slate-700">
              Recebido: {formatCurrency(String(paymentTotal(payments)))} de{" "}
              {formatCurrency(order.total)}
            </p>
            {!paymentsAreComplete(payments) ? (
              <p className="text-xs text-rose-700" role="alert">
                Preencha valor, conta e forma em cada pagamento.
              </p>
            ) : hasDuplicatePaymentDestination(payments) ? (
              <p className="text-xs text-rose-700" role="alert">
                Agrupe valores que usam a mesma forma e conta financeira.
              </p>
            ) : !paymentsMatchOrderTotal(order.total, payments) ? (
              <p className="text-xs text-rose-700" role="alert">
                A soma dos pagamentos precisa ser igual ao total da comanda.
              </p>
            ) : null}
          </div>
        ) : (
          <p className="mt-3 text-xs text-brand-900">
            Sem recebimento agora, a venda será registrada a prazo e poderá ser baixada pelo
            financeiro depois.
          </p>
        )}
      </div>
      <Button disabled={settling || isPaymentInvalid} onClick={onSettle} type="button">
        {settling
          ? "Concluindo…"
          : isCounter
            ? "Confirmar pedido e venda"
            : "Confirmar e liberar mesa"}
      </Button>
    </section>
  );
}
