"use client";

import type { FoodServiceRecipeItemView, ProductView, ProblemDetails } from "@gestor/contracts";
import { foodServiceRecipeItemListSchema } from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { useEffect, useMemo, useState } from "react";

type DraftItem = { ingredientProductId: string; quantity: string };

function formatQuantity(value: string) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(Number(value));
}

export function FoodServiceRecipes({
  branchId,
  organizationId,
  products,
}: {
  branchId: string;
  organizationId: string;
  products: readonly ProductView[];
}) {
  const [productId, setProductId] = useState("");
  const [items, setItems] = useState<readonly DraftItem[]>([]);
  const [saved, setSaved] = useState<readonly FoodServiceRecipeItemView[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const ingredients = useMemo(
    () => products.filter((product) => product.id !== productId && product.kind === "STOCKABLE"),
    [productId, products],
  );

  useEffect(() => {
    if (!branchId || !productId) {
      setItems([]);
      setSaved([]);
      return;
    }
    let active = true;
    void fetch(
      `/api/v1/organizations/${organizationId}/food-service-recipes?branchId=${branchId}&productId=${productId}`,
    )
      .then(async (response) => {
        const result = (await response.json()) as { data?: unknown } & ProblemDetails;
        if (!response.ok)
          throw new Error(result.detail ?? "Não foi possível carregar a ficha técnica.");
        return foodServiceRecipeItemListSchema.parse(result.data);
      })
      .then((recipe) => {
        if (!active) return;
        setSaved(recipe);
        setItems(
          recipe.map((item) => ({
            ingredientProductId: item.ingredientProductId,
            quantity: item.quantity,
          })),
        );
      })
      .catch(
        (error) =>
          active &&
          setMessage(
            error instanceof Error ? error.message : "Não foi possível carregar a ficha técnica.",
          ),
      );
    return () => {
      active = false;
    };
  }, [branchId, organizationId, productId]);

  async function save() {
    if (!branchId || !productId) return setMessage("Selecione o produto que será preparado.");
    const response = await fetch(`/api/v1/organizations/${organizationId}/food-service-recipes`, {
      body: JSON.stringify({ branchId, items, productId }),
      headers: { "content-type": "application/json" },
      method: "PUT",
    });
    const result = (await response.json()) as { data?: unknown } & ProblemDetails;
    if (!response.ok)
      return setMessage(result.detail ?? "Não foi possível salvar a ficha técnica.");
    const recipe = foodServiceRecipeItemListSchema.parse(result.data);
    setSaved(recipe);
    setItems(
      recipe.map((item) => ({
        ingredientProductId: item.ingredientProductId,
        quantity: item.quantity,
      })),
    );
    setMessage(
      recipe.length
        ? "Ficha técnica salva."
        : "Ficha técnica removida. Este produto não terá baixa automática de insumos.",
    );
  }

  return (
    <section className="grid gap-4 rounded-xl border bg-white p-4">
      <div>
        <h2 className="font-semibold">Ficha técnica de insumos</h2>
        <p className="mt-1 text-sm text-slate-600">
          Defina os insumos consumidos para preparar cada produto nesta filial. Produtos preparados
          devem ser não estocáveis, pois a baixa ocorre nos insumos conforme a política configurada.
        </p>
      </div>
      <select
        className="h-10 rounded-xl border px-3"
        onChange={(event) => setProductId(event.target.value)}
        value={productId}
      >
        <option value="">Selecione o produto preparado não estocável</option>
        {products
          .filter((product) => product.kind !== "STOCKABLE")
          .map((product) => (
            <option key={product.id} value={product.id}>
              {product.name}
            </option>
          ))}
      </select>
      {productId ? (
        <>
          {ingredients.length === 0 ? (
            <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">
              Cadastre ao menos um produto estocável adicional para usá-lo como insumo nesta ficha.
            </p>
          ) : null}
          <div className="grid gap-2">
            {items.map((item, index) => (
              <div
                className="grid gap-2 sm:grid-cols-[1fr_10rem_auto]"
                key={`${item.ingredientProductId}-${index}`}
              >
                <select
                  className="h-10 rounded-xl border px-3"
                  onChange={(event) =>
                    setItems((value) =>
                      value.map((current, position) =>
                        position === index
                          ? { ...current, ingredientProductId: event.target.value }
                          : current,
                      ),
                    )
                  }
                  value={item.ingredientProductId}
                >
                  <option value="">Selecione o insumo</option>
                  {ingredients.map((product) => (
                    <option
                      disabled={items.some(
                        (current, position) =>
                          position !== index && current.ingredientProductId === product.id,
                      )}
                      key={product.id}
                      value={product.id}
                    >
                      {product.name} · {product.unit}
                    </option>
                  ))}
                </select>
                <input
                  className="h-10 rounded-xl border px-3"
                  min="0.0001"
                  onChange={(event) =>
                    setItems((value) =>
                      value.map((current, position) =>
                        position === index ? { ...current, quantity: event.target.value } : current,
                      ),
                    )
                  }
                  step="0.0001"
                  type="number"
                  value={item.quantity}
                />
                <Button
                  onClick={() =>
                    setItems((value) => value.filter((_, position) => position !== index))
                  }
                  type="button"
                  variant="outline"
                >
                  Remover
                </Button>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              disabled={ingredients.length === 0}
              onClick={() =>
                setItems((value) => [...value, { ingredientProductId: "", quantity: "1" }])
              }
              type="button"
              variant="outline"
            >
              Adicionar insumo
            </Button>
            <Button onClick={() => void save()} type="button">
              Salvar ficha técnica
            </Button>
          </div>
          {saved.length ? (
            <p className="text-sm text-slate-600">
              Ficha atual:{" "}
              {saved
                .map(
                  (item) =>
                    `${formatQuantity(item.quantity)} ${item.ingredientUnit} de ${item.ingredientProductName}`,
                )
                .join(" · ")}
            </p>
          ) : null}
        </>
      ) : null}
      {message ? (
        <p className="text-sm text-brand-800" role="status">
          {message}
        </p>
      ) : null}
    </section>
  );
}
