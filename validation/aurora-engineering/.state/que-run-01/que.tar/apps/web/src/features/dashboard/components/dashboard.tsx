"use client";

import {
  branchListSchema,
  dashboardViewSchema,
  type BranchView,
  type DashboardView,
} from "@gestor/contracts";
import Link from "next/link";
import { useEffect, useState } from "react";

import { fetchData } from "../../sales/components/direct-sale-data";

const labels: Record<keyof DashboardView["metrics"], string> = {
  bankBalance: "Saldo bancário",
  cashBalance: "Saldo de caixa",
  dueNextSevenDays: "Próximos 7 dias",
  lowStock: "Estoque baixo",
  overdue: "Contas vencidas",
  paid: "Pagamentos realizados",
  received: "Valores recebidos",
  revenue: "Faturamento líquido",
};

export function Dashboard({ organizationId }: { organizationId: string }) {
  const [branchId, setBranchId] = useState("");
  const [branches, setBranches] = useState<readonly BranchView[]>([]);
  const [dashboard, setDashboard] = useState<DashboardView | null>(null);
  const [feedback, setFeedback] = useState("Carregando indicadores...");

  useEffect(() => {
    const controller = new AbortController();
    void fetchData(
      `/api/v1/organizations/${organizationId}/branches`,
      branchListSchema,
      controller.signal,
    )
      .then(setBranches)
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Não foi possível listar filiais.");
      });
    return () => controller.abort();
  }, [organizationId]);

  useEffect(() => {
    const controller = new AbortController();
    const query = branchId ? `?branchId=${branchId}` : "";
    void fetchData(
      `/api/v1/organizations/${organizationId}/dashboard${query}`,
      dashboardViewSchema,
      controller.signal,
    )
      .then((data) => {
        setDashboard(data);
        setFeedback("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted)
          setFeedback(error instanceof Error ? error.message : "Não foi possível abrir o painel.");
      });
    return () => controller.abort();
  }, [branchId, organizationId]);

  return (
    <section className="grid gap-5" aria-labelledby="dashboard-title">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-brand-600 text-xs font-bold tracking-[0.16em] uppercase">
            Visão geral
          </p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight" id="dashboard-title">
            Dashboard operacional
          </h1>
          {dashboard ? (
            <p className="mt-1 text-sm text-slate-600">
              Período de {formatDate(dashboard.period.from)} a {formatDate(dashboard.period.to)}.
            </p>
          ) : null}
        </div>
        <label className="grid gap-1 text-sm font-medium">
          Filial
          <select
            className="min-w-52 rounded-md border bg-white px-3 py-2"
            onChange={(event) => {
              setFeedback("Carregando indicadores...");
              setBranchId(event.target.value);
            }}
            value={branchId}
          >
            <option value="">Todas as filiais permitidas</option>
            {branches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      {feedback ? (
        <p className="rounded-xl border bg-white px-4 py-3 text-sm" role="status">
          {feedback}
        </p>
      ) : null}
      {dashboard ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Object.entries(dashboard.metrics).map(([code, metric]) =>
            metric ? (
              <Link
                className="rounded-2xl border bg-white p-5 shadow-sm transition hover:border-slate-300 hover:shadow-md"
                href={metric.href}
                key={code}
              >
                <p className="text-sm text-slate-600">{labels[code as keyof typeof labels]}</p>
                <p className="mt-2 text-2xl font-semibold text-slate-950">
                  {code === "lowStock" ? (metric.count ?? 0) : formatMoney(metric.value)}
                </p>
                {metric.count !== undefined && code !== "lowStock" ? (
                  <p className="mt-1 text-xs text-slate-500">{metric.count} conta(s)</p>
                ) : null}
                <p className="text-brand-700 mt-4 text-xs font-semibold">Ver origem e detalhes →</p>
              </Link>
            ) : null,
          )}
        </div>
      ) : null}
    </section>
  );
}

function formatMoney(value: string) {
  return new Intl.NumberFormat("pt-BR", { currency: "BRL", style: "currency" }).format(
    Number(value),
  );
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(
    new Date(`${value}T12:00:00.000Z`),
  );
}
