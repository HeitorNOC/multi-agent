import { organizationInvitationParamsSchema } from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = {
  params: Promise<{ invitationId: string; organizationId: string }>;
};

export async function POST(request: Request, route: RouteParameters) {
  return handleApiRequest(request, async (api) => {
    const params = organizationInvitationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      ...api,
      organizationId: params.organizationId,
      userId: identity.userId,
    });
    const invitation = await services.revokeOrganizationInvitation.execute(
      { ...params, idempotencyKey: requireIdempotencyKey(request) },
      actor,
    );
    return Response.json({ data: invitation });
  });
}
