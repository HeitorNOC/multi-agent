"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  catalogCategoryViewSchema,
  createCatalogCategoryBodySchema,
  type CreateCatalogCategoryBody,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useForm } from "react-hook-form";

import { CatalogSection, ErrorText, StatusPill } from "./catalog-layout";
import { post, setProblem, toggle } from "./catalog-helpers";
import type { CatalogSectionProps } from "./catalog-types";

export function CategorySection({
  organizationId,
  setFeedback,
  setState,
  state,
}: CatalogSectionProps) {
  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
  } = useForm<CreateCatalogCategoryBody>({
    defaultValues: { name: "" },
    resolver: zodResolver(createCatalogCategoryBodySchema),
  });
  const submit = handleSubmit(async (values) => {
    const response = await post(
      `/api/v1/organizations/${organizationId}/catalog-categories`,
      values,
    );
    if (!response.ok) return setProblem(response, setError);
    const category = catalogCategoryViewSchema.parse(
      ((await response.json()) as { data: unknown }).data,
    );
    setState((current) =>
      current ? { ...current, categories: [...current.categories, category] } : current,
    );
    reset();
    setFeedback("Categoria cadastrada.");
  });
  return (
    <CatalogSection
      title="Categorias"
      description="Organize produtos e serviços sem misturar categorias financeiras."
    >
      <form className="flex flex-col gap-3 sm:flex-row" onSubmit={submit}>
        <div className="grow">
          <Label htmlFor="category-name">Nome</Label>
          <Input id="category-name" {...register("name")} />
          {errors.name ? <ErrorText>{errors.name.message}</ErrorText> : null}
        </div>
        <Button className="self-end" disabled={isSubmitting} type="submit">
          Cadastrar categoria
        </Button>
      </form>
      {errors.root ? <ErrorText>{errors.root.message}</ErrorText> : null}
      <div className="mt-4 flex flex-wrap gap-2">
        {state.categories.map((category) => (
          <StatusPill
            entity={category}
            key={category.id}
            onToggle={() =>
              void toggle(
                "catalog-categories",
                category,
                organizationId,
                catalogCategoryViewSchema,
                (updated) =>
                  setState((current) =>
                    current
                      ? {
                          ...current,
                          categories: current.categories.map((item) =>
                            item.id === updated.id ? updated : item,
                          ),
                        }
                      : current,
                  ),
                setFeedback,
              )
            }
          />
        ))}
      </div>
    </CatalogSection>
  );
}
