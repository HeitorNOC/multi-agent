"use client";

import type {
  FinancialAccountView,
  FinancialObligationView,
  PaymentMethodConfigurationView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import type { Dispatch, SetStateAction } from "react";

import { formatBrl, formatDate } from "./financial-obligation-format";
import { SettlementForm } from "./financial-obligation-settlement-form";
import { StatusBadge } from "./financial-obligation-ui";
import { CatalogFilesButton } from "../../catalog/components/catalog-files-button";

export type CancellationDraft = {
  id: string;
  idempotencyKey: string;
  reason: string;
};
export type ReversalDraft = CancellationDraft;

type FinancialObligationListProps = {
  branchNames: ReadonlyMap<string, string>;
  cancellation: CancellationDraft | null;
  categoryNames: ReadonlyMap<string, string>;
  feedback: string | null;
  financialAccounts: readonly FinancialAccountView[] | null;
  isCancelling: boolean;
  isLoadingMore: boolean;
  isReversing: boolean;
  kind: "PAYABLE" | "RECEIVABLE";
  loadError: string | null;
  nextCursor: string | null;
  obligations: readonly FinancialObligationView[] | null;
  onConfirmCancellation: (obligation: FinancialObligationView) => Promise<void>;
  onConfirmReversal: (obligation: FinancialObligationView) => Promise<void>;
  onLoadMore: () => Promise<void>;
  onRetry: () => void;
  onSettled: (obligation: FinancialObligationView) => void;
  organizationId: string;
  paymentMethods: readonly PaymentMethodConfigurationView[] | null;
  referencesLoaded: boolean;
  reversal: ReversalDraft | null;
  setCancellation: Dispatch<SetStateAction<CancellationDraft | null>>;
  setSettlementId: Dispatch<SetStateAction<string | null>>;
  setReversal: Dispatch<SetStateAction<ReversalDraft | null>>;
  settlementId: string | null;
  today: string;
};

export function FinancialObligationList({
  branchNames,
  cancellation,
  categoryNames,
  feedback,
  financialAccounts,
  isCancelling,
  isLoadingMore,
  isReversing,
  kind,
  loadError,
  nextCursor,
  obligations,
  onConfirmCancellation,
  onConfirmReversal,
  onLoadMore,
  onRetry,
  onSettled,
  organizationId,
  paymentMethods,
  referencesLoaded,
  reversal,
  setCancellation,
  setSettlementId,
  setReversal,
  settlementId,
  today,
}: FinancialObligationListProps) {
  return (
    <section aria-labelledby="obligation-list-title" className="grid content-start gap-4">
      <div>
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">
          Fluxo projetado
        </p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="obligation-list-title">
          {kind === "RECEIVABLE" ? "Contas a receber" : "Contas a pagar"}
        </h2>
        <p className="mt-2 text-xs leading-5 text-slate-500">
          Vencido é calculado pela data local da empresa e não é um estado gravado.
        </p>
      </div>

      {feedback ? (
        <div className="rounded-xl border bg-white px-4 py-3 text-sm text-slate-700" role="status">
          {feedback}
        </div>
      ) : null}

      {!obligations || !referencesLoaded || !financialAccounts || !paymentMethods ? (
        <div className="grid gap-3 rounded-2xl border bg-white p-5">
          <p className="break-words text-sm text-slate-600">
            {loadError ?? "Carregando contas, filiais, categorias e meios de pagamento..."}
          </p>
          {loadError ? (
            <div>
              <Button
                onClick={() => {
                  onRetry();
                }}
                size="sm"
                variant="outline"
              >
                Tentar novamente
              </Button>
            </div>
          ) : null}
        </div>
      ) : obligations.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-white p-6 text-sm leading-6 text-slate-600">
          Nenhuma conta deste tipo foi registrada.
        </div>
      ) : (
        <div className="grid gap-4">
          <ul className="grid gap-3">
            {obligations.map((obligation) => (
              <li className="rounded-2xl border bg-white p-5" key={obligation.id}>
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="break-words text-sm font-semibold text-slate-950">
                        {obligation.counterpartyName}
                      </h3>
                      <StatusBadge obligation={obligation} />
                    </div>
                    <p className="mt-1 break-words text-xs text-slate-500">
                      {obligation.description} ·{" "}
                      {branchNames.get(obligation.branchId) ?? "Filial indisponível"} ·{" "}
                      {categoryNames.get(obligation.categoryId) ?? "Categoria indisponível"}
                    </p>
                    <p className="mt-4 text-2xl font-semibold tracking-tight text-slate-950">
                      {formatBrl(obligation.openAmount)}
                    </p>
                    <p className="mt-2 text-xs text-slate-500">
                      Vencimento: {formatDate(obligation.dueDate)} · Competência:{" "}
                      {formatDate(obligation.competencyDate)}
                    </p>
                    {obligation.cancellationReason ? (
                      <p className="mt-2 text-xs leading-5 text-slate-500">
                        Motivo: {obligation.cancellationReason}
                      </p>
                    ) : null}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <CatalogFilesButton
                      allowImage={false}
                      itemId={obligation.id}
                      organizationId={organizationId}
                      segment="financial-obligations"
                    />
                    {["PENDING", "PARTIAL"].includes(obligation.status) &&
                    cancellation?.id !== obligation.id &&
                    settlementId !== obligation.id ? (
                      <>
                        <Button
                          onClick={() => {
                            setCancellation(null);
                            setSettlementId(obligation.id);
                          }}
                          size="sm"
                        >
                          {obligation.kind === "RECEIVABLE" ? "Receber" : "Pagar"}
                        </Button>
                        <Button
                          onClick={() => {
                            setSettlementId(null);
                            setCancellation({
                              id: obligation.id,
                              idempotencyKey: crypto.randomUUID(),
                              reason: "",
                            });
                          }}
                          size="sm"
                          variant="outline"
                        >
                          Cancelar
                        </Button>
                      </>
                    ) : null}
                    {obligation.status === "SETTLED" && reversal?.id !== obligation.id ? (
                      <Button
                        onClick={() => {
                          setCancellation(null);
                          setSettlementId(null);
                          setReversal({
                            id: obligation.id,
                            idempotencyKey: crypto.randomUUID(),
                            reason: "",
                          });
                        }}
                        size="sm"
                        variant="outline"
                      >
                        Estornar
                      </Button>
                    ) : null}
                  </div>
                </div>
                {settlementId === obligation.id ? (
                  <SettlementForm
                    financialAccounts={financialAccounts}
                    obligation={obligation}
                    onCancel={() => setSettlementId(null)}
                    onSettled={(updated) => {
                      onSettled(updated);
                    }}
                    organizationId={organizationId}
                    paymentMethods={paymentMethods}
                    today={today}
                  />
                ) : null}
                {cancellation?.id === obligation.id ? (
                  <div className="mt-4 grid gap-3 border-t pt-4">
                    <Label htmlFor={`cancellation-${obligation.id}`}>Motivo do cancelamento</Label>
                    <Input
                      id={`cancellation-${obligation.id}`}
                      onChange={(event) =>
                        setCancellation({ ...cancellation, reason: event.target.value })
                      }
                      placeholder="Ex.: Lançamento duplicado"
                      value={cancellation.reason}
                    />
                    <div className="flex flex-wrap gap-2">
                      <Button
                        disabled={isCancelling}
                        onClick={() => void onConfirmCancellation(obligation)}
                        size="sm"
                      >
                        {isCancelling ? "Cancelando..." : "Confirmar cancelamento"}
                      </Button>
                      <Button
                        disabled={isCancelling}
                        onClick={() => setCancellation(null)}
                        size="sm"
                        variant="outline"
                      >
                        Voltar
                      </Button>
                    </div>
                  </div>
                ) : null}
                {reversal?.id === obligation.id ? (
                  <div className="mt-4 grid gap-3 border-t pt-4">
                    <Label htmlFor={`reversal-${obligation.id}`}>Motivo do estorno</Label>
                    <Input
                      id={`reversal-${obligation.id}`}
                      onChange={(event) => setReversal({ ...reversal, reason: event.target.value })}
                      placeholder="Ex.: Baixa feita na conta incorreta"
                      value={reversal.reason}
                    />
                    <p className="text-xs leading-5 text-slate-500">
                      O estorno cria movimentos compensatórios e não reabre esta dívida.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        disabled={isReversing}
                        onClick={() => void onConfirmReversal(obligation)}
                        size="sm"
                      >
                        {isReversing ? "Estornando..." : "Confirmar estorno"}
                      </Button>
                      <Button
                        disabled={isReversing}
                        onClick={() => setReversal(null)}
                        size="sm"
                        variant="outline"
                      >
                        Voltar
                      </Button>
                    </div>
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
          {nextCursor ? (
            <Button disabled={isLoadingMore} onClick={() => void onLoadMore()} variant="outline">
              {isLoadingMore ? "Carregando..." : "Carregar mais"}
            </Button>
          ) : null}
        </div>
      )}
    </section>
  );
}
