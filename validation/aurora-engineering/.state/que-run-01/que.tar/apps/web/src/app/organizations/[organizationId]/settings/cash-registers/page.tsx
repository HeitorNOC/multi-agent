import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";
import Link from "next/link";

import { CashRegisterConfigurations } from "@/features/cash-registers/components/cash-register-configurations";
import { ModuleGate } from "@/features/modules/components/module-gate";

export const metadata: Metadata = {
  title: "Caixa operacional | Gestor",
};

type CashRegistersPageProps = {
  params: Promise<{ organizationId: string }>;
};

export default async function CashRegistersPage({ params }: CashRegistersPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto min-h-screen w-full max-w-5xl px-5 py-10 sm:px-8 sm:py-14">
      <header className="mb-8">
        <Link
          className="text-brand-700 hover:text-brand-800 inline-flex min-h-11 items-center text-sm font-semibold transition"
          href={`/organizations/${organizationId}`}
        >
          ← Voltar ao checklist
        </Link>
        <p className="text-brand-600 mt-7 text-xs font-bold tracking-[0.16em] uppercase">
          Operação financeira
        </p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">
          Caixa operacional
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          Abra seu caixa, registre entradas e retiradas e confira o dinheiro antes de fechar.
        </p>
      </header>

      <ModuleGate moduleCode="financial" organizationId={organizationId}>
        <CashRegisterConfigurations organizationId={organizationId} />
      </ModuleGate>
    </main>
  );
}
