"use client";

import type { ReactNode } from "react";

import { resolveModuleAccessPresentation } from "../module-access";
import { useOrganizationModules } from "../use-organization-modules";

type ModuleGateProps = {
  children: ReactNode;
  moduleCode: string;
  organizationId: string;
};

export function ModuleGate({ children, moduleCode, organizationId }: ModuleGateProps) {
  const state = useOrganizationModules(organizationId);

  if (state.status === "LOADING") {
    return (
      <div aria-live="polite" className="rounded-2xl border bg-slate-50 p-5 text-sm text-slate-600">
        Verificando acesso ao módulo...
      </div>
    );
  }

  if (state.status === "ERROR") {
    return (
      <div
        aria-live="assertive"
        className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-800"
        role="alert"
      >
        {state.message}
      </div>
    );
  }

  const access = resolveModuleAccessPresentation(state.modules, moduleCode);

  if (access.mode === "DISABLED") {
    return (
      <div
        className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900"
        role="status"
      >
        <p className="font-semibold">Módulo indisponível</p>
        <p className="mt-1">{access.reason}</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      {access.mode === "READ_ONLY" ? (
        <div
          className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900"
          role="status"
        >
          <p className="font-semibold">Somente leitura</p>
          <p className="mt-1">{access.reason}</p>
        </div>
      ) : null}
      <fieldset className="contents" disabled={access.mode === "READ_ONLY"}>
        {children}
      </fieldset>
    </div>
  );
}
