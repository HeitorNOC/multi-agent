"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  adjustStockBodySchema,
  createInitialStockBodySchema,
  stockMutationResultSchema,
  type AdjustStockBody,
  type CreateInitialStockBody,
  type ProblemDetails,
  type StockBalanceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useForm } from "react-hook-form";

export function InitialStockForm(props: StockFormProps) {
  const form = useForm<CreateInitialStockBody>({
    defaultValues: { productId: props.balance.productId, quantity: "0", unitCost: "0" },
    resolver: zodResolver(createInitialStockBodySchema),
  });
  return (
    <StockFormShell balance={props.balance} title="Definir estoque inicial">
      <form
        className="grid gap-4 sm:grid-cols-3"
        onSubmit={form.handleSubmit(async (body) => {
          await submitStock(
            `/api/v1/organizations/${props.organizationId}/branches/${props.branchId}/stock-movements/initial`,
            body,
            props,
          );
        })}
      >
        <input type="hidden" {...form.register("productId")} />
        <Field error={form.formState.errors.quantity?.message} label="Quantidade">
          <Input inputMode="decimal" {...form.register("quantity")} />
        </Field>
        <Field error={form.formState.errors.unitCost?.message} label="Custo unitário">
          <Input inputMode="decimal" {...form.register("unitCost")} />
        </Field>
        <div className="flex items-end">
          <Button disabled={form.formState.isSubmitting} type="submit">
            Salvar estoque inicial
          </Button>
        </div>
      </form>
    </StockFormShell>
  );
}

export function AdjustmentForm(props: StockFormProps) {
  const form = useForm<AdjustStockBody>({
    defaultValues: {
      expectedVersion: props.balance.version,
      productId: props.balance.productId,
      quantityDelta: "",
      reason: "",
    },
    resolver: zodResolver(adjustStockBodySchema),
  });
  return (
    <StockFormShell balance={props.balance} title="Ajustar estoque">
      <form
        className="grid gap-4 sm:grid-cols-3"
        onSubmit={form.handleSubmit(async (body) => {
          await submitStock(
            `/api/v1/organizations/${props.organizationId}/branches/${props.branchId}/stock-movements/adjustments`,
            body,
            props,
          );
        })}
      >
        <input type="hidden" {...form.register("productId")} />
        <input type="hidden" {...form.register("expectedVersion", { valueAsNumber: true })} />
        <Field
          error={form.formState.errors.quantityDelta?.message}
          label="Variação (+ entrada / - saída)"
        >
          <Input inputMode="decimal" {...form.register("quantityDelta")} />
        </Field>
        <Field error={form.formState.errors.reason?.message} label="Motivo">
          <Input {...form.register("reason")} />
        </Field>
        <div className="flex items-end">
          <Button disabled={form.formState.isSubmitting} type="submit">
            Registrar ajuste
          </Button>
        </div>
      </form>
    </StockFormShell>
  );
}

type StockFormProps = {
  balance: StockBalanceView;
  branchId: string;
  onChanged: (balance: StockBalanceView) => void;
  organizationId: string;
  setFeedback: (message: string) => void;
};

async function submitStock(path: string, body: object, props: StockFormProps) {
  props.setFeedback("");
  const response = await fetch(path, {
    body: JSON.stringify(body),
    headers: { "content-type": "application/json", "idempotency-key": crypto.randomUUID() },
    method: "POST",
  });
  const payload = (await response.json()) as { data?: unknown } & Partial<ProblemDetails>;
  if (!response.ok) {
    props.setFeedback(payload.detail ?? "Não foi possível atualizar o estoque.");
    return;
  }
  props.onChanged(stockMutationResultSchema.parse(payload.data).balance);
}

function StockFormShell({
  balance,
  children,
  title,
}: {
  balance: StockBalanceView;
  children: React.ReactNode;
  title: string;
}) {
  return (
    <div className="rounded-2xl border bg-white p-5 shadow-sm">
      <h2 className="text-lg font-semibold">
        {title}: {balance.productName}
      </h2>
      <p className="mb-4 mt-1 text-sm text-slate-600">
        Saldo atual: {balance.quantityOnHand} {balance.unit}
      </p>
      {children}
    </div>
  );
}

function Field({
  children,
  error,
  label,
}: {
  children: React.ReactNode;
  error: string | undefined;
  label: string;
}) {
  return (
    <label className="grid gap-1 text-sm font-medium">
      {label}
      {children}
      {error ? <span className="text-xs text-red-700">{error}</span> : null}
    </label>
  );
}
