import { beforeEach, describe, expect, it, vi } from "vitest";

const { authenticate, requireCurrentLegalAcceptance } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  requireCurrentLegalAcceptance: vi.fn(),
}));

vi.mock("./container", () => ({ services: { identityProvider: { authenticate } } }));
vi.mock("./legal-acceptance", () => ({ requireCurrentLegalAcceptance }));

import { handleApiRequest } from "./api-request";

describe("legal acceptance authorization", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    requireCurrentLegalAcceptance.mockReset().mockResolvedValue(undefined);
  });

  it("requires current legal acceptance before a private handler", async () => {
    const handler = vi.fn().mockResolvedValue(Response.json({ data: true }));
    const response = await handleApiRequest(
      new Request("http://localhost/api/v1/organizations"),
      handler,
      { rateLimit: false },
    );
    expect(response.status).toBe(200);
    expect(requireCurrentLegalAcceptance).toHaveBeenCalledWith("user-1");
    expect(handler).toHaveBeenCalledOnce();
  });

  it("lets the acceptance endpoint inspect its own status", async () => {
    const handler = vi.fn().mockResolvedValue(Response.json({ data: true }));
    await handleApiRequest(new Request("http://localhost/api/v1/legal/acceptance"), handler, {
      legalAcceptance: false,
      rateLimit: false,
    });
    expect(requireCurrentLegalAcceptance).not.toHaveBeenCalled();
  });
});
