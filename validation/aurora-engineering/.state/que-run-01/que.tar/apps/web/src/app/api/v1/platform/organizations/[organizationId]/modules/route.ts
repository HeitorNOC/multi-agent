import { organizationParamsSchema } from "@gestor/contracts";

import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { requireMfaForPlatformRole } from "@/lib/server/mfa-policy";

type RouteParameters = {
  params: Promise<{
    organizationId: string;
  }>;
};

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolvePlatformActor.execute({
      correlationId: api.correlationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    requireMfaForPlatformRole(identity, actor.role);
    const modules = await services.listPlatformOrganizationModules.execute(params, actor);

    return Response.json({ data: modules });
  });
}
