import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, listPurchaseSuggestions, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  listPurchaseSuggestions: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    identityProvider: { authenticate },
    listPurchaseSuggestions: { execute: listPurchaseSuggestions },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET } from "./route";

const organizationId = "30000000-0000-4000-8000-000000000001";
const branchId = "30000000-0000-4000-8000-000000000002";
const route = { params: Promise.resolve({ branchId, organizationId }) };

describe("purchase suggestions route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user-1" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "MANAGER" });
    listPurchaseSuggestions.mockReset().mockResolvedValue([{ suggestedQuantity: "3.0000" }]);
  });

  it("scopes purchase shortages to the selected tenant branch", async () => {
    const response = await GET(
      new Request(
        `http://localhost/api/v1/organizations/${organizationId}/branches/${branchId}/purchase-suggestions?limit=20`,
      ),
      route,
    );
    expect(response.status).toBe(200);
    expect(listPurchaseSuggestions).toHaveBeenCalledWith(
      { branchId, limit: 20, organizationId },
      { role: "MANAGER" },
    );
  });
});
