import {
  completeFoodServiceOrderCheckoutBodySchema,
  organizationParamsSchema,
} from "@gestor/contracts";
import { z } from "zod";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

const parametersSchema = organizationParamsSchema.extend({ orderId: z.uuid() });
type RouteParameters = { params: Promise<{ organizationId: string; orderId: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = parametersSchema.parse(await route.params);
    const body = completeFoodServiceOrderCheckoutBodySchema.parse(await readJsonBody(request));
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    const result = await services.completeFoodServiceCheckout.execute(
      { ...body, ...params, idempotencyKey: requireIdempotencyKey(request) },
      actor,
    );
    return Response.json({ data: result }, { status: 201 });
  });
}
