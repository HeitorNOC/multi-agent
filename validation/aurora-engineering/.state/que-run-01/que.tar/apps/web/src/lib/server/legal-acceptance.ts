import { AppError } from "@gestor/kernel";
import { LegalDocumentType } from "@gestor/database";
import { getAuthDatabase } from "@gestor/auth";

export const CURRENT_LEGAL_DOCUMENTS = {
  privacyPolicy: { type: LegalDocumentType.PRIVACY_POLICY, version: "2026-10-18" },
  termsOfUse: { type: LegalDocumentType.TERMS_OF_USE, version: "2026-10-18" },
} as const;

const requiredDocuments = Object.values(CURRENT_LEGAL_DOCUMENTS);

export type LegalAcceptanceStatus = {
  accepted: boolean;
  documents: Record<keyof typeof CURRENT_LEGAL_DOCUMENTS, { version: string }>;
};

export async function getLegalAcceptanceStatus(userId: string): Promise<LegalAcceptanceStatus> {
  const acceptances = await getAuthDatabase().userLegalAcceptance.findMany({
    select: { documentType: true, version: true },
    where: {
      userId,
      OR: requiredDocuments.map(({ type, version }) => ({ documentType: type, version })),
    },
  });
  const accepted = new Set(
    acceptances.map(({ documentType, version }) => `${documentType}:${version}`),
  );

  return {
    accepted: requiredDocuments.every(({ type, version }) => accepted.has(`${type}:${version}`)),
    documents: {
      privacyPolicy: { version: CURRENT_LEGAL_DOCUMENTS.privacyPolicy.version },
      termsOfUse: { version: CURRENT_LEGAL_DOCUMENTS.termsOfUse.version },
    },
  };
}

export async function requireCurrentLegalAcceptance(userId: string): Promise<void> {
  if ((await getLegalAcceptanceStatus(userId)).accepted) return;

  throw new AppError({
    code: "LEGAL_ACCEPTANCE_REQUIRED",
    kind: "AUTHORIZATION",
    message: "É necessário aceitar os Termos de Uso e a Política de Privacidade para continuar.",
  });
}

export async function acceptCurrentLegalDocuments(userId: string): Promise<LegalAcceptanceStatus> {
  const database = getAuthDatabase();
  await database.$transaction(
    requiredDocuments.map(({ type, version }) =>
      database.userLegalAcceptance.upsert({
        create: { documentType: type, userId, version },
        update: { acceptedAt: new Date() },
        where: { userId_documentType_version: { documentType: type, userId, version } },
      }),
    ),
  );

  return getLegalAcceptanceStatus(userId);
}
