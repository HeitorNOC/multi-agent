import { organizationParamsSchema } from "@gestor/contracts";
import Link from "next/link";

import { CreateBranchForm } from "@/features/branches/components/create-branch-form";

type NewBranchPageProps = {
  params: Promise<{
    organizationId: string;
  }>;
};

export default async function NewBranchPage({ params }: NewBranchPageProps) {
  const { organizationId } = organizationParamsSchema.parse(await params);

  return (
    <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:px-8 sm:py-20">
      <Link className="text-sm font-medium text-slate-600 transition hover:text-slate-950" href="/">
        ← Voltar
      </Link>

      <section className="mt-8 rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.06)] sm:p-9">
        <header className="mb-8">
          <p className="text-brand-600 text-xs font-bold tracking-[0.16em] uppercase">
            Organização
          </p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">Nova filial</h1>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Cadastre uma unidade dentro dos limites e permissões do plano atual.
          </p>
        </header>

        <CreateBranchForm organizationId={organizationId} />
      </section>
    </main>
  );
}
