import { organizationParamsSchema } from "@gestor/contracts";
import type { Metadata } from "next";

import { OrganizationNavigation } from "@/features/modules/components/organization-navigation";
import { OrganizationUserManagement } from "@/features/organization-users/components/organization-user-management";

export const metadata: Metadata = { title: "Usuários e acessos | Gestor" };

export default async function UsersPage({
  params,
}: {
  params: Promise<{ organizationId: string }>;
}) {
  const { organizationId } = organizationParamsSchema.parse(await params);
  return (
    <main className="mx-auto grid min-h-screen w-full max-w-6xl gap-8 px-5 py-10 sm:px-8">
      <header>
        <h1 className="text-3xl font-semibold">Usuários, papéis e filiais</h1>
        <p className="mt-2 text-sm text-slate-600">
          Controle explicitamente o que cada pessoa pode acessar.
        </p>
        <div className="mt-5">
          <OrganizationNavigation organizationId={organizationId} />
        </div>
      </header>
      <OrganizationUserManagement organizationId={organizationId} />
    </main>
  );
}
