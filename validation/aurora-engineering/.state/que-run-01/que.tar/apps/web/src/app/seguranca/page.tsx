import Link from "next/link";

import { MfaEnrollment } from "@/features/auth/components/mfa-enrollment";
import { SessionManagement } from "@/features/auth/components/session-management";

export default function SecurityPage() {
  return (
    <main className="mx-auto w-full max-w-4xl px-5 py-12 sm:px-8">
      <Link className="text-brand-700 text-sm font-semibold hover:underline" href="/">
        Voltar ao início
      </Link>
      <div className="mt-8 grid gap-8">
        <MfaEnrollment />
        <SessionManagement />
      </div>
    </main>
  );
}
