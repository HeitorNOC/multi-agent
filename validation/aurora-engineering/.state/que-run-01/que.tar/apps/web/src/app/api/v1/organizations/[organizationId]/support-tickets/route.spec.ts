import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/server/legal-acceptance", () => ({ requireCurrentLegalAcceptance: vi.fn() }));

const { authenticate, createTicket, listTickets, resolveTenantActor } = vi.hoisted(() => ({
  authenticate: vi.fn(),
  createTicket: vi.fn(),
  listTickets: vi.fn(),
  resolveTenantActor: vi.fn(),
}));
vi.mock("@gestor/config", () => ({
  getServerEnv: () => ({ RATE_LIMIT_HASH_SECRET: "test-secret", TRUST_PROXY_HEADERS: false }),
}));
vi.mock("@/lib/server/container", () => ({
  services: {
    customerCare: { createTicket, listTickets },
    identityProvider: { authenticate },
    resolveTenantActor: { execute: resolveTenantActor },
  },
}));

import { GET, POST } from "./route";

const organizationId = "20000000-0000-4000-8000-000000000001";
const route = { params: Promise.resolve({ organizationId }) };
describe("support ticket route", () => {
  beforeEach(() => {
    authenticate.mockReset().mockResolvedValue({ userId: "user" });
    resolveTenantActor.mockReset().mockResolvedValue({ role: "OWNER" });
    createTicket.mockReset().mockResolvedValue({ id: "ticket" });
    listTickets.mockReset().mockResolvedValue([]);
  });
  it("lists only through the resolved tenant actor", async () => {
    const response = await GET(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/support-tickets`),
      route,
    );
    expect(response.status).toBe(200);
    expect(listTickets).toHaveBeenCalledWith({ organizationId }, { role: "OWNER" });
  });
  it("requires and forwards idempotency when opening a ticket", async () => {
    const body = {
      category: "Uso",
      description: "Não consigo concluir esta operação.",
      priority: "NORMAL",
      subject: "Dúvida no fluxo",
    };
    const response = await POST(
      new Request(`http://localhost/api/v1/organizations/${organizationId}/support-tickets`, {
        body: JSON.stringify(body),
        headers: { "content-type": "application/json", "idempotency-key": "ticket-key-001" },
        method: "POST",
      }),
      route,
    );
    expect(response.status).toBe(201);
    expect(createTicket).toHaveBeenCalledWith(
      { ...body, idempotencyKey: "ticket-key-001", organizationId },
      { role: "OWNER" },
    );
  });
});
