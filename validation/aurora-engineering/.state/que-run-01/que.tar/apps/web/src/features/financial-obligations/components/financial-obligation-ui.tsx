import type { FinancialObligationView } from "@gestor/contracts";
import { Label } from "@gestor/ui/components/label";
import type { ReactNode } from "react";

export function Field({
  children,
  error,
  htmlFor,
  label,
}: {
  children: ReactNode;
  error: string | undefined;
  htmlFor: string;
  label: string;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {error ? (
        <p className="text-sm text-red-700" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function StatusBadge({ obligation }: { obligation: FinancialObligationView }) {
  const label = obligation.isOverdue
    ? "Vencida"
    : obligation.status === "PENDING"
      ? "Pendente"
      : obligation.status === "PARTIAL"
        ? "Parcial"
        : obligation.status === "SETTLED"
          ? "Quitada"
          : obligation.status === "CANCELLED"
            ? "Cancelada"
            : "Estornada";
  const color = obligation.isOverdue
    ? "bg-red-100 text-red-800"
    : obligation.status === "CANCELLED" || obligation.status === "REVERSED"
      ? "bg-slate-200 text-slate-700"
      : obligation.status === "SETTLED"
        ? "bg-emerald-100 text-emerald-800"
        : "bg-amber-100 text-amber-800";

  return <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${color}`}>{label}</span>;
}
