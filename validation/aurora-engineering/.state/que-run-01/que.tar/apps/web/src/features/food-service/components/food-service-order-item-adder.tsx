import {
  foodServiceModifierGroupListSchema,
  type FoodServiceModifierGroupView,
  type ProductView,
} from "@gestor/contracts";
import { useEffect, useState } from "react";

function formatCurrency(value: string) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    Number(value),
  );
}

export function FoodServiceOrderItemAdder({
  organizationId,
  products,
  resetKey,
}: {
  organizationId: string;
  products: readonly ProductView[];
  resetKey: number;
}) {
  const [productId, setProductId] = useState("");
  const [groups, setGroups] = useState<readonly FoodServiceModifierGroupView[]>([]);
  const [selectedOptionIds, setSelectedOptionIds] = useState<Record<string, readonly string[]>>({});
  const [notes, setNotes] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setProductId("");
    setGroups([]);
    setSelectedOptionIds({});
    setNotes("");
    setQuantity("1");
    setError(null);
  }, [resetKey]);

  useEffect(() => {
    if (!productId) {
      setGroups([]);
      setSelectedOptionIds({});
      setError(null);
      return;
    }
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    fetch(
      `/api/v1/organizations/${organizationId}/food-service-product-modifiers?productId=${encodeURIComponent(productId)}`,
      { signal: controller.signal },
    )
      .then(async (response) => {
        const payload = (await response.json()) as { data?: unknown; detail?: string };
        if (!response.ok) throw new Error(payload.detail ?? "Não foi possível carregar as escolhas.");
        const nextGroups = foodServiceModifierGroupListSchema.parse(payload.data);
        setGroups(nextGroups);
        setSelectedOptionIds({});
      })
      .catch((cause: unknown) => {
        if (cause instanceof DOMException && cause.name === "AbortError") return;
        setGroups([]);
        setError(cause instanceof Error ? cause.message : "Não foi possível carregar as escolhas.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [organizationId, productId]);

  function toggleOption(group: FoodServiceModifierGroupView, optionId: string) {
    setSelectedOptionIds((current) => {
      const selected = current[group.id] ?? [];
      if (group.maximumSelections === 1) return { ...current, [group.id]: [optionId] };
      if (selected.includes(optionId)) return { ...current, [group.id]: selected.filter((id) => id !== optionId) };
      if (selected.length >= group.maximumSelections) return current;
      return { ...current, [group.id]: [...selected, optionId] };
    });
  }

  function preventInvalidSelection(event: React.MouseEvent<HTMLButtonElement>) {
    const incomplete = groups.find(
      (group) => (selectedOptionIds[group.id] ?? []).length < group.minimumSelections,
    );
    if (!incomplete) return;
    event.preventDefault();
    setError(
      incomplete.minimumSelections === 1
        ? `Selecione uma opção em ${incomplete.name}.`
        : `Selecione ao menos ${incomplete.minimumSelections} opções em ${incomplete.name}.`,
    );
  }

  return (
    <div className="grid gap-2">
      <select
        className="h-11 rounded-xl border bg-white px-3 text-base sm:col-span-2"
        name="productId"
        onChange={(event) => {
          setProductId(event.target.value);
          setSelectedOptionIds({});
        }}
        required
        value={productId}
      >
        <option value="">Adicionar produto</option>
        {products.map((product) => (
          <option key={product.id} value={product.id}>
            {product.name} · {formatCurrency(product.defaultPrice)}
          </option>
        ))}
      </select>
      {loading ? <p className="text-sm text-slate-600">Carregando escolhas…</p> : null}
      {error ? <p className="text-sm text-red-700">{error}</p> : null}
      {groups.map((group) => (
        <fieldset className="rounded-xl border bg-white p-3" key={group.id}>
          <legend className="px-1 text-sm font-semibold text-slate-900">{group.name}</legend>
          <p className="mb-2 text-xs text-slate-600" id={`modifier-help-${group.id}`}>
            {group.minimumSelections === group.maximumSelections
              ? `Escolha ${group.minimumSelections}.`
              : `Escolha de ${group.minimumSelections} a ${group.maximumSelections}.`}
          </p>
          <p aria-live="polite" className="mb-2 text-xs font-medium text-slate-700">
            {`Selecionadas: ${(selectedOptionIds[group.id] ?? []).length} de ${group.maximumSelections}.`}
          </p>
          {(selectedOptionIds[group.id] ?? []).map((optionId) => (
            <input key={optionId} name="modifierOptionIds" type="hidden" value={optionId} />
          ))}
          <div className="grid gap-2">
            {group.options.map((option) => {
              const selected = (selectedOptionIds[group.id] ?? []).includes(option.id);
              const maximumReached = (selectedOptionIds[group.id] ?? []).length >= group.maximumSelections;
              return (
              <label
                className="flex min-h-11 items-center justify-between gap-3 rounded-lg border px-3 py-2 text-sm has-[:checked]:border-brand-700 has-[:checked]:bg-brand-50"
                key={option.id}
              >
                <span className="flex items-center gap-2">
                  <input
                    aria-describedby={`modifier-help-${group.id}`}
                    checked={selected}
                    disabled={!selected && group.maximumSelections > 1 && maximumReached}
                    name={`modifier-selection-${group.id}`}
                    onChange={() => toggleOption(group, option.id)}
                    type={group.maximumSelections === 1 ? "radio" : "checkbox"}
                    value={option.id}
                  />
                  <span>{option.name}</span>
                </span>
                {Number(option.priceDelta) !== 0 ? (
                  <span className="whitespace-nowrap text-slate-600">
                    {Number(option.priceDelta) > 0 ? "+" : ""}
                    {formatCurrency(option.priceDelta)}
                  </span>
                ) : null}
              </label>
              );
            })}
          </div>
        </fieldset>
      ))}
      <textarea
        aria-label="Observação para a cozinha"
        className="min-h-20 rounded-xl border px-3 py-2 text-sm"
        maxLength={500}
        name="notes"
        onChange={(event) => setNotes(event.target.value)}
        placeholder="Observação para a cozinha (opcional)"
        value={notes}
      />
      <div className="flex gap-2">
        <input
          aria-label="Quantidade"
          className="h-11 w-24 rounded-xl border px-3 text-base"
          min="0.0001"
          name="quantity"
          onChange={(event) => setQuantity(event.target.value)}
          step="0.0001"
          type="number"
          value={quantity}
        />
        <button className="min-h-11 flex-1 rounded-xl bg-brand-700 px-4 text-base font-semibold text-white" onClick={preventInvalidSelection} type="submit">
          Adicionar ao pedido
        </button>
      </div>
    </div>
  );
}
