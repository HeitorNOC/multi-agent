"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createServiceBodySchema,
  serviceViewSchema,
  type CreateServiceBody,
  type ServiceView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { CatalogSection, ErrorText, Field, ItemList } from "./catalog-layout";
import { active, money, patch, post, setProblem, toggle } from "./catalog-helpers";
import type { CatalogSectionProps } from "./catalog-types";
import { NfseOperationIndicatorSelect } from "./nfse-operation-indicator-select";
import {
  nullableServiceValue as nullable,
  serviceDefaults as defaults,
} from "./service-form-values";

export function ServiceSection({
  organizationId,
  setFeedback,
  setState,
  state,
}: CatalogSectionProps) {
  const [editing, setEditing] = useState<ServiceView | null>(null);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateServiceBody>({
    defaultValues: defaults,
    resolver: zodResolver(createServiceBodySchema),
  });
  const nationalNfse = useWatch({ control, name: "nationalNfse" });
  const submit = handleSubmit(async (values) => {
    const response = editing
      ? await patch(`/api/v1/organizations/${organizationId}/services/${editing.id}`, {
          ...values,
          expectedUpdatedAt: editing.updatedAt,
        })
      : await post(`/api/v1/organizations/${organizationId}/services`, values);
    if (!response.ok) return setProblem(response, setError);
    const service = serviceViewSchema.parse(((await response.json()) as { data: unknown }).data);
    setState((current) =>
      current
        ? {
            ...current,
            services: editing
              ? current.services.map((item) => (item.id === service.id ? service : item))
              : [...current.services, service],
          }
        : current,
    );
    setEditing(null);
    reset(defaults);
    setFeedback(editing ? "Serviço atualizado." : "Serviço cadastrado.");
  });
  function beginEditing(service: ServiceView) {
    setEditing(service);
    reset({
      categoryId: service.categoryId,
      code: service.code,
      defaultPrice: service.defaultPrice,
      description: service.description ?? "",
      durationMinutes: service.durationMinutes,
      name: service.name,
      nationalNfse: service.nationalNfse,
      professionalUserIds: [...service.professionalUserIds],
    });
  }
  return (
    <CatalogSection
      title="Serviços"
      description="Profissionais habilitados serão vinculados na gestão de equipe e agenda."
    >
      <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" onSubmit={submit}>
        <Field error={errors.name?.message} id="service-name" label="Nome">
          <Input id="service-name" {...register("name")} />
        </Field>
        <Field error={errors.code?.message} id="service-code" label="Código">
          <Input id="service-code" {...register("code")} />
        </Field>
        <Field error={errors.defaultPrice?.message} id="service-price" label="Preço padrão">
          <Input id="service-price" inputMode="decimal" {...register("defaultPrice")} />
        </Field>
        <Field
          error={errors.durationMinutes?.message}
          id="service-duration"
          label="Duração (minutos)"
        >
          <Input
            id="service-duration"
            type="number"
            {...register("durationMinutes", { valueAsNumber: true })}
          />
        </Field>
        <Field id="service-category" label="Categoria">
          <select
            className="h-10 rounded-xl border bg-white px-3 text-sm"
            id="service-category"
            {...register("categoryId", { setValueAs: (value) => value || null })}
          >
            <option value="">Sem categoria</option>
            {state.categories.filter(active).map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </Field>
        <Field error={errors.description?.message} id="service-description" label="Descrição">
          <textarea
            className="min-h-20 rounded-xl border px-3 py-2 text-sm"
            id="service-description"
            {...register("description")}
          />
        </Field>
        <label className="flex items-center gap-2 self-end pb-3 text-sm font-medium">
          <input
            checked={Boolean(nationalNfse)}
            onChange={(event) =>
              setValue(
                "nationalNfse",
                event.target.checked
                  ? {
                      issRate: null,
                      ibsCbs: null,
                      issTaxation: "1",
                      issWithholding: "1",
                      municipalTaxCode: null,
                      nationalTaxCode: "",
                      nbsCode: null,
                      serviceLocationCityCode: "",
                    }
                  : null,
                { shouldValidate: true },
              )
            }
            type="checkbox"
          />
          Habilitar NFS-e Nacional
        </label>
        {nationalNfse ? (
          <>
            <Field
              error={errors.nationalNfse?.nationalTaxCode?.message}
              id="service-national-tax-code"
              label="Código de tributação nacional"
            >
              <Input
                id="service-national-tax-code"
                inputMode="numeric"
                maxLength={6}
                {...register("nationalNfse.nationalTaxCode")}
              />
            </Field>
            <Field
              error={errors.nationalNfse?.municipalTaxCode?.message}
              id="service-municipal-tax-code"
              label="Código municipal (opcional)"
            >
              <Input
                id="service-municipal-tax-code"
                {...register("nationalNfse.municipalTaxCode", { setValueAs: nullable })}
              />
            </Field>
            <Field
              error={errors.nationalNfse?.nbsCode?.message}
              id="service-nbs-code"
              label="Código NBS (opcional)"
            >
              <Input
                id="service-nbs-code"
                inputMode="numeric"
                maxLength={9}
                {...register("nationalNfse.nbsCode", { setValueAs: nullable })}
              />
            </Field>
            <Field
              error={errors.nationalNfse?.serviceLocationCityCode?.message}
              id="service-location-code"
              label="Município da prestação (IBGE)"
            >
              <Input
                id="service-location-code"
                inputMode="numeric"
                maxLength={7}
                {...register("nationalNfse.serviceLocationCityCode")}
              />
            </Field>
            <Field id="service-iss-taxation" label="Tributação do ISSQN">
              <select
                className="h-10 rounded-xl border bg-white px-3 text-sm"
                id="service-iss-taxation"
                {...register("nationalNfse.issTaxation")}
              >
                <option value="1">Operação tributável</option>
                <option value="2">Imunidade</option>
                <option value="3">Exportação de serviço</option>
                <option value="4">Não incidência</option>
              </select>
            </Field>
            <Field id="service-iss-withholding" label="Retenção do ISSQN">
              <select
                className="h-10 rounded-xl border bg-white px-3 text-sm"
                id="service-iss-withholding"
                {...register("nationalNfse.issWithholding")}
              >
                <option value="1">Não retido</option>
                <option value="2">Retido pelo tomador</option>
                <option value="3">Retido pelo intermediário</option>
              </select>
            </Field>
            <Field
              error={errors.nationalNfse?.issRate?.message}
              id="service-iss-rate"
              label="Alíquota ISS (%) se exigida"
            >
              <Input
                id="service-iss-rate"
                inputMode="decimal"
                placeholder="2.00"
                {...register("nationalNfse.issRate", { setValueAs: nullable })}
              />
            </Field>
            <label className="flex items-center gap-2 self-end pb-3 text-sm font-medium">
              <input
                checked={Boolean(nationalNfse.ibsCbs)}
                onChange={(event) =>
                  setValue(
                    "nationalNfse.ibsCbs",
                    event.target.checked
                      ? {
                          operationIndicator: "",
                          taxClassification: "",
                          taxSituation: "",
                        }
                      : null,
                    { shouldValidate: true },
                  )
                }
                type="checkbox"
              />
              Informar IBS/CBS
            </label>
            {nationalNfse.ibsCbs ? (
              <>
                <Field
                  error={errors.nationalNfse?.ibsCbs?.operationIndicator?.message}
                  id="service-ibs-cbs-operation"
                  label="Tipo e local da operação IBS/CBS"
                >
                  <NfseOperationIndicatorSelect
                    registration={register("nationalNfse.ibsCbs.operationIndicator")}
                  />
                </Field>
                <Field
                  error={errors.nationalNfse?.ibsCbs?.taxSituation?.message}
                  id="service-ibs-cbs-cst"
                  label="CST IBS/CBS"
                >
                  <Input
                    id="service-ibs-cbs-cst"
                    inputMode="numeric"
                    maxLength={3}
                    {...register("nationalNfse.ibsCbs.taxSituation")}
                  />
                </Field>
                <Field
                  error={errors.nationalNfse?.ibsCbs?.taxClassification?.message}
                  id="service-ibs-cbs-classification"
                  label="Classificação tributária IBS/CBS"
                >
                  <Input
                    id="service-ibs-cbs-classification"
                    inputMode="numeric"
                    maxLength={6}
                    {...register("nationalNfse.ibsCbs.taxClassification")}
                  />
                </Field>
              </>
            ) : null}
          </>
        ) : null}
        <div className="self-end">
          <div className="flex gap-2">
            <Button disabled={isSubmitting} type="submit">
              {editing ? "Salvar serviço" : "Cadastrar serviço"}
            </Button>
            {editing ? (
              <Button
                onClick={() => {
                  setEditing(null);
                  reset(defaults);
                }}
                type="button"
                variant="outline"
              >
                Cancelar
              </Button>
            ) : null}
          </div>
        </div>
        {errors.root ? <ErrorText>{errors.root.message}</ErrorText> : null}
      </form>
      <ItemList
        items={state.services}
        onEdit={beginEditing}
        onToggle={(service) =>
          void toggle(
            "services",
            service,
            organizationId,
            serviceViewSchema,
            (updated) =>
              setState((current) =>
                current
                  ? {
                      ...current,
                      services: current.services.map((item) =>
                        item.id === updated.id ? updated : item,
                      ),
                    }
                  : current,
              ),
            setFeedback,
          )
        }
        secondary={(service) =>
          `${service.code} · ${service.durationMinutes} min · R$ ${money(service.defaultPrice)}`
        }
        priceHistory={{ organizationId, segment: "services" }}
        files={{ allowImage: false, organizationId, segment: "services" }}
      />
    </CatalogSection>
  );
}
