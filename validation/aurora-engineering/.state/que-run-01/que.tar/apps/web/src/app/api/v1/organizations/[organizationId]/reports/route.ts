import {
  organizationParamsSchema,
  reportListQuerySchema,
  requestReportBodySchema,
} from "@gestor/contracts";

import {
  authenticateApiRequest,
  handleApiRequest,
  readJsonBody,
  requireIdempotencyKey,
} from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ organizationId: string }> };

export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = organizationParamsSchema.parse(await route.params);
    const query = reportListQuerySchema.parse(
      Object.fromEntries(new URL(request.url).searchParams.entries()),
    );
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      correlationId: api.correlationId,
      organizationId: params.organizationId,
      requestId: api.requestId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.listReports.execute(
        { ...query, organizationId: params.organizationId },
        actor,
      ),
    });
  });
}

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const params = organizationParamsSchema.parse(await route.params);
      const body = requestReportBodySchema.parse(await readJsonBody(request));
      const identity = await authenticateApiRequest(request);
      const actor = await services.resolveTenantActor.execute({
        correlationId: api.correlationId,
        organizationId: params.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });
      const report = await services.requestReport.execute(
        {
          ...body,
          idempotencyKey: requireIdempotencyKey(request),
          organizationId: params.organizationId,
        },
        actor,
      );
      return Response.json(
        { data: report },
        {
          headers: {
            location: `/api/v1/organizations/${params.organizationId}/reports/${report.id}`,
          },
          status: 202,
        },
      );
    },
    { rateLimit: apiRateLimitPolicies.reportRequest },
  );
}
