import {
  financialObligationPageSchema,
  financialObligationViewSchema,
  type CreateFinancialObligationBody,
  type FinancialObligationView,
  type ProblemDetails,
} from "@gestor/contracts";

export async function createFinancialObligation(
  organizationId: string,
  values: CreateFinancialObligationBody,
  idempotencyKey: string,
) {
  const response = await fetch(`/api/v1/organizations/${organizationId}/financial-obligations`, {
    body: JSON.stringify(values),
    headers: { "content-type": "application/json", "idempotency-key": idempotencyKey },
    method: "POST",
  });

  if (!response.ok) {
    return { data: null, problem: (await response.json()) as ProblemDetails } as const;
  }

  const payload = (await response.json()) as { data: unknown };
  return { data: financialObligationViewSchema.parse(payload.data), problem: null } as const;
}

export async function cancelFinancialObligation(
  organizationId: string,
  obligation: FinancialObligationView,
  cancellation: { idempotencyKey: string; reason: string },
): Promise<FinancialObligationView> {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/financial-obligations/${obligation.id}/cancel`,
    {
      body: JSON.stringify({
        expectedVersion: obligation.version,
        kind: obligation.kind,
        reason: cancellation.reason,
      }),
      headers: {
        "content-type": "application/json",
        "idempotency-key": cancellation.idempotencyKey,
      },
      method: "POST",
    },
  );

  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }

  const payload = (await response.json()) as { data: unknown };
  return financialObligationViewSchema.parse(payload.data);
}

export async function reverseFinancialObligation(
  organizationId: string,
  obligation: FinancialObligationView,
  reversal: { idempotencyKey: string; reason: string },
): Promise<FinancialObligationView> {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/financial-obligations/${obligation.id}/reverse`,
    {
      body: JSON.stringify({
        expectedVersion: obligation.version,
        kind: obligation.kind,
        reason: reversal.reason,
      }),
      headers: {
        "content-type": "application/json",
        "idempotency-key": reversal.idempotencyKey,
      },
      method: "POST",
    },
  );
  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }
  const payload = (await response.json()) as { data: unknown };
  return financialObligationViewSchema.parse(payload.data);
}

export async function loadMoreFinancialObligations(
  organizationId: string,
  kind: FinancialObligationView["kind"],
  cursor: string,
) {
  const response = await fetch(
    `/api/v1/organizations/${organizationId}/financial-obligations?kind=${kind}&limit=100&cursor=${encodeURIComponent(cursor)}`,
  );
  if (!response.ok) {
    const problem = (await response.json()) as ProblemDetails;
    throw new Error(problem.detail);
  }
  return financialObligationPageSchema.parse(await response.json());
}
