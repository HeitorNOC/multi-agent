import { catalogFileParamsSchema } from "@gestor/contracts";
import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";

type RouteParameters = { params: Promise<{ fileId: string; organizationId: string }> };
export async function GET(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(request, async (api) => {
    const params = catalogFileParamsSchema.parse(await route.params);
    const identity = await authenticateApiRequest(request);
    const actor = await services.resolveTenantActor.execute({
      ...api,
      organizationId: params.organizationId,
      userId: identity.userId,
    });
    return Response.json({
      data: await services.createCatalogFileDownload.execute(params, actor),
    });
  });
}
