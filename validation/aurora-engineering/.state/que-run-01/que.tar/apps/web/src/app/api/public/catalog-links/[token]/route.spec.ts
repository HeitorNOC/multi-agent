import { beforeEach, describe, expect, it, vi } from "vitest";

const { handleApiRequest, resolvePublicCatalogPortalLink } = vi.hoisted(() => ({
  handleApiRequest: vi.fn(),
  resolvePublicCatalogPortalLink: vi.fn(),
}));

vi.mock("@/lib/server/api-request", () => ({ handleApiRequest }));
vi.mock("@/lib/server/container", () => ({
  services: { resolvePublicCatalogPortalLink: { execute: resolvePublicCatalogPortalLink } },
}));
vi.mock("@/lib/server/rate-limit", () => ({
  apiRateLimitPolicies: { publicPortalLink: { namespace: "public.portal-link" } },
}));

import { GET } from "./route";

describe("GET /api/public/catalog-links/[token]", () => {
  beforeEach(() => {
    handleApiRequest.mockReset();
    resolvePublicCatalogPortalLink.mockReset();
  });

  it("declares only the link-availability check as public", async () => {
    handleApiRequest.mockImplementation(async (_request, handler) => handler());
    resolvePublicCatalogPortalLink.mockResolvedValue({
      commercialPolicy: {
        allowsDelivery: true,
        allowsPickup: false,
        catalogOpen: true,
        fulfillmentNotice: "Entregas em horário comercial.",
        minimumOrderAmount: 30,
      },
      id: "link-1",
    });

    const response = await GET(new Request("https://app.example.com/api/public/catalog-links/shared"), {
      params: Promise.resolve({ token: "shared" }),
    });

    expect(resolvePublicCatalogPortalLink).toHaveBeenCalledWith("shared");
    expect(handleApiRequest).toHaveBeenCalledWith(
      expect.any(Request),
      expect.any(Function),
      expect.objectContaining({ authentication: "PUBLIC", legalAcceptance: false }),
    );
    await expect(response.json()).resolves.toEqual({
      data: {
        available: true,
        commercialPolicy: {
          allowsDelivery: true,
          allowsPickup: false,
          catalogOpen: true,
          fulfillmentNotice: "Entregas em horário comercial.",
          minimumOrderAmount: 30,
        },
      },
    });
  });
});
