import { describe, expect, it } from "vitest";

import { canonicalMoney, formatBrl, formatSignedBrl, moneyEquals } from "./cash-register-money";

describe("cash register money", () => {
  it("canonicalizes equivalent user-entered amounts without floating point", () => {
    expect(canonicalMoney(" 10,5 ")).toBe("10.5000");
    expect(canonicalMoney("10.50009")).toBe("10.5000");
    expect(moneyEquals("10,5", "10.5000")).toBe(true);
    expect(moneyEquals("inválido", "0")).toBe(false);
  });

  it("formats regular and signed BRL values", () => {
    expect(formatBrl("1234.5")).toBe("R$ 1.234,50");
    expect(formatSignedBrl("-12.34")).toBe("-R$ 12,34");
    expect(formatSignedBrl("12.34")).toBe("R$ 12,34");
  });
});
