"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
  createFinancialAccountBodySchema,
  type BranchView,
  type CreateFinancialAccountBody,
  type CreatableFinancialAccountType,
  type FinancialAccountView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";
import { Input } from "@gestor/ui/components/input";
import { Label } from "@gestor/ui/components/label";
import { useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { FinancialAccountList } from "./financial-account-list";
import {
  createFinancialAccount,
  loadFinancialAccountConfiguration,
  toggleFinancialAccountStatus,
} from "./financial-account-api";

const accountTypeOptions: readonly [CreatableFinancialAccountType, string][] = [
  ["CASH", "Caixa físico"],
  ["BANK", "Conta bancária"],
];

type FinancialAccountConfigurationsProps = {
  organizationId: string;
};

export function FinancialAccountConfigurations({
  organizationId,
}: FinancialAccountConfigurationsProps) {
  const [accounts, setAccounts] = useState<readonly FinancialAccountView[] | null>(null);
  const [branches, setBranches] = useState<readonly BranchView[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busyAccount, setBusyAccount] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
  const [reloadVersion, setReloadVersion] = useState(0);
  const today = useMemo(() => new Date().toLocaleDateString("en-CA"), []);
  const {
    control,
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    reset,
    setError,
    setValue,
  } = useForm<CreateFinancialAccountBody>({
    defaultValues: {
      branchId: null,
      initialBalance: "0,00",
      initialBalanceDate: today,
      name: "",
      type: "CASH",
    },
    resolver: zodResolver(createFinancialAccountBodySchema),
  });
  const selectedType = useWatch({ control, name: "type" });
  const selectedBranchId = useWatch({ control, name: "branchId" });
  const activeBranches = useMemo(
    () => branches?.filter((branch) => branch.status === "ACTIVE") ?? [],
    [branches],
  );
  const branchNames = useMemo(
    () => new Map(branches?.map((branch) => [branch.id, branch.name]) ?? []),
    [branches],
  );

  useEffect(() => {
    if (selectedType === "CASH" && !selectedBranchId && activeBranches[0]) {
      setValue("branchId", activeBranches[0].id, { shouldValidate: true });
    }
  }, [activeBranches, selectedBranchId, selectedType, setValue]);

  useEffect(() => {
    const controller = new AbortController();

    async function loadConfiguration() {
      try {
        const configuration = await loadFinancialAccountConfiguration(
          organizationId,
          controller.signal,
        );
        setAccounts(configuration.accounts);
        setBranches(configuration.branches);
        setLoadError(null);
      } catch (error) {
        if (!controller.signal.aborted) {
          setLoadError(
            error instanceof Error
              ? error.message
              : "Não foi possível carregar as contas financeiras.",
          );
        }
      }
    }

    void loadConfiguration();

    return () => controller.abort();
  }, [organizationId, reloadVersion]);

  const submit = handleSubmit(async (values) => {
    setFeedback(null);

    try {
      const result = await createFinancialAccount(organizationId, values, idempotencyKey);
      if (result.problem) {
        setError("root", { message: result.problem.detail, type: result.problem.code });
        return;
      }
      const created = result.data;
      setAccounts((current) => (current ? [...current, created] : [created]));
      setIdempotencyKey(crypto.randomUUID());
      setFeedback("Conta criada e saldo inicial registrado como implantação.");
      reset({
        branchId: values.type === "CASH" ? values.branchId : null,
        initialBalance: "0,00",
        initialBalanceDate: today,
        name: "",
        type: values.type,
      });
    } catch {
      setError("root", {
        message: "Não foi possível conectar ao servidor. Tente novamente.",
        type: "network",
      });
    }
  });

  async function changeStatus(account: FinancialAccountView) {
    setBusyAccount(account.id);
    setFeedback(null);

    try {
      const { status: nextStatus, updated } = await toggleFinancialAccountStatus(
        organizationId,
        account,
      );
      setAccounts(
        (current) => current?.map((item) => (item.id === updated.id ? updated : item)) ?? [updated],
      );
      setFeedback(nextStatus === "ACTIVE" ? "Conta ativada." : "Conta desativada.");
    } catch (error) {
      setFeedback(
        error instanceof Error ? error.message : "Não foi possível alterar a conta financeira.",
      );
    } finally {
      setBusyAccount(null);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
      <section
        aria-labelledby="new-financial-account-title"
        className="h-fit rounded-3xl border bg-white p-6 shadow-[0_12px_40px_rgb(15_23_42/0.05)] sm:p-7"
      >
        <p className="text-brand-600 text-xs font-bold tracking-[0.14em] uppercase">Nova conta</p>
        <h2 className="mt-2 text-xl font-semibold text-slate-950" id="new-financial-account-title">
          Caixa ou banco
        </h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">
          Informe o saldo real na data de implantação. O sistema criará um movimento auditável, sem
          registrar venda, compra, recebimento ou pagamento.
        </p>

        <form className="mt-6 grid gap-5" noValidate onSubmit={submit}>
          <div className="grid gap-2">
            <Label htmlFor="financial-account-name">Nome da conta</Label>
            <Input
              aria-describedby={errors.name ? "financial-account-name-error" : undefined}
              aria-invalid={Boolean(errors.name)}
              id="financial-account-name"
              placeholder="Ex.: Caixa balcão ou Banco principal"
              {...register("name")}
            />
            {errors.name ? (
              <p className="text-sm text-red-700" id="financial-account-name-error" role="alert">
                {errors.name.message}
              </p>
            ) : null}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="financial-account-type">Tipo</Label>
            <select
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="financial-account-type"
              {...register("type")}
            >
              {accountTypeOptions.map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="financial-account-branch">
              {selectedType === "CASH" ? "Filial responsável" : "Filial"}
            </Label>
            <select
              aria-describedby={errors.branchId ? "financial-account-branch-error" : undefined}
              aria-invalid={Boolean(errors.branchId)}
              className="focus-visible:border-ring focus-visible:ring-ring/50 h-11 w-full rounded-xl border bg-white px-3 text-sm outline-none focus-visible:ring-3"
              id="financial-account-branch"
              {...register("branchId", {
                setValueAs: (value) => (value ? String(value) : null),
              })}
            >
              {selectedType === "BANK" ? (
                <option value="">Compartilhada entre filiais</option>
              ) : (
                <option value="">Selecione uma filial</option>
              )}
              {activeBranches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                  {branch.isHeadquarters ? " — Matriz" : ""}
                </option>
              ))}
            </select>
            {errors.branchId ? (
              <p className="text-sm text-red-700" id="financial-account-branch-error" role="alert">
                {errors.branchId.message}
              </p>
            ) : (
              <p className="text-xs leading-5 text-slate-500">
                Caixas pertencem a uma filial. Uma conta bancária pode ser compartilhada.
              </p>
            )}
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="financial-account-balance">Saldo inicial</Label>
              <Input
                aria-describedby={
                  errors.initialBalance ? "financial-account-balance-error" : undefined
                }
                aria-invalid={Boolean(errors.initialBalance)}
                id="financial-account-balance"
                inputMode="decimal"
                placeholder="0,00"
                {...register("initialBalance")}
              />
              {errors.initialBalance ? (
                <p
                  className="text-sm text-red-700"
                  id="financial-account-balance-error"
                  role="alert"
                >
                  {errors.initialBalance.message}
                </p>
              ) : null}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="financial-account-balance-date">Data do saldo</Label>
              <Input
                aria-describedby={
                  errors.initialBalanceDate ? "financial-account-balance-date-error" : undefined
                }
                aria-invalid={Boolean(errors.initialBalanceDate)}
                id="financial-account-balance-date"
                type="date"
                {...register("initialBalanceDate")}
              />
              {errors.initialBalanceDate ? (
                <p
                  className="text-sm text-red-700"
                  id="financial-account-balance-date-error"
                  role="alert"
                >
                  {errors.initialBalanceDate.message}
                </p>
              ) : null}
            </div>
          </div>

          {selectedType === "BANK" ? (
            <p className="rounded-xl bg-amber-50 px-4 py-3 text-xs leading-5 text-amber-900">
              Use valor negativo somente quando a conta bancária estiver devedora na data informada.
            </p>
          ) : null}

          {errors.root?.message ? (
            <div
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
              role="alert"
            >
              {errors.root.message}
            </div>
          ) : null}

          <Button disabled={isSubmitting || (selectedType === "CASH" && !branches)} type="submit">
            {isSubmitting ? "Registrando..." : "Criar conta e registrar saldo"}
          </Button>
        </form>
      </section>

      <FinancialAccountList
        accounts={accounts}
        branchesLoaded={Boolean(branches)}
        branchNames={branchNames}
        busyAccount={busyAccount}
        feedback={feedback}
        loadError={loadError}
        onChangeStatus={changeStatus}
        onRetry={() => {
          setLoadError(null);
          setReloadVersion((version) => version + 1);
        }}
      />
    </div>
  );
}
