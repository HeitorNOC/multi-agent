import { describe, expect, it } from "vitest";

import { remainingQuantity, statusLabel } from "./sale-format";

describe("sale presentation helpers", () => {
  it("calculates remaining quantities with four decimal places", () => {
    expect(remainingQuantity("3.5000", "1.2500")).toBe("2.2500");
    expect(remainingQuantity("1", "2")).toBe("0.0000");
    expect(remainingQuantity("2,5", "0.25")).toBe("2.2500");
  });

  it("maps every sale status", () => {
    expect(statusLabel("DRAFT")).toBe("Rascunho");
    expect(statusLabel("COMPLETED")).toBe("Concluída");
    expect(statusLabel("CANCELLED")).toBe("Cancelada");
    expect(statusLabel("PARTIALLY_RETURNED")).toBe("Parcialmente devolvida");
    expect(statusLabel("FULLY_RETURNED")).toBe("Devolvida");
  });
});
