import { authenticateApiRequest, handleApiRequest } from "@/lib/server/api-request";
import { services } from "@/lib/server/container";
import { apiRateLimitPolicies } from "@/lib/server/rate-limit";

type RouteParameters = { params: Promise<{ token: string }> };

export async function POST(request: Request, route: RouteParameters): Promise<Response> {
  return handleApiRequest(
    request,
    async (api) => {
      const { token } = await route.params;
      const identity = await authenticateApiRequest(request);
      const link = await services.resolvePublicCatalogPortalLink.execute(token);
      await services.ensureCustomerPortalMembership.execute({
        correlationId: api.correlationId,
        organizationId: link.organizationId,
        requestId: api.requestId,
        userId: identity.userId,
      });
      return Response.json({ data: { customerPortalReady: true } });
    },
    { rateLimit: apiRateLimitPolicies.publicPortalLink },
  );
}
