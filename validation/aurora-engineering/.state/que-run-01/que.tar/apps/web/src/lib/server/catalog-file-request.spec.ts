import { afterEach, describe, expect, it, vi } from "vitest";

import { MAX_CATALOG_FILE_BYTES } from "@gestor/catalog";

import { readCatalogFileUpload } from "./catalog-file-request";

afterEach(() => vi.restoreAllMocks());

describe("readCatalogFileUpload", () => {
  it("returns immutable upload metadata and bytes", async () => {
    const form = new FormData();
    form.set("file", new File(["conteúdo"], "manual.txt", { type: "text/plain" }));
    form.set("purpose", "PRODUCT_ATTACHMENT");
    const request = new Request("http://localhost/upload", { body: form, method: "POST" });

    const upload = await readCatalogFileUpload(request);

    expect(upload).toMatchObject({
      mimeType: "text/plain",
      originalName: "manual.txt",
      purpose: "PRODUCT_ATTACHMENT",
    });
    expect(new TextDecoder().decode(upload.bytes)).toBe("conteúdo");
  });

  it("rejects declared oversized payloads before parsing multipart data", async () => {
    const formData = vi.spyOn(Request.prototype, "formData");
    const request = new Request("http://localhost/upload", {
      headers: { "content-length": String(MAX_CATALOG_FILE_BYTES + 512 * 1024 + 1) },
      method: "POST",
    });

    await expect(readCatalogFileUpload(request)).rejects.toMatchObject({ code: "FILE_TOO_LARGE" });
    expect(formData).not.toHaveBeenCalled();
  });

  it("requires a file and a valid purpose", async () => {
    const missingFile = new FormData();
    missingFile.set("purpose", "PRODUCT_ATTACHMENT");
    await expect(
      readCatalogFileUpload(
        new Request("http://localhost/upload", { body: missingFile, method: "POST" }),
      ),
    ).rejects.toMatchObject({ code: "FILE_REQUIRED" });

    const invalidPurpose = new FormData();
    invalidPurpose.set("file", new File(["x"], "file.txt", { type: "text/plain" }));
    invalidPurpose.set("purpose", "UNKNOWN");
    await expect(
      readCatalogFileUpload(
        new Request("http://localhost/upload", { body: invalidPurpose, method: "POST" }),
      ),
    ).rejects.toThrow();
  });
});
