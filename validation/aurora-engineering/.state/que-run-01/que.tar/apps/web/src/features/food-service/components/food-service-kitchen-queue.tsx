import type {
  FoodServiceKitchenStationView,
  FoodServiceKitchenTicketView,
} from "@gestor/contracts";
import { Button } from "@gestor/ui/components/button";

function formatQuantity(value: string) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 4 }).format(Number(value));
}

function ticketStatusLabel(status: FoodServiceKitchenTicketView["status"]) {
  if (status === "QUEUED") return "Na fila";
  if (status === "IN_PREPARATION") return "Em preparo";
  return "Pronto";
}

export function FoodServiceKitchenQueue({
  branchId,
  cancellationReasons,
  onCancellationReasonChange,
  onStationFilterChange,
  onStatusFilterChange,
  onRefresh,
  onResolutionReasonChange,
  onResolveIngredients,
  onTransition,
  resolutionReasons,
  stationFilter,
  statusFilter,
  stations,
  tickets,
}: {
  branchId: string;
  cancellationReasons: Readonly<Record<string, string>>;
  onCancellationReasonChange: (ticketId: string, reason: string) => void;
  onStationFilterChange: (stationId: string) => void;
  onRefresh: () => void;
  onStatusFilterChange: (status: string) => void;
  onResolutionReasonChange: (ticketId: string, reason: string) => void;
  onResolveIngredients: (
    ticket: FoodServiceKitchenTicketView,
    resolution: "LOSS" | "RETURN_TO_STOCK",
  ) => void;
  resolutionReasons: Readonly<Record<string, string>>;
  onTransition: (
    ticket: FoodServiceKitchenTicketView,
    status: "IN_PREPARATION" | "READY" | "SERVED" | "CANCELLED",
  ) => void;
  stationFilter: string;
  statusFilter: string;
  stations: readonly FoodServiceKitchenStationView[];
  tickets: readonly FoodServiceKitchenTicketView[];
}) {
  const activeStations = stations.filter(
    (station) => station.branchId === branchId && station.status === "ACTIVE",
  );
  return (
    <section className="grid gap-4 rounded-xl border bg-slate-50 p-4">
      <div>
        <h2 className="font-semibold">Fila da cozinha</h2>
        <p className="mt-1 text-sm text-slate-600">
          Acompanhe cada item aceito, da fila até o serviço.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={onRefresh} type="button" variant="outline">
            Atualizar fila
          </Button>
          <select
            className="rounded-lg border bg-white px-3 py-2 text-sm"
            onChange={(event) => onStationFilterChange(event.target.value)}
            value={stationFilter}
          >
            <option value="">Todas as estações</option>
            {activeStations.map((station) => (
              <option key={station.id} value={station.id}>
                {station.name}
              </option>
            ))}
          </select>
          <select
            className="rounded-lg border bg-white px-3 py-2 text-sm"
            onChange={(event) => onStatusFilterChange(event.target.value)}
            value={statusFilter}
          >
            <option value="">Todos os status</option>
            <option value="QUEUED">Na fila</option>
            <option value="IN_PREPARATION">Em preparo</option>
            <option value="READY">Pronto</option>
          </select>
        </div>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {tickets.length === 0 ? (
          <p className="text-sm text-slate-600">Nenhum item aguardando preparo nesta seleção.</p>
        ) : (
          tickets.map((ticket) => (
            <article className="grid gap-3 rounded-xl border bg-white p-4" key={ticket.id}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{ticket.description}</p>
                  <p className="text-sm text-slate-600">
                    {formatQuantity(ticket.quantity)}{" "}
                    {Number(ticket.quantity) === 1 ? "unidade" : "unidades"} ·{" "}
                    {ticket.kitchenStationName}
                  </p>
                  {ticket.lastActionByName && ticket.lastActionAt ? (
                    <p className="mt-1 text-xs text-slate-500">
                      Última atualização por {ticket.lastActionByName} às{" "}
                      {new Intl.DateTimeFormat("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      }).format(new Date(ticket.lastActionAt))}
                    </p>
                  ) : null}
                </div>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                  {ticketStatusLabel(ticket.status)}
                </span>
              </div>
              {ticket.status === "QUEUED" ? (
                <Button onClick={() => onTransition(ticket, "IN_PREPARATION")} type="button">
                  Iniciar preparo
                </Button>
              ) : null}
              {ticket.status === "IN_PREPARATION" ? (
                <Button onClick={() => onTransition(ticket, "READY")} type="button">
                  Marcar como pronto
                </Button>
              ) : null}
              {ticket.status === "READY" ? (
                <Button onClick={() => onTransition(ticket, "SERVED")} type="button">
                  Confirmar servido
                </Button>
              ) : null}
              {ticket.ingredientResolutionRequired ? (
                <div className="grid gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">
                  <p className="font-medium text-amber-950">Insumos já foram baixados</p>
                  <p className="text-amber-900">
                    Antes de cancelar, registre a perda ou devolva os insumos ao estoque.
                  </p>
                  <input
                    className="rounded-lg border bg-white px-3 py-2"
                    maxLength={240}
                    onChange={(event) => onResolutionReasonChange(ticket.id, event.target.value)}
                    placeholder="Motivo da perda ou devolução"
                    value={resolutionReasons[ticket.id] ?? ""}
                  />
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => onResolveIngredients(ticket, "LOSS")}
                      type="button"
                      variant="outline"
                    >
                      Registrar perda
                    </Button>
                    <Button
                      onClick={() => onResolveIngredients(ticket, "RETURN_TO_STOCK")}
                      type="button"
                      variant="outline"
                    >
                      Devolver ao estoque
                    </Button>
                  </div>
                </div>
              ) : null}
              {["QUEUED", "IN_PREPARATION"].includes(ticket.status) ? (
                <div className="grid gap-2 border-t pt-3">
                  <label className="grid gap-1 text-sm font-medium text-slate-700">
                    Motivo do cancelamento
                    <input
                      className="rounded-lg border px-3 py-2 font-normal"
                      maxLength={240}
                      onChange={(event) =>
                        onCancellationReasonChange(ticket.id, event.target.value)
                      }
                      value={cancellationReasons[ticket.id] ?? ""}
                    />
                  </label>
                  <Button
                    onClick={() => onTransition(ticket, "CANCELLED")}
                    type="button"
                    variant="outline"
                  >
                    Cancelar item
                  </Button>
                </div>
              ) : null}
            </article>
          ))
        )}
      </div>
    </section>
  );
}
