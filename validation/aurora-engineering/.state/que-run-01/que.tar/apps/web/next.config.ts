import type { NextConfig } from "next";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { applicationSecurityHeaders } from "./src/lib/server/security-headers";

const workspaceRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

const nextConfig: NextConfig = {
  async headers() {
    return [{ headers: [...applicationSecurityHeaders], source: "/(.*)" }];
  },
  output: "standalone",
  outputFileTracingIncludes: {
    "/*": ["../../node_modules/.pnpm/@prisma+client@*/node_modules/.prisma/client/**/*"],
  },
  outputFileTracingRoot: workspaceRoot,
  poweredByHeader: false,
  serverExternalPackages: ["@prisma/client", "prisma"],
  transpilePackages: [
    "@gestor/auth",
    "@gestor/catalog",
    "@gestor/config",
    "@gestor/contracts",
    "@gestor/crm",
    "@gestor/database",
    "@gestor/dashboard",
    "@gestor/financial",
    "@gestor/identity",
    "@gestor/inventory",
    "@gestor/kernel",
    "@gestor/observability",
    "@gestor/organizations",
    "@gestor/purchases",
    "@gestor/sales",
    "@gestor/ui",
  ],
  turbopack: {
    root: workspaceRoot,
  },
};

export default nextConfig;
